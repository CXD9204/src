#!/bin/bash

. /home/oracle/.bash_profile
. /home/oracle/ruanct/awrrpt/util/util_datetime.sh
. /home/oracle/ruanct/awrrpt/util/util_function.sh

V_TODAY=`date +%Y%m%d`
V_AWR_PATH=/home/oracle/ruanct/awrrpt
V_AWR_DATE=`getDateAfter ${V_TODAY} -1`
V_TGT_YYMM=`expr substr ${V_AWR_DATE} 1 6`

mkdir -p ${V_AWR_PATH}/${V_TGT_YYMM}
cd ${V_AWR_PATH}/${V_TGT_YYMM}

DB_USR_NAME=r7
DB_USR_PSWD=1qaz!QAZ

DB_SRV_AKU="10.1.195.175/xtbg"
DB_SRV_SHK="10.110.25.135:11521/xtbg"

DB_ALIAS_AKU="xtbg_aku"
DB_ALIAS_SHK="xtbg_shk"

AWR_STA_TIME="`the_firstday_of_last_week`-0600"
AWR_END_TIME="`the_firstday_of_this_week`-0600"

genAwrRpti $DB_USR_NAME $DB_USR_PSWD $DB_SRV_AKU $DB_ALIAS_AKU $AWR_STA_TIME $AWR_END_TIME 1
genAwrRpti $DB_USR_NAME $DB_USR_PSWD $DB_SRV_AKU $DB_ALIAS_AKU $AWR_STA_TIME $AWR_END_TIME 2
genAwrGrpt $DB_USR_NAME $DB_USR_PSWD $DB_SRV_AKU $DB_ALIAS_AKU $AWR_STA_TIME $AWR_END_TIME

genAwrRpti $DB_USR_NAME $DB_USR_PSWD $DB_SRV_SHK $DB_ALIAS_SHK $AWR_STA_TIME $AWR_END_TIME 1
genAwrRpti $DB_USR_NAME $DB_USR_PSWD $DB_SRV_SHK $DB_ALIAS_SHK $AWR_STA_TIME $AWR_END_TIME 2
genAwrRpti $DB_USR_NAME $DB_USR_PSWD $DB_SRV_SHK $DB_ALIAS_SHK $AWR_STA_TIME $AWR_END_TIME 3
genAwrGrpt $DB_USR_NAME $DB_USR_PSWD $DB_SRV_SHK $DB_ALIAS_SHK $AWR_STA_TIME $AWR_END_TIME

tgz_file_name="${V_TGT_YYMM}_w`date +%W`_double.tar.gz"
tar -zcvf ${tgz_file_name} *.html
ftpPut "10.1.49.171" yirong "112233...." ${V_AWR_PATH}/${V_TGT_YYMM} "/02.各项目和个人目录/R阮春图/awrrpt" ${tgz_file_name}
rm -rf *.html ${tgz_file_name}

