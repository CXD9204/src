#!/bin/ksh

. ~/.profile
export NLS_LANG=american_america.ZHS16GBK

usage(){
    echo ""
    echo "usage: $0 <occur_times> <query_keywords> "
    echo ""
    echo "   1, occur_times: mandatory parameter, format: yyyymmdd-hh24mi, multi occur_times contact with comma"
    echo "   2, query_keywords: mandatory parameter, multi keywords contact with comma"
    echo ""
    echo " for example: $0 20161120-0830,20161120-1030 108286097,108286098"
    echo ""
}

if [ $# -eq 1 ]; then
  if [ "$1" == "-h" -o "$1" == "-H" ]; then
    usage;
    exit;
  fi
fi

if [ $# -ne 2 ]; then
 usage;
 exit;
fi

TIME_PARAM=$1
if [ "${TIME_PARAM}" == "" ]; then
echo "��������־ʱ�����Ϊ��"��
exit;
fi

WHERE_PARAM=$2
if [ "${WHERE_PARAM}" == "" ]; then
echo "��������ѯ��������Ϊ��"��
exit;
fi

TIME_PARAM_STR=`echo ${TIME_PARAM}   |awk '{ gsub(/,/," "); print $0; }'`
WHERE_PARAM_STR=`echo ${WHERE_PARAM} |awk '{ gsub(/,/," "); print $0; }'`

TOP_NUM_ARCH_FILE=6

SELECT_ARCH_SQL=xtbg_logmnr_select_arch.sql
SELECT_ARCH_LOG=xtbg_logmnr_select_arch.log

DATESTR=`date +"%F_%H%M%S"`
LOGMNR_EXECUTE_SQL=xtbg_logmnr_execute.sql
#LOGMNR_RESULTS_LOG=aash_xtbg_logmnr_${DATESTR}.log
LOGMNR_RESULTS_LOG=aash_xtbg_logmnr_${DATESTR}_$1.log

>${SELECT_ARCH_SQL}
>${SELECT_ARCH_LOG}

>${LOGMNR_EXECUTE_SQL}
>${LOGMNR_RESULTS_LOG}

echo "spool ${SELECT_ARCH_LOG}" >> ${SELECT_ARCH_SQL}
echo "set lines 280" >> ${SELECT_ARCH_SQL}
echo "set pages 100" >> ${SELECT_ARCH_SQL}
echo "col name for a70" >> ${SELECT_ARCH_SQL}
echo "col first_change# for a20" >> ${SELECT_ARCH_SQL}
echo "col next_change# for a20" >> ${SELECT_ARCH_SQL}
echo "" >> ${SELECT_ARCH_SQL}

echo "select thread#, sequence#, blocks, first_change#||'' as first_change# , next_change#||'' as  next_change#," >> ${SELECT_ARCH_SQL}
echo "       to_char(first_time,'yyyy-mm-dd hh24:mi:ss') as first_time, " >> ${SELECT_ARCH_SQL}
echo "       to_char(next_time,'yyyy-mm-dd hh24:mi:ss') as next_time, name" >> ${SELECT_ARCH_SQL}
echo "  from v\$archived_log" >> ${SELECT_ARCH_SQL}
i=1;
for VAR_TIME_PARAM in ${TIME_PARAM_STR}
do
  if [ $i -eq 1 ]; then
    echo " where to_date('${VAR_TIME_PARAM}', 'yyyymmdd-hh24mi') between first_time and next_time" >> ${SELECT_ARCH_SQL}
    i=2;
  else
    echo "    or to_date('${VAR_TIME_PARAM}', 'yyyymmdd-hh24mi') between first_time and next_time" >> ${SELECT_ARCH_SQL}
  fi
done
echo "order by thread#, sequence#;" >> ${SELECT_ARCH_SQL}
echo "" >> ${SELECT_ARCH_SQL}

echo "spool off" >> ${SELECT_ARCH_SQL}
echo "exit" >> ${SELECT_ARCH_SQL}



sqlplus / as sysdba @${SELECT_ARCH_SQL}

NUM_ARCH_FILE=`cat ${SELECT_ARCH_LOG} |grep "ARCH/xtbg"|awk '{print $10}'|wc -l`

if [ ${NUM_ARCH_FILE} -eq 0 ]; then
    echo "δ��ѯ��ƥ��鵵��־��`cat ${SELECT_ARCH_LOG}|egrep 'ERROR|ORA-'`"
    exit;
fi

if [ ${NUM_ARCH_FILE} -gt ${TOP_NUM_ARCH_FILE} ]; then
    echo "����ʱ�䷶Χƥ��Ĺ鵵��־������${TOP_NUM_ARCH_FILE}��"
    exit;
fi

>${LOGMNR_EXECUTE_SQL}
>${LOGMNR_RESULTS_LOG}

echo "spool ${LOGMNR_RESULTS_LOG} append" >> ${LOGMNR_EXECUTE_SQL}
echo "set lines 600" >> ${LOGMNR_EXECUTE_SQL}
echo "set pages 200" >> ${LOGMNR_EXECUTE_SQL}
echo "set trimspool on" >> ${LOGMNR_EXECUTE_SQL}
echo "col scn for a18" >> ${LOGMNR_EXECUTE_SQL}
echo "col seg_name for a40" >> ${LOGMNR_EXECUTE_SQL}
echo "col os_username for a16" >> ${LOGMNR_EXECUTE_SQL}
echo "col machine_name for a16" >> ${LOGMNR_EXECUTE_SQL}
echo "col session_info for a60" >> ${LOGMNR_EXECUTE_SQL}
echo "col operation for a16" >> ${LOGMNR_EXECUTE_SQL}
echo "col username for a16" >> ${LOGMNR_EXECUTE_SQL}
echo "col sql_redo for a128" >> ${LOGMNR_EXECUTE_SQL}
echo "col sql_undo for a128" >> ${LOGMNR_EXECUTE_SQL}
echo "" >> ${LOGMNR_EXECUTE_SQL}

echo "begin" >> ${LOGMNR_EXECUTE_SQL}
i=1;
for VAR_ARCH_FILE in `cat ${SELECT_ARCH_LOG} |grep ARCH/xtbg|awk '{print $10}'`
do
  if [ $i -eq 1 ]; then
    echo "  sys.dbms_logmnr.add_logfile(logfilename => '${VAR_ARCH_FILE}', options => sys.dbms_logmnr.new);"  >> ${LOGMNR_EXECUTE_SQL}
    i=2;
  else
    echo "  sys.dbms_logmnr.add_logfile(logfilename => '${VAR_ARCH_FILE}', options => sys.dbms_logmnr.addfile);"  >> ${LOGMNR_EXECUTE_SQL}
  fi
done
echo "  sys.dbms_logmnr.start_logmnr(options => sys.dbms_logmnr.dict_from_online_catalog);"  >> ${LOGMNR_EXECUTE_SQL}
echo "end;" >> ${LOGMNR_EXECUTE_SQL}
echo "/" >> ${LOGMNR_EXECUTE_SQL}
echo "" >> ${LOGMNR_EXECUTE_SQL}

echo "select scn||'' as scn, xid, to_char(timestamp,'yyyy-mm-dd hh24:mi:ss') as timestamp, username," >> ${LOGMNR_EXECUTE_SQL}
echo "       operation,row_id, seg_owner, seg_name, table_name," >> ${LOGMNR_EXECUTE_SQL}
echo "       os_username, machine_name, session_info, session#, serial#," >> ${LOGMNR_EXECUTE_SQL}
echo "       sql_redo, ' | 'as SPR, sql_undo" >> ${LOGMNR_EXECUTE_SQL}
echo "  from v\$logmnr_contents" >> ${LOGMNR_EXECUTE_SQL}
i=1;
for VAR_WHERE_PARAM in ${WHERE_PARAM_STR}
do
  if [ $i -eq 1 ]; then
    echo " where sql_redo like '%${VAR_WHERE_PARAM}%'" >> ${LOGMNR_EXECUTE_SQL}
    i=2;
  else
    echo "    or sql_redo like '%${VAR_WHERE_PARAM}%'" >> ${LOGMNR_EXECUTE_SQL}
  fi
done
echo " ;" >> ${LOGMNR_EXECUTE_SQL}
echo "" >> ${LOGMNR_EXECUTE_SQL}

echo "begin" >> ${LOGMNR_EXECUTE_SQL}
echo "  sys.dbms_logmnr.end_logmnr();" >> ${LOGMNR_EXECUTE_SQL}
echo "end;" >> ${LOGMNR_EXECUTE_SQL}
echo "/" >> ${LOGMNR_EXECUTE_SQL}
echo "" >> ${LOGMNR_EXECUTE_SQL}

echo "spool off" >> ${LOGMNR_EXECUTE_SQL}
echo "exit" >> ${LOGMNR_EXECUTE_SQL}



echo "#######################################################" >> ${LOGMNR_RESULTS_LOG}
echo "##" >> ${LOGMNR_RESULTS_LOG}
echo "## ��־�ھ��� ${DATESTR}" >> ${LOGMNR_RESULTS_LOG}
echo "##" >> ${LOGMNR_RESULTS_LOG}
echo "#######################################################" >> ${LOGMNR_RESULTS_LOG}

echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
echo "## Query ArchiveLog SQL" >> ${LOGMNR_RESULTS_LOG}
echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
cat ${SELECT_ARCH_SQL} >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}

echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
echo "## Query ArchiveLog RESULT" >> ${LOGMNR_RESULTS_LOG}
echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
cat ${SELECT_ARCH_LOG} >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}

echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
echo "## LOGMNR EXECUTE SQL" >> ${LOGMNR_RESULTS_LOG}
echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
cat ${LOGMNR_EXECUTE_SQL} >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}
echo "" >> ${LOGMNR_RESULTS_LOG}

echo "#########################################" >> ${LOGMNR_RESULTS_LOG}
echo "## LOGMNR EXECUTE RESULT" >> ${LOGMNR_RESULTS_LOG}
echo "#########################################" >> ${LOGMNR_RESULTS_LOG}


sqlplus / as sysdba @${LOGMNR_EXECUTE_SQL}

rm -rf ${SELECT_ARCH_SQL} ${SELECT_ARCH_LOG} ${LOGMNR_EXECUTE_SQL}

