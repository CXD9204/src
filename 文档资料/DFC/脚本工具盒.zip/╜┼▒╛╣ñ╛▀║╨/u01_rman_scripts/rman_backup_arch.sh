#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.2.0/db

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib:/usr/local/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib
export PATH=$ORACLE_HOME/OPatch:$ORACLE_HOME/bin:$PATH:$HOME/bin

export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"

BACKUP_PATH=/u01/rman/backup
#DATE=`date +%Y%m%d`
DATE=`date +"%Y%m%d_%H%M"`


rman log ${BACKUP_PATH}/logs/rman_backup.${ORACLE_SID}.arch.${DATE}.log <<EOF
connect target /;

run{
  allocate channel ch1 device type disk;
  allocate channel ch2 device type disk;
  crosscheck archivelog all;
  crosscheck backupset of archivelog all;
  backup as compressed backupset archivelog all format '${BACKUP_PATH}/data/arch_%d_%s_%p_%T' delete all input;
  backup current controlfile format '${BACKUP_PATH}/data/ctrl_%d_%s_%p_%T';
  delete noprompt expired archivelog all;
  delete noprompt expired backupset of archivelog all;
  release channel ch1;
  release channel ch2;
}

exit;
EOF


