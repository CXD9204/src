#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.2.0/db

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib:/usr/local/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib
export PATH=$ORACLE_HOME/OPatch:$ORACLE_HOME/bin:$PATH:$HOME/bin

export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"

BACKUP_PATH=/u01/rman/backup
#DATE=`date +%Y%m%d`
DATE=`date +"%Y%m%d_%H%M"`


# run{
#  allocate channel ch1 device type disk connect 'sys/ZdlXtbg2016@xtbg1';
#  allocate channel ch2 device type disk connect 'sys/ZdlXtbg2016@xtbg2';
#  backup as compressed backupset database format '${BACKUP_PATH}/data/full_data_%d_%s_%p_%T' include current controlfile format '${BACKUP_PATH}/data/full_ctrl_%d_%s_%p_%T' plus archivelog format '${BACKUP_PATH}/data/full_arch_%d_%s_%p_%T';
#  release channel ch1;
#  release channel ch2;
# }

rman log ${BACKUP_PATH}/logs/rman_backup.${ORACLE_SID}.full.${DATE}.log <<EOF

connect target /;

run{
allocate channel ch1 device type disk;
allocate channel ch2 device type disk;
backup as compressed backupset database include current controlfile format '${BACKUP_PATH}/data/DATA_FULLBAK_%d_%s_%p_%T' plus archivelog format '${BACKUP_PATH}/data/ARCH_FULLBAK_%d_%s_%p_%T';
release channel ch1;
release channel ch2;
}

exit;
EOF

