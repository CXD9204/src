#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.2.0/db

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib:/usr/local/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib
export PATH=$ORACLE_HOME/OPatch:$ORACLE_HOME/bin:$PATH:$HOME/bin

export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"

BACKUP_PATH=/u01/rman/backup
#DATE=`date +%Y%m%d`
DATE=`date +"%Y%m%d_%H%M"`

rman log ${BACKUP_PATH}/logs/rman_backup.${ORACLE_SID}.clean.${DATE}.log <<EOF
connect target /;

run{
  allocate channel ch1 device type disk;
  crosscheck archivelog all;
  crosscheck backup;
  crosscheck copy;
  delete noprompt expired archivelog all;
  delete noprompt expired backup;
  delete noprompt expired copy;
  delete noprompt obsolete;
  delete noprompt archivelog all completed before 'sysdate-7';
  release channel ch1;
}

exit;
EOF

