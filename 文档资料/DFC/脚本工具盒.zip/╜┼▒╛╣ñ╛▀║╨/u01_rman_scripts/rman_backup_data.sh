#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=$ORACLE_BASE/product/11.2.0/db

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib:/lib:/usr/lib:/usr/local/lib
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib
export PATH=$ORACLE_HOME/OPatch:$ORACLE_HOME/bin:$PATH:$HOME/bin

export NLS_LANG=AMERICAN_AMERICA.ZHS16GBK
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"

BACKUP_PATH=/u01/rman/backup
#DATE=`date +%Y%m%d`
DATE=`date +"%Y%m%d_%H%M"`
LEVEL=$@

if [ $# != 1 ]; then
echo "usage: rman_backup_data.sh n
where n is the rman backup level(Only 0,1 is permitted)."
exit 1
fi

if [ $@ -ne 0 -a $@ -ne 1 ]; then
echo "usage: rman_backup_data.sh n
where n is the rman backup level(Only 0,1 is permitted)."
exit 2
fi

if [[ ${LEVEL} = 0 ]]; then

rman log ${BACKUP_PATH}/logs/rman_backup.${ORACLE_SID}.level.${LEVEL}.${DATE}.log <<EOF
connect target /;

run{
  allocate channel ch1 device type disk;
  allocate channel ch2 device type disk;
  crosscheck backupset of archivelog all;
  backup as compressed backupset archivelog all format '${BACKUP_PATH}/data/arch_%d_%s_%p_%T' delete all input;
  delete noprompt expired backupset of archivelog all;
  release channel ch1;
  release channel ch2;
}

run{
  allocate channel ch3 device type disk;
  allocate channel ch4 device type disk;
  crosscheck backupset of database;
  crosscheck backupset of controlfile;
  crosscheck backupset of spfile;
  backup incremental level ${LEVEL} as compressed backupset database format '${BACKUP_PATH}/data/data_%d_%s_%p_%T_level_${LEVEL}';
  backup current controlfile format '${BACKUP_PATH}/data/ctrl_%d_%s_%p_%T_level_${LEVEL}';
  backup spfile format '${BACKUP_PATH}/data/spfl_%d_%s_%p_%T_level_${LEVEL}';
  delete noprompt expired backupset of database;
  delete noprompt expired backupset of controlfile;
  delete noprompt expired backupset of spfile;
  release channel ch3;
  release channel ch4;
}

exit;
EOF

else

rman log ${BACKUP_PATH}/logs/rman_backup.${ORACLE_SID}.level.${LEVEL}.${DATE}.log <<EOF

connect target /;
run{
  allocate channel ch1 device type disk;
  allocate channel ch2 device type disk;
  crosscheck backupset of archivelog all;
  backup as compressed backupset archivelog all format '${BACKUP_PATH}/data/arch_%d_%s_%p_%T' delete all input;
  delete noprompt expired backupset of archivelog all;
  release channel ch1;
  release channel ch2;
}

run{
  allocate channel ch3 device type disk;
  allocate channel ch4 device type disk;
  crosscheck backupset of database;
  crosscheck backupset of controlfile;
  crosscheck backupset of spfile;
  backup incremental level ${LEVEL} as compressed backupset database format '${BACKUP_PATH}/data/data_%d_%s_%p_%T_level_${LEVEL}';
  backup current controlfile format '${BACKUP_PATH}/data/ctrl_%d_%s_%p_%T_level_${LEVEL}';
  backup spfile format '${BACKUP_PATH}/data/spfl_%d_%s_%p_%T_level_${LEVEL}';
  delete noprompt expired backupset of database;
  delete noprompt expired backupset of controlfile;
  delete noprompt expired backupset of spfile;
  release channel ch3;
  release channel ch4;
}

exit;
EOF

fi

