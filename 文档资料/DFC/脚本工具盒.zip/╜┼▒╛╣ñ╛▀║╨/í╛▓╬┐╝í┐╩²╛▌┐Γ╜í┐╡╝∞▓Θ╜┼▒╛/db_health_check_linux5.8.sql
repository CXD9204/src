prompt +----------------------------------------------------------------------------+
prompt |                               Yallon King                                  |
prompt |                           oraking_job@163.com                              |
prompt |                            www.yallonking.com                              |
prompt |----------------------------------------------------------------------------|
prompt |                                                                            |
prompt |----------------------------------------------------------------------------|
prompt | DATABASE : Oracle                                                          |
prompt | FILE     : db_health_check.sql                                             |
prompt | PLATFORM : linux5.8                                                        |
prompt | DB TYPE  : Oracle 10g,11g                                                  |
prompt | PURPOSE  : Reports the database health check Infomation                    |
prompt +----------------------------------------------------------------------------+
prompt Please start the database to open state.
prompt This script must be run as sys user.
pause press enter to continue or ctrl-c to exit.;
prompt This process can take several minutes to complete.

set termout       off
set echo          off
set feedback      off
set verify        off
set heading       off
set wrap          on
set trimspool     on
set serveroutput  on
set escape        on
set pagesize 50000
set long     2000000000
set linesize 9999

undef seminar_logfile
alter session set nls_date_format = 'YYYY-mm-dd HH24:MI:SS';
alter system switch logfile;

col tempfile new_value tempfile

select
     instance_name||'_'||utl_inaddr.get_host_address||'_'||to_char(sysdate, 'YYYYMMDD_HH24MISS') tempfile
from v$instance;
def seminar_logfile=db_health_check_&tempfile..html

SPOOL /home/oracle/wyl/db_health_check.tmp
PRO <html>
PRO
PRO <head>
PRO <title>Database_Health_Check_Report.html</title>
PRO

PRO <style type="text/css">
PRO body {font:10pt Arial,Helvetica,Verdana,Geneva,sans-serif; color:black; background:white;}
PRO p {font:10pt Arial,Helvetica,sans-serif; color:black; background:White;}
PRO table,tr,td       {font:10pt Arial,Helvetica,sans-serif; color:Black; background:#FFFFCC; padding:0px 0px 0px 0px; margin:0px 0px 0px 0px;}
PRO a {font-weight:bold; color:#663300;}
PRO pre {font:8pt Monaco,"Courier New",Courier,monospace;} /* for code */
PRO h1 {font-size:13pt; font-weight:bold; color:#336699;}
PRO h2 {font-size:9pt; font-weight:bold; color:#336699;}
PRO h3 {font-size:7pt; font-weight:bold; color:#336699;}
PRO li {font-size:5pt; font-weight:bold; color:#336699; padding:0.1em 0 0 0;}
PRO th {font:bold 10pt Arial,Helvetica,sans-serif; color:White; background:#0066cc; padding:0px 0px 0px 0px;}
PRO body   'BGCOLOR="#C0C0C0"'
PRO table  'WIDTH="90%" BORDER="1"'
PRO </style>
PRO
PRO </head>
PRO <body>
PRO <font size=+3 color="#336699"><b>Database Health Check Report </b></font><hr>Copyright (c) 2014-2015 YallonKing. All rights reserved. (<a href="http://www.yallonking.com"  target="_blank">www.yallonking.com</a>)
PRO
PRO <br>
PRO <br>

PRO <br>
prompt <a name="t1"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Main Report</b></font><hr align="left" width="460">
PRO <ul>
PRO <li><font size="+0" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc1">Current Date		</b></font></a></li>
PRO <br>
PRO <li><font size="+0" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc2">OS Information	</b></font></a></li>
PRO <ul>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc201">OS Profile				</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc202">Memory Infomation		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc203">Disk Usage Infomation	</b></font></a></li>
--PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc204">OS Message Infomation	</b></font></a></li>
PRO </ul>
PRO <br>
PRO <li><font size="+0" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc3">Database Information	</b></font></a></li>
PRO <ul>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc301">Database Version		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc302">Database Base Info		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc303">Database Incarnation	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc304">DB Space Usage Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc318">User Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc305">Tablespace Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc306">Datafile Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc307">Controlfile Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc308">Redo Log Infomation		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc309">Invalidate Objects		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc310">DB Hit (Buffer Nowait|Buffer|Library|Soft Parse)</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc311">Top 5 Wait Event		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc312">Top 5 SQL(ordered by elapsed time)	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc313">Database Parameters	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc314">DB Alert Log Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc315">Recover File Info			</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc316">Corruption Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc317">Rman backup Information	</b></font></a></li>
PRO </ul>
PRO </ul>


PRO <br>
prompt <a name="tc1"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Current Date</b></font><hr align="left" width="460">
PRO
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>Current Date</th>
PRO </tr>
PRO
select '<tr>'||CHR(10)||'<td>'||to_char(sysdate, 'YYYY-mm-dd HH24:MI:SS') ||'</td>'||CHR(10)||'</tr>'||CHR(10) from dual;
PRO
PRO </table>
PRO


PRO <br>
prompt <a name="tc2"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>OS Information</b></font><hr align="left" width="460">
PRO <ul>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc201">OS Profile				</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc202">Memory Infomation		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc203">Disk Usage Infomation	</b></font></a></li>
PRO </ul>


PRO <br>
prompt <a name="tc201"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>OS Profile				</b></font></li>
PRO <table width="90%" border="1" >
PRO
spool off
set escape        off
host hostname |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >Host Name<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host ip=`/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d "addr:"`;echo $ip |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >IP<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host cat /etc/redhat-release |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >OS Version<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host uname -r |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >Kernel Version<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host getconf LONG_BIT |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >CPU Architecture<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host echo $(date -d "$(awk -F. '{print $1}' /proc/uptime) second ago" +"%Y-%m-%d %H:%M:%S";cat /proc/uptime| awk -F. '{run_days=$1 / 86400;run_hour=($1 % 86400)/3600;run_minute=($1 % 3600)/60;run_second=$1 % 60;printf("(uptime:%ddays %dhours %dminutes %dseconds)",run_days,run_hour,run_minute,run_second)}') |sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >OS Start Time<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host uptime|sed 's/^.*average://g'|awk 'BEGIN {FS=","} {print $1",",$2",",$3","}'|sed 's/$/&<\/td><\/tr>/g' |sed 's/^/<tr> <th align=\"left\" width=\"20%\" >Load Average<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host echo $(echo "physical cpu(s):";if [ `grep "physical id" /proc/cpuinfo|sort -u|wc -l` -eq 0 ]; then echo "1"; else grep "physical id" /proc/cpuinfo|sort -u|wc -l ;fi;grep "cpu cores" /proc/cpuinfo|uniq;grep "model name" /proc/cpuinfo|uniq)|sed 's/$/&<\/td><\/tr>/g'|sed 's/^/<tr> <th align=\"left\" width=\"20%\" >CPU Information<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
host top -Mn1 |grep Cpu|col -b |sed 's/Bm39;//g'|sed 's/49m//g' |sed 's/Bm//g'|sed 's/K//g' |awk -F: '{print $2}' |sed 's/$/&<\/td><\/tr>/g'|sed 's/^/<tr> <th align=\"left\" width=\"20%\" >CPU Load<\/th><td>&/g' >> /home/oracle/wyl/db_health_check.tmp
set escape        on
spool /home/oracle/wyl/db_health_check.tmp append
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc202"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Memory Infomation		</b></font></li>
PRO <table width="90%" border="1" >
PRO
spool off
set escape        off
host top -Mn1 |grep Mem|col -b|sed 's/Bm39;//g'|sed 's/49m//g' |sed 's/Bm//g'|sed 's/K//g'|tr -s ":" "\012"|tr -s "," "\012" |awk '{end=$NF;$NF="";print end" "$0}'|sed '1d'|awk -F" " '{print $1,$2}'|awk '{sub(" ","</th> <td>")}1' |sed 's/$/&<\/td><\/tr>/g' |sed s/[[:space:]]//g|sed 's/^/<tr> <th align=\"left\" width=\"20%\" >&/g' | sed 's/mK//' >> /home/oracle/wyl/db_health_check.tmp
host num1=`top -Mn1 |grep Mem|col -b|tr -s ":" "\012"|tr -s "," "\012" |awk '{end=$NF;$NF="";print end" "$0}'|sed '1d'|sed '2,4d'|sed 's/^.//'|awk -F" " '{print $1,$3}' | sed 's/mK//'|sed 's/M//' |awk -F" " '{print $2}'`;num2=`top -Mn1 |grep Mem|col -b|tr -s ":" "\012"|tr -s "," "\012" |awk '{end=$NF;$NF="";print end" "$0}'|sed '1,2d'|sed '2,4d'|sed 's/^.//'|awk -F" " '{print $1,$3}' | sed 's/mK//'|sed 's/M//' |awk -F" " '{print $2}'`;mem_usage=`awk 'BEGIN{printf "%.2f%\n",("'$num2'"/"'$num1'")*100}'`;if [ `echo $mem_usage |awk -F. '{print $1}'` -ge 85 ];then echo '<tr> <th align="left" width="20%" >Memory Usage%</th><td><b><font color="#990000">'$mem_usage'</font></b></td></tr>'; else echo '<tr> <th align="left" width="20%" >Memory Usage%</th><td><b><font color="#006400">'$mem_usage'</font></b></td></tr>';fi >> /home/oracle/wyl/db_health_check.tmp
set escape        on
spool /home/oracle/wyl/db_health_check.tmp append
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc203"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Disk Usage Infomation	</b></font></li>
PRO <table width="90%" border="1" >
PRO
PRO <tr>
PRO <th> Filesystem </th>
PRO <th> Size </th>
PRO <th> Used </th>
PRO <th> Avail </th>
PRO <th> Use% </th>
PRO <th> Mounted on </th>
PRO </tr>
spool off
set escape        off
--host df -Ph |awk -F" " '{print $1"</td><td>"$2"</td><td>"$3"</td><td>"$4"</td><td>"$5"</td><td>"$6"</td></tr>"}'|sed 's/^/<tr><td>&/g'|sed '1d' >> /home/oracle/wyl/db_health_check.tmp
host row_num=`df -Ph |sed '1d' |wc -l`;for ((a=1;a<=$row_num;a++)) ; do disk_usage=`df -Ph |sed '1d' |awk -F" " '{print $5}'|awk -F"%" '{print $1}'|awk -v b=$a 'NR==b{print}'`;l_a_str=`df -Ph |awk -F" " '{print $1"</td><td>"$2"</td><td>"$3"</td><td>"$4"</td><td>"}'|sed 's/^/<tr><td>&/g'|sed '1d'|awk -v b=$a 'NR==b{print}'`;r_a_str=`df -Ph |awk -F" " '{print "</td><td>"$6"</td></tr>"}'|sed '1d'|awk -v b=$a 'NR==b{print}'`;value_a_str=`if [ $disk_usage -ge 85 ];then echo '<b><font color="#990000">'$disk_usage'%</font></b>'; else echo '<b><font color="#006400">'$disk_usage'%</font></b>';fi`;echo $l_a_str$value_a_str$r_a_str;done >> /home/oracle/wyl/db_health_check.tmp
--row_num=`df -Ph |sed '1d' |wc -l`;
--for ((a=1;a<=$row_num;a++)) ; do 
--disk_usage=`df -Ph |sed '1d' |awk -F" " '{print $5}'|awk -F"%" '{print $1}'|awk -v b=$a 'NR==b{print}'`;
--l_a_str=`df -Ph |awk -F" " '{print $1"</td><td>"$2"</td><td>"$3"</td><td>"$4"</td><td>"}'|sed 's/^/<tr><td>&/g'|sed '1d'|awk -v b=$a 'NR==b{print}'`;
--r_a_str=`df -Ph |awk -F" " '{print "</td><td>"$6"</td></tr>"}'|sed '1d'|awk -v b=$a 'NR==b{print}'`;
--value_a_str=`if [ $disk_usage -ge 28 ];then echo '<b><font color="#990000">'$disk_usage'%</font></b>'; else echo '<b><font color="#006400">'$disk_usage'%</font></b>';fi`;
--echo $l_a_str$value_a_str$r_a_str;
--done
set escape        on
spool /home/oracle/wyl/db_health_check.tmp append
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

--PRO <br>
--prompt <a name="tc204"></a>
--PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>OS Message Infomation	</b></font></li>
--PRO <table width="90%" border="1" >
--PRO
--PRO <tr>
--PRO <th> OS Message Infomation(err|warning|crit|alert) </th>
--PRO </tr>
--spool off
--set escape        off
--PRO <tr>
--PRO <th><b><font color="#990000">
--host cat /var/log/messages|grep -E "err|warning|crit|alert"|grep -vE "mail|interrupt"
--PRO </font></b></th>
--PRO </tr>
--
--set escape        on
--spool /home/oracle/wyl/db_health_check.tmp append
--PRO
--PRO </table>
--PRO

PRO <br>
PRO <br>
prompt <a name="tc3"></a>
prompt <font size="+2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Information</b></font><hr align="left" width="460">
PRO <ul>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc301">Database Version		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc302">Database Base Info		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc303">Database Incarnation	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc304">DB Space Usage Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc318">User Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc305">Tablespace Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc306">Datafile Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc307">Controlfile Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc308">Redo Log Infomation		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc309">Invalidate Objects		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc310">DB Hit (Buffer Nowait|Buffer|Library|Soft Parse)</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc311">Top 5 Wait Event		</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc312">Top 5 SQL(ordered by elapsed time)	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc313">Database Parameters	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc314">DB Alert Log Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc315">Recover File Info			</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc316">Corruption Information	</b></font></a></li>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#tc317">Rman backup Information	</b></font></a></li>
PRO </ul>


PRO <br>
prompt <a name="tc301"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Version				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>VERSION</th>
PRO </tr>
PRO
select '<tr>'||CHR(10)||'<td>'||BANNER ||'</td>'||CHR(10)||'</tr>'||CHR(10) from v$version;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc302"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Base Info				</b></font></li>
PRO <table width="90%" border="1" >
PRO
select     '<tr> <th align="left" width="20%" > DBID</th> <td>'||to_char(dbid,'999999999999999')||'</td></tr>'||
           '<tr> <th align="left" width="20%" > NAME</th> <td>'||name||'</td>'||
           '<tr> <th align="left" width="20%" > CREATE_TIME </th> <td>' ||to_char(created, 'yyyy-mm-dd hh24:mi:ss')||'</td>'||
           '<tr> <th align="left" width="20%" > OPEN_MODE</th> <td>'||open_mode||'</td>'||
           '<tr> <th align="left" width="20%" > DATABASE_ROLE</th> <td>'||DATABASE_ROLE||'</td>'||
           '<tr> <th align="left" width="20%" > LOG_MODE</th> <td>'||DECODE(log_mode, 'NOARCHIVELOG','<div align="left"><b><font color="#990000"> NOARCHIVELOG </font></b></div>','<div align="left"><b><font color="#006400">' || log_mode || '</font></b></div>')||'</td>'||
           '<tr> <th align="left" width="20%" > CHECKPOINT_CHANGE</th> <td>'||to_char(checkpoint_change#, '999999999999999') ||'</td>'||
           '<tr> <th align="left" width="20%" > CONTROLFILE_TYPE</th> <td>' ||controlfile_type ||'</td>'||
           '<tr> <th align="left" width="20%" > CONTROLFILE_CREATED</th> <td>'||to_char(controlfile_created,'yyyy-mm-dd hh24:mi:ss')||'</td>'||
           '<tr> <th align="left" width="20%" > CONTROLFILE_CHANGE</th> <td>'||to_char(controlfile_change#, '999999999999999') ||'</td>'||
           '<tr> <th align="left" width="20%" > CONTROLFILE_CREATED_TIME</th> <td>'||to_char(controlfile_time, 'yyyy-mm-dd hh24:mi:ss')||'</td>'||
           '<tr> <th align="left" width="20%" > RESETLOGS_CHANGE</th> <td>'||to_char(resetlogs_change#, '999999999999999') ||'</td>'||
           '<tr> <th align="left" width="20%" > RESETLOGS_TIME</th> <td>'||to_char(resetlogs_time, 'yyyy-mm-dd hh24:mi:ss') ||'</td>'||
           '<tr> <th align="left" width="20%" > ARCHIVE_CHANGE</th> <td>'||to_char(ARCHIVE_CHANGE#, '999999999999999') ||'</td>'||
           '<tr> <th align="left" width="20%" > FLASHBACK_ON</th> <td>'||FLASHBACK_ON||'</td>'||
           '<tr> <th align="left" width="20%" > FORCE_LOGGING</th> <td>'||FORCE_LOGGING||'</td>'||
           '<tr> <th align="left" width="20%" > OPEN_RESETLOGS</th> <td>'||OPEN_RESETLOGS||'</td>'||
           '</tr>'
from v$database
union all
select     '<tr> <th align="left" width="20%" > INSTANCE_STARTUP_TIME</th> <td>'||STARTUP_TIME||'</td>'||
           '</tr>'
from v$instance;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc303"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Incarnation				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>INCARNATION</th>
PRO <th>RESETLOGS_CHANGE</th>
PRO <th>RESETLOGS_TIME</th>
PRO <th>PRIOR_RESETLOGS_CHANGE</th>
PRO <th>PRIOR_RESETLOGS_TIME</th>
PRO <th>STATUS</th>
PRO </tr>
PRO
select '<tr>'||CHR(10)||
       '<td>'||incarnation#||'</td>'||
       '<td>'||to_char(resetlogs_change#, '999999999999999')||'</td>'||
       '<td>'||to_char(resetlogs_time,'yyyy-mm-dd hh24:mi:ss')||'</td>'||
       '<td>'||to_char(prior_resetlogs_change#, '999999999999999')||'</td>'||
       '<td>'||nvl(to_char(prior_resetlogs_time,'yyyy-mm-dd hh24:mi:ss'),'NULL')||'</td>'||
       '<td><font color="#990000"><b>'||status||'</b></font></td>'||
       '</tr>'||CHR(10)
 from v$database_incarnation;
PRO
PRO </table>
PRO

PRO <br>
PRO <br>
prompt <a name="tc304"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB Space Usage Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>CHECK_TIME</th>
PRO <th>DATABASE_SIZE(Mb)</th>
PRO <th>DATABASE_USEDSIZE(Mb)</th>
PRO <th>DIFF(Mb)</th>
PRO <th>Usage(%)</th>
PRO </tr>
select 
'<tr>'||CHR(10)||
'<td>'||check_time||'</td>'||
'<td>'||tablespace_size_Mb||'</td>'||
'<td>'||tablespace_usedsize_Mb||'</td>'||
'<td>'||nvl(to_char(DIFF_MB),'NULL')||'</td>'||
'<td>'||CASE 
				WHEN (usage_per > 85 ) THEN '<div align="center"><b><font color="#990000">'||usage_per
				ELSE '<div align="center"><b><font color="#006400">'||usage_per||'</font></b></div>' END  ||'</td>' ||
'</tr>'||CHR(10)
from (
with tmp as 
(select min(rtime) rtime,
                       sum(tablespace_usedsize_Mb) tablespace_usedsize_Mb,
                       sum(tablespace_size_Mb) tablespace_size_Mb
                  from (select rtime,
                               e.tablespace_id,
                               (e.tablespace_usedsize) * (f.block_size) / 1024/1024 tablespace_usedsize_Mb,
                               (e.tablespace_size) * (f.block_size) / 1024/1024 tablespace_size_Mb
                          from dba_hist_tbspc_space_usage e,
                               dba_tablespaces            f,
                               v$tablespace               g
                         where e.tablespace_id = g.TS#
                           and f.tablespace_name = g.NAME)
                 group by rtime)
       select tmp.rtime check_time,
              tablespace_usedsize_Mb,
              tablespace_size_Mb,
              (tablespace_usedsize_Mb -LAG(tablespace_usedsize_Mb, 1, NULL) OVER(ORDER BY tmp.rtime)) AS DIFF_Mb,
			  ROUND((tablespace_usedsize_Mb/tablespace_size_Mb)*100,2) usage_per
         from tmp,
              (select min(rtime) rtime
                 from tmp
                group by substr(rtime, 1, 10)) t2 where t2.rtime = tmp.rtime);
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>


PRO <br>
PRO <br>
prompt <a name="tc318"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>User Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>USER_NAME</th>
PRO <th>ACCOUNT_STATUS</th>
PRO <th>DEFAULT_TBS</th>
PRO <th>TEMPORARY_TBS</th>
PRO <th>GRANTED_ROLE_NAME</th>
PRO </tr>
with role_name_tmp as (
select GRANTEE,GRANTED_ROLE_NAME
from (select GRANTEE,
GRANTED_ROLE_NAME,
row_number() over(partition by GRANTEE order by GRANTEE, curr_level desc) GRANTED_ROLE_NAME_rank
from (
select
GRANTEE,
GRANTED_ROLE,
rank,
level as curr_level,
ltrim(sys_connect_by_path(GRANTED_ROLE, ','), ',') GRANTED_ROLE_NAME
from (select GRANTEE,
GRANTED_ROLE,
row_number() over(partition by GRANTEE order by GRANTEE, GRANTED_ROLE) rank
from DBA_ROLE_PRIVS
order by GRANTEE, GRANTED_ROLE)
connect by GRANTEE = prior GRANTEE
and rank - 1 = prior rank
)) where GRANTED_ROLE_NAME_rank = 1)
select 
'<tr>'||CHR(10)||
'<td>'||username||'</td>'||
'<td>'||account_status||'</td>'||
'<td>'||default_tablespace||'</td>'||
'<td>'||temporary_tablespace||'</td>'||
'<td style="word-break:break-all">'||SUBSTR(GRANTED_ROLE_NAME,0,512) ||'</td>'||
'</tr>'||CHR(10)
from dba_users,role_name_tmp
where username=GRANTEE
order by account_status,created,username;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>


PRO <br>
PRO <br>
prompt <a name="tc305"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Tablespace Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>TABLESPACE_NAME</th>
PRO <th>SUM_SPACE(M)</th>
PRO <th>SUM_BLOCKS</th>
PRO <th>USED_SPACE(M)</th>
PRO <th>USED_RATE(%)</th>
PRO <th>FREE_SPACE(M)</th>
PRO </tr>
PRO
select '<tr>'||CHR(10)||
       '<td>'||TABLESPACE_NAME||'</td>'||
       '<td>'||SUM_SPACE_Mb||'</td>'||
       '<td>'||SUM_BLOCKS||'</td>'||
       '<td>'||nvl(to_char(USED_SPACE_Mb),'NULL')||'</td>'||
       '<td>'||CASE 
				WHEN (USED_RATE_percent > 85 ) THEN '<div align="center"><b><font color="#990000">'||USED_RATE_percent
				ELSE '<div align="center"><b><font color="#006400">'||USED_RATE_percent||'</font></b></div>' END  ||'</td>' ||
       '<td>'||nvl(to_char(FREE_SPACE_Mb),'NULL')||'</td>'||
       '<tr>'||CHR(10)
  from (SELECT D.TABLESPACE_NAME,
               SPACE SUM_SPACE_Mb,
               BLOCKS SUM_BLOCKS,
               SPACE - NVL(FREE_SPACE, 0) USED_SPACE_Mb,
               ROUND((1 - NVL(FREE_SPACE, 0) / SPACE) * 100, 2) USED_RATE_percent,
               FREE_SPACE FREE_SPACE_Mb
          FROM (SELECT TABLESPACE_NAME,
                       ROUND(SUM(BYTES) / (1024 * 1024), 2) SPACE,
                       SUM(BLOCKS) BLOCKS
                  FROM DBA_DATA_FILES
                 GROUP BY TABLESPACE_NAME) D,
               (SELECT TABLESPACE_NAME,
                       ROUND(SUM(BYTES) / (1024 * 1024), 2) FREE_SPACE
                  FROM DBA_FREE_SPACE
                 GROUP BY TABLESPACE_NAME) F
         WHERE D.TABLESPACE_NAME = F.TABLESPACE_NAME(+)
        UNION ALL
        SELECT D.TABLESPACE_NAME,
               SPACE SUM_SPACE_Mb,
               BLOCKS SUM_BLOCKS,
               USED_SPACE USED_SPACE_Mb,
               ROUND(NVL(USED_SPACE, 0) / SPACE * 100, 2) USED_RATE_percent,
               SPACE - USED_SPACE FREE_SPACE_Mb
          FROM (SELECT TABLESPACE_NAME,
                       ROUND(SUM(BYTES) / (1024 * 1024), 2) SPACE,
                       SUM(BLOCKS) BLOCKS
                  FROM DBA_TEMP_FILES
                 GROUP BY TABLESPACE_NAME) D,
               (SELECT TABLESPACE,
                       ROUND(SUM(BLOCKS * 8192) / (1024 * 1024), 2) USED_SPACE
                  FROM V$SORT_USAGE
                 GROUP BY TABLESPACE) F
         WHERE D.TABLESPACE_NAME = F.TABLESPACE(+)) t  order by USED_RATE_percent desc;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc306"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Datafile Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>TABLESPACE_NAME</th>
PRO <th>FILE_ID</th>
PRO <th>FILE_SIZE(Mb)</th>
PRO <th>STATUS</th>
PRO <th>AUTOEXTENSIBLE</th>
PRO <th>FILE_NAME</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||TABLESPACE_NAME||'</td>'||'<td>'||FILE_ID||'</td>'||
			'<td>'||BYTES/1024/1024||'</td>'||
			'<td>'||DECODE(STATUS, 'OFFLINE','<div align="center"><b><font color="#990000"> Offline </font></b></div>','<div align="center"><b><font color="#006400">'||STATUS|| '</font></b></div>')||'</td>'||
			'<td>'||DECODE(AUTOEXTENSIBLE, 'NO','<div align="center"><b><font color="#990000"> NO </font></b></div>','<div align="center"><b><font color="#006400">'||AUTOEXTENSIBLE|| '</font></b></div>')||'</td>'||
			'<td style="word-break:break-all">'||FILE_NAME ||'</td>'||
			'</tr>'||CHR(10)
     from dba_data_files order by FILE_ID;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc307"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Controlfile Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>NAME</th>
PRO <th>STATUS</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||NAME||'</td>'||
			'<td>'||DECODE(STATUS, NULL,'<div align="center"><b><font color="#006400">OK </font></b></div>','<div align="center"><b><font color="#990000"> Offline </font></b></div>'||STATUS|| '</font></b></div>')||'</td>'||
			'</tr>'||CHR(10)
     from v$controlfile;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc308"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Redo Log Infomation				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>THREAD#</th>
PRO <th>SEQUENCE#</th>
PRO <th>GROUP#</th>
PRO <th>FIRST_CHANGE#</th>
PRO <th>STATUS</th>
PRO <th>ARCGIVED</th>
PRO <th>MEMBER</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||thread#||'</td>'||
			'<td>'||a.sequence# ||'</td>'||
			'<td>'||a.group#||'</td>'||
			'<td>'||TO_CHAR (first_change#,'9999999999999999')||'</td>'||
			'<td>'||DECODE(a.STATUS, 'CURRENT','<div align="center"><b><font color="#006400">CURRENT </font></b></div>','INACTIVE','<div align="center"><b><font color="#006400">INACTIVE </font></b></div>','ACTIVE','<div align="center"><b><font color="#006400">ACTIVE </font></b></div>','<div align="center"><b><font color="#990000">'||a.STATUS||'</font></b></div>'||a.STATUS|| '</font></b></div>')||'</td>'||
			'<td>'||a.ARCHIVED||'</td>'||
			'<td style="word-break:break-all">'||MEMBER||'</td>'||
			'</tr>'||CHR(10)
	FROM v$log a, v$logfile b
		WHERE a.group# = B.GROUP#
	 ORDER BY a.sequence# DESC;  
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc309"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Invalidate Objects			</b></font></li>
PRO <br>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b>Invalidate objects	</b></font>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>OWNER</th>
PRO <th>OBJECT_NAME</th>
PRO <th>OBJECT_TYPE</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||owner||'</td>'||
			'<td><div align="center"><b><font color="#990000">'||object_name ||'</font></b></div></td>'||
			'<td>'||object_type||'</td>'||
			'</tr>'||CHR(10)
from dba_objects where status!='VALID' and owner!='SYS' and owner!='SYSTEM'; 
PRO
PRO </table>
PRO
PRO <br>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b>Invalidate Indexes	</b></font>
PRO <table width="90%" border="1">
PRO
select 		
			'<tr><th>OWNER</th>'||
			'<th>INDEXE_NAME</th>'||
			'<th>TABLE_NAME</th>'||	
			'<th>STATUS</th></tr>'				
			 from  dual
union all
select 		'<tr>'||CHR(10)||
			'<td>'||owner||'</td>'||
			'<td><div align="center"><b><font color="#990000">'||index_name ||'</font></b></div></td>'||
			'<td>'||table_name||'</td>'||
			'<td><div align="center"><b><font color="#990000">'||status ||'</font></b></div></td>'||			
			'</tr>'||CHR(10)
from dba_indexes where status<>'VALID' and owner not in ('SYS','SYSTEM','SYSMAN');
PRO
PRO </table>

PRO <br>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b>Invalidate Triggers	</b></font>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>OWNER</th>
PRO <th>TRIGGER NAME</th>
PRO <th>TABLE NAME</th>
PRO <th>STATUS</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||owner||'</td>'||
			'<td><div align="center"><b><font color="#990000">'||trigger_name ||'</font></b></div></td>'||
			'<td>'||table_name||'</td>'||
			'<td><div align="center"><b><font color="#990000">'||status ||'</font></b></div></td>'||			
			'</tr>'||CHR(10)
FROM dba_triggers WHERE status = 'DISABLED' and OWNER not in ('SYS','SYSTEM','EXFSYS','WMSYS');
PRO
PRO </table>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc310"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB Hit (Buffer Nowait|Buffer|Library|Soft Parse)</b></font></li>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#000000"><b>Report of database percent within the range of two latest default snapshots(1 hour).</b></font>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>Buffer Nowait%</th>
PRO <th>Buffer Hit%</th>
PRO <th>Library Hit%</th>
PRO <th>Soft Parse%</th>
PRO </tr>

set serveroutput on
declare
	L_DBID	number;
	L_INST_NUM	number;
	end_snap	number;
	buffer_nowait	number(5,2);
begin
	select d.dbid into L_DBID
	from v$database d,
		v$instance i;
	select i.instance_number into L_INST_NUM
	from v$database d,
		v$instance i;
	select max(snap_id) into end_snap from dba_hist_snapshot
	where INSTANCE_NUMBER=L_INST_NUM;
select round(100 *
             (1 - ((SELECT SUM(WAIT_COUNT)
                      FROM DBA_HIST_WAITSTAT
                     WHERE SNAP_ID =end_snap
                       AND DBID =L_DBID
                       AND INSTANCE_NUMBER =L_INST_NUM) -
             (SELECT SUM(WAIT_COUNT)
                      FROM DBA_HIST_WAITSTAT
                     WHERE SNAP_ID =end_snap-1
                       AND DBID =L_DBID
                       AND INSTANCE_NUMBER =L_INST_NUM)) /
             ((SELECT sum(value)
                      FROM DBA_HIST_SYSSTAT e
                     WHERE e.SNAP_ID =end_snap
                       AND e.DBID =L_DBID
                       AND e.INSTANCE_NUMBER =L_INST_NUM
                       AND e.STAT_NAME in ('session logical reads')) -
             (SELECT sum(value)
                      FROM DBA_HIST_SYSSTAT b
                     WHERE b.SNAP_ID =end_snap-1
                       AND b.DBID =L_DBID
                       AND b.INSTANCE_NUMBER =L_INST_NUM
                       AND b.STAT_NAME in ('session logical reads')))),
             2) into buffer_nowait
  from dual;
	if buffer_nowait > 95 
	then 
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="##006400">'||buffer_nowait||'</font></b></div></td>');
	else
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="#990000">'||buffer_nowait||'</font></b></div></td>');
	end if;
end;
/

set serveroutput on
declare
	L_DBID	number;
	L_INST_NUM	number;
	end_snap	number;
	buffer_hit	number(5,2);
begin
	select d.dbid into L_DBID
	from v$database d,
		v$instance i;
	select i.instance_number into L_INST_NUM
	from v$database d,
		v$instance i;
	select max(snap_id) into end_snap from dba_hist_snapshot
	where INSTANCE_NUMBER=L_INST_NUM;
	select round(100 *
				(1 -
				((SELECT sum(value)
					FROM DBA_HIST_SYSSTAT e
					WHERE e.SNAP_ID =end_snap
					AND e.DBID =L_DBID
					AND e.INSTANCE_NUMBER =L_INST_NUM
					AND e.STAT_NAME in ('physical reads')) -
				(SELECT sum(value)
					FROM DBA_HIST_SYSSTAT b
					WHERE b.SNAP_ID =end_snap-1
					AND b.DBID =L_DBID
					AND b.INSTANCE_NUMBER =L_INST_NUM
					AND b.STAT_NAME in ('physical reads')) -
				((SELECT sum(value)
					FROM DBA_HIST_SYSSTAT e
					WHERE e.SNAP_ID =end_snap
						AND e.DBID =L_DBID
						AND e.INSTANCE_NUMBER =L_INST_NUM
						AND e.STAT_NAME in ('physical reads direct')) -
				(SELECT sum(value)
					FROM DBA_HIST_SYSSTAT b
					WHERE b.SNAP_ID =end_snap-1
						AND b.DBID =L_DBID
						AND b.INSTANCE_NUMBER =L_INST_NUM
						AND b.STAT_NAME in ('physical reads direct'))) -
				nvl(((SELECT sum(value)
						FROM DBA_HIST_SYSSTAT e
						WHERE e.SNAP_ID =end_snap
							AND e.DBID =L_DBID
							AND e.INSTANCE_NUMBER =L_INST_NUM
							AND e.STAT_NAME in ('physical reads direct (lob)')) -
					(SELECT sum(value)
						FROM DBA_HIST_SYSSTAT b
						WHERE b.SNAP_ID =end_snap-1
							AND b.DBID =L_DBID
							AND b.INSTANCE_NUMBER =L_INST_NUM
							AND b.STAT_NAME in ('physical reads direct (lob)'))),
					0)) /
				((SELECT sum(value)
					FROM DBA_HIST_SYSSTAT e
					WHERE e.SNAP_ID =end_snap
					AND e.DBID =L_DBID
					AND e.INSTANCE_NUMBER =L_INST_NUM
					AND e.STAT_NAME in ('session logical reads')) -
				(SELECT sum(value)
					FROM DBA_HIST_SYSSTAT b
					WHERE b.SNAP_ID =end_snap-1
					AND b.DBID =L_DBID
					AND b.INSTANCE_NUMBER =L_INST_NUM
					AND b.STAT_NAME in ('session logical reads')))),
				2) into buffer_hit
	from dual;
	if buffer_hit > 95 
	then 
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="##006400">'||buffer_hit||'</font></b></div></td>');
	else
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="#990000">'||buffer_hit||'</font></b></div></td>');
	end if;
end;
/

set serveroutput on
declare
	L_DBID	number;
	L_INST_NUM	number;
	end_snap	number;
	lib_hit	number(5,2);
begin
	select d.dbid into L_DBID
	from v$database d,
		v$instance i;
	select i.instance_number into L_INST_NUM
	from v$database d,
		v$instance i;
	select max(snap_id) into end_snap from dba_hist_snapshot
	where INSTANCE_NUMBER=L_INST_NUM;
	SELECT round(100 * (SUM(e.PINHITS) - sum(b.pinhits)) /
             (SUM(e.PINS) - sum(b.pins)),
             2) into lib_hit
	FROM DBA_HIST_LIBRARYCACHE b, DBA_HIST_LIBRARYCACHE e
	WHERE e.SNAP_ID = end_SNAP
	AND e.DBID = L_DBID
	AND e.INSTANCE_NUMBER = L_INST_NUM
	and b.SNAP_ID = end_SNAP-1
	AND b.DBID = L_DBID
	AND b.INSTANCE_NUMBER = L_INST_NUM;
	if lib_hit > 95 
	then 
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="##006400">'||lib_hit||'</font></b></div></td>');
	else
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="#990000">'||lib_hit||'</font></b></div></td>');
	end if;
end;
/

set serveroutput on
declare
	L_DBID	number;
	L_INST_NUM	number;
	end_snap	number;
	soft_parse	number(5,2);
begin
	select d.dbid into L_DBID
	from v$database d,
		v$instance i;
	select i.instance_number into L_INST_NUM
	from v$database d,
		v$instance i;
	select max(snap_id) into end_snap from dba_hist_snapshot
	where INSTANCE_NUMBER=L_INST_NUM;
	select round(100 * (1 -
               ((SELECT sum(value)
                          FROM DBA_HIST_SYSSTAT e
                         WHERE e.SNAP_ID = end_snap
                           AND e.DBID = L_DBID
                           AND e.INSTANCE_NUMBER = L_INST_NUM
                           AND e.STAT_NAME = 'parse count (hard)') -
               (SELECT sum(value)
                          FROM DBA_HIST_SYSSTAT b
                         WHERE b.SNAP_ID = end_snap-1
                           AND b.DBID = L_DBID
                           AND b.INSTANCE_NUMBER = L_INST_NUM
                           AND b.STAT_NAME = 'parse count (hard)')) /
               ((SELECT sum(value)
                          FROM DBA_HIST_SYSSTAT e
                         WHERE e.SNAP_ID = end_snap
                           AND e.DBID = L_DBID
                           AND e.INSTANCE_NUMBER = L_INST_NUM
                           AND e.STAT_NAME = 'parse count (total)') -
               (SELECT sum(value)
                          FROM DBA_HIST_SYSSTAT b
                         WHERE b.SNAP_ID = end_snap-1
                           AND b.DBID = L_DBID
                           AND b.INSTANCE_NUMBER = L_INST_NUM
                           AND b.STAT_NAME = 'parse count (total)'))),
               2) into soft_parse
          from dual;
	if soft_parse > 95 
	then 
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="##006400">'||soft_parse||'</font></b></div></td>');
	else
	DBMS_OUTPUT.PUT_LINE('<td><div align="center"><b><font color="#990000">'||soft_parse||'</font></b></div></td>');
	end if;
end;
/

PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc311"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 5 Wait Event				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>EVENT NAME</th>
PRO <th>WAIT TIME</th>
PRO <th>SECONDS IN WAIT</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||event||'</td>'||
			'<td>'||WAIT_TIME||'</td>'||
			'<td>'||SECONDS_IN_WAIT||'</td>'||
			'</tr>'||CHR(10)
     from v$session_wait where event not like 'SQL%' and event not like 'rdbms%' and event not like '%idle wait%' order by WAIT_TIME desc,SECONDS_IN_WAIT desc;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc312"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Top 5 SQL(ordered by elapsed time)				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>EXECUTIONS</th>
PRO <th>SORTS</th>
PRO <th>COMMAND TYPE</th>
PRO <th>ELAPSED_TIME</th>
PRO <th>SQL_TEXT</th>
PRO </tr>
select 		'<tr>'||CHR(10)||
			'<td>'||EXECUTIONS||'</td>'||
			'<td>'||SORTS||'</td>'||
			'<td>'||COMMAND_TYPE||'</td>'||
			'<td>'||ELAPSED_TIME||'</td>'||
			'<td style="word-break:break-all">'||SQL_TEXT||'</td>'||			
			'</tr>'||CHR(10)
     FROM (SELECT
		EXECUTIONS,SORTS,COMMAND_TYPE,ELAPSED_TIME,
		SQL_TEXT FROM V$SQLAREA ORDER BY ELAPSED_TIME DESC) 
		WHERE ROWNUM<6;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc313"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Database Parameters(No-Default)			</b></font></li>
PRO <table width="90%" border="1">
PRO 
PRO <tr>
PRO <th>Parameter Name</th>
PRO <th>Instance Name</th>
PRO <th>Value</th>
PRO <th>Is Dynamic?</th>
PRO </tr>
PRO
SELECT  '<tr>'||CHR(10)||
        '<td>'||DECODE( p.isdefault,'FALSE','<b><font color="#336699">'||SUBSTR(p.name,0,512) || '</font></b>','<b><font color="#336699">'||SUBSTR(p.name,0,512)||'</font></b>' )||'</td>'||
        '<td>'||DECODE( p.isdefault,'FALSE','<font color="#990000"><b>' || i.instance_name || '</b></font>', i.instance_name )||'</td>'||
        '<td style="word-break:break-all">'||DECODE( p.isdefault,'FALSE','<font color="#990000"><b>' || p.value || '</b></font>', p.value )||'</td>'||
        '<td>'||DECODE( p.isdefault,'FALSE','<div align="right"><font color="#990000"><b>'|| p.issys_modifiable||'</b></font></div>','<div align="right">'|| p.issys_modifiable ||'</div>') ||'</td>'||'</tr>'||CHR(10)
FROM
    gv$parameter p
  , gv$instance  i
WHERE
    p.inst_id = i.inst_id
	and p.isdefault='FALSE'
ORDER BY
    p.name
  , i.instance_name;  
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc314"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>DB Alert Log Information			</b></font></li>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#000000"><b>List the error information in the latest 1000 rows of alert log.</b></font>
PRO <table width="90%" border="1" >
PRO
PRO <tr>
PRO <th> DB Alert Infomation(error|ORA-|ERROR|ora-) </th>
PRO </tr>
spool off
set escape        off
host alert_name=$(find / -iname alert_`env|grep ORACLE_SID|awk -F= '{print $2}'`.log -a -user oracle -a -mtime -1 2>/dev/null);row_num=$(tail -1000 $alert_name|grep -E "error|ORA-|ERROR|ora-" |wc -l);for ((a=1;a<=$row_num;a++)) ;do tail -1000 $alert_name|grep -E "error|ORA-|ERROR|ora-" | awk -v b=$a 'NR==b{print}'|sed 's/$/&<\/font><\/b><\/div<\/td><\/tr>/g'|sed 's/^/<tr><td style="word-break:break-all"><div align="left"><b><font color="#990000">&/g';done >> /home/oracle/wyl/db_health_check.tmp
set escape        on
spool /home/oracle/wyl/db_health_check.tmp append
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc315"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Recover File Info			</b></font></li>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b>Recovery File	</b></font>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>FILE</th>
PRO <th>ONLINE_STATUS</th>
PRO <th>Error</th>
PRO <th>SCN</th>
PRO <th>TIME</th>
PRO </tr>
select    '<tr>'||CHR(10)
				||'<td><div align="center"><b><font color="#990000">'||file#||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||online_status||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||error||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||to_char(change#,'9999999999999999')||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||To_char(time,'yyyy-mm-dd hh24:mi:ss')||'</font></b></div></td>'
				||'</tr>'||CHR(10)
from v$recover_file;
PRO
PRO </table>
PRO
PRO <br>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#663300"><b>Recovery Log	</b></font>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>THREAD</th>
PRO <th>SEQUENCE</th>
PRO <th>TIME</th>
PRO </tr>
select
				'<tr>'||CHR(10)
				||'<td><div align="center"><b><font color="#990000">'||THREAD#||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||to_char(SEQUENCE#,'99999999999')||'</font></b></div></td>'
				||'<td><div align="center"><b><font color="#990000">'||to_char(TIME,'yyyy-mm-dd hh24:mi:ss')||'</font></b></div></td>'
				||'</tr>'||CHR(10)
from v$recovery_log;
PRO
PRO </table>
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc316"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Corruption Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th> FILE </th>
PRO <th> BLOCK </th>
PRO <th> BLOCKS </th>
PRO <th> CORRUPTION_CHANGE </th>
PRO <th> CORRUPTION_TYPE </th>
PRO </tr>
select '<tr>'||CHR(10)||'</td>'
		||'<td><div align="center"><b><font color="#990000">'||FILE#||'</font></b></div></td>'
		||'<td><div align="center"><b><font color="#990000">'||BLOCK#||'</font></b></div></td>'
		||'<td><div align="center"><b><font color="#990000">'||BLOCKS||'</font></b></div></td>'
		||'<td><div align="center"><b><font color="#990000">'||to_char(CORRUPTION_CHANGE#,'9999999999999999999')||'</font></b></div></td>'
		||'<td><div align="center"><b><font color="#990000">'||CORRUPTION_TYPE||'</font></b></div></td>'
		||'</tr>'||CHR(10)
		from V$BACKUP_CORRUPTION;
PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>

PRO <br>
PRO <br>
prompt <a name="tc317"></a>
PRO <li><font size="-1" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b>Rman backup Information				</b></font></li>
PRO <table width="90%" border="1">
PRO
PRO <tr>
PRO <th>BACKUP SET</th>
PRO <th>SET_STAMP</th>
PRO <th>Type LV</th>
PRO <th>including CTL</th>
PRO <th>STATUS</th>
PRO <th>Device Type</th>
PRO <th>START_TIME</th>
PRO <th>COMPLETION_TIME</th>
PRO <th>ELAPSED_SECONDS</th>
PRO <th>TAG</th>
PRO <th>Path</th>
PRO </tr>
SELECT        '<tr>'||CHR(10)
					||'<td>'||A.RECID
					||'</td>'||'<td>'||A.SET_STAMP
					||'</td>'||'<td>'||DECODE (B.INCREMENTAL_LEVEL,'', DECODE (BACKUP_TYPE, 'L', 'Archivelog', 'Full'),1, 'Incr-1',0, 'Incr-0',B.INCREMENTAL_LEVEL)
					||'</td>'||'<td>'||B.CONTROLFILE_INCLUDED
					||'</td>'||'<td>'||DECODE (A.STATUS,'A', 'AVAILABLE','D', 'DELETED','X', 'EXPIRED','ERROR')
					||'</td>'||'<td>'||A.DEVICE_TYPE
					||'</td>'||'<td>'||A.START_TIME
					||'</td>'||'<td>'||A.COMPLETION_TIME
					||'</td>'||'<td>'||A.ELAPSED_SECONDS
					||'</td>'||'<td>'||A.TAG
					||'</td>'||'<td style="word-break:break-all">'||A.HANDLE
					||'</td>'||'</tr>'||CHR(10)
    FROM GV$BACKUP_PIECE A, GV$BACKUP_SET B
   WHERE A.SET_STAMP = B.SET_STAMP AND A.DELETED = 'NO'
ORDER BY A.COMPLETION_TIME DESC;

PRO
PRO </table>
PRO
PRO <font size="-2" face="Arial,Helvetica,Geneva,sans-serif" color="#336699"><b><a href="#t1">Back to Top	</b></font></a>


SELECT '<!-- '||TO_CHAR(SYSDATE, 'YYYY-MM-DD/HH24:MI:SS')||' -->' FROM dual;
PRO <hr size="3">
pro <div style="color:#00FF00">
pro <a href='http://www.yallonking.com'  target="_blank"><p align=right>Copyright@YallonKing</p></a>
pro </div>

PRO </body>
PRO </html>

SPO OFF;
set escape        off
host mv /home/oracle/wyl/db_health_check.tmp &seminar_logfile

SET TERMOUT ON
prompt
prompt Output written to: &seminar_logfile
exit;

