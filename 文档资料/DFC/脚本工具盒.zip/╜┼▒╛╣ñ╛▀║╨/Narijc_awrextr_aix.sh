#!/usr/bin/ksh

. /home/oracle/.profile
. /home/oracle/ruanct/awrrpt/util/util_datetime.sh
. /home/oracle/ruanct/awrrpt/util/util_function.sh

export NLS_LANG=american_america.ZHS16GBK
export NLS_DATE_FORMAT="YYYY-MM-DD HH24:MI:SS"
export LANG=en_US.UTF-8

V_TODAY=`date +%Y%m%d`
V_HOUR=`date +%H`
V_NUM_IN_WEEK=`date +%w`
V_DAYS_DURATION=2
if [ $V_NUM_IN_WEEK -eq 1 ]; then
 V_DAYS_DURATION=3;
fi
V_START_DATE=`getDateAfter $V_TODAY -$V_DAYS_DURATION`

V_START_TIME="${V_START_DATE}${V_HOUR}00"
V_END_TIME="${V_TODAY}${V_HOUR}00"

V_DUMP_DIR_NAME=dpdir
V_DUMP_DIR_PATH=/incremental_backup/xtbg/dpdir
V_AWR_PATH=/home/oracle/ruanct/awrrpt

cd ${V_DUMP_DIR_PATH}

DB_SRV_AKU="10.1.195.175/xtbg"
DB_ALIAS_AKU="xtbg_aku"
DB_USR_NAME=r7
DB_USR_PSWD=1qaz!QAZ
EXEC_SQL_AKU=tmpAwrAku1.sql
SQL_FILE=/home/oracle/ruanct/awrrpt/util/yirong_awrextr_bytime.sql

##
## @yirong_awrextr_bytime.sql <dmpfile_prefix> <directory_name> <snap_btime> <snap_etime>
##
## dmpfile name is <dmpfile_prefix>_<snap_btime>_<snap_etime>_<snap_bid>_<snap_eid>.dmp
##

> ${EXEC_SQL_AKU}
echo "@${SQL_FILE} ${DB_ALIAS_AKU} ${V_DUMP_DIR_NAME} ${V_START_TIME} ${V_END_TIME}" >> ${EXEC_SQL_AKU}
pubExecSQL_AS_SYSDBA ${EXEC_SQL_AKU}
tgz_file_name="${DB_ALIAS_AKU}_${V_START_TIME}_${V_END_TIME}_awrextr.tar"
tar -cvf ${tgz_file_name} ${DB_ALIAS_AKU}_${V_START_TIME}_${V_END_TIME}*
gzip -9 ${tgz_file_name}
ftpPut "10.1.49.171" yirong 112233.... ${V_DUMP_DIR_PATH} "/02.各项目和个人目录/R阮春图/awrextr" ${tgz_file_name}.gz
rm -rf ${DB_ALIAS_AKU}_${V_START_TIME}_${V_END_TIME}*.log ${DB_ALIAS_AKU}_${V_START_TIME}_${V_END_TIME}*.dmp
rm -rf $EXEC_SQL_AKU

