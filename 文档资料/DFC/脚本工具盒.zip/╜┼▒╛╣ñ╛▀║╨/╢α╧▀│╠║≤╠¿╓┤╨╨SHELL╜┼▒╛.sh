#!/bin/bash

export ORACLE_SID=xtbg3
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/db

export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib
export PATH=PATH=$ORACLE_HOME/bin:/usr/sbin:/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/sbin:/usr/lib64/qt-3.3/bin
export CLASSPATH=$ORACLE_HOME/JRE:$ORACLE_HOME/jlib:$ORACLE_HOME/rdbms/jlib

LOG=/home/oracle/beijing_test_insert.log
touch $LOG


echo "" | tee -a $LOG
echo "" | tee -a $LOG
echo "############################################################################" | tee -a $LOG
date +"%F %H:%M:%S" | tee -a $LOG
echo "############################################################################" | tee -a $LOG
echo "" | tee -a $LOG

date +"%F %H:%M:%S" | tee -a $LOG
echo "create start snapshot. doing" | tee -a $LOG

sqlplus / as sysdba << !
exec dbms_workload_repository.create_snapshot();
exit;
!

date +"%F %H:%M:%S" | tee -a $LOG
echo "successful create start snapshot" | tee -a $LOG


echo "" | tee -a $LOG
echo "" | tee -a $LOG


date +"%F %H:%M:%S" | tee -a $LOG
echo "MultiThread execute p_test_insert. doing" | tee -a $LOG

thread_num=$1
loop_count=$2

for (i = 0 ; i < $thread_num ; i ++ ); do 
 {
sqlplus oatest/testOA123@xtbg << !
select sysdate from dual;
exit;
!
sleep 1.2
 } & 
done
wait
date +"%F %H:%M:%S" | tee -a $LOG
echo "successful mult thread execute p_test_insert!" | tee -a $LOG
echo "thread num=$thread_num  loop_count=$loop_count !" | tee -a $LOG


echo "" | tee -a $LOG
echo "" | tee -a $LOG

date +"%F %H:%M:%S" | tee -a $LOG
echo "create end snapshot. doing" | tee -a $LOG

sqlplus / as sysdba << !
exec dbms_workload_repository.create_snapshot();
exit;
!

date +"%F %H:%M:%S" | tee -a $LOG
echo "successful create end snapshot!" | tee -a $LOG

