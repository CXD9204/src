##################################################################################
##
## function pubExecSQL_AS_SYSDBA
## param1: SQL_FILE
##
##################################################################################
pubExecSQL_AS_SYSDBA()
{
sqlplus / as sysdba << EOF
@$1
exit
EOF
}

##################################################################################
##
## function pubExecSQL
##
## param1: DB_USR_NAME
## param2: DB_USR_PSWD
## param3: DB_SRV_NAME
## param4: SQL_FILE
##
##################################################################################
pubExecSQL()
{
sqlplus $1/$2@$3 << EOF
@$4
exit
EOF
}

##################################################################################
##
## function genAwrRpti
##
## param1: DB_USR_NAME
## param2: DB_USR_PSWD
## param3: DB_SRV_NAME
## param4: DB_NAME_ALIAS
## param5: AWR_STA_TIME
## param6: AWR_END_TIME
## param7: INST_NUM
##
## genAwrRpti xxx yyyy 10.1.195.175/xtbg xtbg-aku 20170109-0900 20170109-0930 1
##
##################################################################################
genAwrRpti()
{
sqlplus $1/$2@$3 << EOF
@/home/oracle/ruanct/awrrpt/util/yirong_awrrpti_bytime.sql $4 $5 $6 $7
exit
EOF
}

##################################################################################
##
## function genAwrGrpt
##
## param1: DB_USR_NAME
## param2: DB_USR_PSWD
## param3: DB_SRV_NAME
## param4: DB_NAME_ALIAS
## param5: AWR_STA_TIME
## param6: AWR_END_TIME
##
## genAwrGrpt xxx yyyy 10.1.195.175/xtbg xtbg-aku 20170109-0900 20170109-0930
##
##################################################################################
genAwrGrpt()
{
sqlplus $1/$2@$3 << EOF
@/home/oracle/ruanct/awrrpt/util/yirong_awrgrpt_bytime.sql $4 $5 $6 
exit
EOF
}


##################################################################################
##
## function awrAutoMail
##
### PARAM 1 : 附件文档路径+名字
### PARAM 2 : 附件文档名字
### PARAM 3 : 主题
### PARAM 4 : 发送方### PARAM 5 : 抄送方 [可不写]
##
##################################################################################
awrAutoMail()
{
#echo "\$4 = $4"
#echo "\$5 = $5"
#echo "uuencode ${1} ${2}"
if [ -z "${5}" ]; then
  uuencode ${1} ${2}|mail -s "${3}" ${4} -- -f zhangjuncheng@sgitg.sgcc.com.cn -F ruanchuntu
else
  uuencode ${1} ${2}|mail -s "${3}" ${4} -c ${5} -- -f zhangjuncheng@sgitg.sgcc.com.cn -F ruanchuntu
fi
}

##################################################################################
##
## function ftpPut
## 
## PARAM 1 : target_ip_address
## PARAM 2 : access_username
## PARAM 3 : access_password
## PARAM 4 : source_directory_path
## PARAM 5 : target_directory_path
## PARAM 6 : target_filename 
##
##################################################################################
ftpPut()
{
ftp -nv $1 << EOF
user $2 $3
prompt inactive
lcd $4
cd $5
type binary
put $6
bye
EOF
}

##################################################################################
##
## function ftpGet
## 
## PARAM 1 : target_ip_address
## PARAM 2 : access_username
## PARAM 3 : access_password
## PARAM 4 : source_directory_path
## PARAM 5 : target_directory_path
## PARAM 6 : target_filename 
##
##################################################################################
ftpGet()
{
ftp -nv $1 << EOF
user $2 $3
prompt inactive
lcd $4
cd $5
cd awrrpt
type binary
get $6
bye
EOF
}

