prompt
prompt usage:
prompt
prompt @?/rdbms/admin/yirong_awrrpti_bytime.sql <report_prefix> <begin_time> <end_time> <instance_number>
prompt
prompt   report_prefix,   mandatory
prompt   begin_time,      mandatory, format: yyyymmdd-hh24mi
prompt   end_time,        mandatory, format: yyyymmdd-hh24mi
prompt   instance_number, mandatory
prompt
prompt  current action : generating awr report, please wait a moment!
prompt

set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;

variable dbid		  number;
variable snap_interval    number;
variable snap_bid         number;
variable snap_bid_endtime varchar2(20);
variable snap_eid         number;
variable snap_eid_endtime varchar2(20);
variable rpt_options      number;
variable inst_num         number;

begin

  :rpt_options := 0;
  :inst_num    := &4;

  select dbid into :dbid from v$database;
  select trunc(extract(day from snap_interval)*24*60+extract(hour from snap_interval)*60
  + extract(minute from snap_interval)) into :snap_interval
  from dba_hist_wr_control;

  select min(snap_id) into :snap_bid from dba_hist_snapshot
  where end_interval_time between to_date('&&2','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&&2','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = &4;

  select max(snap_id) into :snap_eid from dba_hist_snapshot
  where end_interval_time between to_date('&&3','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&&3','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = &4;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_bid_endtime
   from dba_hist_snapshot
  where instance_number = &4 and snap_id = :snap_bid;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_eid_endtime
   from dba_hist_snapshot
  where instance_number = &4 and snap_id = :snap_eid;
end;
/

column report_name new_value report_name noprint;
select '&&1'||'_'||'&&4'||'_'||:snap_bid_endtime||'_'||:snap_eid_endtime||'.html' report_name from dual;

spool &report_name
select output from table(sys.dbms_workload_repository.awr_report_html(:dbid, :inst_num, :snap_bid, :snap_eid, :rpt_options));
spool off

prompt  finish generating awr report!
