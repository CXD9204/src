prompt
prompt usage:
prompt
prompt @?/rdbms/admin/yirong_awrgrpt_bytime.sql <report_prefix> <begin_time> <end_time>
prompt 
prompt   report_prefix,   mandatory
prompt   begin_time,      mandatory, format: yyyymmdd-hh24mi
prompt   end_time,        mandatory, format: yyyymmdd-hh24mi
prompt
prompt  current action : generating awr report, please wait a moment!
prompt

set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;

/* 
select distinct
       (case when cd.dbid = wr.dbid and 
                  cd.name = wr.db_name and
                  ci.instance_number = wr.instance_number and
                  ci.instance_name   = wr.instance_name   and
                  ci.host_name       = wr.host_name 
             then '* '
             else '  '
        end) || wr.dbid   dbbid
     , wr.instance_number instt_num
     , wr.db_name         dbb_name
     , wr.instance_name   instt_name
     , wr.host_name       host
  from dba_hist_database_instance wr, v$database cd, v$instance ci
  order by 2;
*/

-- ***************************************************
--   Customer-customizable report settings
--   Change these variables to run a report on different statistics
-- ***************************************************

Rem
Rem define instance_numbers_or_ALL = '1,2,3'
define instance_numbers_or_ALL = 'ALL';

Rem
Rem top n events in the report summary (NULL uses package default, 10)
define top_n_events       = NULL;

Rem
Rem top n segments  (NULL uses package default, 5)
define top_n_segments     = NULL;

Rem
Rem top n services (NULL uses package default, 10)
define top_n_services     = NULL;

Rem
Rem top n SQL statements (NULL uses package default, 10)
define top_n_sql          = NULL;

variable tn_events   NUMBER;
variable tn_segments NUMBER;
variable tn_services NUMBER;
variable tn_sql      NUMBER;

variable dbid        number;
variable instlist    VARCHAR2(50);

variable snap_interval    number;
variable snap_bid         number;
variable snap_bid_endtime varchar2(20);
variable snap_eid         number;
variable snap_eid_endtime varchar2(20);
variable rpt_options      number;

begin
  :rpt_options := 0;
  :snap_bid := &2;
  :snap_eid := &3;
 
  select dbid into :dbid from v$database;

  select trunc(extract(day from snap_interval)*24*60+extract(hour from snap_interval)*60
  + extract(minute from snap_interval)) into :snap_interval
  from dba_hist_wr_control;

  select min(snap_id) into :snap_bid from dba_hist_snapshot
  where end_interval_time between to_date('&&2','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&&2','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = 1;

  select max(snap_id) into :snap_eid from dba_hist_snapshot
  where end_interval_time between to_date('&&3','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&&3','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = 1;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_bid_endtime
   from dba_hist_snapshot
  where instance_number = 1 and snap_id = :snap_bid;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_eid_endtime
   from dba_hist_snapshot
  where instance_number = 1 and snap_id = :snap_eid;   

  :instlist := '&instance_numbers_or_ALL';
  if UPPER(:instlist) = 'ALL' then
    :instlist := '';
  end if;
end;
/

column report_name new_value report_name noprint;
select '&&1'||'_rac_'||:snap_bid_endtime||'_'||:snap_eid_endtime||'.html' report_name from dual;

spool &report_name
select output from table(sys.dbms_workload_repository.awr_global_report_html(:dbid, :instlist, :snap_bid, :snap_eid, :rpt_options));
spool  off;

prompt  finish generating awr report!

