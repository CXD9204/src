set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 1st Parameter is AWR Report Prefix, Please input target value (default: MYDB)
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column report_prefix new_value report_prefix;
set heading off;
select 'AWR Report Prefix is :',lower(nvl('&&1','MYDB')) report_prefix from dual;
set heading on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 2nd Parameter is DB Instance Number, Please input target value (default: 1)
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column instance_number new_value instance_number;
set heading off;
select 'Instance Number is :',upper(nvl('&&2','1')) instance_number from dual;
set heading on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 3rd Parameter is AWR Report Begin Time, It is Mandatory [format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column begin_time new_value begin_time;
set heading off;
select 'AWR Report Begin Time is :',upper('&&3') begin_time from dual;
set heading on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 4rd Parameter is AWR Report End Time,   It is Mandatory [format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column end_time new_value end_time;
set heading off;
select 'AWR Report End Time is :',upper('&&4') end_time from dual;
set heading on;

prompt

variable v_dbid		    number;
variable v_inst_num         number;
variable v_rpt_options      number;
variable v_snap_interval    number;
variable v_snap_bid         number;
variable v_snap_bid_endtime varchar2(20);
variable v_snap_eid         number;
variable v_snap_eid_endtime varchar2(20);

begin
  :v_rpt_options := 0;
  :v_inst_num    := &instance_number;

  select dbid into :v_dbid from v$database;

  select trunc(extract(day from snap_interval)*24*60+extract(hour from snap_interval)*60 + extract(minute from snap_interval))
  into :v_snap_interval from dba_hist_wr_control;

  select min(snap_id) into :v_snap_bid from dba_hist_snapshot
  where end_interval_time between to_date('&begin_time','yyyymmdd-hh24mi')- :v_snap_interval/2/1440
    and to_date('&begin_time','yyyymmdd-hh24mi') + :v_snap_interval/2/1440
    and instance_number = &instance_number;

  select max(snap_id) into :v_snap_eid from dba_hist_snapshot
  where end_interval_time between to_date('&end_time','yyyymmdd-hh24mi')- :v_snap_interval/2/1440
    and to_date('&end_time','yyyymmdd-hh24mi') + :v_snap_interval/2/1440
    and instance_number = &instance_number;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :v_snap_bid_endtime
   from dba_hist_snapshot
  where instance_number = &instance_number and snap_id = :v_snap_bid;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :v_snap_eid_endtime
   from dba_hist_snapshot
  where instance_number = &instance_number and snap_id = :v_snap_eid;
end;
/
column report_name new_value report_name;
set heading off;
select 'Awr Report Name is ','&report_prefix'||'_00'||'&instance_number'||'_'||'&begin_time'||'_'||'&end_time'||'.html' report_name from dual;
set heading on;
prompt Awr Report is being Generated, Please Wait a Moment!
set heading off;
spool &report_name
select output from table(sys.dbms_workload_repository.awr_report_html(:v_dbid, :v_inst_num, :v_snap_bid, :v_snap_eid, :v_rpt_options));
spool off
prompt Finish Generating Awr Report!
undefine report_prefix;
undefine instance_number;
undefine begin_time;
undefine end_time;
exit;
