
# days_of_month()
# validity_of_date()
# leap_year()
# chinese_date_and_week()


########################################################################################
#
# usage: yesterday
# ����
# ���������2010��2��27�գ���ô�������2010-02-26
#
########################################################################################
yesterday()
{
date --date='1 day ago' +%Y-%m-%d
}


########################################################################################
#
# usage: today
# ����
# ���������2010��2��27�գ���ô�������2010-02-27
#
########################################################################################
today()
{
date +%Y-%m-%d
}

########################################################################################
#
# usage: now
# ���ڣ��������ں�ʱ�䡢����
# ���磺2010-02-27 11:29:52.991774000
#
########################################################################################
now()
{
date "+%Y-%m-%d %H:%M:%S.%N"
}


########################################################################################
#
# usage: current_time
# ��ǰʱ�䣬�������ں�ʱ��
# ���磺2010-02-27 11:51:04
#
########################################################################################
current_time()
{
date '+%Y-%m-%d %H:%M:%S'
# Ҳ��д�ɣ�date '+%F %T'
}

########################################################################################
#
# usage: last_month
# ȡ�ϸ��µ�����
# ���磺2010-01
#
########################################################################################
last_month()
{
date --date='1 month ago' '+%Y-%m'
}

########################################################################################
#
# usage: last_month_packed
# ȡ�ϸ��µ�����
# ���磺201001
#
########################################################################################
last_month_packed()
{
date --date='1 month ago' '+%Y%m'
}

########################################################################################
#
# usage: first_date_of_last_month
# ȡ�ϸ��µĵ�һ��
# ���籾����2010��2�£���ô�������2010-01-01
#
########################################################################################
first_date_of_last_month()
{
date --date='1 month ago' '+%Y-%m-01'
}

########################################################################################
#
# usage: last_date_of_last_month
# ȡ�ϸ��µ����һ��
# ���統ǰ��2010��2�£���ô�������2010-01-31
#
########################################################################################
last_date_of_last_month()
{
date --date="`date +%e` days ago" '+%Y-%m-%d'
}

########################################################################################
#
# usage: day_of_week
# ���������
# day of week (0..6);0 represents Sunday
#
########################################################################################
day_of_week()
{
date +%w
}

########################################################################################
#
# usage: last_hour
# �ϸ�Сʱ
# ���磺2010-02-27-10
# �ʺϴ���log4j���ɵ���־�ļ���
#
########################################################################################
last_hour()
{
date --date='1 hour ago' +%Y-%m-%d-%H
}


########################################################################################
#
# usage: the_hour
# ��ǰ��Сʱ��Ϊ���������Ƚϣ��������0��ͷ
# ���磺12
#
########################################################################################
the_hour()
{
#date +%H
# hour (00..23)
date +%k
# hour ( 0..23)
}

########################################################################################
#
# usage: the_minute
# ��ǰ�ķ��ӣ�Ϊ���������Ƚϣ��������0��ͷ
# ���磺
#
########################################################################################
the_minute()
{
MM=`date +%M`
# minute (00..59)
echo $[1$MM-100]
}

########################################################################################
#
# usage: the_second
# ��ǰ������
# ���磺
#
########################################################################################
the_second()
{
SS=`date +%S`
# second (00..60); the 60 is necessary to accommodate a leapsecond
echo $[1$SS-100]
}

########################################################################################
#
# usage: the_year
# ��ǰ����� year (1970...)
# ���磺2010
#
########################################################################################
the_year()
{
date +%Y
}

########################################################################################
#
# usage: the_month
# ��ǰ���·ݣ�Ϊ���������Ƚϣ��������0��ͷ
# ���磺2
#
########################################################################################
the_month()
{
M=`date +%m`
# month (01..12)
echo $[1$M-100]
}

########################################################################################
#
# usage: the_date
# ��ǰ�����ڣ�Ϊ���������Ƚϣ��������0��ͷ
# ���磺27
#
########################################################################################
the_date()
{
date +%e
# day of month, blank padded ( 1..31)
}

########################################################################################
#
# usage: days_ago <n>
# ȡn��ǰ������
# ���磺days_ago 0���ǽ��죬days_ago 1�������죬days_ago 2����ǰ�죬days_ago -1��������
# ��ʽ��2010-02-27
#
########################################################################################
days_ago()
{
date --date="$1 days ago" +%Y-%m-%d
}

########################################################################################
#
# usage: days_ago_packed <n>
# ȡn��ǰ������
# ���磺days_ago 0���ǽ��죬days_ago 1�������죬days_ago 2����ǰ�죬days_ago -1��������
# ��ʽ��20100227
#
########################################################################################
days_ago_packed()
{
date --date="$1 days ago" +%Y%m%d
}


########################################################################################
#
# usage: rand_digit
# ������֣�0-9
#
########################################################################################
rand_digit()
{
S="`date +%N`"
echo "${S:5:1}"
}

########################################################################################
#
# usage: seconds_of_date [<date> [<time>]]
# ��ȡָ�����ڵ���������1970�꣩
# ���磺seconds_of_date "2010-02-27" ���� 1267200000
#
########################################################################################
seconds_of_date()
{
if [ "$1" ]; then
date -d "$1 $2" +%s
else
date +%s
fi
}
########################################################################################
#
# usage: date_of_seconds <seconds>
# ������������1970�꣩�õ�����
# ���磺date_of_seconds 1267200000 ���� 2010-02-27
#
########################################################################################
date_of_seconds()
{
date -d "1970-01-01 UTC $1 seconds" "+%Y-%m-%d"
}

########################################################################################
#
# usage: datetime_of_seconds <seconds>
# ������������1970�꣩�õ�����ʱ��
# ���磺datetime_of_seconds 1267257201 ���� 2010-02-27 15:53:21
#
########################################################################################
datetime_of_seconds()
{
date -d "1970-01-01 UTC $1 seconds" "+%Y-%m-%d %H:%M:%S"
}

############################################################
##
## desc : get the max date number of target year and month
## default: return current month last date number
##
## usage: getLastDateNumber 2014 12 
##        getLastDateNumber
##
############################################################
getLastDateNumberOfMonth(){
  if ( test -z "$1" || test -z "$1" )
        #if [ -z "$1" -o -z "$1" ];
        #if [ -z "$1" ] || [ -z "$1" ];
  then    
    echo "`cal|xargs|awk '{print $NF}'`"
  else
    echo "`cal $2 $1|xargs|awk '{print $NF}'`"
  fi
}

##############################################################
## 
## ���ڼӼ�����
## 
## ����$1 Դ����, ��ʽ��yyyyMMdd
## ����$2 ʱ����, Ĭ��ֵΪ1
## 
##############################################################
getDateAfter()
{
  if [ ! -n "$1" ];then
   echo "Please input date(yyyyMMdd)!" 
   return 1
  fi
   if [ ! -n "$2" ];then
   echo "Please input  Interval!" 
   return 1
  fi
  
  param1len=`expr length $1`
  if [ $param1len -ne 8 ];then
        echo "Date Format IS WRONG,e.g yyyyMMdd"
        return 1
  fi
        
        if [ -n "$1" -a -n "$2" ]; then
          month=`echo $1|cut -c 5-6`
          day=`echo $1|cut -c 7-8`
          year=`echo $1|cut -c 1-4`

          # Add 0 to month. This is a  
          # trick to make month an unpadded integer.   
          month=`expr $month + 0`  
      
          # Subtract one from the current day.   
          day=`expr $day + $2`
      
          # If the day is 0 then determine the last  
          # day of the previous month.   
          if [ $day -eq 0 ]; then  
               # Find the preivous month.   
               month=`expr $month - 1`  
               # If the month is 0 then it is Dec 31 of  
               # the previous year.   
               if [ $month -eq 0 ]; then  
                    month=12  
                    day1=31  
                    year=`expr $year - 1`  
           
               # If the month is not zero we need to find  
               # the last day of the month.   
               else
               case $month in  
                    1|3|5|7|8|10|12) day1=31;;  
                    4|6|9|11) day1=30;;  
                    2)  
                    if [ `expr $year % 4` -eq 0 a `expr $year % 100` % -ne 0  o `expr $year % 400` -eq 0 ]; then  
                                 day1=29                                                                        
                            else  
                                 day1=28
                            fi   
                    ;;  
                    esac
                    day=`expr $day1 + $day` 
               fi  
          fi
          
          if [ $day -lt 0 ]; then
               # Find the preivous month.   
               month=`expr $month - 1`  
               # If the month is 0 then it is Dec 31 of  
               # the previous year.   
               if [ $month -eq 0 ]; then  
                  month=12  
                  day=`expr 31 + $day` 
                  year=`expr $year - 1`  
               # If the month is not zero we need to find  
               # the last day of the month.   
               else 
                       case $month in  
                            1|3|5|7|8|10|12) day1=31;;  
                            4|6|9|11) day1=30;;  
                            2)
                            if [ `expr $year % 4` -eq 0 a `expr $year % 100` % -ne 0  o `expr $year % 400` -eq 0 ]; then  
                                 day1=29                                                                        
                            else  
                                 day1=28
                            fi  
                         ;;  
                         esac
                         day=`expr $day1 + $day`
               fi
          fi
          daylen=`expr length $day`
          monthlen=`expr length $month`
          if [ $daylen -lt 2 ];then
                day=0$day
          fi
          if [ $monthlen -lt 2 ];then
                month=0$month
          fi
          echo $year$month$day
  else
         date2=`date +20%y%m%d`     
      echo "$date2"
  fi
}

################################################################################
## getWeekday
################################################################################
getWeekday()
{
week_day=`date -d "$1" +%w`
case `expr $week_day + 1` in
1) week_day_name='Sun' ;;
2) week_day_name='Mon' ;;
3) week_day_name='Tue' ;;
4) week_day_name='Wed' ;;
5) week_day_name='Thu' ;;
6) week_day_name='Fri' ;;
7) week_day_name='Sat' ;;
*) week_day_name= 'wrong-date' ;;
esac
echo $week_day_name
}


########################################################################################
#
# usage: the_firstday_of_this_week
# 
########################################################################################
the_firstday_of_this_week()
{
NW=`date +%w`
if [ $NW -gt 0 ]; then
NW=$[1$NW-10-1]
else
NW=$[$NW-1+7]
fi
days_ago_packed $NW
}

########################################################################################
#
# usage: the_firstday_of_last_week
#
########################################################################################
the_firstday_of_last_week()
{
NW=`date +%w`
if [ $NW -gt 0 ]; then
NW=$[1$NW-10-1+7]
else
NW=$[$NW-1+14]
fi
days_ago_packed $NW
}

#######################################################################################
#
# date format is yyyymmddhh24mi
#
# for example:
#   getDateTimeByDB 201703061030 -3  ==> 201703031030
#   getDateTimeByDB 201703061030 +3  ==> 201703091030
#
#######################################################################################
getDateTimeByDB()
{
echo `sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select to_char(to_date('$1','yyyymmddhh24mi')+$2,'yyyymmddhh24mi') from dual;
exit
EOF`
}

##################################################
#
# usage: leap_year <yyyy>
# �ж��Ƿ�����
# ���yyyy�����꣬����0Ϊ��, 1Ϊ��
#
##################################################

leap_year()
{
# store year
yy=$1
isleap="false"

#yy=$[$yy-0]
yy=$((yy-0))

if [ $(( yy % 400 )) -eq 0 ]; then
  isleap="true"
elif [ $(( yy % 4 )) -eq 0 -a $(( yy % 100 )) -ne 0 ]; then
  isleap="true"
fi

if [ "$isleap" = "true" ]; then
  return 0
else
  return 1
fi
}

##################################################
#
# usage: days_of_month <yyyy> <mm>
# ��ȡyyyy��mm�µ�������ע�����˳��
# ���磺days_of_month 2007 2 �����28
#
##################################################
days_of_month()
{
# store day, month and year
yy=$1
mm=$2

yy=$[$yy-0]
mm=$[$mm-0]

#yy=$((yy-0))
#mm=$((mm-0))

# store number of days in a month
days=0

if [ $mm -le 0 -o $mm -gt 12 ]; then
# $mm is invalid month.
echo -1
return
fi

# Find out number of days in given month
case $mm in
01) days=31 ;;
02) days=28 ;;
03) days=31 ;;
04) days=30 ;;
05) days=31 ;;
06) days=30 ;;
07) days=31 ;;
08) days=31 ;;
09) days=30 ;;
1) days=31 ;;
2) days=28 ;;
3) days=31 ;;
4) days=30 ;;
5) days=31 ;;
6) days=30 ;;
7) days=31 ;;
8) days=31 ;;
9) days=30 ;;
10) days=31 ;;
11) days=30 ;;
12) days=31 ;;
*) days=-1 ;;
esac

#
# if it is feb, then check of leap year
#
if [ $mm -eq 2 -o "$mm" = "02" ]; then
	if [ $((yy % 400)) -eq 0 ]; then
		# it's a leap year
		days=29
	elif [ $((yy % 4)) -eq 0 -a $((yy % 100)) -nq 0 ]; then
		# it's a leap year
		days=29		
	fi
fi
echo $days
}


##################################################
#
# usage: validity_of_date <yyyy> <mm> <dd>
# �ж�yyyy-mm-dd�Ƿ�Ϸ�������
# ����ǣ�  ����ֵΪ0; 
# ������ǣ�����ֵΪ��0
# ����ʾ�����£�
# if validity_of_date 2007 02 03; then
# echo "2007 02 03 is valid date"
# fi
# if validity_of_date 2007 02 28; then
# echo "2007 02 28 is valid date"
# fi
# if validity_of_date 2007 02 29; then
# echo "2007 02 29 is valid date"
# fi
# if validity_of_date 2007 03 00; then
# echo "2007 03 00 is valid date"
# fi
#
##################################################
validity_of_date()
{
# store day, month and year
yy=$1
mm=$2
dd=$3

# store number of days in a month
days=0

if [ $mm -le 0 -o $mm -gt 12 ]; then
	#echo "$mm is invalid month."
	return 1
fi

case $mm in 
1) days=31 ;;
01) days=31 ;;
2) days=28 ;;
02) days=28 ;;
3) days=31 ;;
03) days=31 ;;
4) days=30 ;;
04) days=30 ;;
5) days=31 ;;
05) days=31 ;;
6) days=30 ;;
06) days=30 ;;
7) days=31 ;;
07) days=31 ;;
8) days=31 ;;
08) days=31 ;;
9) days=30 ;;
09) days=30 ;;
10) days=31 ;;
11) days=30 ;;
12) days=31 ;;
*) days=-1 ;;
esac

if [ $mm -eq 2 -o "$mm" = "02" ]; then
	if [ $((yy % 400)) -eq 0 ]; then
		# it's a leap year
		days=29
	elif [ $((yy % 4)) -eq 0 -a $((yy % 100)) -nq 0 ]; then
		# it's a leap year
		days=29
	fi
fi

if [ $dd -le 0 -o $dd -gt $days ]; then
	#echo "$dd day is invalid"
	return 1
fi

return 0
}

##################################################
#
# usage: chinese_date_and_week()
# ��ӡ���ĵ����ں�����
# ���磺2��27�� ������
#
##################################################
chinese_date_and_week()
{
WEEKDAYS=(������ ����һ ���ڶ� ������ ������ ������ ������)

#
# aix define array
# 
#set -A WEEKDAYS ������ ����һ ���ڶ� ������ ������ ������ ������
#

WEEKDAY=`date +%w`
#DT="`date +%Y��%m��%d��` ${WEEKDAYS[$WEEKDAY]}"
MN=1`date +%m`
MN=$((MN-100))
DN=1`date +%d`
DN=$((DN-100))
DT="$MN��$DN�� ${WEEKDAYS[$WEEKDAY]}"
echo $DT
}

