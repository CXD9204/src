set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;

col dbid new_value dbid
col snap_interval  for a20
col retention      for a20
col snap_interval_in_minute for a24

set heading on

prompt 
prompt Database Workload Repository Control Config:
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
select dbid, snap_interval, ''||trunc(extract(day from snap_interval) * 24 * 60 + extract(hour from snap_interval) * 60
 + extract(minute from snap_interval)) snap_interval_in_minute,  retention
 from dba_hist_wr_control;

prompt
prompt
prompt 

col owner for a16
col directory_name for a30
col directory_path for a60
prompt Database Directory List:
prompt ~~~~~~~~~~~~~~~~~~~~~~~~
select * from dba_directories;

prompt 
prompt 

prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 1st Parameter is Dmpfile Prefix, Please input target value.(default: MYDB)
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column dmpfile_prefix new_value dmpfile_prefix;
set heading off;
select 'Dmpfile Prefix is :',lower(nvl('&&1','MYDB')) dmpfile_prefix from dual;
set heading on;


prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 2nd Parameter is Directory Name, It is Mandatory. 
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column dir_name new_value dir_name;
set heading off;
select 'Directory Name is :',upper('&&2') dir_name from dual;
set heading on;

prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 3rd Parameter is AWR Snapshot Begin Time, It is Mandatory.[format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column begin_time new_value begin_time;
set heading off;
select 'AWR Snapshot Begin Time is :',upper('&&3') begin_time from dual;
set heading on;

prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 4th Parameter is AWR Snapshot End Time,   It is Mandatory.[format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column end_time new_value end_time;
set heading off;
select 'AWR Snapshot End Time is :',upper('&&4') end_time from dual;
set heading on;

REM /* validate dmpfile_dir */
column dir_name new_value dir_name noprint;
set heading off;
select directory_name dir_name
  from dba_directories
 where directory_name = upper('&dir_name');
whenever sqlerror exit;
set heading on;
column snap_bid   new_value snap_bid   noprint;
column snap_eid   new_value snap_eid   noprint;
column snap_btime new_value snap_btime noprint;
column snap_etime new_value snap_etime noprint;

REM /* validate bid btime eid etime*/
set heading off;
select min(snap_id) snap_bid,min(to_char(end_interval_time, 'yyyymmddhh24mi')) snap_btime,
       max(snap_id) snap_eid,max(to_char(end_interval_time, 'yyyymmddhh24mi')) snap_etime
  from dba_hist_snapshot a
 where dbid = &dbid
   and end_interval_time>=
       to_date('&begin_time', 'yyyymmdd-hh24mi') - 1.5 / 1440
   and end_interval_time<=
       to_date('&end_time', 'yyyymmdd-hh24mi') + 1.5 / 1440;
set heading on;
column dmpfile_name new_value dmpfile_name;
set heading off;
select 'Dmpfile Name is :','&dmpfile_prefix'||'_'||'&snap_btime'||'_'||'&snap_etime'||'_'||trim('&snap_bid')||'_'||trim('&snap_eid') dmpfile_name from dual;
set heading on;
prompt Begin Extract AWR Data
set heading off;
set linesize 110 pagesize 50000;
set echo off;
set feedback off;
set termout on;
begin
  /* call PL/SQL routine to extract the data */
  dbms_swrf_internal.awr_extract(dmpfile  => '&dmpfile_name',
                                 dmpdir   => '&dir_name',
                                 bid      => &snap_bid,
                                 eid      => &snap_eid,
                                 dbid     => &dbid);
  dbms_swrf_internal.clear_awr_dbid;
end;
/
prompt Finish Extract AWR Data
undefine dir_name;
undefine dmpfile_prefix;
undefine dmpfile_name
undefine snap_bid;
undefine snap_eid;
undefine snap_btime;
undefine snap_etime;
undefine dbid;
exit;

