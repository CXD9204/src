prompt
prompt usage:
prompt
prompt @?/rdbms/admin/yirong_awrextr_bytime.sql <dmpfile_prefix> <directory_name> <snap_btime> <snap_etime>
prompt 
prompt   dmpfile_prefix,mandatory
prompt   directory_name,mandatory
prompt   snap_btime,    mandatory, format: yyyymmddhh24mi
prompt   snap_etime,    mandatory, format: yyyymmddhh24mi
prompt
prompt   generating awr extract dmpfile now !
prompt   please wait a moment.
prompt
prompt   dmpfile name is <dmpfile_prefix>_<snap_btime>_<snap_etime>_<snap_bid>_<snap_eid>.dmp
prompt

set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;

define dmpfile_prefix='&1';
define dir_name  = '&2';

column dbid new_value dbid noprint;
select dbid from v$database;

REM /* validate dir_name */
column dir_name new_value dir_name noprint;

select directory_name dir_name
  from dba_directories
 where directory_name = upper('&dir_name');

variable v_dir_name varchar2(30);
begin
  :v_dir_name := '&dir_name';
end;
/
whenever sqlerror exit;

column snap_bid new_value snap_bid noprint;
column snap_btime new_value snap_btime noprint;
column snap_eid new_value snap_eid noprint;
column snap_etime new_value snap_etime noprint;

REM /* validate bid btime eid etime*/
select min(snap_id) snap_bid,min(to_char(end_interval_time, 'yyyymmddhh24mi')) snap_btime,
       max(snap_id) snap_eid,max(to_char(end_interval_time, 'yyyymmddhh24mi')) snap_etime
  from dba_hist_snapshot a
 where dbid = &dbid
   and end_interval_time>=
       to_date('&3', 'yyyymmddhh24mi') - 1.5 / 1440
   and end_interval_time<=
       to_date('&4', 'yyyymmddhh24mi') + 1.5 / 1440;

variable v_bid number;
variable v_eid number;
begin
  :v_bid := &snap_bid;
  :v_eid := &snap_eid;
end;
/
whenever sqlerror exit;

column dmpfile_name new_value dmpfile_name noprint;
select '&dmpfile_prefix'||'_'||'&snap_btime'||'_'||'&snap_etime'||'_'||:v_bid||'_'||:v_eid dmpfile_name from dual;
-- select '&dmpfile_prefix'||'_'||'&snap_btime'||'_'||'&snap_etime'||'_'||trim('&snap_bid')||'_'||trim('&snap_eid') dmpfile_name from dual;

set heading off;
set linesize 110 pagesize 50000;
set echo off;
set feedback off;
set termout on;

prompt  Begin to AWR Extract

begin
  /* call PL/SQL routine to extract the data */
  dbms_swrf_internal.awr_extract(dmpfile  => '&dmpfile_name',
                                 dmpdir   => '&dir_name',
                                 bid      => :v_bid,
                                 eid      => :v_eid,
                                 dbid     => &dbid);
  dbms_swrf_internal.clear_awr_dbid;
end;
/

prompt 
prompt  End of AWR Extract

undefine dmpfile_prefix
undefine dir_name

