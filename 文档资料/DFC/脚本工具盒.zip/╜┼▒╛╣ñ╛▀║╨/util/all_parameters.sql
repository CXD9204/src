
--
-- create view as sys user 
-- use for query hidden parameter and its value
--

DROP VIEW SYS.ALL_PARAMETERS;

/* Formatted on 11/25/2016 3:19:32 ���� (QP5 v5.185.11230.41888) */
CREATE OR REPLACE FORCE VIEW SYS.ALL_PARAMETERS
(
   NAME,
   DESCRIPTION,
   VALUE,
   ISDEFAULT,
   ISMODIFIED,
   ISADJUSTED
)
AS
     SELECT i.ksppinm name,
            i.ksppdesc description,
            CV.ksppstvl VALUE,
            CV.ksppstdf isdefault,
            DECODE (BITAND (CV.ksppstvf, 7),
                    1, 'MODIFIED',
                    4, 'SYSTEM_MOD',
                    'FALSE')
               ismodified,
            DECODE (BITAND (CV.ksppstvf, 2), 2, 'TRUE', 'FALSE') isadjusted
       FROM sys.x$ksppi i, sys.x$ksppcv CV
      WHERE     i.inst_id = USERENV ('Instance')
            AND CV.inst_id = USERENV ('Instance')
            AND i.indx = CV.indx
            AND i.ksppinm LIKE '/_%' ESCAPE '/'
   ORDER BY REPLACE (i.ksppinm, '_', '');

