set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 1st Parameter is AWR Report Prefix, Please input target value (default: MYDB)
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column report_prefix new_value report_prefix;
set heading off;
select 'AWR Report Prefix is :',lower(nvl('&&1','MYDB')) report_prefix from dual;
set heading on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 2rd Parameter is AWR Report Begin Time, It is Mandatory [format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column begin_time new_value begin_time;
set heading off;
select 'AWR Report Begin Time is :',upper('&&2') begin_time from dual;
set heading on;
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
prompt 3rd Parameter is AWR Report End Time,   It is Mandatory [format:yyyymmdd-hh24mi]
prompt ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
column end_time new_value end_time;
set heading off;
select 'AWR Report End Time is :',upper('&&3') end_time from dual;
set heading on;

/* 
select distinct
       (case when cd.dbid = wr.dbid and 
                  cd.name = wr.db_name and
                  ci.instance_number = wr.instance_number and
                  ci.instance_name   = wr.instance_name   and
                  ci.host_name       = wr.host_name 
             then '* '
             else '  '
        end) || wr.dbid   dbbid
     , wr.instance_number instt_num
     , wr.db_name         dbb_name
     , wr.instance_name   instt_name
     , wr.host_name       host
  from dba_hist_database_instance wr, v$database cd, v$instance ci
  order by 2;
*/

-- *****************************************************************
--   Customer-customizable report settings
--   Change these variables to run a report on different statistics
-- *****************************************************************

Rem
Rem define instance_numbers_or_ALL = '1,2,3'
define instance_numbers_or_ALL = 'ALL';

Rem
Rem top n events in the report summary (NULL uses package default, 10)
Rem define top_n_events       = NULL;
Rem
Rem top n segments  (NULL uses package default, 5)
Rem define top_n_segments     = NULL;
Rem
Rem top n services (NULL uses package default, 10)
Rem define top_n_services     = NULL;
Rem
Rem top n SQL statements (NULL uses package default, 10)
Rem define top_n_sql          = NULL;

Rem variable tn_events   NUMBER;
Rem variable tn_segments NUMBER;
Rem variable tn_services NUMBER;
Rem variable tn_sql      NUMBER;

variable dbid        number;
variable instlist    VARCHAR2(50);

variable snap_interval    number;

variable snap_bid         number;
variable snap_bid_endtime varchar2(20);
variable snap_eid         number;
variable snap_eid_endtime varchar2(20);

variable rpt_options      number;

begin
  :rpt_options := 0;
  :snap_bid := 0;
  :snap_eid := 0;
 
  select dbid into :dbid from v$database;

  select trunc(extract(day from snap_interval)*24*60+extract(hour from snap_interval)*60
  + extract(minute from snap_interval)) into :snap_interval
  from dba_hist_wr_control;

  select min(snap_id) into :snap_bid from dba_hist_snapshot
  where end_interval_time between to_date('&begin_time','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&begin_time','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = 1;

  select max(snap_id) into :snap_eid from dba_hist_snapshot
  where end_interval_time between to_date('&end_time','yyyymmdd-hh24mi')- :snap_interval/2/1440
    and to_date('&end_time','yyyymmdd-hh24mi') + :snap_interval/2/1440
    and instance_number = 1;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_bid_endtime
   from dba_hist_snapshot
  where instance_number = 1 and snap_id = :snap_bid;

  select to_char(end_interval_time, 'yymmdd-hh24mi')  into :snap_eid_endtime
   from dba_hist_snapshot
  where instance_number = 1 and snap_id = :snap_eid;   

  :instlist := '&instance_numbers_or_ALL';
  if UPPER(:instlist) = 'ALL' then
    :instlist := '';
  end if;
end;
/
column report_name new_value report_name;
set heading off;
select 'Awr Report Name is ','&report_prefix'||'_rac_'||'&begin_time'||'_'||'&end_time'||'.html' report_name from dual;
set heading on;

set heading off;
spool &report_name
select output from table(sys.dbms_workload_repository.awr_global_report_html(:dbid, :instlist, :snap_bid, :snap_eid, :rpt_options));
spool off;
prompt Finish Generating Awr Report!

undefine report_prefix;
undefine begin_time;
undefine end_time;
undefine instance_numbers_or_ALL;

Rem undefine top_n_events;
Rem undefine top_n_segments;
Rem undefine top_n_services;
Rem undefine top_n_sql;

exit;

