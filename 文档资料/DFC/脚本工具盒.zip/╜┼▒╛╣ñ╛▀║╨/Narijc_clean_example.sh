#! /bin/sh

filepath=/app/logs/xtbg      #日志存放路径
filepathbak=/app/logs/xtbglogbak      #日志备份存放路径

accesslogpath1=$WLS_DOMAIN_HOME/servers/Server-engine-2a/logs
accesslogpath2=$WLS_DOMAIN_HOME/servers/AdminServer/logs

DATE=$(date +%Y%m%d)
TIME=$(date +%Y-%m-%d-%H:%M:%S)

echo $TIME  "删除7天前日志文件开始。">>$filepathbak/operate.log
find $filepathbak -type f -mtime +7 -delete
echo $TIME  "删除7天前日志文件结束。">>$filepathbak/operate.log

echo $TIME  "处理日志文件开始。">>$filepathbak/operate.log

find $WLS_DOMAIN_HOME -name "SgccBusinessEngine.log.*" | while read file
do
cd $WLS_DOMAIN_HOME
fname=`basename $file`
tar -cvzf $filepathbak/$fname.tar.gz $fname
rm -f $file 
done
echo $TIME  "处理SgccBusinessEngine.log文件结束。">>$filepathbak/operate.log

find $filepath -name "*.log" | while read file
do
fname=`basename $file .log`
cd $filepath
tar -cvzf $filepathbak/$fname.$DATE.tar.gz $fname.log
:>$file
echo $TIME "处理文件"$fname"结束。">>$filepathbak/operate.log
done

echo $TIME  "处理日志文件结束。">>$filepathbak/operate.log


echo $TIME  "删除7天前的accesslog开始。">>$filepathbak/operate.log
find $accesslogpath1 -type f -mtime +7 -delete
find $accesslogpath2 -type f -mtime +7 -delete
echo $TIME  "删除7天前的accesslog结束。">>$filepathbak/operate.log
echo "==========================================">>$filepathbak/operate.log

