declare
dba_list varchar2(3000) default 'DBA_COLL_TYPES,DBA_DATA_FILES,DBA_DATAPUMP_JOBS,DBA_DB_LINKS
,DBA_DIRECTORIES,DBA_ENABLED_AGGREGATIONS,DBA_ENABLED_TRACES,DBA_ERRORS,DBA_FEATURE_USAGE_STATISTICS
,DBA_FREE_SPACE,DBA_HIGH_WATER_MARK_STATISTICS,DBA_INDEXES,DBA_IND_PARTITIONS,DBA_JOBS,DBA_LIBRARIES
,DBA_LOBS,DBA_MVIEW_LOGS,DBA_MVIEWS,DBA_OBJECTS,DBA_OUTLINE_HINTS,DBA_OUTLINES,DBA_PART_INDEXES
,DBA_PART_KEY_COLUMNS,DBA_PART_TABLES,DBA_RECYCLEBIN,DBA_REFRESH,DBA_REGISTERED_SNAPSHOT_GROUPS
,DBA_REGISTERED_SNAPSHOTS,DBA_REGISTRY,DBA_REGISTRY_HISTORY,DBA_REPCATLOG,DBA_REPCAT_REFRESH_TEMPLATES
,DBA_REPCAT_TEMPLATE_SITES,DBA_REPGROUP,DBA_REPOBJECT,DBA_REPSITES,DBA_ROLE_PRIVS,DBA_ROLES
,DBA_ROLLBACK_SEGS,DBA_SEGMENTS,DBA_SNAPSHOT_LOGS,DBA_SNAPSHOTS,DBA_SYS_PRIVS
,DBA_TAB_COLS,DBA_TAB_COLUMNS,DBA_TAB_HISTOGRAMS,DBA_TABLES,DBA_TABLESPACES,DBA_TAB_PARTITIONS,DBA_TAB_PRIVS
,DBA_TAB_SUBPARTITIONS,DBA_TEMP_FILES,DBA_TYPE_ATTRS,DBA_TYPE_METHODS,DBA_TYPES,DBA_USERS';
v_list varchar2(3000) default 'V$ARCHIVE_DEST,V$ARCHIVED_LOG,V$ASM_DISK,V$ASM_DISKGROUP,V$BACKUP_PIECE
,V$BACKUP_SET,V$BACKUP_SPFILE,V$CONTROLFILE,V$CONTROLFILE_RECORD_SECTION,V$DATABASE,V$DATAFILE
,V$DISPATCHER,V$DISPATCHER_RATE,V$FILESTAT,V$FLASHBACK_DATABASE_LOG,V$FLASHBACK_DATABASE_STAT
,V$FLASH_RECOVERY_AREA_USAGE,V$INSTANCE,V$LATCH,V$LICENSE,V$LOG,V$LOG_HISTORY,V$OPTION,V$PARAMETER
,V$QUEUE,V$RECOVERY_FILE_DEST,V$RMAN_BACKUP_JOB_DETAILS,V$RMAN_CONFIGURATION,V$ROLLNAME,V$ROLLSTAT
,V$SGA_DYNAMIC_COMPONENTS,V$SPPARAMETER,V$SYSAUX_OCCUPANTS,V$SYSSTAT,V$TEMPFILE,V$TEMPSTAT,V$VERSION,V$WAITSTAT';
table_list dbms_utility.uncl_array;
table_list_len number;
procedure collect_table(old_table_name varchar2,new_table_name varchar2)as
sqltext clob;
begin
sqltext := 'create table enmo_collect.'||trim(new_table_name) ||' as select * from '||trim(old_table_name);
execute immediate sqltext;
exception when others then
if(sqlcode=-997)then
sqltext := 'create table enmo_collect.'||new_table_name ||' as select ';
for i in (select column_name from dba_tab_columns where data_type !='LONG' and table_name = trim(old_table_name) and owner  ='SYS') loop
sqltext := sqltext|| i.column_name||',';
--dbms_output.put_line(i.column_name);
end loop;
sqltext :=substr(sqltext,1,dbms_lob.getlength(sqltext)-1)||' from '||old_table_name;
begin
execute immediate sqltext;
exception when others then
dbms_output.put_line('Error:'||SQLERRM||'
'||SQLTEXT);
end;
else
dbms_output.put_line('Error:'||SQLERRM||'
'||SQLTEXT);
end if;
end;
begin
begin
execute immediate ('drop user enmo_collect cascade');
exception when others then null;
end;
begin
execute immediate ('create user enmo_collect identified by enmo_collect default tablespace users quota 500M on users');
exception when others then null;
end;
dbms_utility.comma_to_table(dba_list,table_list_len,table_list);
for i in 1..table_list_len loop
  collect_table(table_list(i),replace(table_list(i),'DBA_','ENM_') );
end loop;
dbms_utility.comma_to_table(v_list,table_list_len,table_list);
for i in 1..table_list_len loop
  collect_table(table_list(i),replace(table_list(i),'V$','E_') );
end loop;
end;
/