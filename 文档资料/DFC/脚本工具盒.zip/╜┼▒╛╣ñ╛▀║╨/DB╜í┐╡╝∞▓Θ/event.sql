with tmp1 as
(select /*+no_merge materialize*/ max(snap_id) end_id,max(startup_time) as last_start_up from dba_hist_snapshot)
 ,tmp2 as (
select /*+no_merge materialize*/ e.event_name,e.time_waited_micro-nvl(b.time_waited_micro,0),
row_number() over(order by e.time_waited_micro-nvl(b.time_waited_micro,0) desc) as r
from dba_hist_system_event b,
dba_hist_system_event e ,
tmp1
where e.snap_id = end_id
and b.snap_id = (select min(snap_id) from dba_hist_snapshot where 1=1 --begin_interval_time>sysdate-3
 and startup_time=last_start_up)
and e.event_name = b.event_name(+) and e.wait_class!='Idle' and b.wait_class(+)!='Idle'
)
select 'SNAP_TIME',0
,max(case when r=1 then event_name end) event1
,max(case when r=2 then event_name end) event2
,max(case when r=3 then event_name end) event3
,max(case when r=4 then event_name end) event4
,max(case when r=5 then event_name end) event5
,max(case when r=6 then event_name end) event6
,max(case when r=7 then event_name end) event7
,max(case when r=8 then event_name end) event8
,max(case when r=9 then event_name end) event9
,max(case when r=10 then event_name end) event10
,'CPU' CPU
,'PARSE' DBTIME
from tmp2
union all
select SNAPTIME,snap_id
,''||sum(case when event='event1' then waittime else 0 end) event1
,''||sum(case when event='event2' then waittime else 0 end) event2
,''||sum(case when event='event3' then waittime else 0 end) event3
,''||sum(case when event='event4' then waittime else 0 end) event4
,''||sum(case when event='event5' then waittime else 0 end) event5
,''||sum(case when event='event6' then waittime else 0 end) event6
,''||sum(case when event='event7' then waittime else 0 end) event7
,''||sum(case when event='event8' then waittime else 0 end) event8
,''||sum(case when event='event9' then waittime else 0 end) event9
,''||sum(case when event='event10' then waittime else 0 end) event10
,''||sum(case when event='CPU' then waittime else 0 end) CPU
,''||sum(case when event='PARSE' then waittime else 0 end) PARSE
 from (
select SNAPTIME,snap_id,event event,round(WAITTIME/1e6)WAITTIME,WAIT_COUNT,round(WAITTIME/greatest(WAIT_COUNT,1)/1e3,1) as AVGWait,
 rank() over(partition  by snap_id order by WAITTIME desc) as R from
 (
select /*+ordered push_pred(s)*/ to_char(begin_interval_time,'YYYYMMDD HH24') SNAPTIME,s.snap_id, event
,case when total_waits < lag(total_waits) over(partition by event order by s.snap_id ) then total_waits else total_waits - lag(total_waits) over(partition by event order by s.snap_id) end WAIT_COUNT
,case when time_waited_micro < lag(time_waited_micro) over(partition by event order by s.snap_id ) then time_waited_micro else time_waited_micro - lag(time_waited_micro) over(partition by event order by s.snap_id) end WAITTIME
from  dba_hist_snapshot snap ,(
select snap_id,total_waits,time_waited_micro
,'event'||r event
from dba_hist_system_event h, tmp2
where wait_class !='Idle'
 and time_waited_micro >0
 and tmp2.event_name = h.event_name and tmp2.r <11
union all
select snap_id,value*1e4,value*1e4 ,'CPU'
from dba_hist_sysstat where stat_name in('CPU used by this session')
union all
select snap_id,value*1e4,value*1e4 ,'PARSE'
from dba_hist_sysstat where stat_name in('parse time elapsed')
--group by snap_id
) s  where snap.snap_id = s.snap_id --and begin_interval_time > sysdate -3
)where  WAITTIME is not null)
group by  SNAPTIME,snap_id;
