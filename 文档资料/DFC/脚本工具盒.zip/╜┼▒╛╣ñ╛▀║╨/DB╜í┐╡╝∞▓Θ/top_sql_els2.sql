select
 sql.*,
 (select to_char(dbms_lob.substr(sql_text, 3000))
    from dba_hist_sqltext t
   where t.sql_id = sql.sql_id
     and t.dbid = sql.dbid) SQL$
  from (select min(to_char(begin_interval_time, 'DD-HH24')) || '/' ||
               max(to_char(begin_interval_time, 'DD-HH24')) STIME,
               parsing_schema_nAME USR,
               sn.dbid,
               sql_id,
               plan_hash_value,
               sum(executions_delta) exe,
               round(sum(elapsed_time_delta) / greatest(sum(executions_delta), 1) / 1e6 / 60,2) ela_per,
               round(sum(elapsed_time_delta) / 1e6 / 60,2) els,
               round(sum(cpu_time_delta) / 1e6 / 60,2) cpu,
               round(sum(iowait_delta) / 1e6 / 60,2) iow,
               sum(buffer_gets_delta) get,
               sum(disk_reads_delta) phy,
               round(sum(rows_processed_delta)/greatest(sum(executions_delta), 1),2) RR
          from dba_hist_sqlstat sql, dba_hist_snapshot sn
         where sn.snap_id = sql.snap_id
              and sn.begin_interval_time > sysdate - nvl('&hour',2)/24
           AND parsing_schema_nAME not LIKE 'SYS%'
           and sn.dbid = sql.dbid
         --  and sn.dbid = 80464158
           and plan_hash_value <> 0
         group by sn.dbid,plan_hash_value, sql_id, parsing_schema_name
         order by sum(disk_reads_delta)/greatest(sum(executions_delta), 1)  desc) sql
 where rownum <= 40
