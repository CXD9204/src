
 
 set lines 160;
 set pages 50 ;
 
 spool db_run_status.txt append;
 
 select to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss') as system_date_time from dual;
 

 SELECT SNAP_ID,STIME
       ,to_char(round(sum(CASE WHEN stat_name = 'DB time' THEN value END)/100/seconds,1),'990D0') DBTIME
       ,to_char(round(sum(CASE WHEN stat_name = 'CPU used by this session' THEN value END)/100/seconds,1),'990D0') CPU
       ,to_char(round(sum(CASE WHEN stat_name = 'session logical reads' THEN value END)/seconds,1),'99999990D0') LGR
       ,to_char(round(sum(CASE WHEN stat_name = 'physical writes' THEN value END)/seconds,1),'99990D0') PHW
       ,to_char(round(sum(CASE WHEN stat_name = 'physical reads' THEN value END)/seconds,1),'9999990D0') PHR
       ,to_char(round(sum(CASE WHEN stat_name = 'db block changes' THEN value END) /seconds,1),'99990D0') BLKCHG
       ,to_char(round(sum(CASE WHEN stat_name = 'concurrency wait time' THEN value END)/1e2/seconds,4),'990D0000') CONNR
 FROM
     (SELECT snap_id, stat_name ,instance_number,
          CASE WHEN value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) < 0 
         THEN value ELSE value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) END VALUE
      FROM dba_hist_sysstat ST
      WHERE stat_name in(
        'physical writes' , 'CPU used by this session','DB time','db block changes',
        'concurrency wait time','application wait time','session logical reads','physical reads'))
       NATURAL JOIN 
     (SELECT snap_id,instance_number,
             to_char(begin_interval_time,'MMDD HH24:MI')||'-'||to_char(end_interval_time,'HH24:MI') STIME,
             (to_date(to_char(end_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS')
             -to_date(to_char(begin_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS'))*86400 AS seconds
      FROM dba_hist_snapshot 
      where instance_number=1
       and begin_interval_time>sysdate-7
      ) SN
 GROUP BY snap_id,
          STIME,
          seconds,instance_number
 ORDER BY SNAP_ID;

SET lines 160
COL stat_name FOR A50


SELECT SNAP_ID,
       BEGIN_TIME,
       END_TIME,
       SUM(CASE
             WHEN METRIC_NAME = 'Database Time Per Sec' THEN
              AVERAGE
           END) DBTIME,
       SUM(CASE
             WHEN METRIC_NAME = 'CPU Usage Per Sec' THEN
              AVERAGE
           END) CPUTIME
  FROM DBA_HIST_SYSMETRIC_SUMMARY
 WHERE METRIC_NAME IN ('Database Time Per Sec', 'CPU Usage Per Sec')
 GROUP BY SNAP_ID,BEGIN_TIME, END_TIME;


select SNAP_ID
,max(case when NAME = ':AT_FR' then VALUE_STRING end)AD_DATE_BF
,max(case when NAME = ':AT_TO' then VALUE_STRING end)AD_DATE_END
from dba_hist_sqlbind
where sql_id = '&sql_id'
group by snap_id;

SELECT BEGIN_TIME, END_TIME
  FROM SEROL.DBA_HIST_METRIC_NAME
 WHERE UPPER(METRIC_NAME) LIKE '%WAIT%';
 

SELECT SNAP_ID, STIME
       ,to_char(round(sum(CASE WHEN stat_name = 'DB time' THEN value END)/100/seconds,1),'990D0') DBTIME
       ,to_char(round(sum(CASE WHEN stat_name = 'CPU used by this session' THEN value END)/100/seconds,1),'990D0') CPU
       ,to_char(round(sum(CASE WHEN stat_name = 'physical writes' THEN value END)/seconds,1),'99990D0') PHW
       ,to_char(round(sum(CASE WHEN stat_name = 'physical reads' THEN value END)/seconds,1),'9999990D0') PHR
       ,to_char(round(sum(CASE WHEN stat_name = 'db block changes' THEN value END) /seconds,1),'99990D0') BLKCHG
       ,to_char(round(sum(CASE WHEN stat_name = 'concurrency wait time' THEN value END)/1e2/seconds,4),'990D0000') CONNR
FROM
    (SELECT snap_id, stat_name ,instance_number,
         CASE WHEN value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) < 0
        THEN value ELSE value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) END value
     FROM dba_hist_sysstat ST
     WHERE stat_name in(
       'physical writes' , 'CPU used by this session',
       'DB time','db block changes',
       'concurrency wait time','application wait time'))
      NATURAL JOIN
    (SELECT snap_id,instance_number,
            to_char(begin_interval_time,'MMDD HH24:MI')||'-'||to_char(end_interval_time,'HH24:MI') STIME,
            (to_date(to_char(end_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS')
              -to_date(to_char(begin_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS'))*86400 AS seconds
     FROM dba_hist_snapshot
    where instance_number=1  
      and begin_interval_time>sysdate-3
     ) SN
GROUP BY snap_id,
         STIME,
         seconds,instance_number
ORDER BY SNAP_ID;

SELECT *
  FROM DBA_HIST_SYSSTAT ST
 WHERE STAT_NAME IN ('user I/O wait time', 'CPU used by this session',
        'DB time', 'cluster wait time', 'concurrency wait time',
        'application wait time')
   AND INSTANCE_NUMBER = 1
 ORDER BY SNAP_ID;

SELECT VALUE
  FROM DBA_HIST_OSSTAT
 WHERE STAT_NAME IN ('IDLE_TIME', 'BUSY_TIME', 'USER_TIME', 'SYS_TIME');


SELECT SNAP_ID,
       STIME
      , round(sum(CASE WHEN stat_name = 'AVG_BUSY_TIME' THEN value END)/100/seconds,1) Busy
      , round(sum(CASE WHEN stat_name = 'AVG_IDLE_TIME' THEN value END)/seconds,1) IDLE
      , round(sum(CASE WHEN stat_name = 'AVG_USER_TIME' THEN value END) /seconds,1) USR
      , round(sum(CASE WHEN stat_name = 'AVG_SYS_TIME' THEN value END)/seconds,1) SYS
    --, sum(CASE WHEN stat_name = 'concurrency wait time' THEN value END)/1e2/seconds CON
FROM
    (SELECT snap_id, stat_name ,instance_number,
         CASE WHEN value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) < 0
        THEN value ELSE value - LAG(value) OVER (PARTITION BY stat_name,instance_number ORDER BY snap_id) END value
     FROM dba_hist_osstat ST
)
      NATURAL JOIN
    (SELECT snap_id,instance_number,
            to_char(begin_interval_time,'MMDD HH24:MI')||'-'||to_char(end_interval_time,'HH24:MI') STIME,
            (to_date(to_char(end_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS')
              -to_date(to_char(begin_interval_time,'YYYYMMDDHH24MISS'),'YYYYMMDDHH24MISS'))*86400 AS seconds
     FROM dba_hist_snapshot 
     where instance_number=1 
     and begin_interval_time>sysdate-3
     ) SN
GROUP BY snap_id,
         STIME,
         seconds,instance_number
ORDER BY SNAP_ID;

SELECT DISTINCT STAT_NAME FROM DBA_HIST_OSSTAT;












	SNAP_ID STIME			DBTIME CPU     PHW    BLKCHG PHY
1	17824	0709 12:00-13:00	12.2	0.5	521.4	323.1	
2	17825	0709 13:00-14:00	10	0.7	57.2	556.6	
3	17826	0709 14:00-15:00	16.2	1.1	75.1	662	
4	17827	0709 15:00-16:00	15.2	1.1	88.1	695.6	
5	17828	0709 16:00-17:00	24.6	0.8	63.7	624.1	
6	17829	0709 17:00-18:00	35.1	1.1	138	702.7	
7	17830	0709 18:00-19:00	7.6	0.9	113.7	2043.1	
8	17831	0709 19:00-20:00	2.6	0.5	71.5	462.1	
9	17832	0709 20:00-21:00	2.3	0.4	66.1	351.1	
10	17833	0709 21:00-22:00	14	0.5	68.9	553	
11	17834	0709 22:00-23:00	5.1	0.6	98.1	642	
12	17835	0709 23:00-00:00	2.1	0.2	64	262.3	
13	17836	0710 00:00-01:00	3.1	0.3	90.9	1185.5	
14	17837	0710 01:00-02:00	1.6	0.2	58.6	240.9	
15	17838	0710 10:55-11:06	12.3	0.8	22.6	1009.9	
16	17839	0710 11:06-12:00	15.8	1.2	471.8	865.2	
17	17840	0710 12:00-13:00	4.6	0.6	50.6	583.4	
18	17841	0710 13:00-14:00	6.6	0.8	421.1	610.5	
19	17842	0710 14:00-15:00	9.3	0.8	177	1051.5	
20	17843	0710 15:00-16:00	8.4	1.1	170.5	643.2	
21	17844	0710 16:00-17:00	9.2	1	96.7	639.1	
22	17845	0710 17:00-18:00	7.8	1	285.7	653.5	
23	17846	0710 18:00-19:00	3.6	0.5	76.1	1877.7	
24	17847	0710 19:00-20:00	2.2	0.4	70.8	354.7	
25	17848	0710 20:00-21:00	1.8	0.4	66.6	359	
26	17849	0710 21:00-22:00	1.8	0.4	63.8	470.3	
27	17850	0710 22:00-23:00	3.6	0.7	200.1	652.3	
28	17851	0710 23:00-00:00	1.7	0.2	59.9	331.5	
29	17852	0711 00:00-01:00	2.4	0.3	98.7	1036.1	
30	17853	0711 01:00-02:00	2.2	0.1	58.5	226.6	
31	17854	0711 02:00-03:00	1.9	0.2	64.4	165.9	
32	17855	0711 03:00-04:01	1.2	0.1	50.3	45.4	
33	17856	0711 04:01-05:00	1.2	0.3	393.1	27255.4	
34	17857	0711 05:00-06:00	1.4	0.7	324.8	13941.9	
35	17858	0711 06:00-07:00	3.3	0.1	149.8	1943.4	
36	17859	0711 07:00-08:00	2	0.2	56	161.8	
37	17860	0711 08:00-09:00	3.8	0.5	74.5	484.9	
38	17861	0711 09:00-10:00	10.4	1.5	69.1	895.5	
39	17862	0711 10:00-11:00	15.4	1.3	48.5	855	
40	17863	0711 11:00-12:00	13.3	1.3	58.2	833.8	
41	17864	0711 12:00-13:00	6.5	0.6	29.7	467.6	
42	17865	0711 13:00-14:00	18	0.9	42.1	701.5	
43	17866	0711 14:00-15:00	17.8	1	49.9	783.1	
44	17867	0711 15:00-16:00	14.7	1.1	183.1	793.7	
45	17868	0711 16:00-17:00	17.2	1.3	52.4	845	
46	17869	0711 17:00-18:00	10.4	1.2	42.7	708.6	
47	17870	0711 18:00-19:00	8.4	0.9	80.7	2091.5	
48	17871	0711 19:00-20:00	5.1	0.6	50.2	560.4	
49	17872	0711 20:00-21:00	2.6	0.6	77.8	680.3	
50	17873	0711 21:00-22:00	2.5	0.6	86.1	820.8	
51	17874	0711 22:00-23:00	4.8	0.7	79.9	723.1	
52	17875	0711 23:00-00:00	2	0.3	65.3	420.1	
53	17876	0712 00:00-01:00	2.5	0.4	100.2	1518.6	
54	17877	0712 01:00-02:00	1.6	0.2	57.8	198.7	
55	17878	0712 02:00-03:00	2.4	0.2	58.1	2791.4	
56	17879	0712 03:00-04:00	2.2	0.2	55.5	124.3	
57	17880	0712 04:00-05:00	2	0.3	250.1	17969.7	
58	17881	0712 05:00-06:00	1.5	0.6	457.2	20026.7	
59	17882	0712 06:00-07:00	5.2	0.5	208.2	5348	
60	17883	0712 07:00-08:00	1.7	0.2	59.7	211.7	
61	17884	0712 08:00-09:00	3.3	0.3	120.6	348	
62	17885	0712 09:00-10:00	4	0.6	76.1	503.5	
63	17886	0712 10:00-11:00	3	0.6	84.7	1845.6	
64	17887	0712 11:00-12:00	3.1	0.6	87.5	1415.9	
65	17888	0712 12:00-13:00	2.4	0.6	75.1	479.1	
66	17889	0712 13:00-14:00	3.9	0.7	84.4	527.7	
67	17890	0712 14:00-15:00	3.5	0.7	88.3	550.2	
68	17891	0712 15:00-16:00	3.2	0.7	88	760	
69	17892	0712 16:00-17:00	3.4	0.7	84.6	465	
70	17893	0712 17:00-18:00	2.7	0.5	59.1	583.6	
71	17894	0712 18:00-19:00	3	0.4	79.3	2199.2	
72	17895	0712 19:00-20:00	2.2	0.5	53.4	767.2	
73	17896	0712 20:00-21:00	2.1	0.5	80.9	780.9	
74	17897	0712 21:00-22:00	1.6	0.3	44.6	606.1	
75	17898	0712 22:00-23:00	2.8	0.7	86.5	718.7	
76	17899	0712 23:00-00:00	1.5	0.2	35.9	284.8	
77	17900	0713 00:00-01:00	2.6	0.4	136.4	1363.4	
78	17901	0713 01:00-02:00	3.6	0.2	61.6	327.5	
79	17902	0713 02:00-03:00	1.8	0.2	56.2	2705.2	
80	17903	0713 03:00-04:00	2.4	0.2	72.4	246.3	
81	17904	0713 04:00-05:00	1.8	0.2	264	19567.1	
82	17905	0713 05:00-06:00	1.4	0.6	444.7	18496.6	
83	17906	0713 06:00-07:00	5	0.4	202.7	5143	
84	17907	0713 07:00-08:00	1.7	0.2	73.7	186.7	
85	17908	0713 08:00-09:00	3.5	0.3	65	445	
86	17909	0713 09:00-10:00	4.1	1.1	76.5	531.8	
87	17910	0713 10:00-11:00	3.5	0.7	87.8	744.2	
88	17911	0713 11:00-12:00	3.2	0.5	78.9	494	
89	17912	0713 12:00-13:00	2.4	0.4	71.6	307.9	
90	17913	0713 13:00-14:00	2.6	0.5	79	508.2	
91	17914	0713 14:00-15:00	4.1	0.8	64.4	497	
92	17915	0713 15:00-16:00	3.1	0.6	40.9	634.1	
93	17916	0713 16:00-17:00	4.2	0.9	37.4	548.2	
94	17917	0713 17:00-18:01	2.7	0.6	42.1	787.3	
95	17918	0713 18:01-19:00	3.5	0.6	77.8	2490	
96	17919	0713 19:00-20:00	2	0.4	47.8	326.1	
97	17920	0713 20:00-21:00	1.6	0.3	64.9	364.9	
98	17921	0713 21:00-22:00	1.7	0.3	66.5	508.1	
99	17922	0713 22:00-23:00	1.7	0.3	65.4	292.4	
100	17923	0713 23:00-00:00	1.5	0.2	67	239.4	
101	17924	0714 00:00-01:00	2.7	0.3	109.7	1175.8	
102	17925	0714 01:00-02:00	2.3	0.3	66.8	226.9	
103	17926	0714 02:00-03:00	1.8	0.2	69.2	2754.2	
104	17927	0714 03:00-04:00	2.2	0.1	57.7	196.6	
105	17928	0714 04:00-05:00	1.8	0.2	260.7	19229.4	
106	17929	0714 05:00-06:00	1.3	0.5	423	18100	
107	17930	0714 06:00-07:04	2	0.3	273.1	9474.6	
108	17931	0714 07:04-08:00	4.7	0.3	81.1	2859.7	
109	17932	0714 08:00-09:00	4.5	0.4	76.3	286.6	
110	17933	0714 09:00-10:00	8.9	1.2	57.5	1185.5	
111	17934	0714 10:00-11:00	11.3	0.9	47.2	1214.6	