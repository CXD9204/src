!echo ''
!echo '##########�鿴���ռ�ʹ�����##########'

set linesize 1000
col tablespace_name for a30
select a.tablespace_name,a.all_space,b.free_space,b.free_space/a.all_space*100 free_ratio from
(select t.tablespace_name, round(sum(bytes/(1024*1024)),0) all_space 
from dba_tablespaces t, dba_data_files d 
where t.tablespace_name = d.tablespace_name 
group by t.tablespace_name) a,
(select sum(bytes)/(1024*1024) as free_space,tablespace_name 
from dba_free_space 
group by tablespace_name) b where a.tablespace_name=b.tablespace_name;



!echo ''
!echo '##########�鿴���ռ���Ƭ���##########'

col tablespace_name for a30
select tablespace_name,count(*) chunks,max(bytes/1024/1024) max_chunk
from dba_free_space
group by tablespace_name;

!echo ''
!echo '##########�鿴�����ļ����##########'
col name for a30
select status,name from v$controlfile;


!echo ''
!echo '##########�鿴redo�ļ����##########'
col member for a30
select * from v$logfile;


!echo ''
!echo '##########�鿴�鵵�ļ�·��##########'
col name for a30
col value for a30
select name,value from v$parameter where name like '%log_archive_dest_%';


!echo ''
!echo '##########�鿴�����ļ�##########'

col file_name for a30
select file_id,file_name,status  from dba_data_files;

!echo ''
!echo '##########�鿴��Ч����##########'
col object_name for a30
col object_type for a30
col status for a30
select owner,object_name,object_type,status from dba_objects where status='INVALID';

!echo ''
!echo '##########�鿴SCN��Ϣ##########'
select dbms_flashback.get_system_change_number, SCN_TO_TIMESTAMP(dbms_flashback.get_system_change_number) from dual;


!echo ''
!echo '##########�鿴���ٻ�����ʹ�����##########'

select sum(decode(NAME, 'consistent gets', VALUE, 0)) "Consistent Gets",
       sum(decode(NAME, 'db block gets', VALUE, 0)) "DB Block Gets",
       sum(decode(NAME, 'physical reads', VALUE, 0)) "Physical Reads",
       round((sum(decode(name, 'consistent gets', value, 0)) +
             sum(decode(name, 'db block gets', value, 0)) -
             sum(decode(name, 'physical reads', value, 0))) /
             (sum(decode(name, 'consistent gets', value, 0)) +
             sum(decode(name, 'db block gets', value, 0))) * 100,
             2) "Hit Ratio"
  from v$sysstat;


!echo ''
!echo '##########�鿴�⻺��������##########'

select Sum(Pins)/(Sum(Pins) + Sum(Reloads)) * 100 "Hit Ratio" from V$LibraryCache;

!echo ''
!echo '##########�鿴�����ֵ仺��������##########'

select (1-(sum(getmisses)/sum(gets))) * 100 "Hit Ratio" from v$rowcache; 


!echo ''
!echo '##########�鿴�⻺��ʧ����##########'

select sum(PINS) pins, sum(RELOADS) misses, sum(RELOADS) / sum(PINS) "library cache miss_ratio" from v$librarycache;


!echo ''
!echo '##########�鿴�����ֵ仺��ʧ����##########'

SELECT SUM (getmisses) misses,SUM (gets) gets,SUM (getmisses) / SUM (gets)  "Dictionary Cache miss Ratio"
FROM v$rowcache;

!echo ''
!echo '##########�鿴�������##########'

!lsnrctl status


!echo ''
!echo '##########�鿴��ǰ�Ự���##########'

col os_user_name for a10
col program for a30
col serial_num for a30
col terminal for a10
col user_name for a10
select s.sid,s.osuser os_user_name, status session_status,    s.terminal terminal,    s.program program,   
s.username user_name from v$session s,    v$process p   where s.paddr=p.addr and    s.type = 'USER' 
order by s.username, s.osuser;

!echo ''
!echo '##########�鿴�û����##########'
col username for a30
col account_status for a20
col default_tablespace for a20
col temporary_tablespace for a20
col profile for a20
select user_id,username,account_status,default_tablespace,temporary_tablespace,profile from dba_users;

!echo ''
!echo '##########�鿴OCR�������##########'

!olsnodes
!ocrcheck
!ocrconfig -showbackup
!crsctl check crs


!echo ''
!echo '##########�鿴RAC��Դ���##########'

!crs_stat -t
!srvctl config database
!srvctl config database -d dbname
!srvctl status database -d dbname
!srvctl status instance -d dbname -i instname
!srvctl start nodeapps -n node1


!echo ''
!echo '##########�鿴���ݿⲹ��##########'

!$ORACLE_HOME/OPatch/opatch lsinventory

exit
exit
EOF

