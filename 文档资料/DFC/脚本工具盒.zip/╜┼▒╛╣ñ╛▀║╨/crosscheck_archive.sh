#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/db
export ORACLE_TERM=xterm

export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib:$ORACLE_HOME/rdbms/lib
export PATH=$ORACLE_HOME/bin:/usr/bin:/usr/sbin:$PATH

export LANG=en_US
export NLS_LANG=american_america.ZHS16GBK


touch crosscheck_archive.log
#>crosscheck_archive.log

rman target / cmdfile=crosscheck_archive.cmd log=crosscheck_archive.log append

