#!/bin/bash

. /home/oracle/.bash_profile
. /home/oracle/ruanct/awrrpt/util/util_datetime.sh
. /home/oracle/ruanct/awrrpt/util/util_function.sh

V_TODAY=`date +%Y%m%d`
TARGET_DATE=${V_TODAY}

V_AWR_PATH=/home/oracle/ruanct/awrrpt
V_AWR_DATE=`getDateAfter ${V_TODAY} -1`
V_TGT_YYMM=`expr substr ${V_AWR_DATE} 1 6`

mkdir -p ${V_AWR_PATH}/${V_TGT_YYMM}
cd ${V_AWR_PATH}/${V_TGT_YYMM}

DB_USR_NAME=r7
DB_USR_PSWD=1qaz!QAZ

DB_SRV_AKU="10.1.195.175/xtbg"
DB_SRV_BKU="10.1.195.185/xtbgkz"
DB_SRV_CKU="10.1.195.180:11521/zbxt"
DB_SRV_SHK="10.110.25.135:11521/xtbg"

DB_ALIAS_AKU="xtbg_aku"
DB_ALIAS_BKU="xtbg_bku"
DB_ALIAS_CKU="xtbg_cku"
DB_ALIAS_SHK="xtbg_shk"

EXEC_SQL_AKU=tmpAwrAku.sql
EXEC_SQL_BKU=tmpAwrBku.sql
EXEC_SQL_CKU=tmpAwrCku.sql
EXEC_SQL_SHK=tmpAwrShk.sql

AWR_UTIL_ISQL=/home/oracle/ruanct/awrrpt/util/yirong_awrextr_bytime.sql

> ${EXEC_SQL_SHK}
echo "@${AWR_UTIL_ISQL} ${DB_ALIAS_SHK} ${TARGET_DATE}-0830 ${TARGET_DATE}-0900 1" >> ${EXEC_SQL_SHK}

pubExecSQL ${DB_USR_NAME} ${DB_USR_PSWD} ${DB_SRV_SHK} ${EXEC_SQL_SHK}
tgz_file_name="${V_TODAY}_${DB_ALIAS_SHK}_awrrpt.tar.gz"
tar -zcvf ${tgz_file_name} *.html
rm -rf *.html
ftpPut "10.1.49.171" yirong 112233.... ${V_AWR_PATH}/${V_TGT_YYMM} "/02.各项目和个人目录/R阮春图/awrrpt" ${tgz_file_name}


> ${EXEC_SQL_AKU}
echo "@${AWR_UTIL_ISQL} ${DB_ALIAS_AKU} ${TARGET_DATE}-0830 ${TARGET_DATE}-0900 1" >> ${EXEC_SQL_AKU}

pubExecSQL ${DB_USR_NAME} ${DB_USR_PSWD} ${DB_SRV_AKU} ${EXEC_SQL_AKU}
tgz_file_name="${V_TODAY}_${DB_ALIAS_AKU}_awrrpt.tar.gz"
tar -zcvf ${tgz_file_name} *.html
rm -rf *.html
ftpPut  "10.1.49.171" yirong 112233.... ${V_AWR_PATH}/${V_TGT_YYMM} "/02.各项目和个人目录/R阮春图/awrrpt" ${tgz_file_name}

> ${EXEC_SQL_BKU}
echo "@${AWR_UTIL_ISQL} ${DB_ALIAS_BKU} ${TARGET_DATE}-0830 ${TARGET_DATE}-0900 1" >> ${EXEC_SQL_BKU}

pubExecSQL ${DB_USR_NAME} ${DB_USR_PSWD} ${DB_SRV_BKU} ${EXEC_SQL_BKU}
tgz_file_name="${V_TODAY}_${DB_ALIAS_BKU}_awrrpt.tar.gz"
tar -zcvf ${tgz_file_name} *.html
rm -rf *.html
ftpPut  "10.1.49.171" yirong 112233.... ${V_AWR_PATH}/${V_TGT_YYMM} "/02.各项目和个人目录/R阮春图/awrrpt" ${tgz_file_name}

> ${EXEC_SQL_CKU}
echo "@${AWR_UTIL_ISQL} ${DB_ALIAS_CKU} ${TARGET_DATE}-0830 ${TARGET_DATE}-0900 1" >> ${EXEC_SQL_CKU}

pubExecSQL ${DB_USR_NAME} ${DB_USR_PSWD} ${DB_SRV_CKU} ${EXEC_SQL_CKU}
tgz_file_name="${V_TODAY}_${DB_ALIAS_CKU}_awrrpt.tar.gz"
tar -zcvf ${tgz_file_name} *.html
rm -rf *.html
ftpPut  "10.1.49.171" yirong 112233.... ${V_AWR_PATH}/${V_TGT_YYMM} "/02.各项目和个人目录/R阮春图/awrrpt" ${tgz_file_name}

rm -rf $EXEC_SQL_AKU
rm -rf $EXEC_SQL_BKU
rm -rf $EXEC_SQL_CKU
rm -rf $EXEC_SQL_SHK

