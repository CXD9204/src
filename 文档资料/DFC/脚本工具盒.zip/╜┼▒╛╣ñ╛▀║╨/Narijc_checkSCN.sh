#!/bin/bash

export ORACLE_SID=xtbg1
export ORACLE_BASE=/u01/app/oracle
export ORACLE_HOME=/u01/app/oracle/product/11.2.0/db
export ORACLE_TERM=xterm
export LD_LIBRARY_PATH=$ORACLE_HOME/lib:/lib:/usr/lib:$ORACLE_HOME/rdbms/lib
export PATH=$ORACLE_HOME/bin:/usr/bin:/usr/sbin:$PATH
export LANG=en_US
export NLS_LANG=american_america.ZHS16GBK

## or source profile
#source ~/.bash_profile

LOG_DIR=/home/oracle/ruanct/logs
mkdir -p $LOG_DIR
DATESTR=`date "+%Y%m%d"`

sqlplus / as sysdba << !
set lines 160
set pages 100
set head on
set trimspool on
spool ${LOG_DIR}/scn_check_${DATESTR}_dbAABJ.txt

@/u01/app/oracle/product/11.2.0/db/suptools/raccheck/.cgrep/scnhealthcheck.sql

SELECT VERSION,
       TO_CHAR(SYSDATE, 'YYYY/MM/DD HH24:MI:SS') DATE_TIME,
       ((((((TO_NUMBER(TO_CHAR(SYSDATE, 'YYYY')) - 1988) * 12 * 31 * 24 * 60 * 60) +
       ((TO_NUMBER(TO_CHAR(SYSDATE, 'MM')) - 1) * 31 * 24 * 60 * 60) +
       (((TO_NUMBER(TO_CHAR(SYSDATE, 'DD')) - 1)) * 24 * 60 * 60) +
       (TO_NUMBER(TO_CHAR(SYSDATE, 'HH24')) * 60 * 60) +
       (TO_NUMBER(TO_CHAR(SYSDATE, 'MI')) * 60) +
       (TO_NUMBER(TO_CHAR(SYSDATE, 'SS')))) * (16 * 1024)) -
       DBMS_FLASHBACK.GET_SYSTEM_CHANGE_NUMBER) /
       (16 * 1024 * 60 * 60 * 24)) INDICATOR
  FROM V\$INSTANCE;

select ss.snap_id as snap_id,
       to_char(sn.BEGIN_INTERVAL_TIME, 'yyyy-mm-dd hh24:mi:ss') as "snap_date",
       sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
       lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1) over(order by ss.snap_id) "kcmgas",
       trunc((sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
             lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1)
              over(order by ss.snap_id)) /
             trunc((cast(SN.END_INTERVAL_TIME as date) -
                   cast(SN.BEGIN_INTERVAL_TIME as date)) * 86400)) "kcmgas per sec"
  from SYS.DBA_HIST_sysstat ss, SYS.DBA_HIST_snapshot sn
 where ss.snap_id = sn.snap_id
   and ss.stat_name in ('calls to kcmgas')
   and ss.dbid = sn.dbid
   and ss.instance_number = sn.instance_number
   and sn.instance_number = 1
   and sn.dbid = (select dbid from v\$database)
 group by ss.snap_id, sn.BEGIN_INTERVAL_TIME, sn.end_interval_time
 order by ss.snap_id;
 
select ss.snap_id as snap_id,
       to_char(sn.BEGIN_INTERVAL_TIME, 'yyyy-mm-dd hh24:mi:ss') as "snap_date",
       sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
       lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1) over(order by ss.snap_id) "kcmgas",
       trunc((sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
             lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1)
              over(order by ss.snap_id)) /
             trunc((cast(SN.END_INTERVAL_TIME as date) -
                   cast(SN.BEGIN_INTERVAL_TIME as date)) * 86400)) "kcmgas per sec"
  from SYS.DBA_HIST_sysstat ss, SYS.DBA_HIST_snapshot sn
 where ss.snap_id = sn.snap_id
   and ss.stat_name in ('calls to kcmgas')
   and ss.dbid = sn.dbid
   and ss.instance_number = sn.instance_number
   and sn.instance_number = 2
   and sn.dbid = (select dbid from v\$database)
 group by ss.snap_id, sn.BEGIN_INTERVAL_TIME, sn.end_interval_time
 order by ss.snap_id;

select ss.snap_id as snap_id,
       to_char(sn.BEGIN_INTERVAL_TIME, 'yyyy-mm-dd hh24:mi:ss') as "snap_date",
       sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
       lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1) over(order by ss.snap_id) "kcmgas",
       trunc((sum(decode(stat_name, 'calls to kcmgas', value, 0)) -
             lag(sum(decode(stat_name, 'calls to kcmgas', value, 0)), 1)
              over(order by ss.snap_id)) /
             trunc((cast(SN.END_INTERVAL_TIME as date) -
                   cast(SN.BEGIN_INTERVAL_TIME as date)) * 86400)) "kcmgas per sec"
  from SYS.DBA_HIST_sysstat ss, SYS.DBA_HIST_snapshot sn
 where ss.snap_id = sn.snap_id
   and ss.stat_name in ('calls to kcmgas')
   and ss.dbid = sn.dbid
   and ss.instance_number = sn.instance_number
   and sn.instance_number = 3
   and sn.dbid = (select dbid from v\$database)
 group by ss.snap_id, sn.BEGIN_INTERVAL_TIME, sn.end_interval_time
 order by ss.snap_id;

spool off
exit
!
