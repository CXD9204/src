#!/bin/bash

. ~/.bash_profile

export ORACLE_TERM=xterm
export LANG=en_US
export NLS_LANG=american_america.ZHS16GBK

usage(){
    echo ""
    echo "usage: $0 <databaseName> <beginTime> <endTime>"
    echo "  1, databaseName, mandatory parameter"
    echo "  2, beginTime,    mandatory parameter, format: yyyymmdd-hh24mi"
    echo "  3, endTime,      mandatory parameter, format: yyyymmdd-hh24mi"
    echo ""
    echo "  for example: $0 xtbgdba 20161120-0830 20161120-1030"
    echo ""
    echo "  generate awr report file name is:"
    echo "  <databaseName>_rac_<beginTime>_<endTime>.html"
    echo ""
}

if [ $# -eq 1 ]; then
  if [ "$1" == "-h" -o "$1" == "-H" ]; then
    usage
    exit
  fi
fi

if [ $# -ne 3 ]; then
 usage
 exit
fi

snap_interval=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select trunc(extract(day from snap_interval) * 24 * 60 +
       extract(hour from snap_interval) * 60 +
       extract(minute from snap_interval))
  from dba_hist_wr_control;
exit
EOF`
echo `date` snap_interval $snap_interval

snap_bid=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select min(snap_id)||'' from dba_hist_snapshot where end_interval_time
  between to_date('$2', 'yyyymmdd-hh24mi') - ${snap_interval} / 2 / 1440
  and to_date('$2', 'yyyymmdd-hh24mi') + ${snap_interval} / 2 / 1440
  ;
exit
EOF`
echo `date` snap_bid $snap_bid

snap_eid=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select max(snap_id)||'' from dba_hist_snapshot where end_interval_time
  between to_date('$3', 'yyyymmdd-hh24mi') - ${snap_interval} / 2 / 1440
  and to_date('$3', 'yyyymmdd-hh24mi') + ${snap_interval} / 2 / 1440
  ;
exit
EOF`
echo `date` snap_eid $snap_eid

if [ "${snap_bid}" = "" ]; then
 echo " begin snap_id is null, please validate begin datetime!"
 exit
fi

if [ "${snap_eid}" = "" ]; then
 echo " end snap_id is null, please validate end datetime!"
 exit
fi

if [ "${snap_bid}" = "${snap_eid}" ]; then
 echo " begin snap_id equals to end snap_id, please validate datetime values !"
 echo " begin datetime cann't equals to end datetime!"
 exit
fi

error_file=tmp_yirong_awrrpt_error.log
touch ${error_file}
echo $snap_bid | grep ERROR >> ${error_file}
echo $snap_eid | grep ERROR >> ${error_file}
error_num=`cat ${error_file} | grep ERROR |wc -l`

if [ ${error_num} -gt 0 ]; then
  cat ${error_file} | awk -F "ERROR" '{print $2}' |awk -F "ORA-" '{print "ORA-"$2}'
  echo "please validate beginTime or endTime!"
  rm -rf ${error_file}
  exit
else
  rm -rf ${error_file}
fi

dbid=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select dbid from v\\$database;
exit
EOF`
echo `date` dbid $dbid

snap_bid_end_time=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select to_char(min(end_interval_time), 'yymmdd-hh24mi')
  from dba_hist_snapshot
 where snap_id = $snap_bid;
exit
EOF`
echo `date` snap_bid_end_time $snap_bid_end_time

snap_eid_end_time=`sqlplus -S /nolog << EOF
set heading off feedback off pagesize 0 verify off echo off
conn / as sysdba
select to_char(max(end_interval_time), 'yymmdd-hh24mi')
  from dba_hist_snapshot
 where snap_id = ${snap_eid};
exit
EOF`
echo `date` snap_eid_end_time $snap_eid_end_time

report_name="$1_rac_${snap_bid_end_time}_${snap_eid_end_time}.html"
rpt_options=0
echo `date` report_name $report_name

MYPWD=`pwd`
mkdir -p ~/ruanct/awr
cd ~/ruanct/awr

sqlplus / as sysdba <<!
set echo off;
set veri off;
set feedback off;
set heading off;
set underline on;
set pagesize 50000;
set linesize 8000;
set trimspool on;
set termout on;
spool ${report_name}
select output from table(dbms_workload_repository.awr_global_report_html(${dbid}, '', ${snap_bid}, ${snap_eid}, ${rpt_options}));
spool off;
exit;
!

