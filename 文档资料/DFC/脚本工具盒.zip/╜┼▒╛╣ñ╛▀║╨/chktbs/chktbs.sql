
set lines 100
set pages 50
col instance_name for a30
col value for a30

spool C:\ruanct\chktbs\chktbs.info append

select '&1' as describe ,value as instance_name,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') as query_time
 from v$parameter where name='instance_name';
 
SELECT UPPER(F.TABLESPACE_NAME) "TBS_NAME",
       D.TOT_GROOTTE_MB "TBS_SIZE(M)",
       D.TOT_GROOTTE_MB - F.TOTAL_BYTES "USE_SIZE(M)",
       TO_CHAR(ROUND((D.TOT_GROOTTE_MB - F.TOTAL_BYTES) / D.TOT_GROOTTE_MB * 100,
                     2),
               '990.99') "USE_PCT",
       F.TOTAL_BYTES "FREE_SIZE(M)",
       F.MAX_BYTES "MAX_BYTES(M)"
  FROM (SELECT TABLESPACE_NAME,
               ROUND(SUM(BYTES) / (1024 * 1024), 2) TOTAL_BYTES,
               ROUND(MAX(BYTES) / (1024 * 1024), 2) MAX_BYTES
          FROM SYS.DBA_FREE_SPACE
         GROUP BY TABLESPACE_NAME) F,
       (SELECT DD.TABLESPACE_NAME,
               ROUND(SUM(DD.BYTES) / (1024 * 1024), 2) TOT_GROOTTE_MB
          FROM SYS.DBA_DATA_FILES DD
         GROUP BY DD.TABLESPACE_NAME) D
WHERE D.TABLESPACE_NAME = F.TABLESPACE_NAME
ORDER BY 4 DESC;


SELECT GROUP_NUMBER,
       NAME,
       BLOCK_SIZE,
       TOTAL_MB,
       FREE_MB,
       ROUND((TOTAL_MB - FREE_MB) / TOTAL_MB * 100, 2) AS USE_PCT
  FROM V$ASM_DISKGROUP
 ORDER BY 6 DESC;

spool off

exit
