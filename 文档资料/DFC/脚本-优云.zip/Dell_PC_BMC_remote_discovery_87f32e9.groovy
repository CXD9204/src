/*!Action
action.name=Dell_PC_BMC_remote_discovery_87f32e9
action.descr=Dell_PC_BMC_remote_discovery
action.version=1.0.0
action.protocols=http
action.main.model=PCServer
discovery.output=Computer
*/

/*!Params
ip:目标设备IP,ip,,true
username:用户名,text,,false
port:端口,number,443,false
password:密码,password,,false
*/

/*!Model
PCServer:PC服务器,PCServer,PC服务器,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
serial_number:序列号,string,null,null,serial_number,序列号
bmc_version:BMC固件版本,string,null,null,bmc_version,BMC固件版本
phys_size:物理容量,string,null,null,phys_size,物理容量
hardDiskInfo:硬盘,inline,null,null,hardDiskInfo,硬盘
serverVDisk:服务器虚拟磁盘,inline,null,null,serverVDisk,服务器虚拟磁盘
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties:
name:名称,string,null,null,name,名称
disk_num:硬盘数量,int,null,块,disk_num,硬盘数量
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/
 
/*!Model
ServerVDisk:服务器虚拟磁盘,ServerVDisk,服务器虚拟磁盘,true,false
properties
raid_level:RAID级别,string,null,null,raid_level,RAID级别
name:名称,string,null,null,name,名称
vdisk_size:虚拟磁盘大小,string,null,null,vdisk_size,虚拟磁盘大小
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;


def httpclientBuild = HttpClientBuilder.create().setSSLSocketFactory(getSSL());
def provider = new BasicCredentialsProvider();
def credentials = new UsernamePasswordCredentials($scriptParams.username, $scriptParams.password);
provider.setCredentials(AuthScope.ANY, credentials);
httpclientBuild.setDefaultCredentialsProvider(provider)
httpclient = httpclientBuild.build();
baseUrl = "https://" + $scriptParams.ip + ":" + $scriptParams.port;

def systemUrls = getUrlKeyData('/redfish/v1/Systems/', 'Members');
if(!systemUrls){
	$logger.logError("find Systems/Members error");
	return ;
}

def body = doGet(systemUrls[0])
def obj = JSONObject.parseObject(body);
def serialNumber = obj.getString("SKU");
def model = obj.getString("Model");

def pcServerCi = $ci.create("PCServer", "PCServer", model + '/' + serialNumber);
pcServerCi.ip = $scriptParams.ip;
pcServerCi.serial_number = serialNumber;

def storage = obj.getJSONObject("Storage")
if(storage){
	discovery_disk_9_above(pcServerCi, storage.getString("@odata.id"))
}
else {
	discovery_disk_8_under(pcServerCi)
}

body = doGet(obj.getJSONObject("Links").getJSONArray("ManagedBy").getJSONObject(0).getString("@odata.id"))
obj = JSONObject.parseObject(body);
pcServerCi.bmc_version = obj.FirmwareVersion





def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def getUrlKeyData(url, key){
	def body = doGet(url)
	def results = [];
	def obj = JSONObject.parseObject(body);
	def array = obj.getJSONArray(key);
	def size = array.size();
	for(def i = 0; i < size; i++){
		def str = array.getJSONObject(i).getString("@odata.id");
		results.add(str);
	}
	return results;
}

def discovery_disk_9_above(pcServerCi, storageUrl){
	def pDisks = []
	def vDisks = []
	for(def url in getUrlKeyData(storageUrl, 'Members')){
		def body = doGet(url)
		def obj = JSONObject.parseObject(body)
		
		def diskInfos = [:]
		def driveUrls = obj.getJSONArray("Drives")
		for(def i = 0; i < driveUrls.size(); i++){
			def physicalDriveUrl = driveUrls.getJSONObject(i).getString("@odata.id")
			def pdisk = discovery_9_above_physical_drive(physicalDriveUrl)
			pDisks.add(pdisk)
			diskInfos.put(physicalDriveUrl, pdisk)
		}
		
		def volumeUrls = obj.getJSONObject("Volumes").getString("@odata.id")
		for(def volumeUrl in getUrlKeyData(volumeUrls, 'Members')){
			vDisks.add(discovery_9_above_logical_drive(volumeUrl, diskInfos))
		}
		
	}
	discovery_disk_info(pcServerCi, pDisks, vDisks)
}

def discovery_9_above_physical_drive(url){
	def body = doGet(url)
	def obj = JSONObject.parseObject(body);
	return [
		model : obj.Model,
		disk_type : obj.Protocol.toLowerCase(),
		disk_size : obj.CapacityBytes,
		disk_media : obj.MediaType.toLowerCase(),
		disk_rpm : obj.RotationSpeedRPM + ' rpm'
	];
}

def discovery_9_above_logical_drive(url, diskInfos){
	def volumeTypeMap = ["NonRedundant" : "RAID 0", "Mirrored" : "RAID 1", "StripedWithParity" : "RAID 5", "SpannedMirrors" : "RAID 10", "SpannedStripesWithParity" : "RAID 50"];
	def body = doGet(url)
	def obj = JSONObject.parseObject(body);
	def drives = obj.getJSONObject("Links").getJSONArray("Drives")
	def disk = null

	for(def i = 0; i < drives.size(); i++){
		def key = drives.getJSONObject(i).getString("@odata.id");
		disk = diskInfos[key]
		if(disk){
			break
		}
	}
	return [
		name : obj.Name,
		disk_size : obj.CapacityBytes,
		disk_media : disk ? disk.disk_media : null,
		raid_level: volumeTypeMap[obj.VolumeType]
	];
}

def discovery_disk_info(pcServerCi, pDisks, vDisks){
	def pDiskMap = [:];
	def physSize = 0l;
	for(def pDisk in pDisks){
		def name = pDisk.model;
		if(name in pDiskMap){
			pDiskMap[name]['disk_num'] += 1
		}
		else {
			pDiskMap[name] = [
                disk_num : 1,
                disk_type : pDisk.disk_type,
                disk_size : convert_bytes(pDisk.disk_size),
                disk_media : pDisk.disk_media,
                disk_rpm : pDisk.disk_rpm
            ]
		}
		physSize += pDisk.disk_size
	}
	pcServerCi.phys_size = convert_bytes(physSize)
	pDiskMap.each { key, value ->
		 def ci = $ci.create('HardDiskInfo', key);
    	 ci.putAll(value);
    	 $ci.createRelationship('Inlines', pcServerCi.id, ci.id)
	}
	
	for(vDisk in vDisks){
		def ci = $ci.create('ServerVDisk', vDisk.name);
    	$ci.createRelationship('Inlines', pcServerCi.id, ci.id)
    	ci.putAll([
    		vdisk_size : convert_bytes(vDisk.disk_size),
    		raid_level : vDisk.raid_level,
    		disk_media : vDisk.disk_media
    	])
	}
}

def discovery_disk_8_under(pcServerCi){
	headers = [];
	def method = null;
	def response = null;
	try{
		method = new HttpPost(baseUrl + "/data/login");
		method.addHeader("Accept", "*/*");
		method.addHeader("Connection", "close");
		def parameters = [];
	    parameters.add(new BasicNameValuePair("user", $scriptParams.username));
	    parameters.add(new BasicNameValuePair("password", $scriptParams.password));
	    method.setEntity(new UrlEncodedFormEntity(parameters, "UTF-8"));
	    response = httpclient.execute(method);
	    def cookie = response.getFirstHeader("Set-Cookie").getValue();
	    String result = EntityUtils.toString(response.getEntity(), "UTF-8");
	    def code = findAllFirst(result, "ST2=(\\d|\\w+)</")
        if(!code){
        	throw new RuntimeException(result);
        }
        headers.add(new HeadParam("Cookie", cookie))
        headers.add(new HeadParam("ST2", code))
        headers.add(new HeadParam("X_SYSMGMT_OPTIMIZE", "true"))
        
        def pDisks = discovery_disk_8_under_physical_drive(headers)
        def vDisks = discovery_disk_8_under_logical_drive(headers)

        discovery_disk_info(pcServerCi, pDisks, vDisks)
	}finally{
		close(method)
		close(response)
		if(headers){//退出
			doGet("/data/logout", headers)
		}
	}
}

def discovery_disk_8_under_physical_drive(headers){
	def body = doGet("/sysmgmt/2010/storage/pdisk", headers)
    def obj = JSONObject.parseObject(body);
	def disks = obj.getJSONObject("PDisks").keySet().stream().filter{e->e.indexOf("|C|") != -1}.collect(Collectors.toList());


	def protocolTypeMap = [16 : "sata", 32 : "sas" , 64 : "pcie" , 256 : "NVMe"];
	def diskMediaMap = [0 : "hdd", 2 : "ssd"];
	body = doGet("/sysmgmt/2010/storage/pdisk?keys=" + encodeParams(disks.join(",")), headers);
	obj = JSONObject.parseObject(body);
	def pDisks = obj.getJSONObject("PDisks");
	def diskInfos = [];
	for(String disk in disks){
		JSONObject diskInfo = pDisks.getJSONObject(disk);
		
		diskInfos.add([
			model : diskInfo.getString("product_id"),
			disk_type : protocolTypeMap[diskInfo.getIntValue("protocol")],
			disk_size : diskInfo.getLong("size"),
			disk_media : diskMediaMap[diskInfo.getIntValue("media_type")]
		])
	}
	return diskInfos;
}

def discovery_disk_8_under_logical_drive(headers){
	def body = doGet("/sysmgmt/2010/storage/vdisk", headers)
    def obj = JSONObject.parseObject(body);
	def disks = obj.getJSONObject("VDisks").keySet().stream().filter{e->e.indexOf("|C|") != -1}.collect(Collectors.toList());

	def volumeTypeMap = [2 : "RAID 0", 4 : "RAID 1", 64 : "RAID 5", 128 : "RAID 6", 2048 : "RAID 10", 8192 : "RAID 50", 16384 : "RAID 60", 32768 : "raid1concat", 65536 : "raid5concat"]
	def diskMediaMap = [8 : "hdd", 4 : "ssd"];
	body = doGet("/sysmgmt/2010/storage/vdisk?keys=" + encodeParams(disks.join(",")), headers);
	obj = JSONObject.parseObject(body);
	def pDisks = obj.getJSONObject("VDisks");
	def diskInfos = [];
	for(String disk in disks){
		JSONObject diskInfo = pDisks.getJSONObject(disk);
		
		diskInfos.add([
			name : diskInfo.getString("name"),
			disk_size : diskInfo.getLong("size"),
			disk_media : diskMediaMap[diskInfo.getIntValue("media_type")],
			raid_level : volumeTypeMap[diskInfo.getIntValue("raidlevel")]
		])
	}
	return diskInfos;
}

def encodeParams(param){
	return URLEncoder.encode(param, "UTF-8").replace("+", "%20");
}

def doGet(url, headers=[]) {
	def response = null;
	def method = null;
	try{
		method = new HttpGet(baseUrl + url);
		method.addHeader("Accept", "*/*");
		method.addHeader("Connection", "close");
		for(def header in headers){
			method.addHeader(header.name, header.value);
		}
		response = httpclient.execute(method);
		def entity = response.getEntity();
		def code = response.getStatusLine().getStatusCode();
		def body = "";
		if(entity){
			body = EntityUtils.toString(entity, "UTF-8");
		}
		//println url + "!" + code
		if(!responseIsSuccess(code)){
			throw new RuntimeException("httpErroe!url:${url},responseCode:${code},responseBody${body}")
		}
		return body;
	} finally {
		close(method)
		close(response)
	}
}

def close(obj){
	try{
		if(obj){
			obj.close();
		}
	}catch(Exception e){
		
	}
}

class HeadParam{
	def name;
	def value;
	public HeadParam(name, value){
		this.name = name;
		this.value = value;
	}
}

def responseIsSuccess(code){
    if (code >= 200 && code < 300){
        return true;
    }
    return false;
}

def getSSL(){
	def sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
	    //信任所有
	    public boolean isTrusted(X509Certificate[] chain,
	        String authType) throws CertificateException {
	        return true;
	    }
	
	}).build();
	
	def sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
	return sslsf;
}