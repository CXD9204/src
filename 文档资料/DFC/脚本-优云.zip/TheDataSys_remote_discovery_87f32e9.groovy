/*!Action
action.name=TheDataSys_remote_discovery_87f32e9
action.descr=TheDataSys_remote_discovery(snmp v1/v2c)  支持天华星航 THEUSS8000A  THEUSS5000
action.version=1.0.0
action.protocols=snmp
action.main.model=FCStorage
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
FCStorage:FC存储,FCStorage,FC存储,false,false
properties
front_port_num:前端端口数量,int,null,null,front_port_num,前端端口数量
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
data_cache:数据缓存,string,null,null,data_cache,数据缓存
mt_model:M/T型号,string,null,null,mt_model,M/T型号
hostname:主机名,string,null,null,hostname,主机名
unconfigured_size:未配置容量,string,null,null,unconfigured_size,未配置容量
model:型号,string,null,null,model,型号
fcstge_brand:品牌,string,null,null,fcstge_brand,品牌
ip:带外管理IP,string,null,null,ip,带外管理IP
version:软件版本(固件版本),string,null,null,version,软件版本(固件版本)
hotspare_num:热备盘个数,int,null,null,hotspare_num,热备盘个数
hardDiskInfo:硬盘信息,inline,null,null,hardDiskInfo,硬盘信息
name:名称,string,null,null,name,名称
controller_num:控制器个数,int,null,个,controller_num,控制器个数
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
fcStoragePool:存储池,inline,null,null,fcStoragePool,存储池
fcStgeLUN:FC存储卷,inline,null,null,fcStgeLUN,FC存储卷
disk_driver_num:磁盘驱动器数,int,null,个,disk_driver_num,磁盘驱动器数
frontPort:前端端口,inline,null,null,frontPort,前端端口
avl_size_after_raid:RAID后可用容量,string,null,null,avl_size_after_raid,RAID后可用容量
phys_size:物理容量,string,null,null,phys_size,物理容量
raidGroup:RAID组,inline,null,null,raidGroup,RAID组
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
used_size_after_raid:RAID后已使用容量,string,null,null,used_size_after_raid,RAID后已使用容量
controller_cache:控制器缓存,string,null,null,controller_cache,控制器缓存
enclosure_num:盘柜个数,int,null,null,enclosure_num,盘柜个数
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
name:硬盘型号,string,null,null,name,硬盘型号
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

/*!Model
FCStoragePool:FC存储池,FCStoragePool,FC存储池,true,false
properties
stge_pool_total_size:容量,string,null,null,stge_pool_total_size,容量
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:存储池名称,string,null,null,name,存储池名称
stge_pool_used_size:已使用容量,string,null,null,stge_pool_used_size,已使用容量
stge_pool_free_size:剩余容量,string,null,null,stge_pool_free_size,剩余容量
*/

/*!Model
FCStgeLUN:FC存储LUN,FCStgeLUN,FC存储LUN,true,false
properties
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
lun_size:LUN大小,string,null,null,lun_size,LUN大小
host_mapping:主机映射,string,null,null,host_mapping,主机映射
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池/RAID组名称,string,null,null,stge_pool_name,存储池/RAID组名称
status:状态,string,null,null,status,状态
*/

/*!Model
FrontPort:前端端口,FrontPort,前端端口,true,false
properties
port_speed:端口速率,string,null,null,port_speed,端口速率
name:前端端口名称,string,null,null,name,前端端口名称
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
RaidGroup:FC存储RAID组,RaidGroup,FC存储RAID组,true,false
properties
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:RAID组名称,string,null,null,name,RAID组名称
combination:组成方式,string,null,null,combination,组成方式
*/

/*!Model
HostGroup:FC存储主机组,HostGroup,FC存储主机组,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
hostGroupLUN:主机组卷,inline,null,null,hostGroupLUN,主机组卷
hostgroup_aloc_size:主机组分配容量,string,null,null,hostgroup_aloc_size,主机组分配容量
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
name:名称,string,null,null,name,名称
hostGroupMapPort:主机组映射端口,inline,null,null,hostGroupMapPort,主机组映射端口
*/

/*!Model
HostGroupLUN:FC存储主机组卷,HostGroupLUN,FC存储主机组卷,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:主机组卷名称,string,null,null,name,主机组卷名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池名称,string,null,null,stge_pool_name,存储池名称
*/

/*!Model
HostGroupMapPort:FC主机组映射端口,HostGroupMapPort,FC主机组映射端口,true,false
properties
name:端口名称,string,null,null,name,端口名称
*/


import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;


def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();

def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
if(sysObjectId != '.1.3.6.1.4.1.1714.1.1'){
	throw new RuntimeException("Unrecognized ID:" + sysObjectId)
}
def model = get(".1.3.6.1.4.1.1714.1.1.1.1.13.0")
def serial_number = get(".1.3.6.1.4.1.1714.1.1.1.1.17.0")

def deviceCi = $ci.create('FCStorage', 'FCStorage', model + '/' + serial_number);
deviceCi.putAll([
	tl_brand : 'thedatasys',
	model : model,
	serial_number : serial_number,
	ip : $scriptParams.ip
])

discovery_pool(deviceCi)
discovery_disk(deviceCi)
discovery_volume(deviceCi)

def discovery_pool(deviceCi){
	$logger.logInfo("pool");
	def data = [:]
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.3.1.3")){
		def map = getOrInitMapValue(item.key, data)
		map.stge_pool_total_size = convert_bytes(Long.parseLong(item.value) * 512)
	}
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.3.1.2")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value
		def ci = $ci.create('FCStoragePool', name)
		ci.putAll(map)
		$ci.createRelationship("Inlines", deviceCi.id, ci.id);
	}
}

def discovery_disk(deviceCi){
	$logger.logInfo("disk");
	def data = [:]
	/*for(def item in walk(".1.3.6.1.4.1.1714.1.1.6.1.9")){
		def map = getOrInitMapValue(item.key, data)
		map.disk_rpm = convert_bytes(Long.parseLong(item.value) * 512)
	}*/
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.6.1.7")){
		def map = getOrInitMapValue(item.key, data)
		map.disk_size = convert_bytes(Long.parseLong(item.value) * 512)
	}
	def disks = [:]
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.6.1.15")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value.trim()
		def ci = disks[name]
		if(ci){
			ci.disk_num ++
		}
		else {
			ci = $ci.create('HardDiskInfo', name)
			disks[name] = ci
			ci.putAll(map)
			ci.disk_num = 1
		}
	}
}

def discovery_volume(deviceCi){
	$logger.logInfo("volume");
	def data = [:]
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.4.1.4")){
		def map = getOrInitMapValue(item.key, data)
		map.lun_size = convert_bytes(Long.parseLong(item.value) * 512)
	}
	for(def item in walk(".1.3.6.1.4.1.1714.1.1.4.1.2")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value
		def ci = $ci.create('FCStgeLUN', name)
		ci.lun_id = name
		$ci.createRelationship("Inlines", deviceCi.id, ci.id);
	}
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}
