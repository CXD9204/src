/*!Action
action.name=Linux_remote_discovery_v2
action.descr=Linux_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=Linux
discovery.output=Computer
 */

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
 */

/*!Model
Linux:Linux,Linux,Linux,false,false
properties
mw_soft_ver:中间件软件/版本,string,null,null,mw_soft_ver,中间件软件/版本
unix_crontab:定时作业,table,null,null,unix_crontab,定时作业
unixGroup:用户组,inline,null,null,unixGroup,用户组
hostname:主机名,string,null,null,hostname,主机名
pass_max_day:密码有效期,int,null,天,pass_max_day,密码有效期
osHCA:OS的HCA卡,inline,null,null,osHCA,OS的HCA卡
password_minlen:密码最小长度,int,null,null,password_minlen,密码最小长度
swap_size:交换分区大小,string,null,null,swap_size,交换分区大小
linuxSysctl:内核参数,inline,null,null,linuxSysctl,内核参数
pass_min_day:密码最短有效期,int,null,天,pass_min_day,密码最短有效期
user_tmout:会话超时时间,int,null,秒,user_tmout,会话超时时间
ip:IP地址,string,null,null,ip,IP地址
dns_server:DNS服务器,string,null,null,dns_server,DNS服务器
bits:位数,string,null,null,bits,位数
version:版本,string,null,null,version,版本
ips:IP列表,array,null,null,ips,IP列表
openssl_ver:openssl版本,string,null,null,openssl_ver,openssl版本
unixUser:用户,inline,null,null,unixUser,用户
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
password_dcredit:密码最少数字,int,null,null,password_dcredit,密码最少数字
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
default_gateway:默认网关,string,null,null,default_gateway,默认网关
password_ucredit:密码最少大写字母,int,null,null,password_ucredit,密码最少大写字母
osLunInfo:OS的LUN,inline,null,null,osLunInfo,OS的LUN
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_arch:CPU架构,string,null,null,cpu_arch,CPU架构
user_unlock_time:锁定时间,int,null,秒,user_unlock_time,锁定时间
osNIC:OS的网卡,inline,null,null,osNIC,OS的网卡
tool_soft_ver:工具软件/版本,string,null,null,tool_soft_ver,工具软件/版本
db_soft_ver:数据库软件/版本,string,null,null,db_soft_ver,数据库软件/版本
unixVG:卷组,inline,null,null,unixVG,卷组
osPort:监听端口,inline,null,null,osPort,监听端口
fileSystem:文件系统,inline,null,null,fileSystem,文件系统
password_ocredit:密码最少特殊字符,int,null,null,password_ocredit,密码最少特殊字符
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
time_zone:时区,string,null,null,time_zone,时区
memory_size:内存大小,string,null,null,memory_size,内存大小
osHBA:OS的HBA卡,inline,null,null,osHBA,OS的HBA卡
user_deny_cnt:用户登录失败锁定次数,int,null,null,user_deny_cnt,用户登录失败锁定次数
password_lcredit:密码最少小写字母,int,null,null,password_lcredit,密码最少小写字母
unixLV:逻辑卷,inline,null,null,unixLV,逻辑卷
kernel_version:内核版本,string,null,null,kernel_version,内核版本
os_distro:发行版版本,string,null,null,os_distro,发行版版本
openssh_ver:openssh版本,string,null,null,openssh_ver,openssh版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
osDisk:OS的本地磁盘,inline,null,null,osDisk,OS的本地磁盘
*/

/*!Model
unix_crontab:定时作业,unix_crontab,定时作业,false,true
properties
user_name:用户,string,null,null,user_name,用户
script:脚本,string,null,null,script,脚本
run_time:执行时间,string,null,null,run_time,执行时间
*/

/*!Model
UnixGroup:Unix用户组,UnixGroup,Unix用户组,true,false
properties
gid:用户组ID,string,null,null,gid,用户组ID
name:用户组名,string,null,null,name,用户组名
*/

/*!Model
OsHCA:OS的HCA卡,OsHCA,OS的HCA卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后HCA卡,string,null,null,bonding_flag,bonding后HCA卡
name:HCA卡名称,string,null,null,name,HCA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
*/

/*!Model
LinuxSysctl:Linux内核参数,LinuxSysctl,Linux内核参数,true,false
properties
name:参数名称,string,null,null,name,参数名称
sysctl_value:参数值,string,null,null,sysctl_value,参数值
*/

/*!Model
UnixUser:Unix用户,UnixUser,Unix用户,true,false
properties
uid:用户ID,string,null,null,uid,用户ID
umask:umask值,string,null,null,umask,umask值
password_expires:密码过期时间,string,null,null,password_expires,密码过期时间
shell:缺省shell目录,string,null,null,shell,缺省shell目录
primary_group:主用户组,string,null,null,primary_group,主用户组
name:用户名,string,null,null,name,用户名
groups:附属用户组,string,null,null,groups,附属用户组
locked_flag:是否锁定,string,null,null,locked_flag,是否锁定
home:用户home目录,string,null,null,home,用户home目录
*/

/*!Model
OsLunInfo:OS的LUN,OsLunInfo,OS的LUN,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
*/

/*!Model
OsNIC:OS的网卡,OsNIC,OS的网卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后网卡,string,null,null,bonding_flag,bonding后网卡
name:网卡名称,string,null,null,name,网卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
status:状态,string,null,null,status,状态
*/

/*!Model
UnixVG:Unix卷组,UnixVG,Unix卷组,true,false
properties
lv_num:逻辑卷个数,int,null,null,lv_num,逻辑卷个数
vg_free_size:卷组剩余大小,string,null,null,vg_free_size,卷组剩余大小
pv_num:物理卷个数,int,null,null,pv_num,物理卷个数
name:卷组名,string,null,null,name,卷组名
vg_used_size:卷组已使用大小,string,null,null,vg_used_size,卷组已使用大小
vg_total_size:卷组大小,string,null,null,vg_total_size,卷组大小
*/

/*!Model
OsPort:OS的监听端口,OsPort,OS的监听端口,true,false
properties
listen_ip:监听IP,string,null,null,listen_ip,监听IP
port:端口,int,null,null,port,端口
name:进程名,string,null,null,name,进程名
*/

/*!Model
FileSystem:Unix文件系统,FileSystem,Unix文件系统,true,false
properties
fs_mount_num:挂载次数,string,null,null,fs_mount_num,挂载次数
fs_type:文件系统类型,string,null,null,fs_type,文件系统类型
name:文件系统名称,string,null,null,name,文件系统名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
fs_mount_point:文件系统挂载点,string,null,null,fs_mount_point,文件系统挂载点
fs_need_fsck_flag:是否需要强制检查,string,null,null,fs_need_fsck_flag,是否需要强制检查
auto_mount:是否自动挂载,string,null,null,auto_mount,是否自动挂载
fs_mount_time:挂载时间,string,null,null,fs_mount_time,挂载时间
status:状态,string,null,null,status,状态
*/

/*!Model
OsHBA:OS的HBA卡,OsHBA,OS的HBA卡,true,false
properties
name:HBA卡名称,string,null,null,name,HBA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
status:状态,string,null,null,status,状态
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
UnixLV:Unix逻辑卷,UnixLV,Unix逻辑卷,true,false
properties
name:逻辑卷名,string,null,null,name,逻辑卷名
vg_name:卷组名称,string,null,null,vg_name,卷组名称
lv_size:逻辑卷大小,string,null,null,lv_size,逻辑卷大小
*/

/*!Model
OsDisk:OS的本地磁盘,OsDisk,OS的本地磁盘,true,false
properties
os_disk_size:磁盘大小,string,null,null,os_disk_size,磁盘大小
name:磁盘名称,string,null,null,name,磁盘名称
*/

/*!Model
PCServer:PC服务器,PCServer,PC服务器,false,false
properties
serverMemoryModule:服务器内存,inline,null,null,serverMemoryModule,服务器内存
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
model:型号,string,null,null,model,型号
bmc_version:BMC固件版本,string,null,null,bmc_version,BMC固件版本
firmware:BIOS固件版本,string,null,null,firmware,BIOS固件版本
serverHBA:服务器HBA卡,inline,null,null,serverHBA,服务器HBA卡
power_supply_mode:电源节能模式,string,null,null,power_supply_mode,电源节能模式
ip:带外管理IP,string,null,null,ip,带外管理IP
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
network_domain:网络域,string,null,null,network_domain,网络域
serverRaidCard:服务器RAID卡,inline,null,null,serverRaidCard,服务器RAID卡
serial_number:序列号,string,null,null,serial_number,序列号
hyper_threading_open_flag:超线程打开模式,string,null,null,hyper_threading_open_flag,超线程打开模式
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
memory_size:内存大小,string,null,null,memory_size,内存大小
pcserver_brand:品牌,string,null,null,pcserver_brand,品牌
hardDiskInfo:硬盘,inline,null,null,hardDiskInfo,硬盘
os_ip:操作系统IP,string,null,null,os_ip,操作系统IP
name:PC服务器名称,string,null,null,name,PC服务器名称
serverHCA:服务器HCA卡,inline,null,null,serverHCA,服务器HCA卡
serverNIC:服务器网卡,inline,null,null,serverNIC,服务器网卡
*/

/*!Model
ServerMemoryModule:服务器内存,ServerMemoryModule,服务器内存,true,false
properties
memory_module_size:内存条大小,string,null,null,memory_module_size,内存条大小
memory_clock_speed:内存条主频,string,null,null,memory_clock_speed,内存条主频
name:内存条型号,string,null,null,name,内存条型号
type:类型,string,null,null,type,类型
memory_module_num:内存条数量,int,null,null,memory_module_num,内存条数量
*/

/*!Model
ServerHBA:服务器HBA卡,ServerHBA,服务器HBA卡,true,false
properties
hba_port_id:HBA卡端口号,string,null,null,hba_port_id,HBA卡端口号
name:HBA卡型号,string,null,null,name,HBA卡型号
hba_slot_id:HBA卡槽位号,string,null,null,hba_slot_id,HBA卡槽位号
hba_speed:HBA卡速率,string,null,null,hba_speed,HBA卡速率
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
ServerRaidCard:服务器RAID卡,ServerRaidCard,服务器RAID卡,true,false
properties
name:RAID卡型号,string,null,null,name,RAID卡型号
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
name:硬盘型号,string,null,null,name,硬盘型号
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

/*!Model
ServerHCA:服务器HCA卡,ServerHCA,服务器HCA卡,true,false
properties
hca_slot_id:HCA卡槽位号,string,null,null,hca_slot_id,HCA卡槽位号
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:HCA卡型号,string,null,null,name,HCA卡型号
hca_port_id:HCA卡端口号,string,null,null,hca_port_id,HCA卡端口号
hca_speed:HCA卡速率,string,null,null,hca_speed,HCA卡速率
*/

/*!Model
ServerNIC:服务器网卡,ServerNIC,服务器网卡,true,false
properties
nic_slot_id:网卡槽位号,string,null,null,nic_slot_id,网卡槽位号
nic_speed:网卡速率,string,null,null,nic_speed,网卡速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:网卡型号,string,null,null,name,网卡型号
nic_port_id:网卡端口号,string,null,null,nic_port_id,网卡端口号
*/


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

cliUtil = $script.use("common/cli_util");

def system = 'Linux';
if('Linux' != system){
	$logger.logWarn("The current operating system is not supported:" + system);
	return ;
}
def osCi = discovery_linux(system);

def osCiId = osCi.id;
def pcCi = discovery_server(osCiId);
def pcCiId = pcCi != null ? pcCi.id : null;

discovery_user_group(osCiId);

//discover_sysctl(osCiId)
//discover_host_allow_deny(osCiId)//TODO
discover_cron(osCiId);

//discover_os_disk(osCiId);
//discover_vluns(osCiId) 
discover_file_system(osCiId);
discover_vg(osCiId);
discover_lv(osCiId);

discover_nic(osCiId, pcCiId);
discover_hba(osCiId, pcCiId);


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class format_time_params{
	def src_format = 'MMM dd, yyyy';
	def to_format = 'yyyy-MM-dd';
	def locale = Locale.UK;
}
def format_time(time_str, format_time_params = new format_time_params()){
    try{
        return LocalDate.parse(time_str, DateTimeFormatter.ofPattern(format_time_params.src_format, format_time_params.locale)).format(DateTimeFormatter.ofPattern(format_time_params.to_format));
    }catch(Exception e) {
        return time_str;
    }
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def is_virtual_machine(){
	def result = cliUtil.executeCommand("""[ -e '/proc/vz' ] || [ -e '/proc/xen' ] && echo true""");
	if(!$text.isNull(result)){
		return true;
	}
	result = cliUtil.executeCommand("""dmesg 2>/dev/null|grep -Ei "Hypervisor detected|Xen virtual console|virtualbox|VMware Virtual|virtualization kvm" || lscpu 2>/dev/null|grep -i "Hypervisor vendor" || dmidecode 2>/dev/null |grep -Ei "product name" |grep -Ei "kvm|hvm|ahv|vmware|virtualbox|virtual machine|openstack|alibaba" || cat /proc/cpuinfo 2>/dev/null |grep -i uml""");
	if(!$text.isNull(result)){
		return true;
	}
	return false;
}

def discover_os_disk(osCiId) {
    $logger.logInfo("Discover Disk");
    def commondResult = cliUtil.executeCommand("""fdisk -l | egrep 'Disk /dev/sd|Disk /dev/vd|Disk /dev/hd'|awk '{print \$2,\$5}'""");
    if($text.isNull(commondResult)){
		return ;
	}
	def infos = findAll(commondResult, """([\\/\\w]+): *(\\w+)""")
    for(def info in infos) {
        def ci = $ci.create('OsDisk', info[0])
        $ci.createRelationship('Inlines', osCiId, ci.id);
        ci.os_disk_size = convert_bytes(info[1])
    }
}       

def discover_hba(osCiId, pcCiId){
	$logger.logInfo("Discover HBA");
	def fc_host = '/sys/class/fc_host/'
    def scsi_host = '/sys/class/scsi_host/'
    def result = cliUtil.executeCommand("""[ -e '${fc_host}' ] && echo true""");
    if($text.isNull(result)){
		return ;
	}
	def commondResult = commondResult = cliUtil.executeCommand("""\\ls -1 ${fc_host}""");
	if($text.isNull(commondResult)){
		return ;
	}
	for(def line in $text.splitWord(commondResult)){
		def name = line;
		def status = cliUtil.executeCommand("""[ -e '${fc_host}${name}/port_state' ] && cat ${fc_host}${name}/port_state""");
		def speed = cliUtil.executeCommand("""[ -e '${fc_host}${name}/speed' ] && cat ${fc_host}${name}/speed""");
		def wwn = cliUtil.executeCommand("""[ -e '${fc_host}${name}/port_name' ] && cat ${fc_host}${name}/port_name""");
		if(wwn.startsWith('0x')){
			wwn = wwn.substring(2);
		}
		wwn = wwn.toUpperCase();
		
		def device = cliUtil.executeCommand("""readlink -f ${fc_host}/${name}/device/ |awk -F/ '{print \$6}'""")
		def hba_port_id = device.split("\\.")[-1]
		def hba_slot_id = cliUtil.executeCommand("""lspci -vvv -s ${device} 2>/dev/null |grep "Physical Slot:" |awk -F: '{print \$2}'""")
		hba_slot_id = $text.trim(hba_slot_id)
		
		def driver_version = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/lpfc_drvr_version' ] && cat ${scsi_host}${name}/lpfc_drvr_version""");
		if(!driver_version){
			driver_version = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/driver_version' ] && cat ${scsi_host}${name}/driver_version""");
		}
	
		def firmware = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/fwrev' ] && cat ${scsi_host}${name}/fwrev""");
		if(!firmware){
			firmware = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/fw_version' ] && cat ${scsi_host}${name}/fw_version""");
		}
		
		def model_name = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/modelname' ] && cat ${scsi_host}${name}/modelname""");
		if(!model_name){
			model_name = cliUtil.executeCommand("""[ -e '${scsi_host}${name}/model_name' ] && cat ${scsi_host}${name}/model_name""");
		}
		
		ci = $ci.create('osHBA', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			status : status,
                    wwn : wwn,
                    firmware : firmware,
                    driver_version : driver_version,
                    speed : speed
                  ]);

		if(pcCiId && model_name){
			def ci = $ci.create('ServerHBA', model_name)
			$ci.createRelationship("Inlines", pcCiId, ci.id);
            ci.putAll([
            			hba_speed : speed,
                        wwn : wwn,
                        hba_port_id : hba_port_id,
                    	hba_slot_id : hba_slot_id
					])
		}
	}
}

def discover_nic(osCiId, pcCiId){
	$logger.logInfo("Discover NIC");
	def ipMap = [:];
	def commondResult = cliUtil.executeCommand("""ip a |grep -w inet|awk '{print \$NF, \$2}'|awk -F'/' '{print \$1}'""");
	if(!$text.isNull(commondResult)){
    	for(def line in $text.splitLine(commondResult)){
	    	def ss = $text.splitWord($text.trim(line));
	        def name = ss[0];
	        def ip = ss[1];
	        name = name.split(":")[0];
	        def ipInfo = ipMap[name];
	        if(ipInfo == null){
	        	ipInfo = [];
	        	ipMap[name] = ipInfo;
	        }
	        ipInfo.add(ip);
	    }
    }
    commondResult = cliUtil.executeCommand("""for nic in \$(ls /sys/class/net |grep -vw lo); do [ -f /sys/class/net/\$nic/address ] && echo "\$nic \$(cat /sys/class/net/\$nic/address)"; done""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def exclude_nicNames = ["idrac"];
    def ib_model = cliUtil.executeCommand("""lspci |grep Mellanox | awk -F: '{print \$NF}'| head -1""");
    for(def line in $text.splitLine(commondResult)){
    	def ss = $text.splitWord($text.trim(line));
    	def name = ss[0];
    	def mac = ss[1];
    	if(!mac){
    		continue;
    	}
    	def ips = ipMap[name];
    	if(!ips){
    		ips = [];
    	}
    	def model = "";
    	def content = cliUtil.executeCommand("""ethtool -i $name""");
    	def bus_id = findAllFirst(content, "bus-info: (.*)")
        if(bus_id){
            model = cliUtil.executeCommand("""lspci -s $bus_id 2>/dev/null | awk -F: '{print \$NF}'""");
        }
        def driver_version = findAllFirst(content, "driver: (.*)") + " " + findAllFirst(content, "version: (.*)");
        def firmware = findAllFirst(content, "firmware-version: (.*)");
        def bonding_flag = "bonding" == findAllFirst(content, "driver: (.*)") ? "true" : false;
       	if (mac.length() == 59){
   			def ci = $ci.create('OsHCA', name)
   			$ci.createRelationship("Inlines", osCiId, ci.id);
            ci.putAll([
                ips : ips.join(","),
                mac_addr : mac,
                netmask : "",
                bonding_flag : bonding_flag,
                driver_version : driver_version,
                firmware : firmware
            ])
            // 物理机ib ci
            if (pcCiId && ib_model){
            	ci = $ci.create('ServerHCA', ib_model)
            	$ci.createRelationship("Inlines", pcCiId, ci.id);
                ci.mac_addr = mac;
       		}
       	}
       	else{
       		if(name in exclude_nicNames){
       			continue
       		}
       		def ci = $ci.create('OsNIC', name)
       		$ci.createRelationship("Inlines", osCiId, ci.id);
            ci.putAll([
                ips : ips.join(","),
                mac_addr : mac,
                netmask : "",
                bonding_flag : bonding_flag,
                driver_version : driver_version,
                firmware : firmware,
                status : cliUtil.executeCommand("""cat /sys/class/net/${name}/operstate""")
            ])
            /* 物理机网卡ci
            if (pcCiId && model){
                ci = $ci.create('ServerNIC', model)
                $ci.createRelationship("Inlines", pcCiId, ci.id);
                ci.mac_addr = mac;
            }*/
       	}
    }
}


def discovery_server(osCiId){
	$logger.logInfo("Discover PCServer");
	if(is_virtual_machine()){
        $logger.logInfo("this is virtual machine");
        return
    }
    def commondResult = cliUtil.executeCommand("""dmidecode -t 0,1,4,17,19""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def result = [:];
    for(String text in commondResult.split("\r*\n\r*\n")){
    	def matchs = findAll(text, """Handle ([x\\dA-F]+).*DMI type (\\d+)""");
    	if(!matchs){
    		continue;
    	}
    	def handle = matchs[0][0];
    	def type = matchs[0][1];
    	if(text.contains('No Module Installed') || text.contains('Not Installed')){
            continue
        }
    	
    	if(!(type in result)){
            result[type] = []
        }
       	matchs = findAll(text + "\t", """([\\S ]+):([^:]+)(?=\\t+?)""");
       	def map = [:];
       	for(def match : matchs){
   			def v = match[1].trim();
            //替换无效字段
            if(v.toLowerCase() in ['none', 'not specified', 'to be filled by o.e.m.', 'fill by oem', '[empty]']){
                v = null;
            }
			if(v && v.contains('\n')) {
                v = v.split('\r*\n\t*');
            }            
       		map[match[0].trim()] = v
       	}
       	if(map){
       		map.putAll(['_handle': handle, '_title': $text.trim($text.splitLine(text)[1])])
       		result[type].add(map);
       	}
    }
    if(!result){
        $logger.logWarn("dmidecode error");
        return
    }
    def bios = result["0"][0]
    def system = result["1"][0]
    def cpu = result["4"][0]
    def manufacturer = system['Manufacturer'];
    if(manufacturer == null){
        manufacturer = '';
    }

    def brand = search(manufacturer,
    		'IBM|HP|Dell|Oracle|Lenovo|HUAWEI|H3C|ZTE|inspur|sugon|Supermicro|Asus|Acer|Cisco|Fujitsu|sun|EMC|HDS|NETAPP|HITACHI|Juniper|Hillstone|BROCADE|fiberhome|fiber home',
             Pattern.CASE_INSENSITIVE);
    if(brand){
    	brand=brand.toLowerCase();
    }
    else{
    	brand = manufacturer.toLowerCase().replace("inc.", "").replace(".", "");
    }
    brand = brand.replace(' ', '')
    ci  = $ci.create('PCServer',  system['Product Name'] + "/" + system['Serial Number']);
    $ci.createRelationship("RunsOn", osCiId, ci.id);
    def hyper_threading_open_flag = null;
    def num = $number.parse(cliUtil.executeCommand("""cat /proc/cpuinfo 2>/dev/null|egrep 'siblings|cpu cores'|awk -F: '{print \$2}'|sort|uniq|wc -l""")).intValue();
    if(num == 1){
    	hyper_threading_open_flag = false;
    }
    else if(num > 1){
    	hyper_threading_open_flag = true;
    }
    def memorySize = 0f;
    for(def item in result["19"]){
    	memorySize += $number.parse(search(item['Range Size'], """\\d+"""));
    }
    ci.putAll([
        			model : system['Product Name'],
           	 		pcserver_brand : brand,
           	 		serial_number : system['Serial Number'],
            		bios_version : bios.get('Version'),
                    cpu_model : cpu.get('Version'),
                    cpu_phys_num : $number.parse(cliUtil.executeCommand("""cat /proc/cpuinfo|grep '^physical\\s*id\\s*:'|sort |uniq |wc -l""")).intValue(),
                    cpu_speed_clock: cpu.get('Current Speed'),
                    hyper_threading_open_flag : hyper_threading_open_flag,
                    memory_size: String.format('%.2f GB', memorySize),
					os_ip: $ccli.params.ip
                  ])
    def mems = result.get("17");
    if(mems){
    	def memInfos = [:];
		for(def mem : mems){
			def name = mem['Part Number'];	
			if(name in memInfos){
				memInfos[name]['memory_module_num'] += 1
			}
			else {
				memInfos[name] = [
                    memory_module_num : 1,
                    alias_type : mem['Type'],
                    memory_module_size : mem['Size'],
                    memory_clock_speed : mem['Configured Clock Speed']
                ]
			}
		}
		memInfos.each { key, value ->
			 def mem_ci = $ci.create('ServerMemoryModule', key);
        	 mem_ci.putAll(value);
        	 $ci.createRelationship('Inlines', ci.id, mem_ci.id)
		}
    }     
    return ci;
}

def discover_sysctl(osCiId){
    $logger.logInfo("Discover sysctl");
    def commondResult = cliUtil.executeCommand("""cat /etc/sysctl.conf |egrep -v '^\\s*\$|^\\s*#'""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
    	def ss = line.split("=");
    	if (ss.size() < 2){
    		continue
    	}
    	ci = $ci.create('linuxSysctl',  $text.trim(ss[0]))
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.sysctl_value = $text.trim(ss[1..-1].join("="));
    }
}

def discover_file_system(osCiId){
	$logger.logInfo("Discover file system");
	def commondResult = cliUtil.executeCommand("""df -Tk |tail -n +2""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def ignoreType = ['iso9660', 'overlay', 'tmpfs']
    def ignoreDevices = ['rootfs', 'sysfs', 'proc', 'devtmpfs', 'securityfs', 'tmpfs', 'cgroup', 'pstore']
    def ignoreStartsWithMountpoints = ['/dev', '/sys', '/run', '/proc', '/var', '/boot']
    for(def line in $text.splitLine(commondResult)){
    	def ss = $text.splitWord($text.trim(line));
        if (ss.size() < 7){
            $logger.logWarn("""file system line error ${line}""");
            continue
        }
        def device = ss[0];
        def type = ss[1];
        def mountpoint = ss[6];
        if(type in ignoreType){
        	continue;
        }
        if(device in ignoreDevices){
        	continue;
        }
        if(ignoreStartsWithMountpoints.any{e -> mountpoint.startsWith(e)}){
        	continue;
        }
        def status = last_mount = mount_num = fsck_flag = null;
        if(type in ['ext2', 'ext3', 'ext4']){
        	def res = cliUtil.executeCommand("""dumpe2fs -h ${device}""");
        	if(!$text.isNull(res)){
    			status = search(res, '(?<=Filesystem state:).*')
                last_mount = search(res, '(?<=Last mount time:).*')
                mount_num = search(res, '(?<=Mount count:).*')
                def interval = search(res, '(?<=Check interval:).*')
                if(!$text.isNull(interval)){
                	if(interval.startsWith('0')){
                		fsck_flag = 'no'
                	}
                	else {
                		fsck_flag = 'yes'
                	}
                }
    		}
        }
        ci = $ci.create('fileSystem', device)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			fs_total_size : convert_bytes(ss[2], new convert_bytes_params(src_unit : 'KB')),
           	 		fs_mount_num : mount_num,
            		fs_mount_point : mountpoint,
                    fs_mount_time : last_mount,
                    fs_need_fsck_flag : fsck_flag,
                    status : status,
                    fs_type : type
                  ])
    }    
}

def discover_lv(osCiId){
    $logger.logInfo("Discover LV");
    def commondResult = cliUtil.executeCommand("""lvs 2>/dev/null|tail -n +2""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
        def ss = $text.splitWord($text.trim(line));
        if (ss.size() < 4){
            $logger.logWarn("""LV line error ${line}""");
            continue
        }
        ci = $ci.create('unixLV', ss[0])
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
                   	lv_size : convert_bytes(ss[3]),
                   	vg_name : ss[1]
                  ])
    }
}

def discover_vg(osCiId){
	$logger.logInfo("Discover VG");
	def commondResult = cliUtil.executeCommand("""vgs 2>/dev/null|tail -n +2""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
        def ss = $text.splitWord($text.trim(line));
        if (ss.size() < 7){
            $logger.logWarn("""VG line error ${line}""");
            continue
        }
        ci = $ci.create('unixVG', ss[0])
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			pv_num : ss[1],
                    lv_num : ss[2],
                    vg_total_size : convert_bytes(ss[5]),
                    vg_free_size : convert_bytes(ss[6]),
                    vg_used_size : convert_bytes(
                    				convert_bytes(ss[5], new convert_bytes_params(unit : 'B', return_str : false))[0] 
                    				- convert_bytes(ss[6], new convert_bytes_params(unit : 'B', return_str : false))[0]
                    				)
                  ]);
    }
}

def discover_cron(osCiId){
    $logger.logInfo("Discover crontab");
    def commondResult = cliUtil.executeCommand("""find /var/spool/cron/ -type f|grep -v '/lastrun/'""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def userCorn in $text.splitLine(commondResult)){
        def user = cliUtil.executeCommand("""basename ${userCorn}""")
        for(def cornContent in $text.splitLine(cliUtil.executeCommand("""cat ${userCorn}| egrep -v '^\\s*\$|^\\s*#' | awk -F# '{print \$1}'"""))){
            def ss = $text.splitWord($text.trim(cornContent));
            if (ss.size() < 6){
                $logger.logWarn("""crontab line error ${cornContent}""");
                continue
            }
            def run_time = ss[0..4].join(" ");
            def script = ss[5..-1].join(" ");
            def ci = $ci.create('unix_crontab', user)
            $ci.createRelationship("Inlines", osCiId, ci.id);
            ci.user_name = user;
            ci.run_time = run_time;
            ci.script = script;
        }
    }
}

def discovery_user_group(osCiId){
    $logger.logInfo("Discover users and user groups");
    def exclude_users = ["root"];
    def all_groups = [];
    def excludeShell = ['', null, '/sbin/nologin', '/sbin/shutdown', '/bin/sync', '/bin/halt', '/sbin/halt', '/bin/false', '/usr/sbin/snappd', '/usr/sbin/uucp/uucico']
    def commondResult = cliUtil.executeCommand("""cat /etc/passwd""");
    if($text.isNull(commondResult)){
        return ;
    }
    for(def userStr in $text.splitLine(commondResult)){
        if($text.isNull(userStr)){
            continue;
        }
        def ss = userStr.split(":", -1);
        def user = [loginName: ss[0], passwd: ss[1], UID: ss[2], GID: ss[3], userName: ss[4], homeDirectory: ss[5], shell: ss[6]]
        if(excludeShell.contains(user.shell)){
            continue;
        }
        if(exclude_users.contains(user.loginName)){
            continue;
        }
        def user_info = cliUtil.executeCommand("""id ${user.loginName}""");
        def tmp = findAll(user_info, "(\\d+)\\((.*?)\\)");
        if (tmp.size() < 3){
            $logger.logWarn("user id error, user:" + user.loginName);
            continue
        }
        def groups = tmp[2..-1];
        all_groups.addAll(groups);
        def ci = $ci.create("unixUser", user.loginName);
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.uid = user.UID;
        ci.home = user.homeDirectory;
        ci.shell = user.shell;
        ci.groups = groups.collect{e->e[1]}.join(",");
        ci.primary_group =  primary_group = tmp[1][1];
        ci.password_expires = format_time(cliUtil.executeCommand("""chage -l ${user.loginName} | grep 'Password expires'|awk -F: '{print \$2}'"""));
    }
    for(g in all_groups.unique()){
        ci = $ci.create('unixGroup', g[1])
        ci.gid = g[0]
        $ci.createRelationship("Inlines", osCiId, ci.id)
    }
}

def discovery_linux(system) {
	$logger.logInfo("Discover Linux");
	def hostname = cliUtil.executeCommand("uname -n");
	def architecture = cliUtil.executeCommand("uname -p");
	def version = cliUtil.executeCommand("""echo \$(cat /etc/*-release 2>/dev/null |sed 's/^#//g' |grep -E "^VERSION|^\$SYSTEM"|grep -v "VERSION_ID"|| grep -E "\$SYSTEM" /etc/issue 2>/dev/null) | sort -u| grep -Eo '[0-9]+(\\.[0-9]+)*'|head -1""");
	def kernel = cliUtil.executeCommand("""uname -r | awk -F'-' '{ print \$1 }'""");
	def cpu = "64";
	if(architecture && !cpu.contains("64")){
		cpu = "32";
	}
	def dists = ['NeoKylin', 'NeoShine', 'iSoft', 'RedFlag', 'CGSL', 'Oracle', 'Turbo']
	def dist = search(cliUtil.executeCommand("""\\ls /etc/*-release"""), dists.join("|"), Pattern.CASE_INSENSITIVE);
	if(dist){
		dist = dists.find({e->e.equalsIgnoreCase(dist)});
	}
	else {
		dist = cliUtil.executeCommand("""echo \$(lsb_release -d 2>/dev/null || cat /etc/*-release 2>/dev/null || cat /etc/issue 2>/dev/null) | grep -Eo 'Debian|Ubuntu|Red Hat|CentOS|openSUSE|Amazon|Arista|SUSE|SuSE|Turbo|AIX|RedHat|RedFlag|Red Flag|NeoKylin|NeoShine|iSoft|Asianux|KYLIN'|sort -u|head -1""");
	}
	dist = dist.replace(" ", "");
    def ci = $ci.create("Linux", "Linux", $ccli.params.ip + "-" + hostname);
    ci.ip = $ccli.params.ip;
    ci.ips = $text.splitLine(cliUtil.executeCommand("""ip a|grep -w inet|grep -Ev '127.0.0|169.254' | awk '{print \$2}'|cut -d/ -f1""")).join(",");
    
    ci.hostname = hostname
    ci.linuxReleaseName = dist
    ci.os_dist_ver = version
    ci.os_ver_detl = "${dist} ${version}"
    ci.cpu_arch = architecture;
    ci.kernelVersion = kernel;
    ci.bits = cpu
    ci.os_type = system;
    ci.cpu_core_num = $number.parse(cliUtil.executeCommand("""cat /proc/cpuinfo| grep processor | wc -l""")).intValue();
    
    ci.memory_size = convert_bytes($text.trim(cliUtil.executeCommand("""cat /proc/meminfo | grep "^MemTotal\\S*:" |awk -F':' '{print \$2}'""")));
    ci.swap_size = convert_bytes($text.trim(cliUtil.executeCommand("""cat /proc/meminfo | grep "^SwapTotal\\S*:" |awk -F':' '{print \$2}'""")));
    
    ci.ntp_server = $text.splitLine(cliUtil.executeCommand("""cat /etc/ntp.conf | grep '^server' | awk '{print \$2}'""")).join(" | ");
    ci.dns_server = $text.splitLine(cliUtil.executeCommand("""cat /etc/resolv.conf|grep ^nameserver|awk '{print \$NF}'""")).join(",");
    def time_zone = cliUtil.executeCommand("""(timedatectl 2>/dev/null || cat /etc/sysconfig/clock 2>/dev/null) | grep -i zone |awk -F':|"' '{print \$2}'""");
    if(!time_zone){
       time_zone = cliUtil.executeCommand("""readlink -f /etc/localtime|awk -F '/' '{print \$(NF-1)"/"\$NF}'""");
    }
    ci.time_zone = time_zone.split()[0]
    ci.default_gateway = cliUtil.executeCommand("""ip route |grep default |awk '{print \$3}'""");
    
    ci.user_tmout = cliUtil.executeCommand("echo \$TMOUT");
   
    def array = cliUtil.executeCommand("sshd -V 2>&1|grep OpenSSH|awk '{print \$1,\$2,\$3}'").split(",");
    ci.openssh_ver = array[0]
    ci.openssl_ver = array.length > 1 ? $text.trim(array[1]) : "";
    
    def system_auth = "";
    system_auth += cliUtil.executeCommand("""[ -f "/etc/pam.d/system-auth" ] && cat /etc/pam.d/system-auth""");
    system_auth += cliUtil.executeCommand("""[ -f "/etc/pam.d/common-password" ] && cat /etc/pam.d/common-password /etc/pam.d/common-auth /etc/pam.d/common-session""");
    
    //密码最多尝试次数
    ci.user_deny_cnt = search(system_auth, "(?<=deny=)\\d+")
    //密码最少数字
    ci.user_unlock_time = search(system_auth, "(?<=unlock_time=)\\d+")
    //密码最少长度
    ci.password_minlen = search(system_auth, "(?<=minlen=)\\d+")
    //密码最少数字
    ci.password_dcredit = search(system_auth, "(?<=dcredit=-)\\d+")
    //密码最少小写字母
    ci.password_lcredit = search(system_auth, "(?<=lcredit=-)\\d+")
    //密码最少特殊字符
    ci.password_ocredit = search(system_auth, "(?<=ocredit=-)\\d+")
    //密码最少大写字母
    ci.password_ucredit = search(system_auth, "(?<=ucredit=-)\\d+")

	system_auth = cliUtil.executeCommand("""[ -f "/etc/login.defs" ] && cat /etc/login.defs""");
	//密码最长过期天数
    ci.pass_max_day = search(system_auth, "(?<=PASS_MAX_DAYS\\s)\\d+");
    //密码最小过期天数
    ci.pass_min_day = search(system_auth, "(?<=PASS_MIN_DAYS\\s)\\d+");
    return ci;
}