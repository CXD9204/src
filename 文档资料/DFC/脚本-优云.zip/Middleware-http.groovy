/*!Action
action.name=WebLogic_remote_discovery
action.descr=WebLogic_remote_discovery
action.version=1.0.0
action.protocols=http
action.main.model=WebLogic
discovery.output=Middleware
*/

/*!Params
protocol:连接协议,enum,https,false,[http, https]
ip:目标设备IP,ip,,true
port:端口,number,7001,false
username:用户名,text,,false
password:密码,password,,false
consolename:控制台名称,text,console,false
timeout:超时(ms),number,10000,false
*/

/*!Model
WebLogic:WebLogic实例,WebLogic,WebLogic实例,false,false
properties
server_name:实例名,string,null,null,server_name,实例名
install_path:安装路径,string,null,null,install_path,安装路径
perm_size:JVM方法区大小,string,null,null,perm_size,JVM方法区大小
hostname:主机名,string,null,null,hostname,主机名
log_file:日志文件,string,null,null,log_file,日志文件
javaApp:Java应用,inline,null,null,javaApp,Java应用
max_perm_size:JVM最大方法区,string,null,null,max_perm_size,JVM最大方法区
jdbc_DS:JDBC数据源,inline,null,null,jdbc_DS,JDBC数据源
maximum_heap_size:最大堆大小,string,null,null,maximum_heap_size,最大堆大小
cluster_name:集群名称,string,null,null,cluster_name,集群名称
ip:IP地址,string,null,null,ip,IP地址
initial_heap_size:初始堆大小,string,null,null,initial_heap_size,初始堆大小
web_container_max:最大线程池,int,null,null,web_container_max,最大线程池
network_domain:网络域,string,null,null,network_domain,网络域
version:WebLogic版本,string,null,null,version,WebLogic版本
weblogicPSU:PSU补丁,inline,null,null,weblogicPSU,PSU补丁
port:端口,int,null,null,port,端口
machine:计算机,string,null,null,machine,计算机
name:名称,string,null,null,name,名称
*/

/*!Model
JavaApp:Java应用,JavaApp,Java应用,true,false
properties
context_path:上下文根,string,null,null,context_path,上下文根
name:应用名称,string,null,null,name,应用名称
target:目标,string,null,null,target,目标
*/

/*!Model
JDBC_DS:JDBC数据源,JDBC_DS,JDBC数据源,true,false
properties
jndi_name:JNDI名称,string,null,null,jndi_name,JNDI名称
ds_driver_type:数据源驱动类型,string,null,null,ds_driver_type,数据源驱动类型
ds_max_conn:连接池最大连接数,int,null,null,ds_max_conn,连接池最大连接数
ds_scope:数据源作用域,string,null,null,ds_scope,数据源作用域
user_name:用户标志,string,null,null,user_name,用户标志
name:数据源名称,string,null,null,name,数据源名称
ds_url:数据源URL,string,null,null,ds_url,数据源URL
ds_min_conn:连接池最小连接数,int,null,null,ds_min_conn,连接池最小连接数
*/

/*!Model
WebLogicPSU:WebLogicPSU补丁,WebLogicPSU,WebLogicPSU补丁,true,false
properties
name:补丁号,string,null,null,name,补丁号
desc:描述,string,null,null,desc,描述
*/

/*!Model
WebLogicServerCluster:WebLogic集群,WebLogicServerCluster,WebLogic集群,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
port:AdminServer端口,int,null,null,port,AdminServer端口
ip:AdminServer地址,string,null,null,ip,AdminServer地址
name:名称,string,null,null,name,名称
javaApp:Java应用,inline,null,null,javaApp,Java应用
network_domain:网络域,string,null,null,network_domain,网络域
jdbc_DS:JDBC数据源,inline,null,null,jdbc_DS,JDBC数据源
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLEngine;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509ExtendedTrustManager;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;


baseUrl = $scriptParams.protocol + "://" + $scriptParams.ip + ":" + $scriptParams.port + "/" + $scriptParams.consolename
httpclient = HttpClientBuilder.create().setSSLSocketFactory(getSSL()).build();

login()

discovery_weblogic()
discovery_cluster()
discovery_application()
discovery_datasource()


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}


def login(){
	def url = baseUrl + "/j_security_check";
    def httpPost = new HttpPost(url);
    httpPost.addHeader("Referer", baseUrl + "/login/LoginForm.jsp")
    def params = new ArrayList<>();
    params.add(new BasicNameValuePair("j_username", $scriptParams.username));
    params.add(new BasicNameValuePair("j_password", $scriptParams.password));
    params.add(new BasicNameValuePair("j_character_encoding", "UTF-8"));
    
    $logger.logInfo("login url:" + url);
    
    httpPost.setEntity(new UrlEncodedFormEntity(params));
    response = httpclient.execute(httpPost);
    
    def entity = response.getEntity();
	def code = response.getStatusLine().getStatusCode();
	def body = "";
	if(entity){
		body = EntityUtils.toString(entity, "UTF-8");
	}
	//println code
	$logger.logInfo("login response code:" + code);
	if(code == 200){//code为303时,client直接去访问了重定向的地址,造成code变成200了
		return ;
	}
	if(code != 301 && code != 302){
		throw new RuntimeException('login fail')
	}
	def location = response.getFirstHeader("Location").getValue();
	//println location
    if(location.contains('login')){
    	throw new RuntimeException('login fail')
    }
    doGet(location) //需要多访问一次,不然不生效
}

def getWeblogicNodes() {
 	def url = baseUrl + "/console.portal?_nfpb=true&_pageLabel=CoreServerServerTablePage";
    def clusterPageHtml = doGet(url);
    def doc = Jsoup.parse(clusterPageHtml);

    def table = doc.getElementById("genericTableFormtable");
    if (table == null) {
        return [];
    }
    def nodes = table.getElementsByTag("tbody").first().childNodes();
    def size = nodes.size();
    def data = []
    for (def i = 1; i < size; i++) {
        def href = nodes[i].getElementsByAttributeValueContaining("href", "DispatcherPortlethandle").first().attr("href");
        def key = findAllFirst(href, 'DispatcherPortlethandle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D(\\S+)%2CType%3DServer%22%29');
        data.add(key)
    }
    return data;
}

def getPageKeys(def code, def appendParams = null, java.util.function.Function callkack = null, def start = null) {
 	def url = baseUrl + "/console.portal?_nfpb=true&_pageLabel=" + code + "Page";
 	if(appendParams){
 		url += appendParams
 	}
 	if(start){
 		url += "&" + code + "Portletstart-rec=" + start
 	}

    def clusterPageHtml = doGet(url);
    def doc = Jsoup.parse(clusterPageHtml);
	def table = null;
	for(def element in doc.getElementsByTag("table")){
		if(element.attr("id").endsWith('Formtable')){
			table = element
		}
	}
    if (table == null) {
        return [];
    }
    def text = doc.getElementsByClass("tablenavigation").first().text()

	def numbers = findAll(text, '(\\d+)')
	if(numbers[2] == '0'){
		return [];
	}
    def nodes = table.getElementsByTag("tbody").first().childNodes();
    def size = nodes.size();
    def data = []
    for (def i = 1; i < size; i++) {
    	def target = nodes[i].getElementsByAttributeValueContaining("href", "handle=").first();
    	def key = null
    	if(callkack != null){
    		key = callkack.apply(target)
    	}
    	else {
       	 	def href = target.attr("href");
       		key = findAllFirst(href, 'handle=.*%28%22com.bea%3AName%3D(\\S+?)%2C');
        }
        data.add(key)
    }
	if(numbers[1] != numbers[2]){
		data.addAll(getPageKeys(code, appendParams, callkack, numbers[1]))
	}
    return data;
}

def getTableInfo(def subUrl) {
 	def url = baseUrl + subUrl
    def clusterPageHtml = doGet(url)

    def doc = Jsoup.parse(clusterPageHtml);

	def data = [:]
	def table = null
	for(def element in doc.getElementsByTag("table")){
		if(element.attr('datatable') == '0'){
			table = element
		}
	}
	if(table){
		def elements = table.getElementsByTag("tbody").first().children()
	    for(def element in elements){
	    	def id = element.attr("id")
	    	if(!id){
	    		continue
	    	}
	    	def name = id.split("\\.")[-1]
	    	if(name.endsWith("_row")){
	    		name = name.split("_", 2)[0]
	    	}
	    	def valueElement = element.children()[-2];
	    	def valueElementClass = valueElement.attr("class");
	    	def value = null;
	    	if(valueElementClass == 'inputFieldRO'){
	    		value = valueElement.text();
	    	}
	    	else if(valueElementClass == 'inputField'){
	    		valueElement = valueElement.children()[-1].child(0)
	    		if('input' == valueElement.tagName()){
	    			value = valueElement.attr('value')
	    		}
	    		else if('select' == valueElement.tagName()){
	    			value = valueElement.getElementsByAttribute("selected").text()
	    		}
	    		else if('textarea' == valueElement.tagName()){
	    			value = valueElement.text()
	    		}
	    	}
	    	else if(valueElementClass == 'labeledField'){
	    		value = valueElement.getElementsByTag('input').last().attr('value')
	    	}
	    	data[name] = value
	    }
	    if(data.size() == 0){
	    	return table
	    }
	}
    return data
}

def discovery_weblogic(){
	$logger.logInfo("Discover weblogic");
	webLogicCis = [:]
	def osCis = [:]
	for(def key : getPageKeys("CoreServerServerTable")){
		//配置>一般信息
		def baseInfo = getTableInfo("/console.portal?_nfpb=true&_pageLabel=ServerConfigGeneralTabPage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D" + key + "%2CType%3DServer%22%29")
		//配置>并发
		def concurrencyInfo = getTableInfo("/console.portal?_nfpb=true&_pageLabel=ServerConfigConcurrencyPage&handle=com.bea.console.handles.JMXHandle%28com.bea%3AName%3D" + key + "%2CType%3DServer%29")
		//监视>一般信息
		def extInfo = getTableInfo("/console.portal?_nfpb=true&_pageLabel=ServerMonitoringTabmonitoringTabPage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D" + key + "%2CType%3DServer%22%29")
		//监视>性能
		def jvmInfo = getTableInfo("/console.portal?_nfpb=true&_pageLabel=ServerMonitoringPerformancePage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D" + key + "%2CType%3DServer%22%29")
		def name = baseInfo.name
		def ci = $ci.create("WebLogic", "WebLogic", name);
		ci.putAll([
			ip : baseInfo.listenAddress,
			port : baseInfo.listenPort,
			hostname : '',
			server_name : name,
			cluster_name : baseInfo.selectedCluster == '(Stand-Alone)' ? '' : baseInfo.selectedCluster,
			version : extInfo.weblogicVersion ? findAllFirst(extInfo.weblogicVersion, 'WebLogic Server (\\S+)') : '',
			machine : baseInfo.selectedMachine,
			maximum_heap_size : convert_bytes(jvmInfo.heapSizeMax),
			web_container_max : concurrencyInfo.maxConcurrentNewThreads
		])
		def osCi = osCis[ci.ip]
		if(!osCi && extInfo.osName){
			def osCode = osCodeSearch(extInfo.osName)
		    if(osCode){
		    	osCi = $ci.create(osCode, ci.hostname ? ci.ip + "-" + ci.hostname : ci.ip)
		    	osCi.ip = ci.ip
		    	osCis[ci.ip] = osCi
		    }
	    }
	    webLogicCis[ci.name] = ci
	}
	for(def ci in webLogicCis.values()){
		def osCi = osCis[ci.ip]
		if(osCi){
			$ci.createRelationship("RunsOn", ci.id, osCi.id);
		}
	}
}

def discovery_cluster(){
	$logger.logInfo("Discover cluster");
	webLogicClusterCis = [:]
	for(def key in getPageKeys("CoreClusterClusterTable")){
		//配置>一般信息
		def baseInfo = getTableInfo('/console.portal?_nfpb=true&_pageLabel=CoreClusterClusterConfigGeneralPage&CoreClusterClusterConfigGeneralPortlethandle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D' + key + '%2CType%3DCluster%22%29')
		def name = baseInfo.name
		def ci = $ci.create("WebLogicServerCluster", name);
		ci.putAll([
			ip : $scriptParams.ip,
			port : $scriptParams.port,
			cluster_name : name
		])
		//配置>服务器
		def hostkeys = getPageKeys('CoreClusterClusterConfigServers', '&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D' + name +'%2CType%3DCluster%22%29', {e->e.text()})
		for(def hostkey : hostkeys){
			$ci.createRelationship("Contains", ci.id, webLogicCis[hostkey].id);
		}
		webLogicClusterCis[ci.name] = ci
	}
}

def getTarget(def url){
	def targetCi = []
	for(def table in getTableInfo(url).getElementsByClass('targetTable')){
		for(def td : table.getElementsByTag("td")){
			def children = td.children()
			if(!children[0].hasAttr("checked")){
				continue
			}
			if(children.size() == 2){
				targetCi.add(webLogicCis[children[1].text()])
			}
			else {
				if(children[2].child(0).hasAttr("checked")){
					targetCi.add(webLogicClusterCis[children[1].text()])
				}
				else {
					for(int i = 4; i < children.size(); i++){
						def child = children[i]
						def childChildren = child.children()
						if(childChildren[0].hasAttr("checked")){
							targetCi.add(webLogicCis[childChildren[1].text()])
						}
					}
				}
			}
		}
	}
	return targetCi
}

def discovery_application(){
	$logger.logInfo("Discover application");
	for(def key in getPageKeys('AppDeploymentsControl', '&AppDeploymentsControlPortlethandle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3Dbase_domain%2CType%3DDomain%22%29')){
		//概览
		def baseInfo = getTableInfo('/console.portal?_nfpb=true&_pageLabel=WebAppApplicationOverviewPage&WebAppApplicationOverviewPortlethandle=com.bea.console.handles.AppDeploymentHandle%28%22com.bea%3AName%3D' + key + '%2CType%3DAppDeployment%22%29')
		def targetCis = getTarget('/console.portal?_nfpb=true&_pageLabel=WebAppApplicationTargetsPage&handle=com.bea.console.handles.AppDeploymentHandle%28%22com.bea%3AName%3D' + key + '%2CType%3DAppDeployment%22%29')
		if(!targetCis){
			$logger.logWarn("datasource:"  + baseInfo.appName + " no target");
			continue
		}
		if(!baseInfo.appName){
			$logger.logWarn("datasource:"  + baseInfo.appName + " get info error");
			continue
		}
		def ci = $ci.create("JavaApp", baseInfo.appName);
		ci.putAll([
			context_path : baseInfo.contextRoot
		])
		ci.target = targetCis.collect{e->e.name}.join(",")
		for(def temp : targetCis){
			$ci.createRelationship("Inlines", temp.id, ci.id);
		}
	}
}

def discovery_datasource(){
	$logger.logInfo("Discover datasource");
	for(def key in getPageKeys('GlobalJDBCDataSourceTable', '&GlobalJDBCDataSourceTablePortlethandle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3Dbase_domain%2CType%3DDomain%22%29')){
		//配置>一般信息
		def baseInfo = getTableInfo('/console.portal?_nfpb=true&_pageLabel=JdbcDatasourcesJDBCDataSourceConfigTabPage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D62.130%2CType%3Dweblogic.j2ee.descriptor.wl.JDBCDataSourceBean%2CParent%3D%5Bbase_domain%5D%2FJDBCSystemResources%5B' + key + '%5D%2CPath%3DJDBCResource%5B62.130%5D%22%29')
		//配置>连接池
		def poolInfo = getTableInfo('/console.portal?_nfpb=true&_pageLabel=JdbcDatasourcesJDBCDataSourceConfigConnectionPoolTabPage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D' + key + '%2CType%3Dweblogic.j2ee.descriptor.wl.JDBCDataSourceBean%2CParent%3D%5Bbase_domain%5D%2FJDBCSystemResources%5B' + key + '%5D%2CPath%3DJDBCResource%5B' + key + '%5D%22%29')
		def targetCis = getTarget('/console.portal?_nfpb=true&_pageLabel=JDBCDataSourcetargetdeployTabPage&handle=com.bea.console.handles.JMXHandle%28%22com.bea%3AName%3D' + key + '%2CType%3Dweblogic.j2ee.descriptor.wl.JDBCDataSourceBean%2CParent%3D%5Bbase_domain%5D%2FJDBCSystemResources%5B' + key +'%5D%2CPath%3DJDBCResource%5B' + key + '%5D%22%29')
		if(!targetCis){
			$logger.logWarn("datasource:" + baseInfo.name + " no target");
			continue
		}
		def ci = $ci.create("JDBC_DS", baseInfo.name);
		ci.putAll([
			ds_scope : baseInfo.scopeDisplayName,
			jndi_name : baseInfo.name,
			user_name : findAllFirst(poolInfo.properties, 'user=(\\S+)'),
			ds_url : poolInfo.url,
			ds_driver_type : poolInfo.driverName,
			ds_min_conn : poolInfo.minCapacity,
			ds_max_conn : poolInfo.maxCapacity
		])
		for(def temp : targetCis){
			$ci.createRelationship("Inlines", temp.id, ci.id);
		}
	}
}

def doGet(url) {
	def response = null;
	def method = null;
	try{
		method = new HttpGet(url);
		response = httpclient.execute(method);
		def entity = response.getEntity();
		def code = response.getStatusLine().getStatusCode();
		def body = "";
		if(entity){
			body = EntityUtils.toString(entity, "UTF-8");
		}
		if(!responseIsSuccess(code)){
			throw new RuntimeException("httpErroe!url:${url},responseCode:${code},responseBody${body}")
		}
		return body;
	} finally {
		close(method)
		close(response)
	}
}

def close(obj){
	try{
		if(obj){
			obj.close();
		}
	}catch(Exception e){
		
	}
}

def responseIsSuccess(code){
    if (code >= 200 && code < 300){
        return true;
    }
    return false;
}

def getSSL(){
	def sslContext = SSLContext.getInstance("TLS");
	sslContext.init(null, [new X509ExtendedTrustManager() {

		@Override
		public X509Certificate[] getAcceptedIssuers() {
		}
		
		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
		}

		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType, SSLEngine engine)
				throws CertificateException {
		}

		@Override
		public void checkServerTrusted(X509Certificate[] chain, String authType, Socket socket)
				throws CertificateException {
		}

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType, SSLEngine engine)
				throws CertificateException {
		}

		@Override
		public void checkClientTrusted(X509Certificate[] chain, String authType, Socket socket)
				throws CertificateException {
		}
	}] as TrustManager[], null);
	
	/*def sslsf = new SSLConnectionSocketFactory(
		sslContext, 
		[ "TLSv1.2" ] as String[],
        null,
        NoopHostnameVerifier.INSTANCE);*/
    def sslsf = new SSLConnectionSocketFactory(
		sslContext, 
		[ "SSLv3","TLSv1","TLSv1.1","TLSv1.2" ] as String[],
        null,
        NoopHostnameVerifier.INSTANCE);    
	return sslsf;
}