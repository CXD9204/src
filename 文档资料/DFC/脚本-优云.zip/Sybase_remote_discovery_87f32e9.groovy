/*!Action 
action.name=Sybase_remote_discovery_87f32e9
action.descr=Sybase_remote_discovery
action.version=1.0.0
action.protocols=sybase
action.main.model=Sybase
discovery.output=Database
*/
 
/*!Params
 ip:目标设备IP,ip,,true
 port:端口,number,5000,false
 username:用户名,text,,false
 password:密码,password,,false
*/

/*!Model
Sybase:SybaseASE实例,Sybase,SybaseASE实例,false,false
properties
number_of_alarms:最大告警数,int,null,null,number_of_alarms,最大告警数
number_of_devices:最大设备数,int,null,null,number_of_devices,最大设备数
cache:缓存信息,table,null,null,cache,缓存信息
characterset:字符集,string,null,null,characterset,字符集
instance_name:实例名,string,null,null,instance_name,实例名
number_of_engines_at_startup:在线引擎数,int,null,null,number_of_engines_at_startup,在线引擎数
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
number_of_sort_buffers:最大sort buffers数,int,null,null,number_of_sort_buffers,最大sort buffers数
version:版本,string,null,null,version,版本
max_memory:最大可用内存数,string,null,null,max_memory,最大可用内存数
number_of_large_io_buffers:最大 large io buffers数,int,null,null,number_of_large_io_buffers,最大 large io buffers数
number_of_locks:最大锁数,int,null,null,number_of_locks,最大锁数
number_of_open_indexes:最大打开索引数,int,null,null,number_of_open_indexes,最大打开索引数
hostname:主机名,string,null,null,hostname,主机名
number_of_user_connections:用户最大连接数,int,null,null,number_of_user_connections,用户最大连接数
max_online_engine:最大引擎数,int,null,null,max_online_engine,最大引擎数
port:端口,int,null,null,port,端口
runnable_process_search_count:最大可运行进程搜索数,int,null,null,runnable_process_search_count,最大可运行进程搜索数
name:名称,string,null,null,name,名称
sybaseDataBase:Sybase数据库,inline,null,null,sybaseDataBase,Sybase数据库
number_of_open_objects:最大打开对象数,int,null,null,number_of_open_objects,最大打开对象数
page_size:页大小,string,null,null,page_size,页大小
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
cache:缓存信息,cache,缓存信息,false,true
properties
cache_name:高速缓存名,string,null,null,cache_name,高速缓存名
cache_size:高速缓存值,string,null,null,cache_size,高速缓存值
*/

/*!Model
SybaseDataBase:Sybase数据库,SybaseDataBase,Sybase数据库,true,false
properties
db_log_size:数据库日志段大小,string,null,null,db_log_size,数据库日志段大小
db_create_date:数据库创建日期,string,null,null,db_create_date,数据库创建日期
name:名称,string,null,null,name,名称
db_data_size:数据库数据段大小,string,null,null,db_data_size,数据库数据段大小
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/


import java.util.regex.Matcher;
import java.util.regex.Pattern;

def sybaseCi = discovery_sybase();

discovery_database(sybaseCi)
discovery_cache(sybaseCi)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def getHostname(){
	def sql = "select asehostname()";
	def hostname = ''
	try{
		hostname = $sybase.queryForValue(sql)
	}catch(Exception e){
		$logger.logWarn("exec sql[${sql}] error", e);
	}
	return hostname;
}


def getCharacterset(){
	def row = $sybase.queryForObject("sp_configure 'default character set id'")
	def item = row.getValues();
	def id = item[4]
	return $sybase.queryForValue("select name from master..syscharsets where id=" + id);
}

def discovery_sybase(){
	$logger.logInfo("Discover Sybase");
	def servername = $sybase.queryForValue("select @@servername")
	def version = $sybase.queryForValue("select @@version")
	def sysconfigures_json = [:]
    for(def row in $sybase.query("select name, value from dbo.sysconfigures")){
    	def item = row.getValues();
		def name = item[0]
		def value = item[1]
    	sysconfigures_json[name] = value
    }
    
	def ci = $ci.create("Sybase", "Sybase", servername);
	ci.putAll([
			ip : $sybase.params.ip,
			port : $sybase.params.port,
			instance_name : servername,
			hostname : getHostname(),
			characterset : getCharacterset(),
			page_size : $sybase.queryForValue("SELECT @@maxpagesize"),
		    version : version.split('/EBF')[0].split('/')[-1],
		    max_online_engine : sysconfigures_json['max online engines'],
            number_of_engines_at_startup : sysconfigures_json['number of engines at startup'],
            number_of_user_connections : sysconfigures_json['number of user connections'],
            runnable_process_search_count : sysconfigures_json['runnable process search count'],
            number_of_devices : sysconfigures_json['number of devices'],
            number_of_locks : sysconfigures_json['number of locks'],
            number_of_open_indexes : sysconfigures_json['number of open indexes'],
            number_of_alarms : sysconfigures_json['number of alarms'],
            number_of_open_objects : sysconfigures_json['number of open objects'],
            number_of_sort_buffers : sysconfigures_json['number of sort buffers'],
            number_of_large_io_buffers : sysconfigures_json['number of large i/o buffers'],
            max_memory : convert_bytes(sysconfigures_json['max memory'], new convert_bytes_params(src_unit : 'KB'))
		])
    def osCode = osCodeSearch(version)
    if(osCode){
    	def osCi = $ci.create(osCode, $sybase.params.ip + "-" + ci.hostname)
    	osCi.ip = $sybase.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}


def discovery_database(sybaseCi){
	$logger.logInfo("Discover database");
	def sql = '''
select
	db_name(data_segment.dbid),
	rtrim(convert(char, data_segment.crdate, 111)),
	rtrim(convert(char, data_segment.crdate, 08)),
	str(round(total_data_pages / ((1024.0 * 1024) / @@maxpagesize), 2), 10, 2) || ' MB',
	str(round(total_log_pages / ((1024.0 * 1024) / @@maxpagesize), 2), 10, 	2) || ' MB'
from
	(
	select
		dbid,
		sum(size) total_log_pages,
		lct_admin('logsegment_freepages',
		dbid ) free_log_pages
	from
		master.dbo.sysusages
	where
		segmap & 4 = 4
	group by
		dbid ) log_segment ,
	(
	select
		crdate,
		dbid,
		sum(size) total_data_pages ,
		sum(curunreservedpgs(dbid, lstart, unreservedpgs)) free_data_pages
	from
		master.dbo.sysusages
	where
		segmap <> 4
	group by
		dbid ) data_segment
where
	data_segment.dbid = log_segment.dbid
'''
	for(def row in $sybase.query(sql)){
		def item = row.getValues();
		def name = item[0]
		def ci = $ci.create('SybaseDataBase', name)
        $ci.createRelationship("Inlines", sybaseCi.id, ci.id);
        ci.putAll([
        	db_create_date : item[1].replace('/', '-') + ' ' + item[2],
            db_data_size : item[3].trim(),
            db_log_size : item[4].trim()
        ])
	}
}


def discovery_cache(sybaseCi){
	$logger.logInfo("Discover cache");

	for(def row in $sybase.query('SELECT CacheName, AllocatedKB FROM master.dbo.monCachePool')){
		def item = row.getValues();
		def name = item[0]
		def ci = $ci.create('cache', name)
        $ci.createRelationship("Inlines", sybaseCi.id, ci.id);
        ci.putAll([
        	cache_name : name,
            cache_size : convert_bytes(item[1], new convert_bytes_params(src_unit : 'KB'))
        ])
	}
}
