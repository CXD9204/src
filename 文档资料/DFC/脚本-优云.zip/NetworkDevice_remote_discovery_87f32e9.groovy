ignore_ports = []

/*!Action
action.name=NetworkDevice_remote_discovery_87f32e9
action.descr=NetworkDevice_remote_discovery(snmp v1/v2c) 在以下 厂家的网络系列设备中验证过 H3C:S5500,S5560,S6300,S10500,S12500,S5130,S6800,S7500,S5120,S5024,SR8800,SR6600
action.version=1.0.0
action.protocols=snmp
action.main.model=Switch
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
Router:路由器,Router,路由器,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
networkPort:网络设备接口,inline,null,null,networkPort,网络设备接口
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:软件版本,string,null,null,version,软件版本
port:端口,int,null,null,port,端口
snmp_param:SNMP参数,string,null,null,snmp_param,SNMP参数
name:名称,string,null,null,name,名称
network_brand:品牌,string,null,null,network_brand,品牌
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
desc:描述,string,null,null,desc,描述
*/

/*!Model
NetworkPort:网络设备接口,NetworkPort,网络设备接口,true,false
properties
port_type:接口类型,string,null,null,port_type,接口类型
port_rate:端口速率,int,null,Mbps,port_rate,端口速率
neighbor_hostname:邻居设备名,string,null,null,neighbor_hostname,邻居设备名
mac_list:动态MAC地址表,string,null,null,mac_list,动态MAC地址表
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
port_index:端口索引号,int,null,null,port_index,端口索引号
neighbor_model:邻居设备型号,string,null,null,neighbor_model,邻居设备型号
neighbor_series:邻居设备系列,string,null,null,neighbor_series,邻居设备系列
*/

/*!Model
Switch:交换机,Switch,交换机,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
networkPort:网络设备接口,inline,null,null,networkPort,网络设备接口
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:软件版本,string,null,null,version,软件版本
port:端口,int,null,null,port,端口
snmp_param:SNMP参数,string,null,null,snmp_param,SNMP参数
name:名称,string,null,null,name,名称
network_brand:品牌,string,null,null,network_brand,品牌
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
desc:描述,string,null,null,desc,描述
*/


import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;

def constant = [
'.1.3.6.1.4.1.2011.2.223.2':['huawei','Huawei S7706','Switch'],
'.1.3.6.1.4.1.2011.2.23.285':['huawei','Huawei S5720-56PC-EI-AC','Switch'],
'.1.3.6.1.4.1.2011.2.23.693':['huawei','Huawei S5731-S48T4X','Switch'],
'.1.3.6.1.4.1.2011.2.236.2':['huawei','Huawei S9706','Switch'],
'.1.3.6.1.4.1.2011.2.239.1':['huawei','Huawei CE12804','Switch'],
'.1.3.6.1.4.1.2011.2.239.2':['huawei','Huawei CE12808','Switch'],
'.1.3.6.1.4.1.2011.2.239.29':['huawei','Huawei CE6855-48S6Q-HI','Switch'],
'.1.3.6.1.4.1.2011.2.239.49':['huawei','Huawei CE6865EI','Switch'],
'.1.3.6.1.4.1.2011.2.239.58':['huawei','Huawei CE16804','Switch'],
'.1.3.6.1.4.1.2011.2.239.59':['huawei','Huawei CE16808','Switch'],
'.1.3.6.1.4.1.2011.2.239.66':['huawei','Huawei CE6881','Switch'],
'.1.3.6.1.4.1.2011.2.279.1':['huawei','Huawei S12700','Switch'],
'.1.3.6.1.4.1.2011.2.88.5':['huawei','Huawei NE20E-S8','Router'],
'.1.3.6.1.4.1.25506.1.1':['h3c','H3C S5500-28C-EI', 'Switch'],
'.1.3.6.1.4.1.25506.1.1063':['h3c','H3C S5560-54C-EI','Switch'],
'.1.3.6.1.4.1.25506.1.1074':['h3c','H3C S6300-48S','Switch'],
'.1.3.6.1.4.1.25506.1.1134':['h3c','H3C S10506','Switch'],
'.1.3.6.1.4.1.25506.1.1135':['h3c','H3C S10510','Switch'],
'.1.3.6.1.4.1.25506.1.1148':['h3c','H3C S12508X-AF','Switch'],
'.1.3.6.1.4.1.25506.1.1191':['h3c','H3C S5130-54C-HI','Switch'],
'.1.3.6.1.4.1.25506.1.1210':['h3c','H3C S6800-54QF','Switch'],
'.1.3.6.1.4.1.25506.1.1250':['h3c','H3C S12508-S','Switch'],
'.1.3.6.1.4.1.25506.1.1306':['h3c','H3C S7506E-X','Switch'],
'.1.3.6.1.4.1.25506.1.1461':['h3c','H3C S5560X-54C-EI','Switch'],
'.1.3.6.1.4.1.25506.1.1463':['h3c','H3C S5560X-54C-PWR-EI','Switch'],
'.1.3.6.1.4.1.25506.1.1504':['h3c','H3C S7503E-M','Switch'],
'.1.3.6.1.4.1.25506.1.1733':['h3c','H3C S6800-54QF-H3','Switch'],
'.1.3.6.1.4.1.25506.1.1858':['h3c','H3C S5024PV3-EI','Switch'],
'.1.3.6.1.4.1.25506.1.2':['h3c','H3C S5500-52C-EI','Switch'],
'.1.3.6.1.4.1.25506.1.208':['h3c','H3C S7503E','Switch'],
'.1.3.6.1.4.1.25506.1.209':['h3c','H3C S7506E','Switch'],
'.1.3.6.1.4.1.25506.1.392':['h3c','H3C S12518','Switch'],
'.1.3.6.1.4.1.25506.1.520':['h3c','H3C S5120-52C-PWR-EI','Switch'],
'.1.3.6.1.4.1.25506.1.573':['h3c','H3C S5500-58C-HI','Switch'],
'.1.3.6.1.4.1.25506.1.636':['h3c','H3C S7508E-X','Switch'],
'.1.3.6.1.4.1.25506.1.682':['h3c','H3C S5024P-EI','Switch'],
'.1.3.6.1.4.1.25506.1.8':['h3c','H3C S5500-28C-SI','Switch'],
'.1.3.6.1.4.1.25506.1.875':['h3c','H3C S12510X-AC','Switch'],
'.1.3.6.1.4.1.25506.1.927':['h3c','H3C S5024PV2-EI','Switch'],
'.1.3.6.1.4.1.25506.1.1036':['h3c','H3C SR8810-X-S','Router'],
'.1.3.6.1.4.1.25506.1.194':['h3c','H3C SR6608','Router'],
'.1.3.6.1.4.1.25506.1.354':['h3c','H3C SR6604','Router'],
'.1.3.6.1.4.1.25506.1.438':['h3c','H3C SR6616','Router'],
'.1.3.6.1.4.1.25506.1.73':['h3c','H3C MSR30-20','Router'],
'.1.3.6.1.4.1.25506.1.76':['h3c','H3C MSR50-40','Router'],
'.1.3.6.1.4.1.25506.1.77':['h3c','H3C MSR50-60','Router'],
'.1.3.6.1.4.1.25506.1.771':['h3c','H3C MSR56-60','Router'],
'.1.3.6.1.4.1.4881.1.1.10.1.154':['ruijie','Ruijie S6000-48GT/4SFP','Switch'],
'.1.3.6.1.4.1.4881.1.1.10.1.162':['ruijie','Ruijie S8605E','Switch'],
'.1.3.6.1.4.1.4881.1.1.10.1.184':['ruijie','Ruijie S7808C','Switch'],
'.1.3.6.1.4.1.4881.1.1.10.1.194':['ruijie','Ruijie S5750C-48GT4XS-H','Switch'],
'.1.3.6.1.4.1.4881.1.1.10.1.199':['ruijie','Ruijie S6220-48XS6QXS-H','Switch'],
'.1.3.6.1.4.1.4881.1.1.10.1.44':['ruijie','Ruijie S8610','Switch'],
'.1.3.6.1.4.1.4881.1.2.1.1.42':['ruijie','Ruijie RSR30-44','Router'],
'.1.3.6.1.4.1.4881.1.2.1.1.52':['ruijie','Ruijie RSR7704','Router'],
'.1.3.6.1.4.1.4881.1.2.1.1.73':['ruijie','Ruijie RSR7708-X','Router'],
'.1.3.6.1.4.1.9.1.1024':['cisco','Cisco WS-C3560V2-48TS-S','Switch'],
'.1.3.6.1.4.1.9.1.1045':['cisco','Cisco CISCO2911/K9','Router'],
'.1.3.6.1.4.1.9.1.1226':['cisco','Cisco WS-C3560X-24T-S','Switch'],
'.1.3.6.1.4.1.9.1.1286':['cisco','Cisco WS-C4507R+E','Switch'],
'.1.3.6.1.4.1.9.1.283':['cisco','Cisco WS-C6509-E','Switch'],
'.1.3.6.1.4.1.9.1.516':['cisco','Cisco WS-C3750X-24T-S','Switch'],
'.1.3.6.1.4.1.9.1.615':['cisco','Cisco WS-C3560G-24TS-S','Switch'],
'.1.3.6.1.4.1.9.1.617':['cisco','Cisco WS-C3560G-48TS-E','Switch'],
'.1.3.6.1.4.1.9.12.3.1.3.1467':['cisco','Cisco N9K-C9508','Switch'],
'.1.3.6.1.4.1.9.12.3.1.3.612':['cisco','Cisco N7K-C7010','Switch'],
'.1.3.6.1.4.1.9.12.3.1.3.777':['cisco','Cisco N7K-C7018','Switch'],
'.1.3.6.1.4.1.9.1.1041':['cisco','Cisco C3900-SPE150/K9','Router']
]

constantModels = constant.values().collect{e->e[1]}

def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();


def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
def constantValue = constant[sysObjectId]
if(!constantValue){
	throw new RuntimeException("Unrecognized ID:" + sysObjectId)
}

def deviceCi = $ci.create(constantValue[2], constantValue[2], constantValue[0]);
deviceCi.ip = $snmp.params.ip
deviceCi.network_brand = constantValue[0]
deviceCi.model = constantValue[1]
switch(constantValue[0]){
	case 'h3c':
		disCoveryH3C(deviceCi)
		break;
	case 'cisco':
		disCoveryCisco(deviceCi)
		break;
	case 'ruijie':
		disCoveryRuijie(deviceCi)
		break;
	case 'huawei':
		disCoveryHuawei(deviceCi)
		break;
}
if(deviceCi.hostname){
	deviceCi.name = deviceCi.hostname
	deviceCi.parent.name = deviceCi.hostname
}


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

def disCoveryCisco(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.4.1.9.3.6.3.0")
	def model = deviceCi.model.toLowerCase();
	def version = null
	if(model.split(" ", 2)[-1].startsWith('n')){
		version = get(".1.3.6.1.2.1.47.1.1.1.1.10")
	}
	else {
		version = get(".1.3.6.1.4.1.9.9.25.1.1.1.2.5")
	}
	if(version){
		def index = version.indexOf('$')
		if(index != -1){
			def str = version.substring(index + 1)
			index = str.indexOf('$')
			if(index > 0){
				version = str.substring(0, index)
			}
		}
		deviceCi.version = version
	}
	
	def portNeighbors = [:]
	def portMacLists = [:]
	if(deviceCi.type == 'Switch'){
		portNeighbors = discovery_portIndex_cisco_neighbor();
		portMacLists = discovery_portIndex_mac();
	}
	def portIpLists = discovery_portIndex_ip();
	def portIndexs = discovery_portIndex();

	discovery_networkPort(deviceCi, portIndexs, portNeighbors, portMacLists, portIpLists)
}

def disCoveryRuijie(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.4.1.4881.1.1.10.2.1.1.24.0")
	deviceCi.version = get(".1.3.6.1.4.1.4881.1.1.10.2.21.1.2.1.8.1")

	def portNeighbors = [:]
	def portMacLists = [:]
	if(deviceCi.type == 'Switch'){
		portNeighbors = discovery_portIndex_neighbor();
		portMacLists = discovery_portIndex_mac();
	}
	def portIpLists = discovery_portIndex_ip();
	def portIndexs = discovery_portIndex();

	discovery_networkPort(deviceCi, portIndexs, portNeighbors, portMacLists, portIpLists)
}


def disCoveryH3C(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.2")
	if(!deviceCi.serial_number){
		deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.1")
	}
	deviceCi.version = get(".1.3.6.1.2.1.47.1.1.1.1.10.2")
	if(!deviceCi.version){
		deviceCi.version = get(".1.3.6.1.2.1.47.1.1.1.1.10.1")
	}
	deviceCi.port_num = get(".1.3.6.1.4.1.25506.2.40.2.3.1.0")
	if(!deviceCi.port_num){
		deviceCi.port_num = get(".1.3.6.1.4.1.2011.10.2.40.2.3.1.0")
	}
	
	def snmp_servers = []
	for(def item : walk(".1.3.6.1.4.1.25506.2.38.1.7.1.1.2")){
		snmp_servers.add(item.value)
	}
	deviceCi.snmp_server = snmp_servers.join(",")
	def ntp_servers = []
	for(def item : walk(".1.3.6.1.4.1.25506.8.22.2.1.1.1.1")){
		ntp_servers.add(item.key.split('\\.')[0..3].join('.'))
	}
	deviceCi.ntp_server = ntp_servers.join(",")
	
	def portNeighbors = [:]
	def portMacLists = [:]
	if(deviceCi.type == 'Switch'){
		portNeighbors = discovery_portIndex_neighbor();
		portMacLists = discovery_portIndex_h3c_mac();
	}
	def portIpLists = discovery_portIndex_ip();
	def portIndexs = discovery_portIndex();

	discovery_networkPort(deviceCi, portIndexs, portNeighbors, portMacLists, portIpLists)
}

def disCoveryHuawei(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.2")
	if(!deviceCi.serial_number){
		deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.1")
	}
	if(!deviceCi.serial_number){
		def data = [:]
		def match = ['3' : [], '9' : []]
		def filters = ['3' : '11', '9' : '12']
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.5")){
			if(match[item.value] != null){
				def map = getOrInitMapValue(item.key, data)
				map.type = item.value
			}
		}
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.3")){
			def map = data[item.key]
			if(!map || !map.type){
				continue
			}
			def filter = filters[map.type]
			if(!filter){
				 continue
			}
			if(!item.value){
				map.remove('type') 
				continue
			}
			def ss = item.value.split("\\.")
			if(ss.size() != 10 || ss[8] != filter){
				map.remove('type') 
				continue
			}
		}
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.11")){
			def map = data[item.key]
			if(!map || !map.type || !item.value){
				continue
			}
			match[map.type].add(item.value)
		}
		for(def entry in match){
			if(entry.value){
				deviceCi.serial_number = entry.value.join(',')
				break;
			}
		}
	}
	deviceCi.version = findAllFirst(get(".1.3.6.1.2.1.1.1.0"), 'Version (\\S+)')
	
	def portNeighbors = [:]
	def portMacLists = [:]
	if(deviceCi.type == 'Switch'){
		portNeighbors = discovery_portIndex_neighbor();
		portMacLists = discovery_portIndex_mac();
	}
	def portIpLists = discovery_portIndex_ip();
	def portIndexs = discovery_portIndex();

	discovery_networkPort(deviceCi, portIndexs, portNeighbors, portMacLists, portIpLists)
}

def discovery_networkPort(deviceCi, portIndexs, portNeighbors, portMacLists, portIpLists){
	for(def item in portIndexs){
		def portIndex = item.key
		def value = item.value
		def ci = $ci.create('NetworkPort', value.name)
		ci.putAll([
        	port_index : portIndex,
            port_rate : value.rate,
            port_type : value.type
        ])
		$ci.createRelationship("Inlines", deviceCi.id, ci.id);
        def addMacs = true
		def neighbor = portNeighbors[portIndex]
		if(neighbor){
			ci.putAll([
	        	neighbor_hostname : neighbor.hostname,
	            neighbor_brand : neighbor.brand,
	            neighbor_model : neighbor.model,
	            neighbor_series : neighbor.series
      	  	])
      	  	if(neighbor.model in constantModels){
      	  		addMacs = false
      	  	}
		}
		//非物理口
		if(value.ifType != '6'){
			addMacs = false
		}
		if(addMacs){
			def portIndexNum = Integer.parseInt(portIndex)
			def ports = ignore_ports[$snmp.params.ip]
			if(ports && portIndexNum in ports){
				addMacs = false
			}
		}
		if(addMacs){
			def macs = portMacLists[portIndex]
			if(macs){
				//ci.mac_list = macs.join(",")
			}
		}
		def ips = portIpLists[portIndex]
		if(ips){
			ci.ip = ips.join(",")
		}
	}
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

//邻居设备
def discovery_portIndex_neighbor(){
	def neighbors = [:]
	for(def item in walk(".1.0.8802.1.1.2.1.4.1.1.9")){
		def map = getOrInitMapValue(item.key, neighbors)
		map.hostname = item.value
	}
	for(def item in walk(".1.0.8802.1.1.2.1.4.1.1.10")){
		def map = getOrInitMapValue(item.key, neighbors)
		if(item.value){
			map.putAll(analysisDeviceDesc(item.value))
		}
	}
	def result = [:]
	for(def item in neighbors){
		if(!item.value.hostname){
			continue
		}
		def key = item.key.split("\\.")[-2]
		def neighbor = result[key]
		if(neighbor == null){
			result[key] = item.value
		}
	}
	return result
}

//邻居设备
def discovery_portIndex_cisco_neighbor(){
	def neighbors = discovery_portIndex_neighbor();
	
	def namePorts = [:]
	for(def item : walk(".1.0.8802.1.1.2.1.3.7.1.3")){
		namePorts[item.value] = item.key
	}
	
	def results = [:]
	for(def item : walk(".1.3.6.1.2.1.31.1.1.1.1")){
		def portIndex = item.key
		def portName = item.value
		def neighbor = neighbors[namePorts[portName]]
		if(neighbor){
			results[portIndex] = neighbor
		}
	}
	return results
}

//mac
def discovery_portIndex_mac(){
	def invalids = []
	for(def item : walk(".1.3.6.1.2.1.17.4.3.1.3")){
		if(item.value == '3'){
			continue
		}
		invalids.add(item.key)
	}
	def portNumMacs = [:]
	for(def item : walk(".1.3.6.1.2.1.17.4.3.1.2")){
		def macs = getOrInitMapValue(item.value, portNumMacs, true)
		def ss = item.key.split("\\.")
		def mac = []
		for(int i = Math.max(0, ss.size() - 6) ; i < ss.size() ; i++){
			def str = Integer.toHexString(Integer.parseInt(ss[i]))
			if(str.size() == 1){
				str = "0" + str
			}
			mac.add(str)
		}
		mac = mac.join(":");
		macs.add(mac) 
	}
	//portNum 和 portIndex 的映射
	def portPortLists = [:]
	for(def item : walk(".1.3.6.1.2.1.17.1.4.1.2")){
		def portNum = item.key
		def portIndex = item.value
		def portLists = getOrInitMapValue(portIndex, portPortLists, true)
		def list = portNumMacs[portNum]
		if(list){
			portLists.addAll(list)
		}
	}
	return portPortLists
}

//mac
def discovery_portIndex_h3c_mac(){
	def portNumMacs = [:]
	for(def item : walk(".1.3.6.1.2.1.17.7.1.2.2.1.2")){
		def macs = getOrInitMapValue(item.value, portNumMacs, true)
		def ss = item.key.split("\\.");
		def mac = []
		for(int i = Math.max(0, ss.size() - 6) ; i < ss.size() ; i++){
			def str = Integer.toHexString(Integer.parseInt(ss[i]))
			if(str.size() == 1){
				str = "0" + str
			}
			mac.add(str)
		}
		mac = mac.join(":");
		macs.add(mac)
	}
	//portNum 和 portIndex 的映射
	def portPortLists = [:]
	for(def item : walk(".1.3.6.1.2.1.17.1.4.1.2")){
		def portNum = item.key
		def portIndex = item.value
		def portLists = getOrInitMapValue(portIndex, portPortLists, true)
		def list = portNumMacs[portNum]
		if(list){
			portLists.addAll(list)
		}
	}
	return portPortLists
}

//ip地址
def discovery_portIndex_ip(){
	def ipLists = [:]
	for(def item : walk(".1.3.6.1.2.1.4.20.1.2")){
		def ip = item.key
		def port_index = item.value
		def list = getOrInitMapValue(port_index, ipLists, true)
		list.add(ip)
	}
	return ipLists
}

//端口
def discovery_portIndex(){
	def indexs = [:]
	for(def item : walk(".1.3.6.1.2.1.2.2.1.2")){
		def map = getOrInitMapValue(item.key, indexs)
		map.name = item.value
		map.type = getInterfaceType(item.value)
	}
	for(def item : walk(".1.3.6.1.2.1.31.1.1.1.15")){
		def map = getOrInitMapValue(item.key, indexs)
		map.rate  = item.value
	}
	for(def item : walk(".1.3.6.1.2.1.2.2.1.3")){
		def map = getOrInitMapValue(item.key, indexs)
		map.ifType  = item.value
	}
	return indexs;
}

def getInterfaceType(def descr) {
    descr = descr.toLowerCase();
    if (descr.contains("loopback")){
        return "LoopPort";
    }
    else if (descr.contains("eth") || (descr.contains("slot") && descr.contains("port"))){
        return "EthernetPort";
    }
    else if (descr.contains("serial")){
        return "SerialPort"
    }
    else if (descr.contains("vlan")){
        return "VlanPort"
    }
    else if (descr.contains("aggreg")){
        return "ConvergencePort"
    }
    else{
        return "Other";
    }
}

def analysisDeviceDesc(def deviceDesc){
	def brand = ""
	def model = ""
	def series = ""
	if(deviceDesc){
		if(deviceDesc.contains('H3C')){
			brand = 'H3C'
			model = findAllFirst(deviceDesc, '\r+\nH3C (\\S+)')
			if(!model){
				model = findAllFirst(deviceDesc, '(\\S+) Software')
			}
		}
		else if(deviceDesc.contains('Cisco')){
			brand = 'Cisco'
			model = findAllFirst(deviceDesc, '(\\S+) running on')
		}
		else if(deviceDesc.contains('Ruijie')){
			brand = 'Ruijie'
			model = findAllFirst(deviceDesc, '\\((\\S+)\\)')
		}
		else if(deviceDesc.contains('Huawei')){
			brand = 'Huawei'
			model = findAllFirst(deviceDesc, 'Version \\S+ (\\S+)')
		}
	}
	if(model != ''){
		model = brand + " " + model
		series: brand + " " + analysisSseries(model)
	}
	else if(deviceDesc){
		$logger.logWarn("deviceDesc:" + deviceDesc);
	}
	return [model: model, brand: brand, series: series]
}

def analysisSseries(def model){
	if(model && model != ''){
		return findAllFirst(model, '([A-Za-z]*[0-9]+)')
	}
	return ''
}


def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}
