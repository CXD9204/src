/*!Action
action.name=EMC_Symmetrix_SMI-S_remote_discovery_87f32e9
action.descr=EMC_Symmetrix_SMI-S_remote_discovery 已验证通过DMX,VMAX
action.protocols=smis
action.main.model=FCStorage
discovery.output=Storage
*/

/*!Params
protocol:连接协议,enum,https,false,[http, https]
ip:目标设备IP,ip,,true
port:端口,number,5989,false
username:用户名,text,,false
password:密码,password,,false
namespace:命名空间,text,root/emc,false
privProtocol:加密协议,text,null,true
*/

/*!Model
FCStorage:FC存储,FCStorage,FC存储,false,false
properties
front_port_num:前端端口数量,int,null,null,front_port_num,前端端口数量
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
data_cache:数据缓存,string,null,null,data_cache,数据缓存
mt_model:M/T型号,string,null,null,mt_model,M/T型号
hostname:主机名,string,null,null,hostname,主机名
unconfigured_size:未配置容量,string,null,null,unconfigured_size,未配置容量
model:型号,string,null,null,model,型号
fcstge_brand:品牌,string,null,null,fcstge_brand,品牌
ip:带外管理IP,string,null,null,ip,带外管理IP
version:软件版本(固件版本),string,null,null,version,软件版本(固件版本)
hotspare_num:热备盘个数,int,null,null,hotspare_num,热备盘个数
hardDiskInfo:硬盘信息,inline,null,null,hardDiskInfo,硬盘信息
name:名称,string,null,null,name,名称
controller_num:控制器个数,int,null,个,controller_num,控制器个数
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
fcStoragePool:存储池,inline,null,null,fcStoragePool,存储池
fcStgeLUN:FC存储卷,inline,null,null,fcStgeLUN,FC存储卷
disk_driver_num:磁盘驱动器数,int,null,个,disk_driver_num,磁盘驱动器数
frontPort:前端端口,inline,null,null,frontPort,前端端口
avl_size_after_raid:RAID后可用容量,string,null,null,avl_size_after_raid,RAID后可用容量
phys_size:物理容量,string,null,null,phys_size,物理容量
raidGroup:RAID组,inline,null,null,raidGroup,RAID组
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
used_size_after_raid:RAID后已使用容量,string,null,null,used_size_after_raid,RAID后已使用容量
controller_cache:控制器缓存,string,null,null,controller_cache,控制器缓存
enclosure_num:盘柜个数,int,null,null,enclosure_num,盘柜个数
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
name:硬盘型号,string,null,null,name,硬盘型号
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

/*!Model
FCStoragePool:FC存储池,FCStoragePool,FC存储池,true,false
properties
stge_pool_total_size:容量,string,null,null,stge_pool_total_size,容量
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:存储池名称,string,null,null,name,存储池名称
stge_pool_used_size:已使用容量,string,null,null,stge_pool_used_size,已使用容量
stge_pool_free_size:剩余容量,string,null,null,stge_pool_free_size,剩余容量
*/

/*!Model
FCStgeLUN:FC存储LUN,FCStgeLUN,FC存储LUN,true,false
properties
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
lun_size:LUN大小,string,null,null,lun_size,LUN大小
host_mapping:主机映射,string,null,null,host_mapping,主机映射
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池/RAID组名称,string,null,null,stge_pool_name,存储池/RAID组名称
status:状态,string,null,null,status,状态
*/

/*!Model
FrontPort:前端端口,FrontPort,前端端口,true,false
properties
port_speed:端口速率,string,null,null,port_speed,端口速率
name:前端端口名称,string,null,null,name,前端端口名称
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
RaidGroup:FC存储RAID组,RaidGroup,FC存储RAID组,true,false
properties
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:RAID组名称,string,null,null,name,RAID组名称
combination:组成方式,string,null,null,combination,组成方式
*/

/*!Model
HostGroup:FC存储主机组,HostGroup,FC存储主机组,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
hostGroupLUN:主机组卷,inline,null,null,hostGroupLUN,主机组卷
hostgroup_aloc_size:主机组分配容量,string,null,null,hostgroup_aloc_size,主机组分配容量
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
name:名称,string,null,null,name,名称
hostGroupMapPort:主机组映射端口,inline,null,null,hostGroupMapPort,主机组映射端口
*/

/*!Model
HostGroupLUN:FC存储主机组卷,HostGroupLUN,FC存储主机组卷,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:主机组卷名称,string,null,null,name,主机组卷名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池名称,string,null,null,stge_pool_name,存储池名称
*/

/*!Model
HostGroupMapPort:FC主机组映射端口,HostGroupMapPort,FC主机组映射端口,true,false
properties
name:端口名称,string,null,null,name,端口名称
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def storageCis = discovery_storage()
if(!storageCis){
	return
}

for(def storageCi in storageCis){
	$logger.logInfo("Discover pool");
	discovery_pool(storageCi)
	$logger.logInfo("Discover disk");
	discovery_disk(storageCi)
	$logger.logInfo("Discover fc_port");
	discovery_fc_port(storageCi)
	$logger.logInfo("Discover volume");
	discovery_volume(storageCi)
	//$logger.logInfo("Discover host");
	//discovery_hostgroup(storageCi)
}


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
    	return 0
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_storage(){
	def storageSystems = $smis.getInstancesByClass('Symm_StorageSystem');
	if(!storageSystems){
		$logger.logWarn("not find CIM:Symm_StorageSystem");
		return ;
	}
	
	def storageCis = []
	for(def storageSystem in storageSystems){
		def enclosure_num = 0
		def name = $smis.getProperty(storageSystem, 'ElementName')
		def objectPath = storageSystem.getObjectPath()
		def chassise = $smis.getAssociatedInstances(objectPath, "CIM_Dependency", "Symm_ArrayChassis", "Dependent", "Antecedent")[0]
		def product = $smis.getAssociatedInstances(chassise.getObjectPath(), "CIM_Component", "Symm_ArrayProduct", "PartComponent", "GroupComponent")[0]
		def enclosureChassises = $smis.getAssociatedInstances(product.getObjectPath(), "CIM_Component", "Symm_EnclosureChassis", "GroupComponent", "PartComponent")
		for(def enclosureChassis in enclosureChassises){
			enclosure_num += 1 + $smis.getAssociatedInstances(enclosureChassis.getObjectPath(), "CIM_Component", "Symm_EnclosureChassis", "GroupComponent", "PartComponent").size()
		}
		
		def hostname = name
		def primordialStoragePool = $smis.getAssociatedInstances(objectPath, "CIM_Component", "Symm_PrimordialStoragePool", "GroupComponent", "PartComponent")[0]
		def systemSoftware = $smis.getAssociatedInstances(objectPath, "CIM_InstalledSoftwareIdentity", "Symm_StorageSystemSoftwareIdentity", "System", "InstalledSoftware")[0]
	
		def ci = $ci.create("FCStorage", "FCStorage", hostname);
		ci.putAll([
			hostname: hostname,
	        model : $smis.getProperty(product, 'Version'),
	        version : $smis.getProperty(systemSoftware, 'VersionString'),
	        fcstge_brand : 'emc',
	        enclosure_num : enclosure_num,
	        serial_number : $smis.getProperty(chassise, 'SerialNumber'),
	        controller_num : null,
	        unconfigured_size : convert_bytes($smis.getProperty(primordialStoragePool, 'EMCRemainingRawCapacity')),
	        phys_size : convert_bytes($smis.getProperty(primordialStoragePool, 'EMCTotalRawCapacity')),
	        controller_cache : convert_bytes($smis.getProperty(storageSystem, 'EMCMemorySize'), new convert_bytes_params(src_unit : 'MB'))
		])
		ci.parent.objectPath = objectPath
		storageCis.add(ci)
	}
	return storageCis
}

def discovery_pool(def storageCi){
	def pools = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Symm_VirtualProvisioningPool", "GroupComponent", "PartComponent");
	def avl_size_after_raid = 0L
	def used_size_after_raid = 0L
	for(def item in pools){
		def poolname = $smis.getProperty(item, 'ElementName')
		def ci = $ci.create("FCStoragePool", poolname);
		def total_size = $smis.getProperty(item, 'TotalManagedSpace')
		def free_size = $smis.getProperty(item, 'RemainingManagedSpace')
		def used_size = total_size - free_size
		avl_size_after_raid += total_size
		used_size_after_raid += used_size
		ci.putAll([
			stge_pool_total_size : convert_bytes(total_size),
			stge_pool_used_size : convert_bytes(used_size),
			stge_pool_free_size: convert_bytes(free_size),
			stge_raid_level : $smis.getProperty(item, 'EMCRaidLevel').toLowerCase()
		])
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
	}
	if(avl_size_after_raid != 0L){
		storageCi.avl_size_after_raid = convert_bytes(avl_size_after_raid)
		storageCi.used_size_after_raid = convert_bytes(used_size_after_raid)
	}
}

def discovery_disk(def storageCi){
	def disk_infos = [:]
	def systems = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Symm_ComponentSystem", "GroupComponent", "PartComponent")
	def total_disk_capacity = 0L
	def num = 0;
	for(def system in systems){
		def disks = $smis.getAssociatedInstances(system.getObjectPath(), "CIM_Component", "Symm_DiskDrive", "GroupComponent", "PartComponent")
		for(def item in disks){
			num ++
			def disk_size = $smis.getProperty(item, 'EMCNumberOfBlocks') * $smis.getProperty(item, 'DefaultBlockSize')
			total_disk_capacity += disk_size
			def productID = $smis.getProperty(item, 'EMCModel')
			def disk_info = disk_infos[productID]
			if(!disk_info){
				disk_info = [:]
				disk_infos[productID] = disk_info
				def caption = $smis.getProperty(item, 'Caption').toLowerCase()
				def disk_type = null
				def disk_media = null
				if(caption in ['ssd', 'hdd', 'hhd']){
					disk_media = caption
				}
				else if(caption == 'efd'){
					disk_media = 'ssd'
				}
				else{
					disk_type = caption
				}
				disk_info.putAll([
					disk_num : 1,
	                disk_rpm : $smis.getProperty(item, 'RPM', 0)/1000 + 'k rpm',
	                disk_size : convert_bytes(disk_size),
	                disk_type : disk_type,
	                disk_media : disk_media
	            ])
			}
			else{
				disk_info['disk_num'] += 1
			}
		}
	}
	
	storageCi.putAll([
		disk_driver_num : num
	])
	if(storageCi.phys_size == 0){ //RAID1.0
		storageCi.phys_size = convert_bytes(total_disk_capacity)
		storageCi.unconfigured_size = null
	}
	
	for(def item in disk_infos){
		def ci = $ci.create("HardDiskInfo", item.key.trim());
		ci.putAll(item.value)
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
	}
}

def discovery_fc_port(def storageCi){
	def num = 0;
	def systems =  $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Symm_StorageProcessorSystem", "GroupComponent", "PartComponent")
	for(def system in systems){
		def ports = $smis.getAssociatedInstances(system.getObjectPath(), "CIM_Component", "Symm_FrontEndFCPort", "GroupComponent", "PartComponent")
		for(def item in ports){
			num ++
			def name = $smis.getProperty(item, 'ElementName')
			def ci = $ci.create("FrontPort", name);
			def maxSpeed = $smis.getProperty(item, 'Speed') 
			if(maxSpeed == 0){
				ci.port_speed = 'N/A'
			}
			else{
				ci.port_speed = convert_bytes(maxSpeed, new convert_bytes_params(src_unit : 'GB', return_str : false))[0] + " Gbps"
			}
			ci.wwn = $smis.getProperty(item, 'PermanentAddress')
			$ci.createRelationship("Inlines", storageCi.id, ci.id);
		}
	}
	storageCi.front_port_num = num
}

def discovery_volume(def storageCi){
	def volumes = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Symm_StorageVolume", "GroupComponent", "PartComponent");
	def volumeCis = [:]
	for(def item in volumes){
		def lun_id = $smis.getProperty(item, 'EMCWWN')
		if(lun_id == '00000000000000000000000000000000'){
			continue
		}
		def name = $smis.getProperty(item, 'Name')
		def ci = $ci.create("FCStgeLUN", name);
		def lun_value = $smis.getProperty(item, 'NumberOfBlocks') * $smis.getProperty(item, 'BlockSize')
		ci.putAll([
			lun_id : lun_id,
			status : $smis.getProperty(item, 'StatusDescriptions').join(","),
			lun_size : convert_bytes(lun_value)
		])
		def pools = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_Dependency", "Symm_VirtualProvisioningPool", "Antecedent", "Dependent");
		if(pools){
			ci.stge_pool_name = $smis.getProperty(pools[0], 'ElementName')
		}
		ci.parent.lun_value = lun_value
		ci.parent.lun_host = []
		volumeCis[ci.lun_id] = ci
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
	}
	storageCi.parent.volumeCis = volumeCis
}
