/*!Action 
action.name=WMQ_remote_discovery_87f32e9
action.descr=WMQ_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=WMQQmgr
discovery.output=MQ
*/

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
WMQQmgr:WMQ队列管理器,WMQQmgr,WMQ队列管理器,false,false
properties
wmqLocalQueue:本地队列,inline,null,null,wmqLocalQueue,本地队列
install_path:安装路径,string,null,null,install_path,安装路径
wmqChannel:通道,inline,null,null,wmqChannel,通道
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
version:WMQ版本,string,null,null,version,WMQ版本
qmgr_name:Qmgr名称,string,null,null,qmgr_name,Qmgr名称
wmqListener:监听,inline,null,null,wmqListener,监听
hostname:主机名,string,null,null,hostname,主机名
wmqRemoteQueue:远程队列,inline,null,null,wmqRemoteQueue,远程队列
name:名称,string,null,null,name,名称
deadq:死信队列,string,null,null,deadq,死信队列
*/

/*!Model
WMQLocalQueue:WMQ本地队列,WMQLocalQueue,WMQ本地队列,true,false
properties
q_trigdata:触发通道,string,null,null,q_trigdata,触发通道
maxmsgl:最大消息长度,string,null,null,maxmsgl,最大消息长度
q_max_depth:队列最大深度,int,null,null,q_max_depth,队列最大深度
name:本地队列名称,string,null,null,name,本地队列名称
q_max_qlenth:最大消息大小,string,null,null,q_max_qlenth,最大消息大小
alias_type:队列类型,string,null,null,type,队列类型
*/

/*!Model
WMQChannel:WMQ通道,WMQChannel,WMQ通道,true,false
properties
remote_ip:对端地址,string,null,null,remote_ip,对端地址
remote_port:对端端口,int,null,null,remote_port,对端端口
name:通道名称,string,null,null,name,通道名称
channel_type:通道类型,string,null,null,channel_type,通道类型
xmitq:传输队列,string,null,null,xmitq,传输队列
*/

/*!Model
WMQListener:WMQ监听,WMQListener,WMQ监听,true,false
properties
port:端口,int,null,null,port,端口
name:监听名称,string,null,null,name,监听名称
*/

/*!Model
WMQRemoteQueue:WMQ远程队列,WMQRemoteQueue,WMQ远程队列,true,false
properties
remote_qmgr_name:对端队列管理器名称,string,null,null,remote_qmgr_name,对端队列管理器名称
name:远程队列名称,string,null,null,name,远程队列名称
alias_type:类型,string,null,null,type,类型
destq:对端目的队列,string,null,null,destq,对端目的队列
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

cliUtil = $script.use("common/cli_util");

def qmgrCis = discovery_qmgrs();
if(!qmgrCis){
	$logger.logWarn("not find qmgr");
	return
}
discover_queue(qmgrCis)
discovery_channel(qmgrCis)
discovery_listener(qmgrCis)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def toMap(def text){
	def map = [:]
	def values = findAll(text, '(\\w+)\\((.*?)\\)')
	for(def value in values){
		map[value[0]] = value[1].trim()
	}
	return map
}

def discovery_qmgrs(){
	$logger.logInfo("Discover qmgr");
	def commondResult = cliUtil.executeCommand("which dspmq 2>/dev/null");
	if($text.isNull(commondResult)){
		return ;
	}
	def install_path = cliUtil.executeCommand("dirname $commondResult");
	def hostname = cliUtil.executeCommand("uname -n")
	def cis = []
	for(def line in $text.splitLine(cliUtil.executeCommand("dspmq -o all"))){
		def qmgr = toMap(line)
		def name = qmgr['QMNAME']
		def ci = $ci.create("WMQQmgr", "WMQQmgr", name)
		ci.putAll([
			ip : $ccli.params.ip,
			qmgr_name : name,
			hostname : hostname,
            version : qmgr['INSTVER'],
            deadq : qmgr['DEADQ'],
            install_path : install_path
        ])
        cis.addAll(ci)
	}
	if(cis){
		def system = cliUtil.executeCommand("uname");
		def osCode = osCodeSearch(system)
		if(osCode){
			def osCi = $ci.create(osCode, $ccli.params.ip + "-" + hostname)
    		osCi.ip = $ccli.params.ip
    		for(def ci in cis){
    			$ci.createRelationship("RunsOn", ci.id, osCi.id);
    		}
		}
	}
	return cis;
}

def discover_queue(qmgrCis){
	$logger.logInfo("Discover queue");
	for(def qmgrCi in qmgrCis){
		def commondResult = cliUtil.executeCommand("echo 'dis q(*)'|runmqsc -e ${qmgrCi.name}");	
		for(def name in findAll(commondResult, 'QUEUE\\((.*?)\\)')){
			if(name.startsWith('SYSTEM')){
				continue
			}
			def info = toMap(cliUtil.executeCommand("echo 'dis queue(${name})'|runmqsc -e ${qmgrCi.name}"))
			def ci = null
			def type = info['TYPE']
			if(type == 'QREMOTE'){
				ci = $ci.create('WMQRemoteQueue', name)
				ci.putAll([
					alias_type : type,
                    remote_qmgr_name : info['RQMNAME'],
                    remote_queue_name : info['RNAME']
				])
			}
			else {
				ci = $ci.create('WMQLocalQueue', name)
				ci.putAll([
					alias_type : type,
                    maxmsgl : info['MAXMSGL'],
                    q_trigdata : info['TRIGDATA'],
                    q_max_depth : info['MAXDEPTH'],
                    q_max_qlenth : info['MAXDEPTH']
				])
			}
			$ci.createRelationship("Inlines", qmgrCi.id, ci.id);
		}
	}	
}

def discovery_channel(qmgrCis){
	$logger.logInfo("Discover channel");
	for(def qmgrCi in qmgrCis){
		def commondResult = cliUtil.executeCommand("echo 'dis channel(*)'|runmqsc -e ${qmgrCi.name}");	
		for(def name in findAll(commondResult, 'CHANNEL\\((.*?)\\)')){
			if(name.startsWith('SYSTEM')){
				continue
			}
			def info = toMap(cliUtil.executeCommand("echo 'dis channel(${name})'|runmqsc -e ${qmgrCi.name}"))
			def remote_ip = null
			def remote_port = null
			def conname = info['CONNAME']
			if(conname){
				def ss = conname.split('\\(')
				remote_ip = ss[0]
				remote_port = ss[1]
			}
			def ci = $ci.create('WMQChannel', name)
			ci.putAll([
				channel_type : info['CHLTYPE'],
            	xmitq : info['XMITQ'],
            	remote_ip : remote_ip,
            	remote_port : remote_port,
			])
			$ci.createRelationship("Inlines", qmgrCi.id, ci.id);
		}
	}	
}

def discovery_listener(qmgrCis){
	$logger.logInfo("Discover listener");
	def system = cliUtil.executeCommand("uname");
	for(def qmgrCi in qmgrCis){
		def commondResult = cliUtil.executeCommand("echo 'dis LSSTATUS(*)'|runmqsc -e ${qmgrCi.name}");	
		for(def item in findAll(commondResult, 'LISTENER\\((.*?)\\)[\\s\\S]*?PID\\((.*?)\\)')){
			def name = item[0]
			def port = null;
			if(system == 'AIX'){
				port = cliUtil.executeCommand("netstat -Aan|grep LISTEN|while read saddr proto recv send laddr raddr state; do  pid=\$(rmsock \$saddr tcpcb|awk '{print \$(NF-1)}'); [[ \$pid == '${item[1]}' ]] && echo \$laddr|awk -F'.' '{print  \$NF}'; done")
				println port
			}
			else {
				port = cliUtil.executeCommand("netstat -antp 2>/dev/null | grep -w '${item[1]}/runmqlsr'| awk '{print \$4}'|awk -F: '{print \$NF}'")
			}
			
			def ci = $ci.create('WMQListener', name)
			ci.port = port
			$ci.createRelationship("Inlines", qmgrCi.id, ci.id);
		}
	}	
}

