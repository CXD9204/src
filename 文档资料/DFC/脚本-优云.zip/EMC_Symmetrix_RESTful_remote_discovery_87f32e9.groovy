/*!Action
action.name=EMC_Symmetrix_RESTful_remote_discovery_87f32e9
action.descr=EMC_Symmetrix_RESTful_remote_discovery 已验证通过VMAX
action.version=1.0.0
action.protocols=http
action.main.model=FCStorage
discovery.output=Storage
*/

/*!Params
ip:目标设备IP,ip,,true
username:用户名,text,,false
port:端口,number,8443,false
password:密码,password,,false
*/

/*!Model
FCStorage:FC存储,FCStorage,FC存储,false,false
properties
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
*/

/*!Model
HostGroup:FC存储主机组,HostGroup,FC存储主机组,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
hostGroupLUN:主机组卷,inline,null,null,hostGroupLUN,主机组卷
hostgroup_aloc_size:主机组分配容量,string,null,null,hostgroup_aloc_size,主机组分配容量
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
name:名称,string,null,null,name,名称
hostGroupMapPort:主机组映射端口,inline,null,null,hostGroupMapPort,主机组映射端口
*/

/*!Model
HostGroupLUN:FC存储主机组卷,HostGroupLUN,FC存储主机组卷,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:主机组卷名称,string,null,null,name,主机组卷名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池名称,string,null,null,stge_pool_name,存储池名称
*/

/*!Model
HostGroupMapPort:FC主机组映射端口,HostGroupMapPort,FC主机组映射端口,true,false
properties
name:端口名称,string,null,null,name,端口名称
*/


import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;


def httpclientBuild = HttpClientBuilder.create().setSSLSocketFactory(getSSL());
def provider = new BasicCredentialsProvider();
def credentials = new UsernamePasswordCredentials($scriptParams.username, $scriptParams.password);
provider.setCredentials(AuthScope.ANY, credentials);
httpclientBuild.setDefaultCredentialsProvider(provider)
httpclient = httpclientBuild.build();
baseUrl = "http://" + $scriptParams.ip + ':' + $scriptParams.port

def storageCis = discovery_storage()
for(def storageCi : storageCis){
	$logger.logInfo("Discover storage group");
	discovery_storagegroup(storageCi)
	$logger.logInfo("Discover maskingview");
	discovery_maskingview(storageCi)
    $logger.logInfo("Discover pool");
	discovery_pool(storageCi)
	$logger.logInfo("Discover volume");
	discovery_volume(storageCi)
	$logger.logInfo("Discover host");
	discovery_host(storageCi)
	$logger.logInfo("Discover hostgroup");
	discovery_hostgroup(storageCi)
	break;
}


def discovery_storage(){
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix'))
	def symmetrixIds = obj.symmetrixId
	if(!symmetrixIds){
		$logger.logWarn("not find symmetrix ids");
		return
	}
	def storageCis = []
	for(def symmetrixId : symmetrixIds){
		def ci = $ci.create("FCStorage", "FCStorage", symmetrixId);
		ci.serial_number = symmetrixId
		ci.parent.symmetrixId = symmetrixId
		storageCis.add(ci)
	}
	return storageCis
}

def discovery_maskingview(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def maskingViewStorageGroups = [:]
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/maskingview'))
	if(obj.maskingViewId){
		for(def maskingViewId : obj.maskingViewId){
			obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/maskingview/' + maskingViewId)).maskingView[0]
			maskingViewStorageGroups.put(maskingViewId, obj.storageGroupId)
		}
	}
	storageCi.parent.maskingViewStorageGroups = maskingViewStorageGroups
}

def discovery_host(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def maskingViewStorageGroups = storageCi.parent.maskingViewStorageGroups
	def storageGroupVolumns = storageCi.parent.storageGroupVolumns
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/host'))
	if(obj.hostId){
		for(def hostId : obj.hostId){
			obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/host/' + hostId)).host[0]
			if(obj.hostgroup){//存在对应的主机组,有主机组来发现
				continue
			}
			def hostGroupCi = $ci.create("HostGroup", hostId);
			hostGroupCi.putAll([
				stge_sn : storageCi.serial_number,
				hostgroup_name : hostId
			])
			$ci.createRelationship("RunsOn", hostGroupCi.id, storageCi.id);
			for(def initiator : obj.initiator){
				def ci = $ci.create("HostGroupMapPort", initiator);
				$ci.createRelationship("Inlines", hostGroupCi.id, ci.id);
			}
			buildHostVolume(storageCi, hostGroupCi, obj.maskingview)
		}
	}
}


def discovery_hostgroup(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/hostgroup'))
	if(obj.hostGroupId){
		for(def hostGroupId : obj.hostGroupId){
			obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/hostgroup/' + hostGroupId)).hostGroup[0]
			if(obj.host){//不存在主机先忽略
				continue
			}
			def hostGroupCi = $ci.create("HostGroup", hostGroupId);
			hostGroupCi.putAll([
				stge_sn : storageCi.serial_number,
				hostgroup_name : hostGroupId
			])
			$ci.createRelationship("RunsOn", hostGroupCi.id, storageCi.id);
			for(def host : obj.host){
				for(def initiator : host.initiator){
					def ci = $ci.create("HostGroupMapPort", initiator);
					$ci.createRelationship("Inlines", hostGroupCi.id, ci.id);
				}
			}
			buildHostVolume(storageCi, hostGroupCi, obj.maskingview)
		}
	}
}

def buildHostVolume(def storageCi, hostGroupCi, maskingviewIds){
	def maskingViewStorageGroups = storageCi.parent.maskingViewStorageGroups
	def storageGroupVolumns = storageCi.parent.storageGroupVolumns
	def volumes = []
	if(maskingviewIds){
		for(def maskingviewId : maskingviewIds){
			def targetStorageGroupId = maskingViewStorageGroups[maskingviewId]
			if(!targetStorageGroupId){
				continue
			}
			def storageGroupIds = findStorageGroup(maskingViewStorageGroups, targetStorageGroupId)
			for(def storageGroupId : storageGroupIds){
				def temps = storageGroupVolumns[storageGroupId]
				if(temps){
					volumes.addAll(temps)	
				}
			}
		}
	}
	def hosts_lun_size = 0
	for(def volume : volumes){
		def ci = $ci.create('HostGroupLUN', volume.name)
        ci.putAll(volume)
        $ci.createRelationship("Inlines", hostGroupCi.id, ci.id);
		hosts_lun_size += volume.lun_value
	}
	hostGroupCi.hostgroup_aloc_size = convert_bytes(hosts_lun_size, new convert_bytes_params(src_unit : 'MB'))
}

def findStorageGroup(alls, storageGroupId){
	def results = []
	def targets = [storageGroupId]
	loopStorageGroup(alls, targets, results)
	return targets
}

def loopStorageGroup(alls, targets, results){
	def temps = []
	for(def target : targets){
		if(!results.contains(target)){
			results.add(target)
			def nexts = alls[target]
			if(nexts){
				temps.addAll(nexts)
			}
		}
	}
	if(temps){
		loopStorageGroup(all, temps, results)
	}
}

def discovery_storagegroup(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def storageGroups = [:]
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/storagegroup'))
	if(obj.storageGroupId){
		for(def storageGroupId : obj.storageGroupId){
			obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/storagegroup/' + storageGroupId)).storageGroup[0]
			storageGroups.put(storageGroupId, obj.parent_storage_groups)
		}
	}
	storageCi.parent.storageGroups = storageGroups
}

def discovery_pool(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def volumePools = [:]
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/thinpool'))
	if(obj.poolId){
		for(def poolId : obj.poolId){
			obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/thinpool/' + poolId)).thinPool[0]
			addVolumePool(volumePools, obj.enabled_data_vols, poolId)
			addVolumePool(volumePools, obj.disabled_data_vols, poolId)
		}
	}
	storageCi.parent.volumePools = volumePools
}

def addVolumePool(volumePools, def volumes, def poolId){
	if(volumes){
		for(def volumeId : volumes){
			volumePools.put(volumeId, poolId)
		}
	}
}

def discovery_volume(def storageCi){
	def symmetrixId = storageCi.parent.symmetrixId
	def volumePools = storageCi.parent.volumePools
	def volumnIds = []
	def obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/volume'))
	def id = obj.getString('id')
	def count = obj.getIntValue('count')
	def size = obj.getIntValue('maxPageSize')
	def from = 1
	def to = size
	obj = obj.getJSONObject('resultList')
	while(true){
		volumnIds.addAll(obj.result.collect{e->e.volumeId})
		if(to >= count){
			break;
		}
		from += size
		to += size
		if(to > count){
			to = count
		}
		obj = JSONObject.parseObject(doGet('/univmax/restapi/common/Iterator/'+ id + '/page?from=' + from + "&to=" + to))
	}
	
	def storageGroupVolumns = [:]
	for(def volumnId : volumnIds){
		obj = JSONObject.parseObject(doGet('/univmax/restapi/provisioning/symmetrix/' + symmetrixId + '/volume/' + volumnId)).volume[0]
		def storageGroupIds = obj.storageGroupId
		if(storageGroupIds){
			if(storageGroupIds.size() > 1){
				$logger.logWarn('volumnId:' + volumnId + ",storageGroupIds:" + storageGroupIds)
				continue
			}		
			def storageGroupId = storageGroupIds[0]
			def volumes = storageGroupVolumns[storageGroupId]
			if(!volumes){
				volumes = []
				storageGroupVolumns[storageGroupId] = volumes
			}
				
			def lun_size = convert_bytes(obj.cap_mb, new convert_bytes_params(src_unit : 'MB'))
			def stge_pool_name = volumePools[volumnId]
			volumes.add([name : volumnId, lun_size :lun_size, lun_value : obj.cap_mb, lun_id: obj.wwn, stge_pool_name : stge_pool_name])
		}
	}
	storageCi.parent.storageGroupVolumns = storageGroupVolumns
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def doGet(url) {
	def response = null;
	def method = null;
	try{
		url = baseUrl + url
		//$logger.logInfo("url:" + url);
		method = new HttpGet(url);
		method.addHeader("Accept", "*/*");
		method.addHeader("Connection", "close");
		//method.addHeader("Authorization", "Basic YWRtaW46P1h8QjIudmBeLA==");

		response = httpclient.execute(method);
		def entity = response.getEntity();
		def code = response.getStatusLine().getStatusCode();
		def body = "";
		if(entity){
			body = EntityUtils.toString(entity, "UTF-8");
		}
		//$logger.logInfo(url + "!" + code);
		//$logger.logInfo(body);
		if(!responseIsSuccess(code)){
			throw new RuntimeException("httpErroe!url:${url},responseCode:${code},responseBody${body}")
		}
		//$logger.logInfo("url end :" + url);
		return body;
	} finally {
		close(method)
		close(response)
	}
}

def close(obj){
	try{
		if(obj){
			obj.close();
		}
	}catch(Exception e){
		
	}
}

def responseIsSuccess(code){
    if (code >= 200 && code < 300){
        return true;
    }
    return false;
}

def getSSL(){
	def sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
	    //信任所有
	    public boolean isTrusted(X509Certificate[] chain,
	        String authType) throws CertificateException {
	        return true;
	    }
	
	}).build();
	
	def sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
	return sslsf;
}