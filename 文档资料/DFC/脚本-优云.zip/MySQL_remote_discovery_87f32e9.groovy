/*!Action 
action.name=MySQL_remote_discovery_87f32e9
action.descr=MySQL_remote_discovery
action.version=1.0.0
action.protocols=mysql
action.main.model=MySQL
discovery.output=Database
*/
 
/*!Params
ip:目标设备IP,ip,,true
port:端口,number,3306,false
db:数据库,text,mysql,false
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
MySQL:MySQL实例,MySQL,MySQL实例,false,false
properties
master_info_file:master-info文件,string,null,null,master_info_file,master-info文件
binlog_format:binlog的格式,string,null,null,binlog_format,binlog的格式
slave_load_tmpdir:slave_load_tmpdir路径,string,null,null,slave_load_tmpdir,slave_load_tmpdir路径
install_path:安装路径,string,null,null,install_path,安装路径
log_error: 错误日志文件,string,null,null,log_error, 错误日志文件
expire_logs_days:binlog过期时间,int,null,null,expire_logs_days,binlog过期时间
bind_address:绑定地址,string,null,null,bind_address,绑定地址
relay_log_info_file:relay_log_info文件,string,null,null,relay_log_info_file,relay_log_info文件
default_storage_engine:缺省存储引擎,string,null,null,default_storage_engine,缺省存储引擎
hostname:主机名,string,null,null,hostname,主机名
sync_binlog:sync_binlog值,int,null,null,sync_binlog,sync_binlog值
log_bin_basename:log_bin_basename,string,null,null,log_bin_basename,log_bin_basename
binlog_cache_size:binlog的cached值,string,null,null,binlog_cache_size,binlog的cached值
relay_log:relay-log日志路径,string,null,null,relay_log,relay-log日志路径
slow_query_log:慢查询控制开关,string,null,null,slow_query_log,慢查询控制开关
innodb_log_file_size:innodb日志文件大小,string,null,null,innodb_log_file_size,innodb日志文件大小
innodb_read_io_threads:innodb_read_io_threads,int,null,null,innodb_read_io_threads,innodb_read_io_threads
max_connections:最大连接数,int,null,null,max_connections,最大连接数
innodb_log_buffer_size:innodb日志缓冲区大小,string,null,null,innodb_log_buffer_size,innodb日志缓冲区大小
innodb_write_io_threads:innodb_write_io_threads,int,null,null,innodb_write_io_threads,innodb_write_io_threads
max_allowed_packet:最大允许包大小,string,null,null,max_allowed_packet,最大允许包大小
slow_query_log_file:慢查询日志文件,string,null,null,slow_query_log_file,慢查询日志文件
innodb_buffer_pool_size:	innodb缓冲区大小,string,null,null,innodb_buffer_pool_size,	innodb缓冲区大小
datadir:数据目录,string,null,null,datadir,数据目录
ip:IP地址,string,null,null,ip,IP地址
max_connect_errors:最大错误连接数,int,null,null,max_connect_errors,最大错误连接数
open_files_limit:打开文件限制个数,int,null,null,open_files_limit,打开文件限制个数
mysqlUserPrivileges:MySQL用户权限,inline,null,null,mysqlUserPrivileges,MySQL用户权限
collation_server:字符序,string,null,null,collation_server,字符序
general_log_file:通用日志文件,string,null,null,general_log_file,通用日志文件
server_id:实例ID,int,null,null,server_id,实例ID
character_set_server:字符集,string,null,null,character_set_server,字符集
version:版本,string,null,null,version,版本
max_binlog_size: binlog文件最大值,string,null,null,max_binlog_size, binlog文件最大值
log_bin:binlog打开方式,string,null,null,log_bin,binlog打开方式
repl_mode:复制模式,string,null,null,repl_mode,复制模式
pid_file:守护PID文件,string,null,null,pid_file,守护PID文件
plugin_dir:插件目录,string,null,null,plugin_dir,插件目录
max_user_connections:用户最大连接数,int,null,null,max_user_connections,用户最大连接数
port:端口,int,null,null,port,端口
innodb_log_files_in_group:innodb日志组个数,int,null,null,innodb_log_files_in_group,innodb日志组个数
mysqlDatabase:MySQL数据库,inline,null,null,mysqlDatabase,MySQL数据库
instance_role:实例角色,string,null,null,instance_role,实例角色
name:名称,string,null,null,name,名称
innodb_file_per_table:innodb独立表空间控制开关,string,null,null,innodb_file_per_table,innodb独立表空间控制开关
socket:套接字,string,null,null,socket,套接字
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
MySQLUserPrivileges:MySQL用户权限,MySQLUserPrivileges,MySQL用户权限,true,false
properties
privilege_type:权限类型,string,null,null,privilege_type,权限类型
name:名称,string,null,null,name,名称
is_grantable:能将此权限赋予其他用户,string,null,null,is_grantable,能将此权限赋予其他用户
*/

/*!Model
MySQLDatabase:MySQL数据库,MySQLDatabase,MySQL数据库,true,false
properties
character_set_database:字符集,string,null,null,character_set_database,字符集
name:名称,string,null,null,name,名称
database_size:数据库大小,string,null,null,database_size,数据库大小
*/

/*!Model
MySQLCluster:MySQL集群,MySQLCluster,MySQL集群,false,false
properties
vipMember:VIP成员,inline,null,null,vipMember,VIP成员
cluster_instance_port:集群实例端口,string,null,null,cluster_instance_port,集群实例端口
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
VIPMember:VIP成员,VIPMember,VIP成员,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
MySQLDR:MySQL容灾,MySQLDR,MySQL容灾,false,false
properties
dr_perst_ip:容灾永久IP,string,null,null,dr_perst_ip,容灾永久IP
name:名称,string,null,null,name,名称
dr_instance_port:容灾实例端口,string,null,null,dr_instance_port,容灾实例端口
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def mysqlCi = discovery_mysql();

discovery_database(mysqlCi)
discovery_user_privileges(mysqlCi)
discovery_cluster(mysqlCi)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_mysql(){
	$logger.logInfo("Discover mysql");
	def show_variables = [:]
	for(def row in $mysql.query("show variables")){
		def item = row.getValues()
		def name = item[0]
		def value = item[1]
		show_variables[name] = value
	}
	def ci = $ci.create("MySQL", "MySQL", "MYSQL" + $mysql.params.port);
	ci.putAll([
			ip : $mysql.params.ip,
			port : $mysql.params.port,
		    version : $mysql.queryForValue("select version()"),
		    master_info_file : show_variables['master_info_repository'],
		    open_files_limit : show_variables['open_files_limit'],
            binlog_format : show_variables['binlog_format'],
            slave_load_tmpdir : show_variables['slave_load_tmpdir'],
            install_path : show_variables['basedir'],
            log_error : show_variables['log_error'],
            expire_logs_days : show_variables['expire_logs_days'],
            bind_address : show_variables['bind_address'],
            relay_log_info_file : show_variables['relay_log_info_file'],
            default_storage_engine : show_variables['default_storage_engine'],
            innodb_buffer_pool_size : convert_bytes(show_variables['innodb_buffer_pool_size'], new convert_bytes_params(src_unit : 'B')),
            max_connections : show_variables['max_connections'],
            hostname : $mysql.queryForValue("select @@HOSTNAME"),
            sync_binlog : show_variables['sync_binlog'],
            binlog_cache_size : convert_bytes(show_variables['max_binlog_cache_size'], new convert_bytes_params(src_unit : 'B')),
            relay_log : show_variables['relay_log_basename'],
            character_set_server : show_variables['character_set_server'],
            innodb_log_file_size : convert_bytes(show_variables['innodb_log_file_size'], new convert_bytes_params(src_unit : 'B')),
            innodb_read_io_threads : show_variables['innodb_read_io_threads'],
            innodb_log_buffer_size : convert_bytes(show_variables['innodb_log_buffer_size'], new convert_bytes_params(src_unit : 'B')),
            innodb_write_io_threads : show_variables['innodb_write_io_threads'],
            max_allowed_packet : convert_bytes(show_variables['max_allowed_packet'], new convert_bytes_params(src_unit : 'B')),
            slow_query_log_file : show_variables['slow_query_log_file'],
            datadir : show_variables['datadir'],
            max_connect_errors : show_variables['max_connect_errors'],
            collation_server : show_variables['collation_server'],
            general_log_file : show_variables['general_log_file'],
            slow_query_log : show_variables['slow_query_log'],
            server_id : show_variables['server_id'],
            max_binlog_size : convert_bytes(show_variables['max_binlog_size'], new convert_bytes_params(src_unit : 'B')),
            pid_file : show_variables['pid_file'], 
            innodb_log_files_in_group : show_variables['innodb_log_files_in_group'],
            innodb_file_per_table : show_variables['innodb_file_per_table'],
            socket : show_variables['socket'],
            max_user_connections : show_variables['max_user_connections'],
            log_bin_basename : show_variables['log_bin_basename'],
            log_bin : show_variables['log_bin'].toLowerCase()
		])
	def is_master_res = $mysql.queryForValue("SELECT count(*) FROM information_schema.PROCESSLIST AS p WHERE p.COMMAND = 'Binlog Dump'");
	def show_slave_status = $mysql.queryForObject("show slave status");
	def instance_role = null
	if(is_master_res == 0){
    	if(!show_slave_status){
        	ci.instance_role = 'standalone'
        }
        else{
        	ci.instance_role='slave'
        	def obj = $mysql.queryForObject("show status where variable_name = 'Rpl_semi_sync_slave_status'");
        	def repl_mode = 'async'
        	if(obj['value'] == 'ON'){
        		repl_mode = 'semi_sync'
        	}
            ci.repl_mode = repl_mode
        }
    }         
    ci.instance_role = 'master'
    def osInfo = $mysql.queryForValue("select @@version_compile_os")
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, $mysql.params.ip + "-" + ci.hostname)
    	osCi.ip = $mysql.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}


def discovery_database(mysqlCi){
	$logger.logInfo("Discover database");
	def sql = "SELECT table_schema AS DataBase_Name, sum( data_length + index_length )  AS database_size FROM information_schema.TABLES  where table_schema not in ('sys','performance_schema','mysql','information_schema') GROUP BY table_schema"
	for(def row in $mysql.query(sql)){
		def item = row.getValues();
		def name = item[0]
		def ci = $ci.create('MySQLDatabase', name)
        $ci.createRelationship("Inlines", mysqlCi.id, ci.id);
        ci.database_size = convert_bytes(item[1], new convert_bytes_params(src_unit : 'B'))
        def show_database_charset_res = $mysql.queryForObject("show create database ${name}").getValues()[1]
        ci.charset = search(show_database_charset_res, 'DEFAULT\\s+CHARACTER\\s+SET\\s+(\\S*)').split()[-1]
	}
}

def discovery_user_privileges(mysqlCi){
	$logger.logInfo("Discover user Privileges");
	def sql = """select * from information_schema.user_privileges where GRANTEE not in ("'root'@'localhost'","'mysql.sys'@'localhost'")"""
	for(def row in $mysql.query(sql)){
		def item = row.getValues();
		def ci = $ci.create('MySQLUserPrivileges', item[0])
        $ci.createRelationship("Inlines", mysqlCi.id, ci.id);
        ci.putAll([
        	 privilege_type : item[2],
        	 is_grantable : item[3].toLowerCase()
        ])
	}
}

def getKey(def ip){
	return ip.split("\\.")[0..2].join(".");
}

def discovery_cluster(mysqlCi){
	$logger.logInfo("Discover cluster");
	
	def sql = "show slave hosts";
	def table = null;
	try{
		table = $mysql.query(sql);
	}catch(Exception e){
		$logger.logWarn("exec sql[${sql}] error", e);
		return null;
	}
	def key = getKey($mysql.params.ip)
	def clusterIps = [$mysql.params.ip]
	def clusterPorts = [$mysql.params.port.toString()]
	def allIps = [$mysql.params.ip]
	def allPorts = [$mysql.params.port.toString()]
	
	def hasNoHost = false;
	for(def row in $mysql.query(sql)){
		def item = row.getValues();
		def host = item[1]
		def port = item[2].toString()
		if(!host){
			hasNoHost = true
			break
		}
		def k = getKey(host)
		allIps.add(host)
		allPorts.add(port)
		if(k == key){
			clusterIps.add(host)
			clusterPorts.add(port)
		}
	}
	if(hasNoHost){
		$logger.logWarn("configure report-host error");
		return 
	}
	def clusterCi = null
	def drCi = null
	def ci = null
	if(clusterIps.size() > 1){
        def names = "MySQL" + clusterPorts.sort({a, b -> return compareStr(a, b);}).join("_")
        def ips = clusterIps.unique().sort({a, b -> return compareStr(a, b);}).join("_")
        ci = $ci.create('MySQLCluster', names)
        ci.putAll([
        	cluster_instance_port : names,
        	cluster_perst_ip : ips
        ])
        clusterCi = ci
        $ci.createRelationship("Contains", clusterCi.id, mysqlCi.id);
        
        def size = clusterIps.size();
        for(def i = 1; i < size; i++){
        	def ip = clusterIps[i]
			def port = clusterPorts[i]
			def name = "MYSQL${port}"
			ci = $ci.create('MySQL', name)
			ci.putAll([
				ip : ip,
				port : port
			])
			$ci.createRelationship("Contains", clusterCi.id, ci.id);
        }
	}
	if(allIps.size() > clusterIps.size()){
		def names = "MySQL" + allPorts.sort({a, b -> return compareStr(a, b);}).join("_")
        def ips = allIps.unique().sort({a, b -> return compareStr(a, b);}).join("_")
        ci = $ci.create('MySQLDR', names)
        ci.putAll([
        	dr_instance_port : names,
        	dr_perst_ip : ips
        ])
        drCi = ci
        if(clusterCi){
        	$ci.createRelationship("Contains", drCi.id, clusterCi.id);
        }
        else {
        	$ci.createRelationship("Contains", drCi.id, mysqlCi.id);
        }
        
        def size = allIps.size();
        for(def i = 1; i < size; i++){
        	def ip = allIps[i]
        	if(ip in clusterIps){
   				continue     		
        	}
			def port = allPorts[i]
			def name = "MYSQL${port}"
			ci = $ci.create('MySQL', name)
			ci.putAll([
				ip : ip,
				port : port
			])
			$ci.createRelationship("Contains", drCi.id, ci.id);
        }
	}
}
