/*!Action
action.name=AIX_remote_discovery_87f32e9
action.descr=AIX_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=AIX
discovery.output=Computer
 */

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties
mw_soft_ver:中间件软件/版本,string,null,null,mw_soft_ver,中间件软件/版本
unix_crontab:定时作业,table,null,null,unix_crontab,定时作业
unixGroup:用户组,inline,null,null,unixGroup,用户组
hostname:主机名,string,null,null,hostname,主机名
pass_max_day:密码有效期,int,null,天,pass_max_day,密码有效期
osHCA:OS的HCA卡,inline,null,null,osHCA,OS的HCA卡
password_minlen:密码最小长度,int,null,null,password_minlen,密码最小长度
aix_max_uproc:最大用户进程数,int,null,null,aix_max_uproc,最大用户进程数
swap_size:交换分区大小,string,null,null,swap_size,交换分区大小
pass_min_day:密码最短有效期,int,null,天,pass_min_day,密码最短有效期
user_tmout:会话超时时间,int,null,秒,user_tmout,会话超时时间
ip:IP地址,string,null,null,ip,IP地址
dns_server:DNS服务器,string,null,null,dns_server,DNS服务器
bits:位数,string,null,null,bits,位数
aixVmo:vmo参数,inline,null,null,aixVmo,vmo参数
version:版本,string,null,null,version,版本
ips:IP列表,array,null,null,ips,IP列表
lpar_id:分区ID,int,null,null,lpar_id,分区ID
openssl_ver:openssl版本,string,null,null,openssl_ver,openssl版本
unixUser:用户,inline,null,null,unixUser,用户
name:名称,string,null,null,name,名称
aixNo:no参数,inline,null,null,aixNo,no参数
password_dcredit:密码最少数字,int,null,null,password_dcredit,密码最少数字
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
aix_aio_maxreqs:异步IO,int,null,null,aix_aio_maxreqs,异步IO
lpar_name:分区名称,string,null,null,lpar_name,分区名称
default_gateway:缺省网关,string,null,null,default_gateway,缺省网关
osLunInfo:OS的LUN,inline,null,null,osLunInfo,OS的LUN
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_arch:CPU架构,string,null,null,cpu_arch,CPU架构
user_unlock_time:锁定时间,int,null,秒,user_unlock_time,锁定时间
osNIC:OS的网卡,inline,null,null,osNIC,OS的网卡
tool_soft_ver:工具软件/版本,string,null,null,tool_soft_ver,工具软件/版本
db_soft_ver:数据库软件/版本,string,null,null,db_soft_ver,数据库软件/版本
unixVG:卷组,inline,null,null,unixVG,卷组
osPort:监听端口,inline,null,null,osPort,监听端口
fileSystem:文件系统,inline,null,null,fileSystem,文件系统
password_ocredit:密码最少特殊字符,int,null,null,password_ocredit,密码最少特殊字符
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
time_zone:时区,string,null,null,time_zone,时区
memory_size:内存大小,string,null,null,memory_size,内存大小
osHBA:OS的HBA卡,inline,null,null,osHBA,OS的HBA卡
user_deny_cnt:用户登录失败锁定次数,int,null,null,user_deny_cnt,用户登录失败锁定次数
unixLV:逻辑卷,inline,null,null,unixLV,逻辑卷
openssh_ver:openssh版本,string,null,null,openssh_ver,openssh版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
osDisk:OS的本地磁盘,inline,null,null,osDisk,OS的本地磁盘
*/

/*!Model
unix_crontab:定时作业,unix_crontab,定时作业,false,true
properties
user_name:用户,string,null,null,user_name,用户
script:脚本,string,null,null,script,脚本
run_time:执行时间,string,null,null,run_time,执行时间
*/

/*!Model
UnixGroup:Unix用户组,UnixGroup,Unix用户组,true,false
properties
gid:用户组ID,string,null,null,gid,用户组ID
name:用户组名,string,null,null,name,用户组名
*/

/*!Model
OsHCA:OS的HCA卡,OsHCA,OS的HCA卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后HCA卡,string,null,null,bonding_flag,bonding后HCA卡
name:HCA卡名称,string,null,null,name,HCA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
*/

/*!Model
AIXVmo:AIX的vmo参数,AIXVmo,AIX的vmo参数,true,false
properties
name:参数名称,string,null,null,name,参数名称
vmo_value:参数值,string,null,null,vmo_value,参数值
*/

/*!Model
UnixUser:Unix用户,UnixUser,Unix用户,true,false
properties
uid:用户ID,string,null,null,uid,用户ID
umask:umask值,string,null,null,umask,umask值
password_expires:密码过期时间,string,null,null,password_expires,密码过期时间
shell:缺省shell目录,string,null,null,shell,缺省shell目录
primary_group:主用户组,string,null,null,primary_group,主用户组
name:用户名,string,null,null,name,用户名
groups:附属用户组,string,null,null,groups,附属用户组
locked_flag:是否锁定,string,null,null,locked_flag,是否锁定
home:用户home目录,string,null,null,home,用户home目录
*/

/*!Model
AIXNo:AIX的no参数,AIXNo,AIX的no参数,true,false
properties
name:参数名称,string,null,null,name,参数名称
no_value:参数值,string,null,null,no_value,参数值
*/

/*!Model
OsLunInfo:OS的LUN,OsLunInfo,OS的LUN,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
*/

/*!Model
OsNIC:OS的网卡,OsNIC,OS的网卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后网卡,string,null,null,bonding_flag,bonding后网卡
name:网卡名称,string,null,null,name,网卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
status:状态,string,null,null,status,状态
*/

/*!Model
UnixVG:Unix卷组,UnixVG,Unix卷组,true,false
properties
lv_num:逻辑卷个数,int,null,null,lv_num,逻辑卷个数
vg_free_size:卷组剩余大小,string,null,null,vg_free_size,卷组剩余大小
pv_num:物理卷个数,int,null,null,pv_num,物理卷个数
name:卷组名,string,null,null,name,卷组名
pp_size:物理段大小,string,null,null,pp_size,物理段大小
vg_used_size:卷组已使用大小,string,null,null,vg_used_size,卷组已使用大小
vg_total_size:卷组大小,string,null,null,vg_total_size,卷组大小
*/

/*!Model
OsPort:OS的监听端口,OsPort,OS的监听端口,true,false
properties
listen_ip:监听IP,string,null,null,listen_ip,监听IP
port:端口,int,null,null,port,端口
name:进程名,string,null,null,name,进程名
*/

/*!Model
FileSystem:Unix文件系统,FileSystem,Unix文件系统,true,false
properties
fs_mount_num:挂载次数,string,null,null,fs_mount_num,挂载次数
fs_type:文件系统类型,string,null,null,fs_type,文件系统类型
name:文件系统名称,string,null,null,name,文件系统名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
fs_mount_point:文件系统挂载点,string,null,null,fs_mount_point,文件系统挂载点
fs_need_fsck_flag:是否需要强制检查,string,null,null,fs_need_fsck_flag,是否需要强制检查
auto_mount:是否自动挂载,string,null,null,auto_mount,是否自动挂载
fs_mount_time:挂载时间,string,null,null,fs_mount_time,挂载时间
status:状态,string,null,null,status,状态
*/

/*!Model
OsHBA:OS的HBA卡,OsHBA,OS的HBA卡,true,false
properties
name:HBA卡名称,string,null,null,name,HBA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
status:状态,string,null,null,status,状态
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
UnixLV:Unix逻辑卷,UnixLV,Unix逻辑卷,true,false
properties
name:逻辑卷名,string,null,null,name,逻辑卷名
vg_name:卷组名称,string,null,null,vg_name,卷组名称
lv_size:逻辑卷大小,string,null,null,lv_size,逻辑卷大小
*/

/*!Model
OsDisk:OS的本地磁盘,OsDisk,OS的本地磁盘,true,false
properties
os_disk_size:磁盘大小,string,null,null,os_disk_size,磁盘大小
name:磁盘名称,string,null,null,name,磁盘名称
*/

/*!Model
MiniServer:IBM小型机,MiniServer,IBM小型机,false,false
properties
serverMemoryModule:服务器内存,inline,null,null,serverMemoryModule,服务器内存
mt_model:M/T型号,string,null,null,mt_model,M/T型号
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
model:型号,string,null,null,model,型号
par_num:分区数量,int,null,null,par_num,分区数量
firmware:系统固件版本,string,null,null,firmware,系统固件版本
miniserver_brand:品牌,string,null,null,miniserver_brand,品牌
serverHBA:服务器HBA卡,inline,null,null,serverHBA,服务器HBA卡
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
serverRaidCard:服务器RAID卡,inline,null,null,serverRaidCard,服务器RAID卡
serial_number:序列号,string,null,null,serial_number,序列号
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
memory_size:内存大小,string,null,null,memory_size,内存大小
hardDiskInfo:硬盘,inline,null,null,hardDiskInfo,硬盘
name:IBM小型机名称,string,null,null,name,IBM小型机名称
serverHCA:服务器HCA卡,inline,null,null,serverHCA,服务器HCA卡
serverNIC:服务器网卡,inline,null,null,serverNIC,服务器网卡
*/

/*!Model
ServerMemoryModule:服务器内存,ServerMemoryModule,服务器内存,true,false
properties
memory_module_size:内存条大小,string,null,null,memory_module_size,内存条大小
memory_clock_speed:内存条主频,string,null,null,memory_clock_speed,内存条主频
name:内存条型号,string,null,null,name,内存条型号
alias_type:类型,string,null,null,type,类型
memory_module_num:内存条数量,int,null,null,memory_module_num,内存条数量
*/

/*!Model
ServerHBA:服务器HBA卡,ServerHBA,服务器HBA卡,true,false
properties
hba_port_id:HBA卡端口号,string,null,null,hba_port_id,HBA卡端口号
name:HBA卡型号,string,null,null,name,HBA卡型号
hba_slot_id:HBA卡槽位号,string,null,null,hba_slot_id,HBA卡槽位号
hba_speed:HBA卡速率,string,null,null,hba_speed,HBA卡速率
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
ServerRaidCard:服务器RAID卡,ServerRaidCard,服务器RAID卡,true,false
properties
name:RAID卡型号,string,null,null,name,RAID卡型号
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
name:硬盘型号,string,null,null,name,硬盘型号
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

/*!Model
ServerHCA:服务器HCA卡,ServerHCA,服务器HCA卡,true,false
properties
hca_slot_id:HCA卡槽位号,string,null,null,hca_slot_id,HCA卡槽位号
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:HCA卡型号,string,null,null,name,HCA卡型号
hca_port_id:HCA卡端口号,string,null,null,hca_port_id,HCA卡端口号
hca_speed:HCA卡速率,string,null,null,hca_speed,HCA卡速率
*/

/*!Model
ServerNIC:服务器网卡,ServerNIC,服务器网卡,true,false
properties
nic_slot_id:网卡槽位号,string,null,null,nic_slot_id,网卡槽位号
nic_speed:网卡速率,string,null,null,nic_speed,网卡速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:网卡型号,string,null,null,name,网卡型号
nic_port_id:网卡端口号,string,null,null,nic_port_id,网卡端口号
*/

/*!Model
MiniServerLPAR:IBM小型机LPAR分区,MiniServerLPAR,IBM小型机LPAR分区,false,false
properties
par_id:分区ID,int,null,null,par_id,分区ID
profile:profile,string,null,null,profile,profile
name:名称,string,null,null,name,名称
serial_number:小型机序列号,string,null,null,serial_number,小型机序列号
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
memory_size:内存大小,string,null,null,memory_size,内存大小
par_name:分区名称,string,null,null,par_name,分区名称
*/

/*!Model
VIOC:VIOC,VIOC,VIOC,false,false
properties
par_id:分区ID,int,null,null,par_id,分区ID
profile:profile,string,null,null,profile,profile
name:名称,string,null,null,name,名称
serial_number:序列号,string,null,null,serial_number,序列号
process_units:CPU单元,double,null,null,process_units,CPU单元
memory_size:内存大小,string,null,null,memory_size,内存大小
status:状态,string,null,null,status,状态
par_name:分区名称,string,null,null,par_name,分区名称
*/

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


cliUtil = $script.use("common/cli_util");
def system = cliUtil.executeCommand("uname");

if('AIX' != system){
	$logger.logWarn("The current operating system is not supported:" + system);
	return ;
}
def osCi = discovery_AIX(system);

def osCiId = osCi.id;

discover_cron(osCiId)
discover_vmo(osCiId)
discover_no(osCiId)
discover_nic(osCiId);
discover_file_system(osCiId);
discovery_user_group(osCiId);

discover_hba(osCiId);
discover_vg_lv(osCiId);

if(isvirtual()){
	discover_vioc(osCi)
}
else {
	def serverCi = discovery_server(osCi);
	if(serverCi){
		discovery_server_hba(serverCi)
        discovery_server_nic(serverCi)
	}	
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class format_time_params{
	def src_format = 'MMM dd, yyyy';
	def to_format = 'yyyy-MM-dd';
	def locale = Locale.UK;
}
def format_time(time_str, format_time_params = new format_time_params()){
    try{
        return LocalDate.parse(time_str, DateTimeFormatter.ofPattern(format_time_params.src_format, format_time_params.locale)).format(DateTimeFormatter.ofPattern(format_time_params.to_format));
    }catch(Exception e) {
        return time_str;
    }
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discover_cron(osCiId){
	$logger.logInfo("Discover cron");
	def exclude_crontabs = [
        '/usr/bin/errclear',
        '/usr/sbin/dumpctrl',
        '/usr/lib/ras/dumpcheck',
        '/var/perf/pm/bin/pmcfg',
        '/usr/lpp/diagnostics/bin/run_ssa_ela',
        '/usr/lpp/diagnostics/bin/run_ssa_healthcheck',
        '/usr/lpp/diagnostics/bin/run_ssa_encl_healthcheck',
        '/usr/lpp/diagnostics/bin/run_ssa_link_speed'
    ]
    def commondResult = cliUtil.executeCommand("""find /var/spool/cron/ -type f|egrep -v '(/lastrun/|/adm|/esaadmin|/sys|/uucp)'""")
    if($text.isNull(commondResult)){
    	return ;
    }
	def lines = $text.splitLine(commondResult);
	for(def userCorn in $text.splitLine(commondResult)){
        def user = cliUtil.executeCommand("""basename ${userCorn}""")
        for(def cornContent in $text.splitLine(cliUtil.executeCommand("""cat ${userCorn}| egrep -v '^\\s*\$|^\\s*#' | awk -F# '{print \$1}'"""))){
            def ss = $text.splitWord($text.trim(cornContent));
            if (ss.size() < 6){
                $logger.logWarn("""crontab line error ${cornContent}""");
                continue
            }
            def run_time = ss[0..4].join(" ");
            def script = ss[5..-1].join(" ");
            def ci = $ci.create('unix_crontab', user)
            $ci.createRelationship("Inlines", osCiId, ci.id);
            ci.user_name = user;
            ci.run_time = run_time;
            ci.script = script;
        }
    }
}

def discover_vmo(osCiId){
	$logger.logInfo("Discover vmo");
    def vmo_key_list = [
        'maxclient%',
        'maxclient',
        'maxperm%',
        'maxperm',
        'minperm%',
        'strict_maxclient',
        'strict_maxperm',
        'minfree',
        'maxfree'
    ]
    def commondResult = cliUtil.executeCommand("vmo -a")
    def values = findAll(commondResult, '(\\S+)\\s*=\\s*(\\S+)')
    for(item in values){
        if(item[0] in vmo_key_list){
            def ci = $ci.create('AIXVmo', item[0])
            $ci.createRelationship("Inlines", osCiId, ci.id);
            ci.vmo_value = item[1]
        }
    }
}

def discover_no(osCiId){
	$logger.logInfo("Discover no");
    def vmo_key_list = ['udp_sendspace', 'udp_recvspace', 'tcp_sendspace', 'tcp_recvspace', 'rfc1323', 'sb_max', 'ipqmaxlen']
    def commondResult = cliUtil.executeCommand("no -a")
    def values = findAll(commondResult, '(\\S+)\\s*=\\s*(\\S+)')
    for(item in values){
        if(item[0] in vmo_key_list){
            def ci = $ci.create('AIXNo', item[0])
            $ci.createRelationship("Inlines", osCiId, ci.id);
            ci.no_value = item[1]
        }
    }
}

def discover_hba(osCiId){
	$logger.logInfo("Discover HBA");
	def commondResult = commondResult = cliUtil.executeCommand("""lsdev -Cc adapter -S a |grep -w fc.* |awk '{print \$1}'""");
	if($text.isNull(commondResult)){
		return ;
	}
	for(def line in $text.splitWord(commondResult)){
		def name = line;
		def ci = $ci.create('OsHBA', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			name : name,
                    wwn : cliUtil.executeCommand("""lscfg -pvl ${name} |grep Network.*Address|awk -F. '{print \$NF}'"""),
                    status : 'Available',
                  ]);
	}
}

def discover_nic(osCiId){
	$logger.logInfo("Discover NIC");
	def ipMap = [:];
	def commondResult = cliUtil.executeCommand("""ifconfig -a""");
	if($text.isNull(commondResult)){
    	return ;
    }
	def lines = $text.splitLine(commondResult);
	for (def i = 0; i < lines.length; i++) {
		def line = lines[i];
		def pos = line.indexOf(": flags=");
		if (pos <= 0){
			continue;
		}
		def name = line.substring(0, pos);
		if (name.startsWith("lo")){
			continue;
		}
		def ips = [];
		def ip = null;
		i++;
		while (i < lines.length){
			line = lines[i];
			ip = $text.between(line, "inet ", " ");
			if(!ip){
				break;
			}
			if (ip && ip.startsWith("127.")){
				ip = null;
			}
			else {
				ips.add(ip);
			}
			i++;
		}
		def mac = getNicMAC(name);
		def ci = $ci.create('OsNIC', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			 ips : ips.join(","),
           			 mac_addr : mac,
            		 name : name
                  ])
	}
}

def getNicMAC(name) {
	def lines = $text.splitLine(cliUtil.executeCommand("netstat -I " + name));
	for (def i = 0; i < lines.length; i++) {
		def fields = $text.splitWord(lines[i]);
		if (fields.length < 4)
			continue;
			
		fields = fields[3].split("\\.");
		if (fields.length == 6) {
			def mac = "";
			for (field in fields) {
				if (mac.length() > 0)
					mac += ":";
				if (field.length() == 1)
					mac += "0";
				mac += field;
			}
			return mac;
		}			
	}
	return null;
}

def isvirtual(){
    def cmd = "lsdev -Cc adapter -S a |grep -w ^ent.*|grep -w 'Virtual'|wc -l"
    if($number.parse(cliUtil.executeCommand(cmd)).intValue() > 0){
        return true
    }
    else{
        return false
	}
}

def discover_vioc(osCi){
	$logger.logInfo("Discover VIOC");
	
	def ss = cliUtil.executeCommand("uname -uL |awk -F, '{print \$2}'").split()
	
	def vioc_ci = $ci.create('VIOC', ss[2])
    vioc_ci.putAll([
    	par_id : ss[1],
        par_name : ss[0],
        serial_number : osCi.serial_number
    ])
    $ci.createRelationship("RunsOn", osCi.id, vioc_ci.id);
}

def discovery_server_hba(serverCi){
	$logger.logInfo("Discover server hba");
	def commondResult = cliUtil.executeCommand("""lsdev -Cc adapter -S a |grep -v Virtual|grep -w fc.* |awk '{print \$1,\$NF}'""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
    	def hbaname = hbainfo.split()[0]
    	def wwninfo = cliUtil.executeCommand("lscfg -pvl ${hbaname}")
    	def fcsinfo = cliUtil.executeCommand("fcstat ${hbanum}")
    	
    	def part_num = findAllFirst('Part Number.100'.replace(".", ""), '(?<=Part\\sNumber)(\\S+)')
		def wwn = findAllFirst('Network sAddress.200'.replace(".", ""), '(?<=Network\\sAddress)(\\S+)')
		def server_hba_slot = findAllFirst('Physical Location: 1-bb-cc'.replace(".", ""), '(?<=Physical\\sLocation:\\s)(\\S+)').split('-')[1..-1]
		def fcs_speed = findAllFirst('Port Speed (running):300', '(?<=Port\\sSpeed\\s\\(running\\):)(.+)').split()
    	
    	def ci = $ci.create('ServerHBA', part_num)
	    ci.putAll([
	    	wwn : wwn,
            hba_speed : fcs_speed ? fcs_speed[0] + 'G bps' : '',
            hba_slot_id : server_hba_slot.join('-'),
            hba_port_id : server_hba_slot[-1]
	    ])
	    $ci.createRelationship("Inlines", serverCi.id, ci.id);
    }
}

def discovery_server_nic(serverCi){
	$logger.logInfo("Discover server nic");
	def commondResult = cliUtil.executeCommand("""lsdev -Cc adapter -S a |egrep -v 'Virtual|Logical'|grep -w ent.* |awk '{print \$1}'""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
    	def result = cliUtil.executeCommand("entstat -d ${line}")
    	def mac = findAllFirst(result, '(?<=Hardware\\sAddress:\\s)(\\S+)').toLowerCase()
		def speed = findAllFirst(result, '(?<=Media\\sSpeed\\sRunning:\\s)(\\S+)')
		
    	result = cliUtil.executeCommand("lscfg -vpl ${line}")
    	def part_num = findAllFirst('Part Number.100'.replace(".", ""), '(?<=Part\\sNumber)(\\S+)')
    	def server_nic_slot = findAllFirst('Physical Location: 1-bb-cc'.replace(".", ""), '(?<=Physical\\sLocation:\\s)(\\S+)').split('-')[1..-1]
    	
    	def ci = $ci.create('ServerNIC', part_num)
	    ci.putAll([
	    	mac_addr : mac,
            nic_speed : speed,
            nic_slot_id : server_nic_slot.join('-'),
            nic_port_id : server_nic_slot[-1]
	    ])
	    $ci.createRelationship("Inlines", serverCi.id, ci.id);
    }
}


def discovery_server(osCi){
	$logger.logInfo("Discover PCServer");
    def model_map = [
        '7037-A50': 'p185',
        '9115-505': 'p505',
        '9110-510': 'p510',
        '9110-51A': 'p510',
        '9111-520': 'p520',
        '9131-52A': 'p52A',
        '9113-550': 'p550',
        '9133-55A': 'p55A',
        '9116-561': 'p560Q',
        '9117-570': 'p570',
        '9118-575': 'p575',
        '9119-590': 'p590',
        '9119-595': 'p595',
        '8203-E4A': 'p520',
        '8204-E8A': 'p550',
        '8234-EMA': 'p560',
        '9117-MMA': 'p570',
        '9119-FHA': 'p595',
        '8231-E2B': 'p710/p730',
        '8202-E4B': 'p720',
        '8205-E6B': 'p740',
        '8233-E8B': 'p750',
        '9117-MMB': 'p770',
        '9125-F2B': 'p755',
        '9179-MHB': 'p780',
        '8246-L1D': 'PowerLinux 7R1',
        '8246-L2D': '7R2',
        '8248-L4T': '7R4',
        '8268-E1D': 'Power 710',
        '8231-E2D': '730',
        '8205-E6D': '740',
        '9117-MMD': '770',
        '9179-MHD': '780',
        '9119-FHB': '795',
        '7042-CR6': 'HMC 控制台',
        '7316-TF3': 'TF3 液晶套件',
        '7014-T42': 'T42 机柜',
        '7014-T00': 'T00 机柜',
        '7216-1U2': '1U2 外置磁带机'
    ]
    def model = cliUtil.executeCommand("""uname -M | awk -F, '{print \$2}'""");
    def name = model_map[model];
    if(!name){
        return 
    }
    def firmware = cliUtil.executeCommand("lsmcode -c |grep -w 'current permanent'").split()[-1]
	def proc_name = cliUtil.executeCommand("lsdev -Cc processor |grep -w 'Available' |grep -w 'proc0'").split()[0]
	def cpu_model = cliUtil.executeCommand("lsattr -E -l ${proc_name} |grep -w '^type'|awk '{print \$2}'")
	def cpu_speed_clock = cliUtil.executeCommand("prtconf -s |awk -F: '{print \$2}'").replace(" ", "");

    def serverCi = $ci.create('MiniServer', "${name}/${osCi.serial_number}")
    serverCi.putAll([
        ip : osCi.ip,
        model : name,
        firmware : firmware,
        mt_model : model,
        cpu_model : cpu_model,
        general_model : name,
        serial_number : osCi.serial_number,
        cpu_speed_clock : cpu_speed_clock,
        miniserver_brand : 'ibm'
    ])
    
   	def ss = cliUtil.executeCommand("uname -uL |awk -F, '{print \$2}'").split()
    def lparCi = $ci.create('MiniServerLPAR', ss[2])
    lparCi.putAll([
    	par_id : ss[1],
        par_name : ss[0],
        serial_number : osCi.serial_number
    ])
    $ci.createRelationship("RunsOn", osCi.id, lparCi.id)
    $ci.createRelationship("RunsOn", lparCi.id, serverCi.id)
    return serverCi;
}

def discover_file_system(osCiId){
	$logger.logInfo("Discover file system");
	def commondResult = cliUtil.executeCommand("""lsfs |tail -n +2""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def exclude_filesystems = ['/dev/livedump', '/dev/hd11admin', '/proc']
    for(def line in $text.splitLine(commondResult)){
    	def ss = $text.splitWord($text.trim(line));
        def fsname = ss[0];
        def fstype = ss[3];
        def fsmount = ss[2];
        def fssize = ss[4];
        if(fsname in exclude_filesystems){
            continue
        }
        if(fssize == '--'){
        	continue
        }
        def ci = $ci.create('FileSystem', fsname)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			name : fsname,
        			fs_type : fstype,
        			fs_mount_point : fsmount,
        			fs_total_size : convert_bytes(convert_bytes(fssize, new convert_bytes_params(src_unit : 'KB', unit : 'B', return_str : false))[0] / 2)
                  ])
    }
}

def discover_vg_lv(osCiId){
	$logger.logInfo("Discover VG and LV");
	def commondResult = cliUtil.executeCommand("""lsvg -o""");
    if($text.isNull(commondResult)){
    	return ;
    }
    for(def line in $text.splitLine(commondResult)){
        def name = line
        def pp_size = cliUtil.executeCommand("""lsvg ${name} |tail -n +2 |grep PP.*SIZE |awk '{print \$6}'""");
        def lvs_num_and_usedpps = cliUtil.executeCommand("""lsvg ${name} |tail -n +2 |grep ^LVs |awk '{print \$2,\$5}'""").split();
        def pv_num = cliUtil.executeCommand("""lsvg ${name} |tail -n +2 |grep ^TOTAL.*PVs |awk '{print \$3}'""");
        def total_pps = cliUtil.executeCommand("""lsvg ${name} |tail -n +2 |grep TOTAL.*PPs |awk '{print \$6}'""");
        def free_pps =  cliUtil.executeCommand("""lsvg ${name} |tail -n +2 |grep FREE.*PPs |awk '{print \$6}'""");
        pp_size = $number.parse(pp_size).floatValue()
        
        def vg_free_size = convert_bytes($number.parse(free_pps).floatValue() * pp_size, new convert_bytes_params(src_unit : 'MB'))
        def vg_total_size = convert_bytes($number.parse(total_pps).floatValue() * pp_size, new convert_bytes_params(src_unit : 'MB'))
        def vg_used_size = convert_bytes($number.parse(lvs_num_and_usedpps[1]).floatValue() *  pp_size, new convert_bytes_params(src_unit : 'MB'))
        
        def ci = $ci.create('UnixVG', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
					name : name,
            		lv_num : lvs_num_and_usedpps[0],
             		pv_num : pv_num,
             		pp_size : convert_bytes(pp_size, new convert_bytes_params(src_unit : 'MB')), 
            		vg_free_size : vg_free_size,
            		vg_used_size : vg_used_size,
            		vg_total_size : vg_total_size
                  ]);
        discover_lv(name, pp_size, osCiId) 
    }
}

def discover_lv(vgName, pp_size, osCiId){
	def exclude_lv = ['/dev/livedump', '/dev/hd11admin']
	def exclude_lv_types = ['boot', 'paging', 'jfs2log', 'sysdump']
	for(def line in $text.splitLine(cliUtil.executeCommand("""lsvg -l ${vgName} |grep -w 'open/syncd' |awk '{print \$1,\$2,\$4}'"""))){
        def ss = line.split();
        def lv_name = ss[0];
        def lv_type = ss[1];
        def lv_pps = ss[2];
        def name = "/dev/" + lv_name;
        def x = name in exclude_lv;
        if(name in exclude_lv){
            continue
        }
		if(lv_type in exclude_lv_types){
        	continue
        }
        def ci = $ci.create('UnixLV', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
					name : name,
            		lv_size : convert_bytes($number.parse(lv_pps).floatValue() * pp_size, new convert_bytes_params(src_unit : 'MB')),
             		vg_name : vgName
                  ]);
        
    }
}


def discovery_user_group(osCiId){
	$logger.logInfo("Discover users and user groups");
	def exclude_users = ["root", "daemon", "bin", "sys", "sshd", "adm", "uucp", "guest", "nobody", "lpd", "lp", "invscount", "snapp", "ipsec", "invscout", "esaadmin", "nuucp", "pconsole", "srvproxy"];
	def all_groups = [];
	def excludeShell = []
	def commondResult = cliUtil.executeCommand("""cat /etc/passwd""");
    if($text.isNull(commondResult)){
    	return ;
    }
	for(def userStr in $text.splitLine(commondResult)){
		def ss = userStr.split(":", 7);
		def user = [loginName: ss[0], passwd: ss[1], UID: ss[2], GID: ss[3], userName: ss[4], homeDirectory: ss[5], shell: ss[6]]
		if(excludeShell.contains(user.shell)){
            continue;
        }
        if(exclude_users.contains(user.loginName)){
            continue;
        }
        def user_info = cliUtil.executeCommand("""id ${user.loginName}""");
        def tmp = findAll(user_info, "(\\d+)\\((.*?)\\)");
        def groups = tmp[1..-1];
        all_groups.addAll(groups);
        def ci = $ci.create("UnixUser", user.loginName);
        $ci.createRelationship("Inlines", osCiId, ci.id);
		ci.uid = user.UID;
        ci.home = user.homeDirectory;
        ci.shell = user.shell;
        ci.groups = groups.collect{e->e[1]}.join(",");
        ci.primary_group = tmp[1][1];
        ci.password_expires = get_password_expires(user.loginName);
	}
	def exclude_groups = ["system", "staff", "bin", "sys", "sshd", "adm", "uucp", "mail", "security", "cron", "printq", "audit", "ecs", "nobody", "usr", "perf", "shutdown", "lp", "invscout", "esaadmin", "snapp", "ipsec", "pconsole"]
	for(g in all_groups.unique()){
		def groupName = g[1]
		if(exclude_groups.contains(groupName)){
            continue;
        }
		ci = $ci.create('UnixGroup', groupName)
        ci.gid = g[0]
        $ci.createRelationship("Inlines", osCiId, ci.id)
	}
}

def get_password_expires(user){
    def day = 86400
    // 获取密码到期前的周数，maxage=0 意味着永远不到期，maxage=2 意味着两周后到期
    def weeks = cliUtil.executeCommand("lsuser -a maxage ${user}|awk -F'=' '{print \$2}'").trim();
    if(weeks == '0'){
        return 'never'
    }
    // 获取密码最后修改时间(单位：秒/s)
    def last_update = cliUtil.executeCommand("pwdadm -q ${user}|grep lastupdate|awk '{print \$3}'")
    if(!last_update){
        return 'nopassword'
	}
    // maxage的值与最后一次修改密码的时间相加
    def total_seconds = day * 7 *  $number.parse(weeks).intValue() +  $number.parse(last_update).intValue();

	def date = new Date(total_seconds * 1000);
	SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    return sdf.format(date)
}

def discovery_AIX(system) {
	$logger.logInfo("Discover AIX");
	def hostname = cliUtil.executeCommand("uname -n");
	def architecture = cliUtil.executeCommand("uname -p");
	def version = "no version"
	def kernel = cliUtil.executeCommand("""uname -r | awk -F'-' '{ print \$1 }'""");
	def cpu = "64";
	if(architecture && !cpu.contains("64")){
		cpu = "32";
	}
	def dist = 'Aix'
	dist = dist.replace(" ", "");
    def ci = $ci.create("AIX", "AIX", $ccli.params.ip + "-" + hostname);
    ci.ip = $ccli.params.ip;
    
    ci.hostname = hostname
    //ci.os_dist_ver = version
    def detlInfo = cliUtil.executeCommand("""oslevel -s |awk -F- '{print \$1,\$2,\$3}'""").split();
    ci.os_ver_detl = "AIX${String.format('%.1f', Float.parseFloat(detlInfo[0])/1000)}TL${detlInfo[1]}SP${detlInfo[2]}"
    //ci.cpu_arch = architecture;
    //ci.kernelVersion = kernel;
    ci.bits = cpu
    //ci.os_type = system;
    ci.cpu_core_num = $number.parse(cliUtil.executeCommand("""bindprocessor -q""").split()[-1]).intValue() + 1;
    
    ci.memory_size = convert_bytes(cliUtil.executeCommand("""lsattr -El sys0 -a realmem|awk '{print \$2}'"""), new convert_bytes_params(src_unit : 'KB') );
    ci.swap_size = convert_bytes($text.trim(cliUtil.executeCommand("""lsps -s | awk 'NR>1'""").split()[0]));
    
    ci.ntp_server = $text.splitLine(cliUtil.executeCommand("""cat /etc/ntp.conf | grep '^server' | awk '{print \$2}'""")).join(" | ");
    ci.dns_server = $text.splitLine(cliUtil.executeCommand("""cat /etc/resolv.conf 2>/dev/null |grep ^nameserver |awk '{print \$2}'""")).join(",");
    ci.time_zone = cliUtil.executeCommand("""echo \$TZ""")
    ci.default_gateway = cliUtil.executeCommand("""netstat -nr |grep -w default |awk '{print \$2}'""");
    
    //ci.user_tmout = cliUtil.executeCommand("echo \$TMOUT");
    
    def serial_number = cliUtil.executeCommand("uname -u | awk -F, '{print \$2}'");
    if(serial_number.length() > 7){
    	serial_number = serial_number[-7..-1]
    }
    ci.serial_number = serial_number;
   
    ci.openssh_ver = cliUtil.executeCommand("lslpp -l |grep -w 'openssh.base.server'|awk 'NR==1{print \$2}'");
    ci.openssl_ver = cliUtil.executeCommand("lslpp -l |grep -w 'openssl.base'|awk 'NR==1{print \$2}'");
    
    ci.aix_aio_maxreqs = cliUtil.executeCommand("ioo -o aio_maxreqs").split()[-1];
    ci.aix_max_uproc = cliUtil.executeCommand("lsattr -El sys0 -a maxuproc |awk '{print \$2}'")
    
    def lpar = cliUtil.executeCommand("uname -L").split();
    ci.lpar_id = lpar[0]
    ci.lpar_name = lpar[1]
    
    ci.password_minlen = cliUtil.executeCommand("""lssec -f /etc/security/user -s default -a minlen | awk -F= '{print \$2}'""").trim()
    ci.password_dcredit = cliUtil.executeCommand("""lssec -f /etc/security/user -s default -a minalpha | awk -F= '{print \$2}'""").trim()
    ci.pass_max_day = cliUtil.executeCommand("""lssec -f /etc/security/user -s default -a expires | awk -F= '{print \$2}'""").trim()
    ci.password_ocredit = cliUtil.executeCommand("""lssec -f /etc/security/user -s default -a minother | awk -F= '{print \$2}'""").trim()

	ci.user_deny_cnt = cliUtil.executeCommand("""lssec -f /etc/security/login.cfg -s default -a logindisable | awk -F= '{print \$2}'""").trim()
	ci.user_unlock_time = cliUtil.executeCommand("""lssec -f /etc/security/login.cfg -s default -a loginreenable | awk -F= '{print \$2}'""").trim()
    return ci;
}