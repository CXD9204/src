/*!Action 
action.name=K8S_remote_discovery_87f32e9
action.descr=K8S_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=K8SMaster
discovery.output=Virtual
*/

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
K8SCluster:K8S集群,K8SCluster,K8S集群,false,false
properties
name:集群名称,string,null,null,name,集群名称
svc_ip:服务IP,string,null,null,svc_ip,服务IP
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
version:K8S版本,string,null,null,version,K8S版本
k8sNamespace:K8S命名空间,inline,null,null,k8sNamespace,K8S命名空间
*/

/*!Model
K8SNamespace:K8S命名空间,K8SNamespace,K8S命名空间,true,false
properties
name:命名空间名称,string,null,null,name,命名空间名称
*/

/*!Model
K8SMaster:K8SMaster,K8SMaster,K8SMaster,false,false
properties
port:端口,int,null,null,port,端口
ip:IP地址,string,null,null,ip,IP地址
taints_flag:是否污点,string,null,null,taints_flag,是否污点
container_runtime:容器引擎,string,null,null,container_runtime,容器引擎
name:Master名称,string,null,null,name,Master名称
network_domain:网络域,string,null,null,network_domain,网络域
label:标记,string,null,null,label,标记
status:状态,string,null,null,status,状态
*/

/*!Model
K8SNode:K8SNode,K8SNode,K8SNode,false,false
properties
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
ip:IP地址,string,null,null,ip,IP地址
taints_flag:是否污点,string,null,null,taints_flag,是否污点
container_runtime:容器引擎,string,null,null,container_runtime,容器引擎
name:Node名称,string,null,null,name,Node名称
network_domain:网络域,string,null,null,network_domain,网络域
label:标记,string,null,null,label,标记
status:状态,string,null,null,status,状态
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

cliUtil = $script.use("common/cli_util");

def commondResult = cliUtil.executeCommand("which kubectl 2>/dev/null");
if($text.isNull(commondResult)){
	$logger.logWarn("not find kubectl");
	return ;
}

def clusterCis = discovery_k8s()
if(!clusterCis){
	$logger.logWarn("not find k8s cluster");
	return ;
}
discovery_namespace(clusterCis)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_k8s(){
	$logger.logInfo("Discover k8s");
	def clusterCis = []
	def commondResult = cliUtil.executeCommand("kubectl config get-contexts | tail -n +2")
	for(def line in  $text.splitLine(commondResult)){
		if(line.startsWith("*")){
			line = line.substring(1);
		}
		def ss = line.split()
		if(ss.size() < 3){
			continue
		}
		def content = ss[0]
		def cluster = ss[1]
		
		def result = cliUtil.executeCommand("kubectl cluster-info --context=${content}")
		def info = findAll(result, "Kubernetes master is running at \\S+://(\\S+):(\\S+)")
		if(info.size() != 1){
			continue
		}
		def port = info[0][1]
		def ip = info[0][0]
		def ci = $ci.create('K8SCluster', cluster)
		clusterCis.add(ci)
		ci.svc_ip = ip
		ci.content = content
		def json = cliUtil.executeCommand("kubectl get node --context=${content} -o json")
		def nodes = JSONObject.parseObject(json).getJSONArray("items");
		def nodeCis = []
		for(def i = 0; i < nodes.size(); i++){
			def node = nodes.getJSONObject(i);
			nodeCis.add(analysisNode(node, port, ci))
		}
		ci.cluster_perst_ip = nodeCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
		json = cliUtil.executeCommand("kubectl version --context=${content} -o json")
		ci.version = JSONObject.parseObject(json).getJSONObject("serverVersion").getString("gitVersion")
	}
	return clusterCis
}

def analysisNode(def node, def masterPort, def clusterCi){
	def metadata = node.getJSONObject("metadata")
	def status = node.getJSONObject("status")
	def name = metadata.getString("name")
	def ip = ""
	def addresses = status.getJSONArray("addresses");
	for(def i = 0; i < addresses.size(); i++){
		def jsonObj = addresses.getJSONObject(i)
		if("InternalIP" == jsonObj.getString("type")){
			ip = jsonObj.getString("address")
		}
	}
	def statusValue = ""
	def conditions = status.getJSONArray("conditions");
	for(def i = 0; i < conditions.size(); i++){
		def jsonObj = conditions.getJSONObject(i)
		if(jsonObj.getBoolean("status")){
			statusValue = jsonObj.getString("type")
		}
	}
	def role = metadata.getJSONObject("labels").containsKey("node-role.kubernetes.io/master")
	def port = status.getJSONObject("daemonEndpoints").getJSONObject("kubeletEndpoint").getString("Port")
	def container = status.getJSONObject("nodeInfo").getString("containerRuntimeVersion")
	def ci = null
	if(role){
		ci = $ci.create('K8SMaster', name)
		ci.port = masterPort
	}
	else {
		ci = $ci.create('K8SNode', name)
		ci.port = port
	}
	ci.putAll([
		status : statusValue,
		ip : ip,
		container_runtime : container
	])
	$ci.createRelationship("Contains", clusterCi.id, ci.id);
	if($scriptParams.ip == ip){
		def hostname = cliUtil.executeCommand("uname -n")
		def osCi = $ci.create(osCodeSearch(cliUtil.executeCommand("uname")), $scriptParams.ip + "-" + hostname)
    	osCi.ip = $scriptParams.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
	}
	return ci
}

def discovery_namespace(def clusterCis){
	$logger.logInfo("Discover namespace");
	for(def clusterCi in clusterCis){
		def json = cliUtil.executeCommand("kubectl get ns --context=${clusterCi.content} -o json")
		def items = JSONObject.parseObject(json).getJSONArray("items")
		
		for(def i = 0; i < items.size(); i++){
			def name = items.getJSONObject(i).getJSONObject("metadata").getString("name")
			def ci = $ci.create('K8SNamespace', name)
			$ci.createRelationship("Inlines", clusterCi.id, ci.id);
		}
	}
}

