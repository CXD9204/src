/*!Action
action.name=TapeLibrary_remote_discovery_87f32e9
action.descr=TapeLibrary_remote_discovery(snmp v1/v2c)
action.version=1.0.0
action.protocols=snmp
action.main.model=TapeLibrary
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
TapeLibrary:物理带库,TapeLibrary,物理带库,false,false
properties
mt_model:M/T型号,string,null,null,mt_model,M/T型号
tape:磁带,inline,null,null,tape,磁带
model:型号,string,null,null,model,型号
tape_slot_num:数据磁带槽位数,int,null,null,tape_slot_num,数据磁带槽位数
tl_brand:品牌,string,null,null,tl_brand,品牌
phys_size:物理容量,string,null,null,phys_size,物理容量
tapeDriver:驱动器,inline,null,null,tapeDriver,驱动器
ip:带外管理IP,string,null,null,ip,带外管理IP
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
name:名称,string,null,null,name,名称
*/

/*!Model
Tape:磁带信息,Tape,磁带信息,true,false
properties
tape_size:磁带大小,string,null,null,tape_size,磁带大小
tape_num:磁带数量,int,null,null,tape_num,磁带数量
name:磁带型号,string,null,null,name,磁带型号
*/

/*!Model
TapeDriver:带库驱动器,TapeDriver,带库驱动器,true,false
properties
driver_if_type:驱动器接口类型,string,null,null,driver_if_type,驱动器接口类型
name:驱动器型号,string,null,null,name,驱动器型号
driver_num:驱动器数量,int,null,null,driver_num,驱动器数量
*/

import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;


def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();

def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
if(sysObjectId != '.1.3.6.1.4.1.2.6.182.1'){
	throw new RuntimeException("Unrecognized ID:" + sysObjectId)
}
def model = get(".1.3.6.1.4.1.2.6.182.3.4.2.0")
def serial_number = get(".1.3.6.1.4.1.2.6.182.3.4.3.0")

def deviceCi = $ci.create('TapeLibrary', 'TapeLibrary', model + '/' + serial_number);
deviceCi.putAll([
	ip : $scriptParams.ip,
	tl_brand : 'ibm',
	model : model,
	serial_number : serial_number,
	mt_model : get(".1.3.6.1.4.1.14851.3.1.4.10.1.3.1")
])

discovery_tape_driver(deviceCi)
discovery_tape(deviceCi)

def discovery_tape(deviceCi){
	$logger.logInfo("tape");
	def keyBefore = null
	keyBefore = "2.1.6."
	def tapes = [:]
	for(def item in walk(".1.3.6.1.4.1.2.6.182.3.7", true)){
		if(!item.key.startsWith(keyBefore)){
			continue
		}
		def key = item.key.substring(keyBefore.length())
		def map = getOrInitMapValue(key, tapes)
		map.size = Long.parseLong(item.value.replace(":", ""), 16)
	}
	keyBefore = "2.1.9."
	def tapes = [:]
	for(def item in walk(".1.3.6.1.4.1.2.6.182.3.7", true)){
		if(!item.key.startsWith(keyBefore)){
			continue
		}
		def key = item.key.substring(keyBefore.length())
		def map = getOrInitMapValue(key, tapes)
		map.type = item.value
	}
	def tapeCis = [:]
	keyBefore = "2.1.8."
	def tape_slot_num = 0
	def phys_size = 0L
	for(def item in walk(".1.3.6.1.4.1.2.6.182.3.7")){
		if(!item.key.startsWith(keyBefore)){
			continue
		}
		def key = item.key.substring(keyBefore.length())
		def name = item.value
		if(!name || name.getBytes()[0] == 0){
			$logger.logWarn("Drive model is empty")
			continue
		}
		def map = getOrInitMapValue(key, tapes)
		def tapeCi = tapeCis.get(name)
		if(tapeCi == null){
			tapeCi = $ci.create('Tape', name)
			tapeCi.putAll([
				tape_num : 1,
				tape_size : convert_bytes(map.size)
			])
			tapeCis.put(name, tapeCi)
			$ci.createRelationship("Inlines", deviceCi.id, tapeCi.id);
		}
		else {
			tapeCi.tape_num ++
		}
		if(map.type == '2'){
			phys_size += map.size
			tape_slot_num ++
		}
	}
	deviceCi.phys_size = convert_bytes(phys_size)
	deviceCi.tape_slot_num = tape_slot_num
}

def discovery_tape_driver(deviceCi){
	$logger.logInfo("tape_driver");
	def driver_if_typeMap = ['0' : 'unknown', '1' : 'wormDrive', '2' : 'magnetoOpticalDrive', '3' : 'tapeDrive', '4' : 'dvdDrive', '5' : 'cdromDrive']
	def drivers = [:]
	def keyBefore = null
	def data = walk(".1.3.6.1.4.1.2.6.182.3.6")
	keyBefore = "2.1.2."
	for(def item in data){
		if(!item.key.startsWith(keyBefore)){
			continue
		}
		def key = item.key.substring(keyBefore.length())
		def map = getOrInitMapValue(key, drivers)
		map.driver_if_type = 'fc'
	}
	def modelCis = [:]
	keyBefore = "2.1.3."
	for(def item in data){
		if(!item.key.startsWith(keyBefore)){
			continue
		}
		def key = item.key.substring(keyBefore.length())
		def map = getOrInitMapValue(key, drivers)
		def model = item.value.split()[1]  //"IBM     ULT3580-TD4     0007899435"
		def modelCi = modelCis.get(model)
		if(modelCi == null){
			modelCi = $ci.create('TapeDriver', model)
			modelCi.putAll([
				driver_num : 1,
				driver_if_type : map.driver_if_type
			])
			modelCis.put(model, modelCi)
			$ci.createRelationship("Inlines", deviceCi.id, modelCi.id);
		}
		else {
			modelCi.driver_num ++
		}
	}
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}
