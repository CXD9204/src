/*!Action
action.name=SecurityDevice_remote_discovery_87f32e9
action.descr=SecurityDevice_remote_discovery(snmp v1/v2c)
action.version=1.0.0
action.protocols=snmp
action.main.model=Firewall
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
Firewall:防火墙,Firewall,防火墙,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
securityPort:安全设备接口,inline,null,null,securityPort,安全设备接口
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
security_brand:品牌,string,null,null,security_brand,品牌
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:软件版本,string,null,null,version,软件版本
port:端口,int,null,null,port,端口
snmp_param:SNMP参数,string,null,null,snmp_param,SNMP参数
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
desc:描述,string,null,null,desc,描述
*/

/*!Model
SecurityPort:安全设备接口,SecurityPort,安全设备接口,true,false
properties
mac_list:动态MAC地址表,string,null,null,mac_list,动态MAC地址表
ip:IP地址,string,null,null,ip,IP地址
name:接口名称,string,null,null,name,接口名称
port_index:端口索引号,int,null,null,port_index,端口索引号
*/

/*!Model
IPS:IPS,IPS,IPS,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
securityPort:安全设备接口,inline,null,null,securityPort,安全设备接口
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
security_brand:品牌,string,null,null,security_brand,品牌
version:版本,string,null,null,version,版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
IDS:IDS,IDS,IDS,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
securityPort:安全设备接口,inline,null,null,securityPort,安全设备接口
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
security_brand:品牌,string,null,null,security_brand,品牌
version:版本,string,null,null,version,版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
DDoS:DDoS,DDoS,DDoS,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
securityPort:安全设备接口,inline,null,null,securityPort,安全设备接口
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
security_brand:品牌,string,null,null,security_brand,品牌
serial_number:序列号,string,null,null,serial_number,序列号
version:版本,string,null,null,version,版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
WAF:WAF,WAF,WAF,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
securityPort:安全设备接口,inline,null,null,securityPort,安全设备接口
hostname:主机名,string,null,null,hostname,主机名
model:型号,string,null,null,model,型号
port_num:端口数,int,null,个,port_num,端口数
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
security_brand:品牌,string,null,null,security_brand,品牌
version:版本,string,null,null,version,版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;

def constant = [
'.1.3.6.1.4.1.2011.2.192.13':['huawei','Huawei USG5160','Firewall'],
'.1.3.6.1.4.1.2011.2.321.1.154':['huawei','Huawei USG6600E','Firewall'],
'.1.3.6.1.4.1.2011.2.321.1.220':['huawei','Huawei USG6655E-AC','Firewall'],
'.1.3.6.1.4.1.2011.2.321.1.212':['huawei','Huawei USG6615E-AC','Firewall'],
'.1.3.6.1.4.1.2011.6.133.3':['huawei','Huawei USG5530S','Firewall'],
'.1.3.6.1.4.1.25506.1.1040':['h3c','H3C SecPath F5020','Firewall'],
'.1.3.6.1.4.1.25506.1.1041':['h3c','H3C SecPath F5040','Firewall'],
'.1.3.6.1.4.1.25506.1.1090':['h3c','H3C SecPath F1030','Firewall'],
'.1.3.6.1.4.1.25506.1.1470':['h3c','H3C SecPathF5010-NSQZ1F5010','IPS'],
'.1.3.6.1.4.1.25506.1.1558':['h3c','H3C SecPath-F5030','Firewall'],
'.1.3.6.1.4.1.25506.1.1762':['h3c','H3C SecPath-F5030-D','Firewall'],
'.1.3.6.1.4.1.28557.1.125': ['hillstone', 'Hillstone SG-6000-E1606', 'Firewall'],
'.1.3.6.1.4.1.28557.1.88': ['hillstone', 'Hillstone SG-6000-E2300', 'Firewall'],
'.1.3.6.1.4.1.28557.1.94': ['hillstone', 'Hillstone SG-6000-E5960', 'Firewall'],
'.1.3.6.1.4.1.28557.1.96': ['hillstone', 'Hillstone SG-6000-E5660', 'Firewall'],
'.1.3.6.1.4.1.3224.1.50':['juniper', 'Juniper SSG-520', 'Firewall'],
'.1.3.6.1.4.1.8072.3.2.10':['nsfocus', 'NSFOCUS WAFNX3-P2000B', 'WAF']
]

constantModels = constant.values().collect{e->e[1]}

def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();


def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
def constantValue = constant[sysObjectId]
if(!constantValue){
	if(sysObjectId.split("\\.")[7] == '19849'){
		def codeConstant = ['ads' : 'DDoS', 'ddos' : 'DDoS', 'waf' : 'WAF', 'ids' : 'IDS', 'ips' : 'IPS']
		def code = null
		def codeStr = get(".1.3.6.1.4.1.19849.6.1.7.0")
		def modelType = get(".1.3.6.1.4.1.19849.6.1.1.0")
		if(codeStr){
			def temp = codeStr.toLowerCase()
			for(def entry in codeConstant){
				if(temp == entry.key){
					code = entry.value
					break
				}
			}
			if(!code){
				throw new RuntimeException("NSFOCUS Product code[${codeStr}] not recognized")
			}
		}
		else if(modelType){
			def temp = modelType.toLowerCase()
			for(def entry in codeConstant){
				if(temp.contains(entry.key)){
					code = entry.value
					break
				}
			}
		}
		if(!code){
			def ipCodeConstant = [:]
			code = ipCodeConstant[$scriptParams.ip]
			if(!code){
				throw new RuntimeException("NSFOCUS Product type not recognized")
			}
		}
		constantValue = ['nsfocus', null, code]
	}
	else {
		throw new RuntimeException("Unrecognized ID:" + sysObjectId)
	}
}

def deviceCi = $ci.create(constantValue[2], constantValue[2], constantValue[0]);
deviceCi.ip = $scriptParams.ip
deviceCi.security_brand = constantValue[0]
deviceCi.model = constantValue[1]
switch(constantValue[0]){
	case 'h3c':
		disCoveryH3C(deviceCi)
		break;
	case 'cisco':
		disCoveryCisco(deviceCi)
		break;
	case 'ruijie':
		disCoveryRuijie(deviceCi)
		break;
	case 'huawei':
		disCoveryHuawei(deviceCi)
		break;
	case 'nsfocus':
		disCoveryNsfocus(deviceCi)
		break;
	case 'hillstone':
		disCoveryHillstone(deviceCi)
		break;
	case 'juniper':
		disCoveryJuniper(deviceCi)
		break;
}
if(deviceCi.hostname){
	deviceCi.name = deviceCi.hostname
	deviceCi.parent.name = deviceCi.hostname
}


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

def disCoveryCisco(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.4.1.9.3.6.3.0")
	def model = deviceCi.model.toLowerCase();
	def version = null
	if(model.split(" ", 2)[-1].startsWith('n')){
		version = get(".1.3.6.1.2.1.47.1.1.1.1.10")
	}
	else {
		version = get(".1.3.6.1.4.1.9.9.25.1.1.1.2.5")
	}
	if(version){
		def index = version.indexOf('$')
		if(index != -1){
			def str = version.substring(index + 1)
			index = str.indexOf('$')
			if(index > 0){
				version = str.substring(0, index)
			}
		}
		deviceCi.version = version
	}
	
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}

def disCoveryRuijie(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.4.1.4881.1.1.10.2.1.1.24.0")
	deviceCi.version = get(".1.3.6.1.4.1.4881.1.1.10.2.21.1.2.1.8.1.0")

	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}


def disCoveryH3C(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.2")
	if(!deviceCi.serial_number){
		deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.1")
	}
	deviceCi.version = get(".1.3.6.1.2.1.47.1.1.1.1.10.2")
	if(!deviceCi.version){
		deviceCi.version = get(".1.3.6.1.2.1.47.1.1.1.1.10.1")
	}
	deviceCi.port_num = get(".1.3.6.1.4.1.25506.2.40.2.3.1.0")
	if(!deviceCi.port_num){
		deviceCi.port_num = get(".1.3.6.1.4.1.2011.10.2.40.2.3.1.0")
	}
	
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}

def disCoveryHuawei(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.2")
	if(!deviceCi.serial_number){
		deviceCi.serial_number = get(".1.3.6.1.2.1.47.1.1.1.1.11.1")
	}
	if(!deviceCi.serial_number){
		def data = [:]
		def match = ['3' : [], '9' : []]
		def filters = ['3' : '11', '9' : '12']
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.5")){
			if(match[item.value] != null){
				def map = getOrInitMapValue(item.key, data)
				map.type = item.value
			}
		}
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.3")){
			def map = data[item.key]
			if(!map || !map.type){
				continue
			}
			def filter = filters[map.type]
			if(!filter){
				 continue
			}
			if(!item.value){
				map.remove('type') 
				continue
			}
			def ss = item.value.split("\\.")
			if(ss.size() != 10 || ss[8] != filter){
				map.remove('type') 
				continue
			}
		}
		for(def item in walk(".1.3.6.1.2.1.47.1.1.1.1.11")){
			def map = data[item.key]
			if(!map || !map.type || !item.value){
				continue
			}
			match[map.type].add(item.value)
		}
		for(def entry in match){
			if(entry.value){
				deviceCi.serial_number = entry.value.join(',')
				break;
			}
		}
	}
	deviceCi.version = findAllFirst(get(".1.3.6.1.2.1.1.1.0"), 'Version (\\S+)')
	
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}

def disCoveryNsfocus(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.4.0")
	if(!deviceCi.hostname){
		deviceCi.hostname = deviceCi.ip
	}
	deviceCi.devId = get(".1.3.6.1.4.1.19849.6.1.2.0")
	deviceCi.version = get(".1.3.6.1.4.1.19849.6.1.4.0")
	
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}


def disCoveryHillstone(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	def str = get(".1.3.6.1.2.1.1.1.0")
	deviceCi.serial_number = findAllFirst(str, 'SN: (\\S+),')
	deviceCi.version = findAllFirst(str, 'Version (\\S+)')
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}

def disCoveryJuniper(deviceCi){
	deviceCi.hostname = get(".1.3.6.1.2.1.1.5.0")
	deviceCi.serial_number = get(".1.3.6.1.4.1.28557.2.2.1.1.0")
	deviceCi.version = findAllFirst(get(".1.3.6.1.4.1.28557.2.2.1.2.0"), 'version (\\S+)')
	def portIpLists = discovery_portIndex_ip()
	def portIndexs = discovery_portIndex()

	discovery_port(deviceCi, portIndexs, portIpLists)
}

def discovery_port(deviceCi, portIndexs, portIpLists){
	for(def item in portIndexs){
		def portIndex = item.key
		def value = item.value
		def ci = $ci.create('SecurityPort', value.name)
		ci.putAll([
        	port_index : portIndex
        ])
		$ci.createRelationship("Inlines", deviceCi.id, ci.id);
		def ips = portIpLists[portIndex]
		if(ips){
			ci.ip = ips.join(",")
		}
	}
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

//ip地址
def discovery_portIndex_ip(){
	def ipLists = [:]
	for(def item : walk(".1.3.6.1.2.1.4.20.1.2")){
		def ip = item.key
		def port_index = item.value
		def list = getOrInitMapValue(port_index, ipLists, true)
		list.add(ip)
	}
	return ipLists
}

//端口
def discovery_portIndex(){
	def indexs = [:]
	for(def item : walk(".1.3.6.1.2.1.2.2.1.2")){
		def map = getOrInitMapValue(item.key, indexs)
		map.name = item.value
		map.type = getInterfaceType(item.value)
	}
	for(def item : walk(".1.3.6.1.2.1.31.1.1.1.15")){
		def map = getOrInitMapValue(item.key, indexs)
		map.rate  = item.value
	}
	for(def item : walk(".1.3.6.1.2.1.2.2.1.3")){
		def map = getOrInitMapValue(item.key, indexs)
		map.ifType  = item.value
	}
	return indexs;
}

def getInterfaceType(def descr) {
    descr = descr.toLowerCase();
    if (descr.contains("loopback")){
        return "LoopPort";
    }
    else if (descr.contains("eth") || (descr.contains("slot") && descr.contains("port"))){
        return "EthernetPort";
    }
    else if (descr.contains("serial")){
        return "SerialPort"
    }
    else if (descr.contains("vlan")){
        return "VlanPort"
    }
    else if (descr.contains("aggreg")){
        return "ConvergencePort"
    }
    else{
        return "Other";
    }
}

def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}
