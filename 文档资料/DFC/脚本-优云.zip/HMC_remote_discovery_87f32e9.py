# coding: UTF-8
# Author: zhengyd@uyunsoft.cn
# Date  : 2020/10/28
# HMC 远程发现
import copy
import re
import paramiko
try:
    from _utils.Ci import Ci
    __ci__ = Ci()
    __ip__ = ['10.1.11.140']
    __args__ = [{'username': 'hscroot', 'password': '', 'port': '22'}]
except:
    pass

"""!Action
action.name=HMC_87f32e9
action.descr=HMC远程发现
action.main.model=HMC
discovery.output=
"""

"""!Params
ip:ip地址,ip,,true
port:端口,number,22,false
username:用户名,text,hscroot,false
password:密码,password,,false
"""

"""!Model
HMC:HMC,HMC,HMC,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
ipv6:IPV6,string,null,null,ipv6,IPV6
name:名称,string,null,null,name,名称
port:端口,int,null,null,port,端口
brand:品牌,string,null,null,brand,品牌
model:型号,string,null,null,model,型号
version:版本,string,null,null,version,版本
mt_model:M/T型号,string,null,null,mt_model,M/T型号
device_model:设备型号,reference,null,null,device_model,设备型号
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
VIOS:VIOS,VIOS,VIOS,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
bits:位数,string,null,null,bits,位数
name:名称,string,null,null,name,名称
par_id:分区ID,int,null,null,par_id,分区ID
profile:profile,string,null,null,profile,profile
hostname:主机名,string,null,null,hostname,主机名
par_name:分区名称,string,null,null,par_name,分区名称
memory_size:内存大小,string,null,null,memory_size,内存大小
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
process_units:CPU单元,double,null,null,process_units,CPU单元
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
VIOC:VIOC,VIOC,VIOC,false,false
properties:
name:名称,string,null,null,name,名称
ip:IP地址,string,null,null,ip,IP地址
par_id:分区ID,int,null,null,par_id,分区ID
status:状态,string,null,null,status,状态
profile:profile,string,null,null,profile,profile
par_name:分区名称,string,null,null,par_name,分区名称
memory_size:内存大小,string,null,null,memory_size,内存大小
process_units:CPU单元,double,null,null,process_units,CPU单元
serial_number:序列号,string,null,null,serial_number,序列号
"""

"""!Model
MiniServerLPAR:IBM小型机LPAR分区,MiniServerLPAR,IBM小型机LPAR分区,false,false
properties:
name:名称,string,null,null,name,名称
ip:IP地址,string,null,null,ip,IP地址
par_id:分区ID,int,null,null,par_id,分区ID
profile:profile,string,null,null,profile,profile
par_name:分区名称,string,null,null,par_name,分区名称
memory_size:内存大小,string,null,null,memory_size,内存大小
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
serial_number:序列号,string,null,null,serial_number,序列号
"""

"""!Model
MiniServer:IBM小型机,MiniServer,IBM小型机,false,false
properties:
name:名称,string,null,null,name,名称
ip:IP地址,string,null,null,ip,IP地址
model:型号,string,null,null,model,型号
par_num:分区数量,int,null,null,par_num,分区数量
firmware:固件版本,string,null,null,firmware,固件版本
mt_model:M/T型号,string,null,null,mt_model,M/T型号
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
memory_size:内存大小,string,null,null,memory_size,内存大小
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
device_model:设备型号,reference,null,null,device_model,设备型号
serial_number:序列号,string,null,null,serial_number,序列号
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
monitor_enabled:是否监控,string,null,null,monitor_enabled,是否监控
miniserver_brand:品牌,string,null,null,miniserver_brand,品牌
"""


model_map = {
    '7037-A50': 'P185',
    '9115-505': 'P505',
    '9110-510': 'P510',
    '9110-51A': 'P510',
    '9111-520': 'P520',
    '9131-52A': 'P52A',
    '9113-550': 'P550',
    '9133-55A': 'P55A',
    '9116-561': 'P560Q',
    '9117-570': 'P570',
    '9118-575': 'P575',
    '9119-590': 'P590',
    '9119-595': 'P595',
    '8203-E4A': 'P520',
    '8204-E8A': 'P550',
    '8234-EMA': 'P560',
    '9117-MMA': 'P570',
    '9119-FHA': 'P595',
    '8231-E2B': 'P710/P730',
    '8202-E4B': 'P720',
    '8205-E6B': 'P740',
    '8233-E8B': 'P750',
    '9117-MMB': 'P770',
    '9125-F2B': 'P755',
    '9179-MHB': 'P780',
    '8246-L1D': 'PowerLinux 7R1',
    '8246-L2D': '7R2',
    '8248-L4T': '7R4',
    '8268-E1D': 'Power 710',
    '8231-E2D': '730',
    '8205-E6D': '740',
    '9117-MMD': '770',
    '9179-MHD': '780',
    '9119-FHB': '795',

    '7042-C06': 'x3200',
    '7042-C07': 'x3200 M2',

    '7042-CR4': 'x3550',
    '7042-CR5': 'x3550 M2',
    '7042-CR6': None,
    '7042-CR7': None,
    '7310-CR3': None,
    '7316-TF3': 'TF3 液晶套件',
    '7014-T42': 'T42 机柜',
    '7014-T00': 'T00 机柜',
    '7216-1U2': '1U2 外置磁带机'
}


def re_findall(pattern, msg, convert_to=str, index=0, multiply=None):
    tmp = re.findall(pattern, msg)
    if tmp:
        try:
            tmp = tmp[index].strip()
            if multiply is not None:
                tmp = float(tmp) * multiply     # 对结果乘以指定数字
            return convert_to(tmp)              # 转为指定类型
        except Exception as err:
            __ci__.result_log('WARN', 're_findall: regex {}, result: {}, {}'
                              .format(pattern, tmp, err))


def convert_bytes(size, unit=None, src_unit=None, multiple=1024, return_str=True):
    """自动转换字节大小, 支持指定原始单位"""
    symbols = ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB')
    symbols1 = ('B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
    symbols2 = ('B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB')
    try:
        # 10.21g 获取大小和单位
        if isinstance(size, str):
            size = size.replace(',', '')
            util_tmp = re.search('[bkmgtpezyi]{1,3}', size, re.I)
            if util_tmp:
                _src_unit = util_tmp.group().upper()
                if _src_unit in symbols1:
                    src_unit = symbols[symbols1.index(_src_unit)]
                elif _src_unit in symbols2:
                    src_unit = symbols[symbols2.index(_src_unit)]
                elif _src_unit in symbols:
                    src_unit = _src_unit

            size = float(re.search('\d+(\.\d+)?', size).group())
        else:
            size = float(size)
        # print size, src_unit
        step = 0
        if src_unit:  # 指定了原始单位
            size = size * (multiple ** (symbols.index(src_unit.upper())))
        if not unit:  # 自动计算单位
            while size >= multiple and step < len(symbols) - 1:
                size /= multiple
                step += 1
            unit = symbols[step]
        else:  # 转换为指定单位
            index_of_unit = symbols.index(unit)
            while len(symbols) - 1 > step and index_of_unit != step:
                size /= multiple
                step += 1
        if return_str:
            return '{:.2f} {}'.format(size, unit)
        else:
            return size, unit
    except Exception as e:
        print('[ERROR] Convert bytes error, {} {}'.format(size, e))
        return size


class HMC(object):
    def __init__(self, ip, username, password, port=22, timeout=5):
        self.client = None
        self.ip = ip
        self.username = username
        self.password = password
        self.port = int(port)
        self.timeout = timeout
        self.client = None
        self.channel = None

    def login(self):
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(self.ip, self.port, username=self.username, password=self.password, timeout=self.timeout)
            self.client = client
            __ci__.result_log('INFO', '{}@{}:{} login succeed'.format(self.username, self.ip, self.port))
            return True
        except paramiko.AuthenticationException as err:
            __ci__.result_log('WARN', '{}@{}:{} login failed: {}'.format(self.username, self.ip, self.port, err))
            raise paramiko.AuthenticationException(err)
        except Exception as err:
            __ci__.result_log('ERROR', '{}@{}:{} login failed: {}'.format(self.username, self.ip, self.port, err))
            return False

    def run_cmd(self, cmd):
        if not self.client:
            self.login()
        self.channel = self.client.get_transport().open_session()
        self.channel.get_pty()
        self.channel.exec_command(cmd)
        stdout = self.channel.makefile('r', -1).read()
        stderr = self.channel.makefile_stderr('r', -1).read()
        code = self.channel.recv_exit_status()
        if code or stderr:
            __ci__.result_log('WARN', 'run cmd: {}, return code {}; {}; {}'.format(cmd, code, stdout, stderr))
        return code, stdout.strip()

    def logout(self):
        if self.channel:
            self.channel.close()
            self.client.close()
            __ci__.result_log('INFO', 'logout')

    @staticmethod
    def to_list(out):
        return [dict(re.findall(r'(\w+)=([^,]+.*?)', line)) for line in out.strip().splitlines()]

    def to_dict(self, out, key='lpar_id'):
        try:
            return {i[key]: i for i in self.to_list(out)}
        except Exception as err:
            __ci__.result_log("WARN", 'Convert to dict error: {}, {}'.format(err, repr(out)))
            return {}

    @staticmethod
    def create_lpar_ci(ci_code, parent_ci, name, **kwargs):
        """
        用于创建 VIOS、 VIOC、 MiniServerLPAR 的 Ci
        """
        ci = __ci__.create(ci_code, name)
        ci['properties'] = kwargs
        __ci__.createrelationship(ci['cid'], parent_ci['cid'], 'RunsOn')
        return ci

    def discovery_lpars(self, server_name, miniserver_ci):
        """发现一台小机下的所有 lpar 分区"""
        # 所有分区
        code, lpars_str = self.run_cmd('lssyscfg -r lpar -m {}'.format(server_name))
        # 所有分区的内存信息
        code, lpars_mem_str = self.run_cmd('lshwres -r mem -m {} --level lpar'.format(server_name))
        if code:
            return
        # 所有分区的cpu信息
        lpars_cpu_str = self.run_cmd('lshwres -r proc -m {} --level lpar'.format(server_name))[1]
        lpars_dict = self.to_dict(lpars_str)
        lpars_mem_dict = self.to_dict(lpars_mem_str)
        lpars_cpu_dict = self.to_dict(lpars_cpu_str)

        __ci__.result_log('INFO', '{} 发现中发现 {} 个 lpar'.format(server_name, len(lpars_dict)))
        miniserver_ci['properties']['par_num'] = len(lpars_dict)
        sn = miniserver_ci['properties']['serial_number']

        # 通过有无 vioserver 判断是否为 PowerVM虚拟化
        is_power_vm = False
        vios_ci = None
        for lpar_id, lpar in lpars_dict.items():
            if lpar.get('lpar_env') == 'vioserver':
                is_power_vm = True
                vios_ci = self.create_lpar_ci(
                    'VIOS',
                    miniserver_ci, lpar['name'],
                    ip=lpar.get('rmc_ipaddr'),
                    par_name=lpar['name'],
                    par_id=lpar_id,
                    serial_number=sn,
                    profile=lpar.get('curr_profile'),
                    process_units=lpars_cpu_dict[lpar_id].get('pend_proc_units'),
                    memory_size=convert_bytes(lpars_mem_dict[lpar_id].get('pend_mem'), src_unit='MB')
                  )
                break

        for lpar_id, lpar in lpars_dict.items():
            cpu = lpars_cpu_dict[lpar_id].get('pend_proc_units')
            mem = convert_bytes(lpars_mem_dict[lpar_id].get('pend_mem'), src_unit='MB')

            if lpar.get('lpar_env') == 'vioserver':
                continue

            ci_code = 'VIOC' if is_power_vm else 'MiniServerLPAR'
            main_ci = vios_ci if is_power_vm else miniserver_ci
            self.create_lpar_ci(ci_code,
                                main_ci,
                                lpar['name'],
                                ip=lpar.get('rmc_ipaddr'),
                                par_name=lpar['name'],
                                par_id=lpar_id,
                                serial_number=sn,
                                process_units=cpu,
                                memory_size=mem,
                                status=lpar.get('state'),
                                profile=lpar.get('curr_profile')
                                )

    def discovery_servers(self, hmc_ci):
        """发现所有被管服务器和它的lpar"""
        code, all_sys = self.run_cmd('lssyscfg -r sys')
        if code:
            return
        managed_systems = self.to_list(all_sys)
        for server in managed_systems:
            # print(server)
            __ci__.result_log('INFO', '发现Server {}'.format(server['name']))

            if server.get('state') not in ('Operating', 'Standby'):
                __ci__.result_log('WARN', 'Server {} 状态不正常，{}'.format(server['name'], server.get('state')))
                continue

            server_mem_str = self.run_cmd('lshwres -r mem -m {} --level sys'.format(server['name']))[1]
            server_cpu_str = self.run_cmd('lshwres -r proc -m {} --level sys'.format(server['name']))[1]
            lpar_proc_compat_modes = self.run_cmd('lssyscfg -r sys -F lpar_proc_compat_modes -m {}'.format(server['name']))[1]
            server_mem_dict = self.to_list(server_mem_str)[0]
            server_cpu_dict = self.to_list(server_cpu_str)[0]

            # 将 M/T型号转为通用型号,如 8204-E8A --> P550
            general_model = model_map.get(server['type_model'])

            name = '{}/{}'.format(general_model or server['type_model'], server['serial_num'])

            miniserver_ci = __ci__.create('MiniServer', name)
            miniserver_ci['properties'] = {
                'ip': server['ipaddr'],
                'model': general_model,
                'mt_model': server['type_model'],
                'serial_number': server['serial_num'],
                'miniserver_brand': 'ibm',
                'cpu_model': lpar_proc_compat_modes.strip('"').split(',')[-1],
                'cpu_phys_num': server_cpu_dict.get('installed_sys_proc_units'),
                'memory_size': convert_bytes(server_mem_dict.get('installed_sys_mem'), src_unit='MB')
            }
            __ci__.createrelationship(hmc_ci['cid'], miniserver_ci['cid'], 'Manages')

            self.discovery_lpars(server['name'], miniserver_ci)

    def discovery(self):
        if not self.login():
            return
        code, hmc_version_res = self.run_cmd('lshmc -v')
        if code:
            __ci__.result_log('WARN', '非 HMC，退出发现')
            self.logout()
            return
        mt_model = re_findall(r'\*TM (.*)', hmc_version_res)
        hmc_ci = __ci__.create('HMC', 'HMC-{}'.format(self.ip))
        hmc_ci['properties'] = {
            'ip': self.ip,
            'brand': 'IBM',
            'model': model_map.get(mt_model),
            'mt_model': mt_model,
            'version': re_findall(r'\*RM (.*)', hmc_version_res),
            'serial_number': re_findall(r'\*SE (.*)', hmc_version_res)
        }

        __ci__.result_log('info', '发现HMC: {}'.format(hmc_ci['properties']))

        self.discovery_servers(hmc_ci)
        self.logout()
        __ci__.result_log('INFO', '发现完成')


def merge_args(ip='ip'):
    """合并 __ip__ 和 __args__"""
    all_args = {}
    for i in globals().get('__ip__', []):
        all_args[i] = __args__
    for i in globals().get('__ip_ranges__', []):
        all_args[i] = __args__
    for _arg in __args__:
        if _arg.get(ip):
            all_args[_arg[ip]] = [_arg]
    # print all_args
    __ci__.result_log('INFO', "Merged {} args".format(len(all_args)))
    return all_args


if __name__ == '__main__':
    for ip, args in merge_args().items():
        __ci__.ip = ip
        for _args in args:
            arg = copy.deepcopy(_args)
            arg['ip'] = ip
            try:
                HMC(**arg).discovery()
                break
            except paramiko.AuthenticationException:
                __ci__.result_log('WARN', '登陆失败, 尝试使用新的认证信息')
                continue
            except Exception as e:
                __ci__.result_log('ERROR', '发现HMC失败, 原因 :{}'.format(e))
                # print traceback.print_exc()
                break
    __ci__.result_log('INFO', '全部发现结束')
    __ci__.result_data()
