/*!Action 
action.name=PostgreSQL_remote_discovery_87f32e9
action.descr=PostgreSQL_remote_discovery
action.version=1.0.0
action.protocols=postgresql
action.main.model=PostgreSQL
discovery.output=Database
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,5432,false
database:数据库名,text,postgres,false
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
PostgreSQL:PostgreSQL实例,PostgreSQL,PostgreSQL实例,false,false
properties
postgresqlUser:PostgreSQL用户,inline,null,null,postgresqlUser,PostgreSQL用户
wal_leve:WAL日志级别,string,null,null,wal_leve,WAL日志级别
tcp_keepalives_idle:tcp_keepalives_idle,int,null,秒,tcp_keepalives_idle,tcp_keepalives_idle
max_parallel_workers:并行查询最大允许的worker数,int,null,null,max_parallel_workers,并行查询最大允许的worker数
install_path:安装路径,string,null,null,install_path,安装路径
max_files_per_process:max_files_per_process,int,null,null,max_files_per_process,max_files_per_process
postgresqlDatabase:PostgreSQL数据库,inline,null,null,postgresqlDatabase,PostgreSQL数据库
postgresqlExtension:PosgreSQL插件,inline,null,null,postgresqlExtension,PosgreSQL插件
hostname:主机名,string,null,null,hostname,主机名
tcp_keepalives_count:tcp_keepalives_count ,int,null,null,tcp_keepalives_count,tcp_keepalives_count 
postgresqlRole:PostgreSQL角色,inline,null,null,postgresqlRole,PostgreSQL角色
wal_keep_segments:wal_keep_segments,int,null,null,wal_keep_segments,wal_keep_segments
archive_mode:归档模式,string,null,null,archive_mode,归档模式
max_worker_processes:最大允许后台进程数,int,null,null,max_worker_processes,最大允许后台进程数
max_connections:最大连接数,int,null,null,max_connections,最大连接数
datadir:数据目录,string,null,null,datadir,数据目录
archive_dest:归档路径,string,null,null,archive_dest,归档路径
ip:IP地址,string,null,null,ip,IP地址
pg_hba:pg_hba配置,table,null,null,pg_hba,pg_hba配置
sync_state:流复制模式,string,null,null,sync_state,流复制模式
time_zone:时区,string,null,null,time_zone,时区
tcp_keepalives_interval:tcp_keepalives_interval,int,null,秒,tcp_keepalives_interval,tcp_keepalives_interval
version:版本,string,null,null,version,版本
maintenance_work_mem:maintenance_work_mem,string,null,null,maintenance_work_mem,maintenance_work_mem
effective_cache_size:最大缓存,string,null,null,effective_cache_size,最大缓存
port:端口,int,null,null,port,端口
max_wal_size:WAL日志大小,string,null,null,max_wal_size,WAL日志大小
instance_role:实例角色,string,null,null,instance_role,实例角色
name:名称,string,null,null,name,名称
shared_buffer:共享内存缓冲区,string,null,null,shared_buffer,共享内存缓冲区
work_mem:work_mem,string,null,null,work_mem,work_mem
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
PostgreSQLUser:PostgreSQL用户,PostgreSQLUser,PostgreSQL用户,true,false
properties
usecreatedb:创建数据库权限,string,null,null,usecreatedb,创建数据库权限
name:名称,string,null,null,name,名称
valuntil:过期时间,string,null,null,valuntil,过期时间
userepl:复制权限,string,null,null,userepl,复制权限
usesuper:超级管理员权限,string,null,null,usesuper,超级管理员权限
*/

/*!Model
PostgreSQLDatabase:PostgreSQL数据库,PostgreSQLDatabase,PostgreSQL数据库,true,false
properties
db_size:数据库大小,string,null,null,db_size,数据库大小
name:名称,string,null,null,name,名称
encoding:字符编码方,string,null,null,encoding,字符编码方
datdba:数据库所有人,string,null,null,datdba,数据库所有人
*/

/*!Model
PostgreSQLExtension:PostgreSQL插件,PostgreSQLExtension,PostgreSQL插件,true,false
properties
schema:Schema,string,null,null,schema,Schema
name:名称,string,null,null,name,名称
version:版本,string,null,null,version,版本
*/

/*!Model
PostgreSQLRole:PostgreSQL角色,PostgreSQLRole,PostgreSQL角色,true,false
properties
rolinherit:角色继承权限,string,null,null,rolinherit,角色继承权限
rolcanlogin:登录权限,string,null,null,rolcanlogin,登录权限
rolcreaterole:创建角色权限,string,null,null,rolcreaterole,创建角色权限
rolcreatedb:创建数据库权限,string,null,null,rolcreatedb,创建数据库权限
rolvaliduntil:过期时间,string,null,null,rolvaliduntil,过期时间
name:名称,string,null,null,name,名称
rolreplication:复制权限,string,null,null,rolreplication,复制权限
rolsuper:超级管理员权限,string,null,null,rolsuper,超级管理员权限
*/

/*!Model
pg_hba:pg_hba配置,pg_hba,pg_hba配置,false,true
properties
type:type,string,null,null,type,type
database:database,string,null,null,database,database
user:user,string,null,null,user,user
address:address,string,null,null,address,address
method:method,string,null,null,method,method
*/

/*!Model
PostgreSQLCluster:PostgreSQL集群,PostgreSQLCluster,PostgreSQL集群,false,false
properties
vipMember:VIP成员,inline,null,null,vipMember,VIP成员
cluster_instance_port:集群实例端口,string,null,null,cluster_instance_port,集群实例端口
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
VIPMember:VIP成员,VIPMember,VIP成员,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
PostgreSQLDR:PostgreSQL容灾,PostgreSQLDR,PostgreSQL容灾,false,false
properties
dr_perst_ip:容灾永久IP,string,null,null,dr_perst_ip,容灾永久IP
name:名称,string,null,null,name,名称
dr_instance_port:容灾实例端口,string,null,null,dr_instance_port,容灾实例端口
*/
 
/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def postgresqlCi = discovery_postgresql();

discovery_user(postgresqlCi)
discovery_database(postgresqlCi)
discovery_role(postgresqlCi)
discovery_extension(postgresqlCi)
discovery_cluster(postgresqlCi)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_postgresql(){
	$logger.logInfo("Discover PostgreSQL");
	def pg_setting = [:]
	for(def row in $postgresql.query("select name,setting from pg_settings")){
		def item = row.getValues()
		def name = item[0]
		def value = item[1]
		pg_setting[name] = value
	}
	if(!pg_setting['data_directory']){
		def sql = "select current_setting('data_directory')";
		try{
			pg_setting['data_directory'] = $postgresql.queryForValue(sql)
		}catch(Exception e){
			$logger.logWarn("exec sql[${sql}] error", e);
		}
	}
	def archive_dest = pg_setting['archive_command'].split()[-1];
	if(archive_dest.endsWith("/%f")){
		archive_dest = archive_dest.substring(0, archive_dest.length() - "/%f".length())
	}
	def pg_is_in_recovery = $postgresql.queryForValue('select pg_is_in_recovery()')
	def wal_level = $postgresql.queryForValue("SELECT current_setting('wal_level')")
	def pg_stat_replications = $postgresql.query('select client_addr,client_port,sync_state from pg_stat_replication')
	
	def instance_role = null;
	if(wal_level == 'minimal'){
    	instance_role = 'standalone'
   	}
    else if(pg_is_in_recovery){
    	instance_role = 'slave'
    }
    else if(!pg_is_in_recovery && pg_stat_replications){
    	instance_role = 'master'
    }
    else {
    	instance_role = 'standalone'
	}
	def ci = $ci.create("PostgreSQL", "PostgreSQL", "PgSQL" + $postgresql.params.port);
	ci.putAll([
			ip : $postgresql.params.ip,
			port : $postgresql.params.port,
			hostname : '',
			instance_role : instance_role,
		    hba_file : pg_setting['hba_file'],
            config_file : pg_setting['config_file'],
            datadir : pg_setting['data_directory'],
            wal_leve : pg_setting['wal_level'],
            version : pg_setting['server_version'],
            time_zone : pg_setting['TimeZone'],
            archive_dest : archive_dest,
            archive_mode : pg_setting['archive_mode'] == 'on' ? 'yes' : 'no',
            max_wal_size : convert_bytes(pg_setting['max_wal_size'], new convert_bytes_params(src_unit : 'MB')),
            shared_buffer : convert_bytes(pg_setting['shared_buffers'], new convert_bytes_params(src_unit : 'MB')),
            max_connections : pg_setting['max_connections'],
            effective_cache_size : convert_bytes(pg_setting['effective_cache_size']),
            maintenance_work_mem : convert_bytes(pg_setting['maintenance_work_mem']),
            max_parallel_workers : pg_setting['max_parallel_workers'],
            max_worker_processes : pg_setting['max_worker_processes'],
            max_files_per_process : pg_setting['max_files_per_process'],
            tcp_keepalives_idle : pg_setting['tcp_keepalives_idle'],
            tcp_keepalives_count : pg_setting['tcp_keepalives_count'],
            tcp_keepalives_interval : pg_setting['tcp_keepalives_interval'],
            work_mem : convert_bytes(pg_setting['work_mem'], new convert_bytes_params(src_unit : 'KB')),
            wal_keep_segments : pg_setting['wal_keep_segments']
		])
	def osInfo = $postgresql.queryForValue("select version()")
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, ci.hostname ? $postgresql.params.ip + "-" + ci.hostname : $postgresql.params.ip)
    	osCi.ip = $postgresql.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}


def discovery_database(postgresqlCi){
	$logger.logInfo("Discover database");
	def exclude_databases = ['postgres', 'template0', 'template1']
	def sql = '''select
    d.datname as "db_name",
    (select pg_size_pretty(pg_database_size(d.datname))),
    r.rolname as "db_owen",
    pg_catalog.pg_encoding_to_char(d.encoding) as "encoding",
    (select ppu.usename from pg_catalog.pg_user ppu where ppu.usesysid=t.spcowner  ) as "tbs_owen",
        pg_tablespace_location(t.oid) as tbs_locate,
    t.spcname as "tbs_name" 
from
    pg_catalog.pg_database d
right join pg_catalog.pg_roles r on
    d.datdba = r.oid
right join pg_catalog.pg_tablespace t on
    d.dattablespace = t.oid
right join pg_catalog.pg_user u on 
    d.datdba=u.usesysid
order by 1
'''
	for(def row in $postgresql.query(sql)){
		def item = row.getValues();
		def name = item[0]
		if(!name || name in exclude_databases){
			continue
		}
		def ci = $ci.create('PostgresqlDatabase', name)
        $ci.createRelationship("Inlines", postgresqlCi.id, ci.id);
        ci.putAll([
       		encoding : item[3],
            datdba : item[2],
            db_size : item[1]
        ])
	}
}

def discovery_user(postgresqlCi){
	$logger.logInfo("Discover user");
	def exclude_users = ['postgres']
	for(def row in $postgresql.query("select usename, usecreatedb ,usesuper ,userepl ,valuntil from pg_user")){
		def item = row.getValues();
		def name = item[0]
		if(name in exclude_users){
			continue
		}
		def ci = $ci.create('PostgreSQLUser', name)
        $ci.createRelationship("Inlines", postgresqlCi.id, ci.id);
        ci.putAll([
        	userepl : item[3],
            usesuper : item[2],
            valuntil : item[4],
            usecreatedb : item[1]
        ])
	}
}

def discovery_role(postgresqlCi){
	$logger.logInfo("Discover role");
	for(def row in $postgresql.query("select rolname,rolsuper,rolinherit,rolcreaterole,rolcreatedb,rolcanlogin,rolreplication,rolvaliduntil from pg_roles")){
		def item = row.getValues();
		def name = item[0]
		if(name == 'postgres' || name.startsWith("pg_")){
			continue
		}
		def ci = $ci.create('PostgreSQLRole', name)
        $ci.createRelationship("Inlines", postgresqlCi.id, ci.id);
        ci.putAll([
        	rolsuper : item[1],
            rolinherit : item[2],
            rolcreaterole : item[3],
            rolcreatedb : item[4],
            rolcanlogin : item[5],
            rolreplication : item[6],
            rolvaliduntil : item[7]
        ])
	}
}

def discovery_extension(postgresqlCi){
	$logger.logInfo("Discover extension");
	def sql = '''SELECT
  e.extname AS "name",
  e.extversion AS "version",
  n.nspname AS "schema",
  c.description AS "description"
FROM pg_catalog.pg_extension e
LEFT JOIN pg_catalog.pg_namespace n ON n.oid = e.extnamespace
LEFT JOIN pg_catalog.pg_description c ON c.objoid = e.oid
  AND c.classoid = 'pg_catalog.pg_extension' :: pg_catalog.regclass
ORDER BY 1
'''
	for(def row in $postgresql.query(sql)){
		def item = row.getValues();
		def name = item[0]
		if(name == 'postgres' || name.startsWith("pg_")){
			continue
		}
		def ci = $ci.create('PostgresqlExtension', name)
        $ci.createRelationship("Inlines", postgresqlCi.id, ci.id);
        ci.putAll([
        	version : item[1],
            schema : item[2],
            description : item[3]
        ])
	}
}

def getKey(def ip){
	return ip.split("\\.")[0..2].join(".");
}

def discovery_cluster(postgresqlCi){
	$logger.logInfo("Discover cluster");
	
	def key = getKey($postgresql.params.ip)
	def clusterCis = [postgresqlCi]
	def allCis = [postgresqlCi]
	
	def ci = null
	for(def row in $postgresql.query("select client_addr,client_port,sync_state from pg_stat_replication")){
		def item = row.getValues();
		def ip = item[0].getValue()
		def port = $postgresql.params.port.toString()
		def k = getKey(ip)
		
		def name = "PgSQL${port}"
		ci = $ci.create('PostgreSQL', name)
        ci.putAll([
        	ip : ip,
			port : $postgresql.params.port,
			sync_state : item[2]
        ])
		allCis.add(ci)
		if(k == key){
			clusterCis.add(ci)
		}
	}
	def clusterCi = null
	if(clusterCis.size() > 1){
        def names = "PgSQL" + clusterCis.collect{e->e.port}.join("_")
        def ips = clusterCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
        ci = $ci.create('PostgreSQLCluster', names)
        ci.putAll([
        	cluster_instance_port : names,
        	cluster_perst_ip : ips
        ])
        clusterCi = ci
        $ci.createRelationship("Contains", clusterCi.id, postgresqlCi.id);
        for(def temp : clusterCis){
			$ci.createRelationship("Contains", clusterCi.id, temp.id);
        }
	}
	def drCi = null
	if(allCis.size() > clusterCis.size()){
		def names = "PgSQL" + allCis.collect{e->e.port}.join("_")
        def ips = allCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
        ci = $ci.create('PostgreSQLDR', names)
        ci.putAll([
        	dr_instance_port : names,
        	dr_perst_ip : ips
        ])
        drCi = ci
        if(clusterCi){
        	$ci.createRelationship("Contains", drCi.id, clusterCi.id);
        }
        else {
        	$ci.createRelationship("Contains", drCi.id, postgresqlCi.id);
        }
        
        for(def temp : allCis){
        	if(temp in clusterCis){
   				continue     		
        	}
			$ci.createRelationship("Contains", drCi.id, temp.id);
        }
	}
}
