/*!Action
action.name=MongoDB_remote_discovery_87f32e9
action.descr=MongoDB_remote_discovery
action.version=1.0.0
action.protocols=MongoDB
action.main.model=MongoDB
discovery.output=Database
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,27017,false
db:数据库,text,admin,false
user:用户名,text,,true
password:密码,password,,true
timeout:操作超时时间(ms),text,30000,false
*/

/*!Model
MongoDB:MongoDB实例,MongoDB,MongoDB实例,false,false
properties
mongodbDatabase:MongoDB数据库,inline,null,null,mongodbDatabase,MongoDB数据库
max_connections:最大连接数,int,null,null,max_connections,最大连接数
logpath:日志路径,string,null,null,logpath,日志路径
role:角色,string,null,null,role,角色
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
bind_address:绑定地址,string,null,null,bind_address,绑定地址
version:版本,string,null,null,version,版本
pidfile:进程pid文件,string,null,null,pidfile,进程pid文件
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
shard_name:分片名称,string,null,null,shard_name,分片名称
socket:套接字,string,null,null,socket,套接字
dbpath:数据文件路径,string,null,null,dbpath,数据文件路径
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
MongoDBDatabase:MongoDB数据库,MongoDBDatabase,MongoDB数据库,true,false
properties
collections:表个数,int,null,null,collections,表个数
index_size:索引大小,string,null,null,index_size,索引大小
db_size:数据库大小,string,null,null,db_size,数据库大小
name:名称,string,null,null,name,名称
index_num:索引数,int,null,null,index_num,索引数
*/

/*!Model
MongoDBCluster:MongoDB集群,MongoDBCluster,MongoDB集群,false,false
properties
mongodbDatabase:MongoDB数据库,inline,null,null,mongodbDatabase,MongoDB数据库
cluster_instance_port:集群实例端口,string,null,null,cluster_instance_port,集群实例端口
name:名称,string,null,null,name,名称
cluster_name:集群名,string,null,null,cluster_name,集群名
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def field = $MongoDB.getClass().getDeclaredField("mongoClient")
field.setAccessible(true);
mongoClient = field.get($MongoDB)



def mongodbCi = discovery_mongodb();
def clusterCi = discovery_cluster(mongodbCi);
discover_database(mongodbCi, clusterCi)

if(mongodbCi.parent.serverStatus.process == 'mongos' || is_configsvr()){
	$logger.logInfo("Discover shard");
	discovery_shard()
	if(mongodbCi.parent.serverStatus.process == 'mongos'){
		build_cluster(mongodbCi.parent.serverStatus.sharding.configsvrConnectionString, false)
	}

}


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_mongodb(){
	$logger.logInfo("Discover mongodb");
	def db = $MongoDB.runCommand("serverStatus", 1);
	def ci = $ci.create("MongoDB", "MongoDB", "MongoDB" + $MongoDB.params.port);
	ci.putAll([
			ip : $MongoDB.params.ip,
			port : $MongoDB.params.port,
			hostname : db.host.split(":", 2)[0],
            version : db.version,
            max_connections : db.connections.current + db.connections.available
		])
	def osInfo = $MongoDB.runCommand("hostInfo", 1).os.type;
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, $MongoDB.params.ip + "-" + ci.hostname)
    	osCi.ip = $MongoDB.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
    ci.parent.serverStatus = db
	return ci;
}

def discover_database(mongodbCi, clusterCi){
	if(mongodbCi.role != 'STANDALONE' && mongodbCi.role != 'PRIMARY'){
		return null;
	}
	$logger.logInfo("Discover database");
	def exclude_dbs = ['admin', 'config', 'local']
	
	for(def db in $MongoDB.runCommand("listDatabases", 1).databases){
		def name = db.name;
		if(name in exclude_dbs){
			continue;
		}
		def dbInfo = mongoClient.getDatabase(name).runCommand(new org.bson.Document("dbStats", 1));
		def ci = $ci.create('MongodbDatabase', name)
        ci.putAll([
        	db_size : convert_bytes(dbInfo.dataSize, new convert_bytes_params(src_unit : 'B')),
            index_num : dbInfo.indexes,
            index_size : convert_bytes(dbInfo.indexSize, new convert_bytes_params(src_unit : 'B')),
            collections : dbInfo.collections
        ])
        if(clusterCi){
			$ci.createRelationship("Inlines", clusterCi.id, ci.id);
		}
		else {
			$ci.createRelationship("Inlines", mongodbCi.id, ci.id);
		}
	}
}

def discovery_cluster(mongodbCi){
	def info = $MongoDB.runCommand("isMaster", 1);
	def replSet = info.setName
	if(!replSet) {
		mongodbCi.role = 'STANDALONE'
		return ;
	}
	$logger.logInfo("Discover cluster");
	def hosts = []
	def primary = info.primary
	for(def name : info.hosts){
		def role = 'SECONDARY'
		if(name == primary){
			role = 'PRIMARY'
		}
		hosts.add([name: name, role: role])
	}
	if(info.arbiters){
		for(def name : info.arbiters){
			hosts.add([name: name, role: 'ARBITER'])
		}
	}
	
	def allCis = [mongodbCi]
	//def key = mongodbCi.ip + ":" + mongodbCi.port
	def key = info.me
	for(def host : hosts){
		def name = host.name
		if(name == key){
			mongodbCi.role = host.role
			continue
		}
		def ss = name.split(":");
		def ip = ss[0]
		def port = Integer.parseInt(ss[1])
		def ci = $ci.create("MongoDB", "MongoDB${port}");
		ci.putAll([
			ip : ip,
			port : port,
			role : host.role
		])
		allCis.add(ci)
	}
	return build_cluster_cis(allCis, replSet)
}


def is_configsvr(){
	def result = mongoClient.getDatabase('admin').runCommand(new org.bson.Document("replSetGetConfig", 1));
	return result.config.configsvr ? true : false
}


def discovery_shard(){
	def findIterable = mongoClient.getDatabase('config').getCollection("shards").find();
	def mongoCursor = findIterable.iterator();  
    while(mongoCursor.hasNext()){  
       def obj = mongoCursor.next();  
       build_cluster(obj.host)
    } 
}

def build_cluster(def repl, def addShardName = true){
	def replArray = repl.split("/")
	def name = replArray[0]
	def cis = []
	for(def hostPort in replArray[1].split(",")){
		def hostPortArray = hostPort.split(":")
		def ip = hostPortArray[0]
		def port = hostPortArray[1]
		
		def ci = $ci.create("MongoDB", "MongoDB${port}")
		ci.putAll([
			ip : ip,
			port : port
		])
		if(addShardName){
			ci.shard_name = name
		}
		cis.add(ci)
	}
	build_cluster_cis(cis, name)
}

def build_cluster_cis(def allCis, def name){
	def clusterCi = null;
	if(allCis.size() > 1){
		def cluster_instance_port = "MongoDB" + allCis.collect{e-> "" + e.port}.sort({a, b -> return compareStr(a, b);}).join("_")
        def ips = allCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
        def ci = $ci.create('MongoDBCluster', name)
        ci.putAll([
        	cluster_name : name,
        	cluster_instance_port : cluster_instance_port,
        	cluster_perst_ip : ips
        ])
        for(def temp : allCis){
			$ci.createRelationship("Contains", ci.id, temp.id);
        }
        clusterCi = ci
	}
	return clusterCi
}
