/*!Action 
action.name=Informix_remote_discovery_87f32e9
action.descr=Informix_remote_discovery
action.version=1.0.0
action.protocols=informix
action.main.model=Informix
discovery.output=Database
*/
 
/*!Params
ip:目标设备IP,ip,,true
port:端口,number,1533,false
server:服务器,text,,false
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
Informix:Informix实例,Informix,Informix实例,false,false
properties
instance_name:实例名,string,null,null,instance_name,实例名
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
version:Informix版本,string,null,null,version,Informix版本
onconfig:onconfig文件,string,null,null,onconfig,onconfig文件
informixDatabase:Informix数据库,inline,null,null,informixDatabase,Informix数据库
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
server_number:实例Number,int,null,null,server_number,实例Number
name:名称,string,null,null,name,名称
sqlhosts:sqlhosts文件,string,null,null,sqlhosts,sqlhosts文件
*/

/*!Model
InformixDatabase:Informix数据库,InformixDatabase,Informix数据库,true,false
properties
name:数据库名称,string,null,null,name,数据库名称
database_size:数据库大小,string,null,null,database_size,数据库大小
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def informixCi = discovery_informix();
discovery_database(informixCi)

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_informix(){
	$logger.logInfo("Discover informix");
	
	def ci = $ci.create('Informix', $scriptParams.server)
	ci.putAll([
		instance_name : $scriptParams.server,
		ip : $scriptParams.ip,
		port : $scriptParams.port,
		version : $informix.queryForValue("SELECT DBINFO('version','full') FROM systables WHERE tabid = 1")
	])
	return ci
}


def discovery_database(mysqlCi){
	$logger.logInfo("Discover database");
	def sql = """
SELECT dbsname[1,15] database_name, SUM(pe_size)*4 size_KB
FROM sysmaster:sysptnext,
OUTER sysmaster:systabnames
WHERE pe_partnum = partnum
GROUP BY 1
ORDER BY 2 DESC
"""
	for(def row in $informix.query(sql)){
		def item = row.getValues();
		def name = item[0].trim()
		def ci = $ci.create('InformixDatabase', name)
        $ci.createRelationship("Inlines", mysqlCi.id, ci.id);
        ci.database_size = convert_bytes(item[1], new convert_bytes_params(src_unit : 'KB'))
	}
}