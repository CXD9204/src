/*!Action
action.name=SpecialEquipment_remote_discovery_87f32e9
action.descr=SpecialEquipment_remote_discovery(snmp v1/v2c) 专用服务器采集,支持信安世纪NetSign设备
action.version=1.0.0
action.protocols=snmp
action.main.model=SpecialEquipment
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
SpecialEquipment:专用服务器,SpecialEquipment,专用服务器,false,false
properties
hostname:主机名,string,null,null,hostname,主机名
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
model:型号,string,null,null,model,型号
brand:品牌,string,null,null,brand,品牌
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:版本,string,null,null,version,版本
memory_size:内存大小,string,null,null,memory_size,内存大小
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
*/

import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;


def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();


def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
if(sysObjectId != '.1.3.6.1.4.1.4976'){
	throw new RuntimeException("Unrecognized ID:" + sysObjectId)
}
def name = get(".1.3.6.1.4.1.47566.3.6.1.0")

def deviceCi = $ci.create('SpecialEquipment', 'SpecialEquipment', name);
deviceCi.putAll([
	ip : $scriptParams.ip,
	hostname : name,
	brand : get(".1.3.6.1.2.1.1.5.0"),
	memory_size : convert_bytes(get(".1.3.6.1.4.1.47566.3.1.2.0"), new convert_bytes_params(src_unit : 'MB')),
	version : get(".1.3.6.1.2.1.1.1.0").split()[-1]
])

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}
