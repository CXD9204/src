/*!Action
action.name=Elasticsearch_remote_discovery_87f32e9
action.descr=Elasticsearch_remote_discovery
action.protocols=http
action.main.model=Elasticsearch
discovery.output=Computer
*/

/*!Params
ip:目标设备IP,ip,,true
username:用户名,text,,false
port:端口,number,9200,false
password:密码,password,,false
*/

/*!Model
Elasticsearch:Elasticsearch实例,Elasticsearch,Elasticsearch实例,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
java_opts_xmx:最大内存,string,null,null,java_opts_xmx,最大内存
role:角色,string,null,null,role,角色
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
node_name:节点名称,string,null,null,node_name,节点名称
master_flag:是否Master,string,null,null,master_flag,是否Master
path_plugins:插件路径,string,null,null,path_plugins,插件路径
bind_address:绑定地址,string,null,null,bind_address,绑定地址
version:版本,string,null,null,version,版本
http_port:HTTP端口,int,null,null,http_port,HTTP端口
hostname:主机名,string,null,null,hostname,主机名
path_data:数据文件路径,string,null,null,path_data,数据文件路径
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
publish_host:Publish地址,string,null,null,publish_host,Publish地址
java_opts_xms:初始内存,string,null,null,java_opts_xms,初始内存
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
ElasticsearchCluster:Elasticsearch集群,ElasticsearchCluster,Elasticsearch集群,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;
import org.apache.http.util.EntityUtils;
import org.apache.http.client.methods.*;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

def httpclientBuild = HttpClientBuilder.create();
def provider = new BasicCredentialsProvider();
def credentials = new UsernamePasswordCredentials($http.params.getFieldValue("username"), $http.params.getFieldValue("password"));
provider.setCredentials(AuthScope.ANY, credentials);
httpclientBuild.setDefaultCredentialsProvider(provider)
httpclient = httpclientBuild.build();
baseUrl = "http://" + $http.params.ip + ":" + $http.params.port;


def esCi = discovery_elasticsearch();
discovery_cluster(esCi)


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}


def discovery_elasticsearch(){
	$logger.logInfo("Discover elasticsearch");
	def body = doGet(httpclient, baseUrl + "/")
	def name = JSONObject.parseObject(body).getString("name")
	
	def masterNodes = []
	body = doGet(httpclient, baseUrl + "/_cat/nodes?h=name,master")
	for(def line in body.split("\r*\n")){
		def ss = line.split();
		if(ss[1] == '*'){
			masterNodes.add(ss[0])
		}
	}
	def master_flag = 'false'
	if(name in masterNodes){
		master_flag = 'true'
	}
	
	body = doGet(httpclient, baseUrl + "/_nodes")
	def jsonObj = JSONObject.parseObject(body)
	def _nodes = jsonObj.getJSONObject("_nodes");
	if(_nodes.getInteger("failed") > 0){
		throw new RuntimeException("get /_nodes error: " + _nodes.getString("failures"))
	}
	def jsonNodes = jsonObj.getJSONObject("nodes");
	nodes = [];
	def node = null
	jsonNodes.each{key,value -> 
		if( name == value.getString("name")){
			node  = value
		}
		else {
			nodes.add(value)
		}
	}
	if(node == null){
		throw new RuntimeException("not find node: " + name)
	}
	def jvmParams = node.getJSONObject('jvm').getJSONArray('input_arguments');
	def jvm_xms = jvmParams.find{e -> e.startsWith("-Xms")};
	if(jvm_xms){
		jvm_xms = convert_bytes(jvm_xms.substring(4))
	}
	else {
		jvm_xms = ''
	}
	def jvm_xmx = jvmParams.find{e -> e.startsWith("-Xmx")};
	if(jvm_xmx){
		jvm_xmx = convert_bytes(jvm_xmx.substring(4))
	}
	else {
		jvm_xmx = ''
	}
	
	def settings = node.getJSONObject('settings')
	def port = getTransportPort(node)
	def ci = $ci.create("Elasticsearch", "Elasticsearch", "Elasticsearch${port}")
	ci.putAll([
		ip : node.ip,
		port : port,
		hostname : '',
        version : node.getString('version'),
        role : node.getJSONArray('roles').join(","),
        http_port : node.getJSONObject('http').getString('publish_address').split(':')[-1],
        node_name : node.getString('name'),
        path_data : settings.getJSONObject('path').getJSONArray('data').join(","),
        bind_address : settings.getJSONObject('network').getString('host'),
        cluster_name : settings.getJSONObject('cluster').getString('name'),
        install_path : settings.getJSONObject('path').getString('home'),
        publish_host :  settings.getJSONObject('network').getString('publish_host'),
        master_flag : master_flag,
        java_opts_xms : jvm_xms,
        java_opts_xmx : jvm_xmx
	])
	def osInfo = node.getJSONObject('os').getString('name')
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, ci.hostname ? $http.params.ip + "-" + ci.hostname : $http.params.ip)
    	osCi.ip = $http.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
    return ci
}

def getTransportPort(def node){
	return node.getJSONObject('transport').getString('publish_address').split(':')[-1];
}

def discovery_cluster(esCi){
	if(nodes.size() == 0){
		return ;
	}
	$logger.logInfo("Discover cluster");
	def allCis = [esCi]
	for(def node : nodes){
		def port = getTransportPort(node)
		def ci = $ci.create("Elasticsearch", "Elasticsearch${port}")
		ci.putAll([
			ip : node.ip,
			port : port
		])
		allCis.add(ci)
	}
	def ips = allCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
	def clusterCi = $ci.create('ElasticsearchCluster', esCi.cluster_name)
    clusterCi.putAll([
    	cluster_name : esCi.cluster_name,
        cluster_perst_ip : ips
    ])
    for(def temp : allCis){
		$ci.createRelationship("Contains", clusterCi.id, temp.id);
    }
}


def doGet(httpclient, url) {
	def response = null;
	def method = null;
	try{
		method = new HttpGet(url);
		method.addHeader("Accept", "*/*");
		method.addHeader("Connection", "close");
		response = httpclient.execute(method);
		def entity = response.getEntity();
		def code = response.getStatusLine().getStatusCode();
		def body = "";
		if(entity){
			body = EntityUtils.toString(entity, "UTF-8");
		}
		//println url + "!" + code
		if(!responseIsSuccess(code)){
			throw new RuntimeException("httpErroe!url:${url},responseCode:${code},responseBody${body}")
		}
		return body;
	} finally {
		close(method)
		close(response)
	}
}

def responseIsSuccess(code){
    if (code >= 200 && code < 300){
        return true;
    }
    return false;
}

def close(obj){
	try{
		if(obj){
			obj.close();
		}
	}catch(Exception e){
		
	}
}