/*!Action
action.name=Oracle_remote_discovery
action.descr=Oracle_remote_discovery   不支持OracleADG容灾
action.version=1.0.0
action.protocols=oracle
action.main.model=Oracle
discovery.output=Database
 */

/*!Params
 ip:目标设备IP,ip,,true
 port:端口,number,1521,false
 connectType:连接方式,enum,SID,false,[serviceName,SID]
 sid:实例名/服务名,text,orcl,false
 username:用户名,text,,false
 password:密码,password,,false
*/

/*!Model
Oracle:Oracle实例,Oracle,Oracle实例,false,false
properties
audit_flag:是否开了审计,string,null,null,audit_flag,是否开了审计
oracle_alert_log:实例Alert日志文件,string,null,null,oracle_alert_log,实例Alert日志文件
grid_ORACLE_HOME:ASM实例ORACLE_HOME目录,string,null,null,grid_ORACLE_HOME,ASM实例ORACLE_HOME目录
hostname:主机名,string,null,null,hostname,主机名
oracle_version:Oracle版本,string,null,null,oracle_version,Oracle版本
crs_alert_log:集群Alert日志文件,string,null,null,crs_alert_log,集群Alert日志文件
archive_mode:归档模式,string,null,null,archive_mode,归档模式
instance_name:实例名,string,null,null,instance_name,实例名
archive_dest:归档路径,string,null,null,archive_dest,归档路径
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
grid_ORACLE_BASE:ASM实例ORACLE_BASE目录,string,null,null,grid_ORACLE_BASE,ASM实例ORACLE_BASE目录
oracle_ORACLE_HOME:实例ORACLE_HOME目录,string,null,null,oracle_ORACLE_HOME,实例ORACLE_HOME目录
grid_version:Grid版本,string,null,null,grid_version,Grid版本
asm_alert_log:ASM实例Alert日志文件,string,null,null,asm_alert_log,ASM实例Alert日志文件
name:名称,string,null,null,name,名称
oracle_ORACLE_BASE:实例ORACLE_BASE目录,string,null,null,oracle_ORACLE_BASE,实例ORACLE_BASE目录
*/

/*!Model
OracleDatabase:Oracle数据库,OracleDatabase,Oracle数据库,false,false
properties
sga_target:SGA目标值,string,null,null,sga_target,SGA目标值
asm_memory_target:ASM的Memory目标值,string,null,null,asm_memory_target,ASM的Memory目标值
oracle_processes:用户最大进程数,int,null,null,oracle_processes,用户最大进程数
asm_processes:ASM最大进程数,int,null,null,asm_processes,ASM最大进程数
db_role:数据库角色,string,null,null,db_role,数据库角色
spfile:服务器参数文件,string,null,null,spfile,服务器参数文件
protection_mode:protection_mode,string,null,null,protection_mode,protection_mode
open_mode:open_mode,string,null,null,open_mode,open_mode
oracleLogArchiveDest:Log_Archive_Dest,inline,null,null,oracleLogArchiveDest,Log_Archive_Dest
database_role:database_role,string,null,null,database_role,database_role
oracleTBS:表空间,inline,null,null,oracleTBS,表空间
oracleStandbyRedo:Standby重做日志,inline,null,null,oracleStandbyRedo,Standby重做日志
awr_snap_interval:AWR报告采样间隔,string,null,null,awr_snap_interval,AWR报告采样间隔
nls_characterset:数据库字符集,string,null,null,nls_characterset,数据库字符集
instance_cluster_name:实例/集群名称,string,null,null,instance_cluster_name,实例/集群名称
asmDiskGroup:ASM磁盘组,inline,null,null,asmDiskGroup,ASM磁盘组
oracleControlFile:控制文件,inline,null,null,oracleControlFile,控制文件
db_file_num_limit:允许数据文件数量,int,null,null,db_file_num_limit,允许数据文件数量
memory_target:Memory目标值,string,null,null,memory_target,Memory目标值
pga_aggregate_target:PGA目标值,string,null,null,pga_aggregate_target,PGA目标值
oracle_sessions:用户session最大连接数,int,null,null,oracle_sessions,用户session最大连接数
network_domain:网络域,string,null,null,network_domain,网络域
instance_cluster_ip:实例/集群IP,string,null,null,instance_cluster_ip,实例/集群IP
db_file_num_current:当前数据文件数量,int,null,null,db_file_num_current,当前数据文件数量
oracleOnlineRedo:在线重做日志,inline,null,null,oracleOnlineRedo,在线重做日志
nls_nchar_characterset:国家字符集,string,null,null,nls_nchar_characterset,国家字符集
sga_max_size:SGA最大值,string,null,null,sga_max_size,SGA最大值
db_name:数据库名,string,null,null,db_name,数据库名
name:名称,string,null,null,name,名称
undo_retention:保留过期Undo段时间,string,null,null,undo_retention,保留过期Undo段时间
db_unique_name:数据库唯一性名称,string,null,null,db_unique_name,数据库唯一性名称
oracleService:服务名,inline,null,null,oracleService,服务名
oracleSchema:Schema,inline,null,null,oracleSchema,Schema
instance_cluster_hostname:实例/集群主机名,string,null,null,instance_cluster_hostname,实例/集群主机名
*/

/*!Model
OracleLogArchiveDest:OracleLogArchiveDest,OracleLogArchiveDest,OracleLogArchiveDest,true,false
properties
name:名称,string,null,null,name,名称
value:参数值,string,null,null,value,参数值
*/

/*!Model
OracleTBS:Oracle表空间,OracleTBS,Oracle表空间,true,false
properties
tbs_file_num:表空间文件数量,int,null,null,tbs_file_num,表空间文件数量
tbs_total_size:大小,string,null,null,tbs_total_size,大小
contents:类型,string,null,null,contents,类型
name:表空间名称,string,null,null,name,表空间名称
extent_management:段管理方式,string,null,null,extent_management,段管理方式
tbs_free_size:剩余大小,string,null,null,tbs_free_size,剩余大小
status:状态,string,null,null,status,状态
tbs_used_size:已使用大小,string,null,null,tbs_used_size,已使用大小
*/

/*!Model
OracleStandbyRedo:OracleStandby日志,OracleStandbyRedo,OracleStandby日志,true,false
properties
thread_id:线程号,int,null,null,thread_id,线程号
size:大小,string,null,null,size,大小
group_id:组号,int,null,null,group_id,组号
name:StandbyLog名称,string,null,null,name,StandbyLog名称
*/

/*!Model
ASMDiskGroup:ASM磁盘组,ASMDiskGroup,ASM磁盘组,true,false
properties
voting_files_flag:仲裁标志,string,null,null,voting_files_flag,仲裁标志
diskgroup_free_size:剩余大小,string,null,null,diskgroup_free_size,剩余大小
name:磁盘组名称,string,null,null,name,磁盘组名称
redundancy:冗余模式,string,null,null,redundancy,冗余模式
diskgroup_used_size:已使用大小,string,null,null,diskgroup_used_size,已使用大小
diskgroup_size:磁盘组大小,string,null,null,diskgroup_size,磁盘组大小
compatibility:磁盘组兼容性,string,null,null,compatibility,磁盘组兼容性
status:状态,string,null,null,status,状态
*/

/*!Model
OracleControlFile:Oracle控制文件,OracleControlFile,Oracle控制文件,true,false
properties
size:大小,string,null,null,size,大小
name:控制文件名称,string,null,null,name,控制文件名称
*/

/*!Model
OracleOnlineRedo:Oracle在线重做日志,OracleOnlineRedo,Oracle在线重做日志,true,false
properties
thread_id:线程号,int,null,null,thread_id,线程号
size:大小,string,null,null,size,大小
group_id:组号,int,null,null,group_id,组号
name:OnlineLog名称,string,null,null,name,OnlineLog名称
*/

/*!Model
OracleService:Oracle服务,OracleService,Oracle服务,true,false
properties
service_role:服务角色,string,null,null,service_role,服务角色
pref_instance:优先运行实例,string,null,null,pref_instance,优先运行实例
name:Service名称,string,null,null,name,Service名称
avl_instance:后备运行实例,string,null,null,avl_instance,后备运行实例
*/

/*!Model
OracleSchema:OracleSchema,OracleSchema,OracleSchema,true,false
properties
expiry_date:过期时间,string,null,null,expiry_date,过期时间
profile:profile,string,null,null,profile,profile
db_schema_role:角色,string,null,null,db_schema_role,角色
name:Schema名称,string,null,null,name,Schema名称
account_status:用户状态,string,null,null,account_status,用户状态
db_schema_tbs:缺省表空间,string,null,null,db_schema_tbs,缺省表空间
*/

/*!Model
OraclePDB:OraclePDB数据库,OraclePDB,OraclePDB数据库,false,false
properties
db_name:PDB数据库名,string,null,null,db_name,PDB数据库名
oracleTBS:PDB表空间,inline,null,null,oracleTBS,PDB表空间
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
instance_cluster_name:实例/集群名称,string,null,null,instance_cluster_name,实例/集群名称
db_unique_name:数据库唯一性名称,string,null,null,db_unique_name,数据库唯一性名称
oracleService:PDB服务名,inline,null,null,oracleService,PDB服务名
oracleSchema:PDB Schema,inline,null,null,oracleSchema,PDB Schema
instance_cluster_ip:实例/集群IP,string,null,null,instance_cluster_ip,实例/集群IP
instance_cluster_hostname:实例/集群主机名,string,null,null,instance_cluster_hostname,实例/集群主机名
db_total_size:数据库大小,string,null,null,db_total_size,数据库大小
*/

/*!Model
OracleRAC:OracleRAC集群,OracleRAC,OracleRAC集群,false,false
properties
cluster_instance_name:集群实例名,string,null,null,cluster_instance_name,集群实例名
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

cluster = db_cluster();
nodeInfos = node_info();
def databaseCi = discovery_oracle_database();

def racCi = discovery_oracle_rac(databaseCi);
discovery_asm_diskgroup(databaseCi)
discovery_tablespace(databaseCi);
discovery_control_file(databaseCi);
discovery_online_redolog(databaseCi);
discovery_online_standbyLlg(databaseCi);
discovery_schema(databaseCi);
discovery_log_archive_dests(databaseCi);

def oracleCis = discovery_oracle(databaseCi, racCi);
discovery_pdb(databaseCi, racCi ? racCi : oracleCis[0]);

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def db_cluster(){
    def r = $oracle.queryForValue("SELECT value FROM V\$parameter where name = 'cluster_database'");
    if(r && "TRUE".equalsIgnoreCase(r)){
    	return true;
    }
    return false;
}

def db_version(){
	return $oracle.queryForValue("SELECT version FROM v\$instance");
}

def is_pdb_enable(){
	def r = $oracle.queryForValue("SELECT CDB FROM V\$DATABASE");
	if("YES".equalsIgnoreCase(r)){
		return true;
	}
	return false;
}


def db_unique_name(){
    return $oracle.queryForValue("select value from v\$parameter where name ='db_unique_name'");
}

def db_name(){
    return $oracle.queryForValue("select value from v\$parameter where name ='db_name'");
}

def db_hostname(){
    return $oracle.queryForValue("select host_name from gv\$instance");
}

def db_instance_name(){
    return $oracle.queryForValue("select instance_name from gv\$instance");
}

def db_schema(){
	def dbVersion = db_version();
	def sql = null;
    if(compareStr(dbVersion, "12") <= 0){
        sql = "SELECT a.username , a.default_tablespace , b.granted_role, ACCOUNT_STATUS,to_char(EXPIRY_DATE,'YYYY-MM-DD hh24:mi:ss') EXPIRY_DATE ,profile FROM dba_users a LEFT JOIN (( SELECT grantee, LISTAGG(granted_role, ',') WITHIN GROUP ( ORDER BY granted_role) AS granted_role FROM DBA_ROLE_PRIVS GROUP BY grantee)) b ON a.username = b.grantee WHERE a.username NOT IN ( 'SYS', 'SYSTEM', 'XS\$NULL', 'OJVMSYS', 'LBACSYS', 'OUTLN', 'SYS\$UMF', 'DBSNMP', 'APPQOSSYS', 'DBSFWUSER', 'GGSYS', 'ANONYMOUS', 'CTXSYS', 'SI_INFORMTN_SCHEMA', 'DVSYS', 'DVF', 'GSMADMIN_INTERNAL', 'ORDPLUGINS', 'MDSYS', 'OLAPSYS', 'ORDDATA', 'XDB', 'WMSYS', 'ORDSYS', 'GSMCATUSER', 'MDDATA', 'SYSBACKUP', 'REMOTE_SCHEDULER_AGENT', 'GSMUSER', 'SYSRAC', 'AUDSYS', 'DIP', 'SYSKM', 'ORACLE_OCM', 'SYSDG', 'SPATIAL_CSW_ADMIN_USR', 'XS\$NULL', 'APEX', 'APEX_PUBLIC_USER', 'FLOWS_FILES', 'SPATIAL_WFS_ADMIN_USR', 'APEX_040200','OWBSYS_AUDIT','SCOTT','EXFSYS','EXFSYS','MGMT_VIEW','MGMT_VIEW','APEX_030200','SYSMAN','OWBSYS')"
    }
    else{
        sql = "select a.username,a.default_tablespace,nvl(b.granted_role,'null'),ACCOUNT_STATUS,to_char(EXPIRY_DATE,'YYYY-MM-DD hh24:mi:ss') EXPIRY_DATE,profile from dba_users a left join ((SELECT grantee,LISTAGG(granted_role, ',') WITHIN GROUP (ORDER BY granted_role) as granted_role FROM DBA_ROLE_PRIVS group by grantee)) b on a.username = b.grantee where a.username not in ( 'SYS', 'SYSTEM', 'XS\$NULL', 'OJVMSYS', 'LBACSYS', 'OUTLN', 'SYS\$UMF', 'DBSNMP', 'APPQOSSYS', 'DBSFWUSER', 'GGSYS', 'ANONYMOUS', 'CTXSYS', 'SI_INFORMTN_SCHEMA', 'DVSYS', 'DVF', 'GSMADMIN_INTERNAL', 'ORDPLUGINS', 'MDSYS', 'OLAPSYS', 'ORDDATA', 'XDB', 'WMSYS', 'ORDSYS', 'GSMCATUSER', 'MDDATA', 'SYSBACKUP', 'REMOTE_SCHEDULER_AGENT', 'GSMUSER', 'SYSRAC', 'AUDSYS', 'DIP', 'SYSKM', 'ORACLE_OCM', 'SYSDG', 'SPATIAL_CSW_ADMIN_USR', 'XS\$NULL', 'APEX', 'APEX_PUBLIC_USER', 'FLOWS_FILES', 'SPATIAL_WFS_ADMIN_USR', 'APEX_040200','OWBSYS_AUDIT','SCOTT','EXFSYS','EXFSYS','MGMT_VIEW','MGMT_VIEW','APEX_030200','SYSMAN','OWBSYS')"
    }
    return $oracle.query(sql)
}

def db_tablespace(){
    return $oracle.query("SELECT /*+ first_rows */d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0) as total, ROUND(NVL(a.bytes - NVL(f.bytes, 0), 0) / 1024 / 1024, 2) as used, ROUND(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0), 2) as used_pct, a.autoext as autoextend, ROUND(NVL(f.bytes, 0) / 1024 / 1024, 2) as free, d.status, a.count as file_count, d.contents, d.extent_management, d.segment_space_management FROM sys.dba_tablespaces d, ( SELECT tablespace_name, SUM(bytes) bytes, COUNT(file_id) COUNT, DECODE(SUM(DECODE(autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM dba_data_files GROUP BY tablespace_name) a, ( SELECT tablespace_name, SUM(bytes) bytes FROM dba_free_space GROUP BY tablespace_name) f WHERE d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = f.tablespace_name(+) AND NOT d.contents = 'UNDO' AND NOT (d.extent_management = 'LOCAL' AND d.contents = 'TEMPORARY') AND d.tablespace_name LIKE '%%' UNION ALL SELECT d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0), ROUND(NVL(t.bytes, 0) / 1024 / 1024, 2), ROUND(NVL(t.bytes / a.bytes * 100, 0), 2), a.autoext, ROUND((NVL(a.bytes, 0) / 1024 / 1024 - NVL(t.bytes, 0) / 1024 / 1024), 2), d.status, a.count, d.contents, d.extent_management, d.segment_space_management FROM sys.dba_tablespaces d, ( SELECT tablespace_name, SUM(bytes) bytes, COUNT(file_id) COUNT, DECODE(SUM(DECODE(autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM dba_temp_files GROUP BY tablespace_name) a, ( SELECT ss.tablespace_name, SUM((ss.used_blocks * ts.block_size)) bytes FROM gv\$sort_segment ss, dba_tablespaces ts WHERE ss.tablespace_name = ts.tablespace_name GROUP BY ss.tablespace_name) t WHERE d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = t.tablespace_name(+) AND d.extent_management = 'LOCAL' AND d.contents = 'TEMPORARY' AND d.tablespace_name LIKE '%%' UNION ALL SELECT d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0), ROUND(NVL(u.bytes, 0) / 1024 / 1024, 2), ROUND(NVL(u.bytes / a.bytes * 100, 0), 2), a.autoext, ROUND(NVL(a.bytes - NVL(u.bytes, 0), 0) / 1024 / 1024, 2), d.status, a.count, d.contents, d.extent_management, d.segment_space_management FROM sys.dba_tablespaces d, ( SELECT tablespace_name, SUM(bytes) bytes, COUNT(file_id) COUNT, DECODE(SUM(DECODE(autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM dba_data_files GROUP BY tablespace_name) a, ( SELECT tablespace_name, SUM(bytes) bytes FROM ( SELECT tablespace_name, SUM(bytes) bytes, status FROM dba_undo_extents WHERE status = 'ACTIVE' GROUP BY tablespace_name, status UNION ALL SELECT tablespace_name, SUM(bytes) bytes, status FROM dba_undo_extents WHERE status = 'UNEXPIRED' GROUP BY tablespace_name, status) GROUP BY tablespace_name) u WHERE d.tablespace_name = a.tablespace_name(+) AND d.tablespace_name = u.tablespace_name(+) AND d.contents = 'UNDO' ORDER BY 4 DESC");
}

def db_adg_rac_info(cluster){
	def sql = "select '" + $oracle.params.ip + "' as ip,i.host_name,i.inst_id,i.instance_name,d.DATABASE_ROLE,d.OPEN_MODE,d.PROTECTION_MODE,(select value from v\$parameter where name ='db_unique_name')  from gv\$database d, gv\$instance i where d.inst_id=i.inst_id order by i.host_name,i.inst_id";
	if(cluster){
		//utl_inaddr.get_host_address 必须要有权限
		sql = "select (utl_inaddr.get_host_address(i.host_name)) as ip,i.host_name,i.inst_id,i.instance_name,d.DATABASE_ROLE,d.OPEN_MODE,d.PROTECTION_MODE,(select value from v\$parameter where name ='db_unique_name')  from gv\$database d, gv\$instance i where d.inst_id=i.inst_id order by i.host_name,i.inst_id";
	}
    return $oracle.query(sql)
}

def db_role(){
    def role = $oracle.queryForValue("select DATABASE_ROLE from gv\$database");
    if('STANDBY' == role){
        return 'slave'
    }
    else{
        return ''
    }
}

def db_nlsNCharacterSet(){
    return $oracle.queryForValue("SELECT value from  NLS_DATABASE_PARAMETERS WHERE parameter='NLS_CHARACTERSET'");
}

def db_nlsCharacterSet(){
	return $oracle.queryForValue("SELECT value from  NLS_DATABASE_PARAMETERS WHERE parameter='NLS_NCHAR_CHARACTERSET'");
}

def db_oracle_db_files_currert(){
	return $oracle.queryForValue("select count(0) as value from dba_data_files");
}

def db_oracle_db_files(){
	return $oracle.queryForValue("select value from v\$parameter where name='db_files'");
}

def db_oracle_undo_retention(){
	return $oracle.queryForValue("select value from v\$parameter where name='undo_retention'");
}

def db_arr_interval(){
	return $oracle.queryForValue("select to_char(SNAP_INTERVAL) from dba_hist_wr_control");
}

def db_oracle_spfile(){
	def v = $oracle.queryForValue("select value from v\$parameter where name='spfile'");
	if(!v){
		v = "";
	}
	return v;
}

def db_oracle_memory_target(){
	def v = $oracle.queryForValue("select value from v\$parameter where name='memory_target'");
	return convert_bytes(v, new convert_bytes_params(src_unit : 'B'))
}

def db_oracle_pga_aggregate_target(){
	def v = $oracle.queryForValue("select value from v\$parameter where name='pga_aggregate_target'");
	return convert_bytes(v, new convert_bytes_params(src_unit : 'B'))
}

def db_oracle_sga_max_size(){
	def v = $oracle.queryForValue("select value from v\$parameter where name='sga_max_size'");
	return convert_bytes(v, new convert_bytes_params(src_unit : 'B'))
}

def db_oracle_sga_target(){
	def v = $oracle.queryForValue("select value from v\$parameter where name='sga_target'");
	return convert_bytes(v, new convert_bytes_params(src_unit : 'B'))
}

def db_oracle_processes(){
	return $oracle.queryForValue("select value from v\$parameter where name='processes'");
}

def db_oracle_sessions(){
	return $oracle.queryForValue("select value from v\$parameter where name='sessions'");
}

def db_asm_process(){
	return '';
}

def db_asm_diskgroup(){
    return $oracle.query("SELECT name,state,total_mb, (total_mb-free_mb) as used_mb, free_mb,COMPATIBILITY ,  DATABASE_COMPATIBILITY,voting_files,type   from v\$asm_diskgroup");
}

def db_control_file(){
	return $oracle.query("select NAME ,BLOCK_SIZE,FILE_SIZE_BLKS from v\$controlfile");
}

def db_online_redolog(){
	return $oracle.query("SELECT a.GROUP#,a.THREAD#,b.MEMBER ,a.BYTES FROM v\$log a JOIN v\$logfile b ON a.Group#=b.Group# ORDER BY a.GROUP#,a.thread#");
}

def db_online_standbyLlg(){
	return $oracle.query("SELECT a.GROUP# ,a.THREAD#, b.MEMBER ,(a.BYTES) AS AllForOne FROM v\$standby_log a JOIN v\$logfile b ON a.Group#=b.Group# ORDER BY a.GROUP#,a.thread#");
}

def db_log_archive_dests(){
	def values = [];
	def index = 1;
	while(true){
		def value = $oracle.queryForValue("select value from v\$parameter where name='log_archive_dest_${index}'");
		if(value){
			values.add(value);
			index++;
		}
		else{
			break;
		}
	}
	return values;
}

def db_oracle_servive(){
	return $oracle.query("select value from v\$parameter where name ='service_names'");
}

def db_os(){
	def str = 'TNS for '
	def value = $oracle.queryForValue("SELECT PRODUCT FROM PRODUCT_COMPONENT_VERSION where PRODUCT like '${str}%'");
	if(value){
		return osCodeSearch(value)
	}
	return null;
}

def db_oracle_pdb(){
	return $oracle.query("select name,TOTAL_SIZE,BLOCK_SIZE from v\$pdbs where name !='PDB\$SEED' and name != 'CDB\$ROOT'");
}

def db_oracle_pdb_schema(){
	return $oracle.query('''
SELECT
	c.pdb_id,
	c.pdb_name,
	a.username ,
	a.default_tablespace ,
	NVL(b.granted_role, 'null') granted_role,
	ACCOUNT_STATUS,
	to_char(EXPIRY_DATE,'YYYY-MM-DD hh24:mi:ss'),
	profile
FROM
	cdb_users a
LEFT JOIN ((
	SELECT
		con_id, grantee, LISTAGG(granted_role, ',') WITHIN GROUP (
	ORDER BY
		granted_role) AS granted_role
	FROM
		cdb_role_privs
	GROUP BY
		con_id, grantee)) b ON
	a.username = b.grantee
	AND a.con_id = b.con_id
LEFT JOIN cdb_pdbs c ON
	a.con_id = c.pdb_id
WHERE
	a.username NOT IN ( 'SYS', 'SYSTEM', 'XS$NULL', 'OJVMSYS', 'LBACSYS', 'OUTLN', 'SYS$UMF', 'DBSNMP', 'APPQOSSYS', 'DBSFWUSER', 'GGSYS', 'ANONYMOUS', 'CTXSYS', 'SI_INFORMTN_SCHEMA', 'DVSYS', 'DVF', 'GSMADMIN_INTERNAL', 'ORDPLUGINS', 'MDSYS', 'OLAPSYS', 'ORDDATA', 'XDB', 'WMSYS', 'ORDSYS', 'GSMCATUSER', 'MDDATA', 'SYSBACKUP', 'REMOTE_SCHEDULER_AGENT', 'GSMUSER', 'SYSRAC', 'AUDSYS', 'DIP', 'SYSKM', 'ORACLE_OCM', 'SYSDG', 'SPATIAL_CSW_ADMIN_USR', 'XS$NULL', 'APEX', 'APEX_PUBLIC_USER', 'FLOWS_FILES', 'SPATIAL_WFS_ADMIN_USR', 'APEX_040200', 'OWBSYS_AUDIT', 'SCOTT', 'EXFSYS', 'EXFSYS', 'MGMT_VIEW', 'MGMT_VIEW', 'APEX_030200', 'SYSMAN', 'OWBSYS')
	AND a.username NOT LIKE 'C##%'
''');
}

def db_oracle_pdb_tablespace(){
	return $oracle.query('''SELECT /*+ first_rows */v3.name, d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0) "Size MB", ROUND(NVL(a.bytes - NVL(f.bytes, 0), 0) / 1024 / 1024, 2) "Used MB", ROUND(NVL((a.bytes - NVL(f.bytes, 0)) / a.bytes * 100, 0), 2) "Used %", a.autoext "Autoextend", ROUND(NVL(f.bytes, 0) / 1024 / 1024, 2) "Free MB", d.status "STAT", a.count "Files", d.contents "Type", d.extent_management "Ext MGMT", d.segment_space_management "Seg MGMT" FROM sys.cdb_tablespaces d, v\$containers v3, ( SELECT v2.name, a1.tablespace_name, SUM(a1.bytes) bytes, COUNT(a1.file_id) COUNT, DECODE(SUM(DECODE(a1.autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM cdb_data_files a1, v\$containers v2 WHERE v2.con_id = a1.con_id GROUP BY v2.name, a1.tablespace_name ) a, ( SELECT v1.name, f1.tablespace_name, SUM(f1.bytes) bytes FROM cdb_free_space f1, v\$containers v1 WHERE f1.con_id = v1.con_id GROUP BY v1.name, f1.tablespace_name ) f WHERE d.tablespace_name = a.tablespace_name (+) AND d.con_id = v3.con_id AND v3.name = a.name (+) AND d.tablespace_name = f.tablespace_name (+) AND a.name = f.name AND NOT d.contents = 'UNDO' AND NOT ( d.extent_management = 'LOCAL' AND d.contents = 'TEMPORARY' ) AND d.tablespace_name LIKE '%%'  UNION ALL SELECT vd.name, d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0), ROUND(NVL(t.bytes, 0) / 1024 / 1024, 2), ROUND(NVL(t.bytes / a.bytes * 100, 0), 2), a.autoext, ROUND((NVL(a.bytes, 0) / 1024 / 1024 - NVL(t.bytes, 0) / 1024 / 1024), 2), d.status, a.count, d.contents, d.extent_management, d.segment_space_management FROM sys.cdb_tablespaces d, v\$containers vd, ( SELECT ve.name, te.tablespace_name, SUM(te.bytes) bytes, COUNT(te.file_id) COUNT, DECODE(SUM(DECODE(te.autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM cdb_temp_files te, v\$containers ve WHERE te.con_id = ve.con_id GROUP BY ve.name, te.tablespace_name ) a, ( SELECT vs.name, ss.tablespace_name, SUM((ss.used_blocks * ts.block_size)) bytes FROM gv\$sort_segment ss, cdb_tablespaces ts, v\$containers vs WHERE ts.con_id = vs.con_id AND ss.tablespace_name = ts.tablespace_name AND vs.con_id = ts.con_id GROUP BY vs.name, ss.tablespace_name ) t WHERE d.tablespace_name = a.tablespace_name (+) AND d.con_id = vd.con_id AND vd.name = a.name(+) AND vd.name = t.name(+) AND a.name = t.name AND d.tablespace_name = t.tablespace_name (+) AND d.extent_management = 'LOCAL' AND d.contents = 'TEMPORARY' AND d.tablespace_name LIKE '%%' UNION ALL SELECT v2.name, d.tablespace_name, NVL(a.bytes / 1024 / 1024, 0), ROUND(NVL(u.bytes, 0) / 1024 / 1024, 2), ROUND(NVL(u.bytes / a.bytes * 100, 0), 2), a.autoext, ROUND(NVL(a.bytes - NVL(u.bytes, 0), 0) / 1024 / 1024, 2), d.status, a.count, d.contents, d.extent_management, d.segment_space_management FROM sys.cdb_tablespaces d, v\$containers v2, ( SELECT vc1.name, f2.tablespace_name, SUM(f2.bytes) bytes, COUNT(f2.file_id) COUNT, DECODE(SUM(DECODE(f2.autoextensible, 'NO', 0, 1)), 0, 'NO', 'YES') autoext FROM cdb_data_files f2, v\$containers vc1 WHERE f2.con_id = vc1.con_id GROUP BY vc1.name, f2.tablespace_name ) a, ( SELECT name, tablespace_name, SUM(bytes) bytes FROM ( SELECT cv.name, ex.tablespace_name, SUM(ex.bytes) bytes, ex.status FROM cdb_undo_extents ex, v\$containers CV WHERE ex.con_id = cv.con_id AND ex.status = 'ACTIVE' GROUP BY cv.name, ex.tablespace_name, ex.status UNION ALL SELECT cv2.name, ex.tablespace_name, SUM(ex.bytes) bytes, ex.status FROM cdb_undo_extents ex, v\$containers cv2 WHERE ex.con_id = cv2.con_id AND ex.status = 'UNEXPIRED' GROUP BY cv2.name, ex.tablespace_name, ex.status ) GROUP BY name, tablespace_name ) u WHERE d.con_id = v2.con_id AND d.tablespace_name = a.tablespace_name (+) AND v2.name = a.name(+) AND v2.name = u.name(+) AND a.name = u.name AND d.tablespace_name = u.tablespace_name (+) AND d.contents = 'UNDO' ORDER BY 1, 5 DESC''')
}

def node_info(){
	def infos = [];
	for(def row in db_adg_rac_info(cluster)){
		def item = row.getValues();
		
		def info = [:];
		info.ip = item[0]
		info.name = item[3];
		info.hostname = item[1];
		info.database_role = item[4];
		info.open_mode = item[5];
		info.protection_mode = item[6];
		infos.add(info);
	}
	return infos;
}

def discovery_oracle_database(){
	$logger.logInfo("Discover database");
	def ci = null;
	
	def rac_ips = []
    def rac_names = []
    def rac_hostnames = []
	for(def nodeInfo in nodeInfos){
		rac_ips.add(nodeInfo.ip)
		rac_names.add(nodeInfo.name)
        rac_hostnames.add(nodeInfo.hostname)
	}
		
	ci = $ci.create("OracleDatabase", "OracleDatabase", db_unique_name());
	ci.putAll([		    
	    instance_cluster_ip: rac_ips.unique().sort({a, b -> return compareStr(a, b);}).join("_"),
	    instance_cluster_name : rac_names.unique().sort().join("/"),
	    instance_cluster_hostname : rac_hostnames.unique().sort().join("_")
	])
	ci.putAll([
		    nls_nchar_characterset : db_nlsCharacterSet(),
		    nls_characterset : db_nlsNCharacterSet(),
		    db_file_num_current : db_oracle_db_files_currert(),
		    db_file_num_limit : db_oracle_db_files(),
		    undo_retention : db_oracle_undo_retention(),
		    awr_snap_interval : db_arr_interval(),
		    spfile : db_oracle_spfile(),
		    memory_target : db_oracle_memory_target(),
		    pga_aggregate_target : db_oracle_pga_aggregate_target(),
		    sga_max_size : db_oracle_sga_max_size(),
		    sga_target : db_oracle_sga_target(),
		    oracle_processes : db_oracle_processes(),
		    oracle_sessions : db_oracle_sessions(),
		    asm_processes : db_asm_process(),
		    db_unique_name : ci.name,
		    db_role : db_role(),
		    db_name : db_name(),
		    database_role : nodeInfos[0].database_role,
		    open_mode : nodeInfos[0].open_mode,
            protection_mode : nodeInfos[0].protection_mode
		])
	return ci;
}


def discovery_oracle_rac(databaseCi){
	if(cluster){
		$logger.logInfo("Discover rac");
		def rac = $ci.create("OracleRAC", databaseCi.instance_cluster_name);
		rac.putAll([
                        cluster_perst_ip : databaseCi.instance_cluster_ip,
                        cluster_instance_name : databaseCi.instance_cluster_name
                  ])
       	$ci.createRelationship('RunsOn', databaseCi.id, rac.id)
       	return rac;
   	}
}

def discovery_schema(databaseCi){
	$logger.logInfo("Discover schema");
	for(def row in db_schema()){
		def item = row.getValues();
		def username = item[0];
		def default_tablespace = item[1];
		def granted_role = item[2];
		def account_status = item[3];
		def expiry_date = item[4];
		def profile = item[5];
		if(!granted_role){
			granted_role = '';
		}
		if(!expiry_date){
			expiry_date = '';
		}
		
		ci = $ci.create('OracleSchema', username)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			db_schema_tbs : default_tablespace,
                    db_schema_role : granted_role,
                    account_status : account_status,
                    expiry_date : expiry_date,
                    profile : profile
                  ])	
	}
}

def discovery_asm_diskgroup(databaseCi){
	$logger.logInfo("Discover asm diskgroup");
	for(def row in db_asm_diskgroup()){
		def item = row.getValues();
		ci = $ci.create('ASMDiskGroup', item[0])
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
					status : item[1], 
					voting_files_flag : item[7],
		            diskgroup_size : convert_bytes(item[2], new convert_bytes_params(src_unit : 'MB')),
		            compatibility : item[5],
		            diskgroup_used_size : convert_bytes(item[3], new convert_bytes_params(src_unit : 'MB')),
		            diskgroup_free_size : convert_bytes(item[4], new convert_bytes_params(src_unit : 'MB')),
		            redundancy : item[8].toLowerCase()
                  ])	
	}
}

def discovery_tablespace(databaseCi){
	$logger.logInfo("Discover tablespace");
	for(def row in db_tablespace()){
		def item = row.getValues();
		def tablespace_name = item[0];
		def total = item[1];
		def used = item[2];
		def free = item[5];
		def status = item[6];
		def file_count = item[7];
		def contents = item[8];
		def extent_management = item[9];

		
		ci = $ci.create('OracleTBS', tablespace_name)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			tbs_total_size : total ? convert_bytes(total, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_free_size : free ? convert_bytes(free, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_used_size : used ? convert_bytes(used, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_file_num : file_count,
            		contents : contents, 
            		extent_management: extent_management,
            		status : status
                  ])	
	}
}

def discovery_control_file(databaseCi){
	$logger.logInfo("Discover control file");
	for(def row in db_control_file()){
		def item = row.getValues();
		def name = item[0];
		def block_size = item[1].longValue();
		def file_size_blks = item[2].longValue();
		
		ci = $ci.create('OracleControlFile', name)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			size : convert_bytes(block_size * file_size_blks, new convert_bytes_params(src_unit : 'B'))
                  ])	
	}
}


def discovery_online_redolog(databaseCi){
	$logger.logInfo("Discover online redolog");
	for(def row in db_online_redolog()){
		def item = row.getValues();
		def group = item[0];
		def thread = item[1];
		def member = item[2];
		def size = item[3];
		
		ci = $ci.create('OracleOnlineRedo', member)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			group_id : group,
        			thread_id : thread,
        			member : member,
        			size : convert_bytes(size, new convert_bytes_params(src_unit : 'B'))
                  ])	
	}
}

def discovery_online_standbyLlg(databaseCi){
	$logger.logInfo("Discover standbyLlg");
	for(def row in db_online_standbyLlg()){
		def item = row.getValues();
		def group = item[0];
		def thread = item[1];
		def member = item[2];
		def size = item[3];
		
		ci = $ci.create('OracleStandbyRedo', member)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			group_id : group,
        			thread_id : thread,
        			member : member,
        			size : convert_bytes(size, new convert_bytes_params(src_unit : 'B'))
                  ])
    }
}


def discovery_log_archive_dests(databaseCi){
	$logger.logInfo("Discover log archive dests");
	def values = db_log_archive_dests();
	values.eachWithIndex { value, i ->
		ci = $ci.create('OracleLogArchiveDest', "log_archive_dest_${i + 1}")
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.value = value
    }
}

def discovery_oracle_servive(databaseCi){
	$logger.logInfo("Discover oracle servive");
	for(def row in db_oracle_servive()){
		def item = row.getValues();
		def name = item[0];
		
		ci = $ci.create('OracleService', name)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			service_role : '',
        			preferredInstance : name,
        			availableInstance : name
                  ])
    }
}

def discovery_pdb(databaseCi, relationshipCi){
	def dbVersion = db_version();
	if(compareStr(dbVersion, "12") < 0){
		return 
	}
	if(!is_pdb_enable()){
		return 
	}
	$logger.logInfo("Discover oracle pdb");
	def cis = [:]
	for(def row in db_oracle_pdb()){
		def item = row.getValues();
		def name = item[0].toUpperCase();
		
		ci = $ci.create('OraclePDB', name)
        $ci.createRelationship("RunsOn", ci.id, relationshipCi.id);
        ci.putAll([
        	db_name : name,
            db_unique_name : databaseCi.db_unique_name,
            instance_cluster_ip : databaseCi.instance_cluster_ip,
            instance_cluster_name : databaseCi.instance_cluster_name,
            instance_cluster_hostname : databaseCi.instance_cluster_hostname,
            db_total_size : convert_bytes(item[1])
        ])
        cis[name] = ci
    }
    for(def row in db_oracle_pdb_schema()){
		def item = row.getValues();
		def name = item[1].toUpperCase();
		def pdbCi = cis[name]
		if(!pdbCi){
			continue
		}
		ci = $ci.create('OracleSchema', item[2])
        $ci.createRelationship("Inlines", pdbCi.id, ci.id);
        ci.putAll([
        	db_schema_tbs : item[3],
            db_schema_role : item[4] ? item[4] : '',
            account_status : item[5],
            expiry_date : item[6] ? item[6] : '',
            profile : item[7]
	    ])
    }
    for(def row in db_oracle_pdb_tablespace()){
    	def item = row.getValues();
    	def name = item[0].toUpperCase();
    	def pdbCi = cis[name]
    	def tablespace_name = item[1];
		if(!pdbCi){
			continue
		}
		def total = item[2];
		def used = item[3];
		def free = item[6];
		def status = item[7];
		def file_count = item[8];
		def contents = item[9];
		def ext_MGMT = item[10];
		
		ci = $ci.create('OracleTBS', tablespace_name)
        $ci.createRelationship("Inlines", pdbCi.id, ci.id);
        ci.putAll([
        			tbs_total_size : total ? convert_bytes(total, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_free_size : free ? convert_bytes(free, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_used_size : used ? convert_bytes(used, new convert_bytes_params(src_unit : 'MB')) : 0,
            		tbs_file_num : file_count,
            		contents : contents, 
            		status : status,
            		extent_management : ext_MGMT
                  ])	
    }
}

def discovery_oracle(databaseCi, racCi){
	$logger.logInfo("Discover oracle");
	def dbVersion = db_version();
	def osType = db_os();
	def oracleCis = []
	for(def nodeInfo in nodeInfos){
		def oracleCi = $ci.create('Oracle', nodeInfo.name)
		if(racCi){
			$ci.createRelationship("Contains", racCi.id, oracleCi.id);
		}
		else {
       		$ci.createRelationship("RunsOn", databaseCi.id, oracleCi.id);
       	}
       	oracleCis.add(oracleCi)
        oracleCi.putAll([
			ip : nodeInfo.ip,
			instance_name : nodeInfo.name,
            hostname : nodeInfo.hostname,
            oracle_version : dbVersion
          ])
       if(osType){
       	  def ocCi = $ci.create(osType, nodeInfo.ip + "-" + nodeInfo.hostname)
       	  ocCi.ip = nodeInfo.ip;
       	  $ci.createRelationship("RunsOn", oracleCi.id, ocCi.id);
       }
	}
	return oracleCis
}