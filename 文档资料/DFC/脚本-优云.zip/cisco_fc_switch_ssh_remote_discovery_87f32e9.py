# coding: UTF-8
# UYUN script
# @Author: zhengyd@uyunsoft.cn
# @Date  : 2020/10/25
import copy
import json
import sys
import re
import paramiko

try:
    # 测试使用
    from _utils.Ci import Ci
    __ci__ = Ci()
    __ip__ = ['10.1.1.13']
    __args__ = [{'ip': '10.1.1.13', 'port': 22, 'username': 'admin', 'password': ''}]
except ImportError:
    pass


"""!Action
action.name=思科FC存储交换机(ssh)_87f32e9
action.descr=思科FC存储交换机(ssh)远程发现
action.version=1.0.0
action.main.model=FCSwitch
discovery.output=storage
"""

"""!Params
ip:IP地址,text,,true
port:端口,number,22,false
username:用户名,text,,false
password:密码,password,,false
"""

"""!Model
FCSwitch:FC存储交换机,FCSwitch,FC存储交换机,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
model:型号,string,null,null,model,型号
cfgname:cfg配置名称,string,null,null,cfgname,cfg配置名称
version:固件版本,string,null,null,version,固件版本
hostname:主机名,string,null,null,hostname,主机名
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
port_num:端口数,int,null,个,port_num,端口数
domain_id:Domain ID,int,null,null,domain_id,Domain ID
switch_role:交换机角色,string,null,null,switch_role,交换机角色
fcSwitchPort:端口信息,inline,null,null,fcSwitchPort,端口信息
serial_number:序列号,string,null,null,serial_number,序列号
fabricFCSwitch:级联FC存储交换机,inline,null,null,fabricFCSwitch,级联FC存储交换机
fcswitch_brand:品牌,string,null,null,fcswitch_brand,品牌
"""

"""!Model
fcSwitchPort:端口信息,FCSwitchPort,端口信息,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
status:状态,string,null,null,status,状态
port_type:端口类型,string,null,null,port_type,端口类型
zone_name:所属Zone名称,string,null,null,zone_name,所属Zone名称
port_index:端口索引号,int,null,null,port_index,端口索引号
port_speed:端口速率,string,null,null,port_speed,端口速率
"""

"""!Model
fabricFCSwitch:级联FC存储交换机,FabricFCSwitch,级联FC存储交换机,true,false
properties:
name:名称,string,null,null,name,名称
wwn:WWN号,string,null,null,wwn,WWN号
"""

"""!Model
FCSwitchZone:FC存储交换机Zone,FCSwitchZone,FC存储交换机Zone,false,false
properties:
name:名称,string,null,null,name,名称
wwn:WWN号,string,null,null,wwn,WWN号
vsan_id:VSAN编号,int,null,null,vsan_id,VSAN编号
zonePort:Zone端口,inline,null,null,zonePort,Zone端口
fcswitch_name:存储交换机名称,string,null,null,fcswitch_name,存储交换机名称
fcswitch_serial:交换机序列号,string,null,null,fcswitch_serial,交换机序列号
"""

"""!Model
zonePort:Zone端口,ZonePort,Zone端口,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
port_index:端口索引号,int,null,null,port_index,端口索引号
"""


def re_search(flag, msg, group=0, convert_to=None, sep=None, num=-1):
    tmp = re.search(flag, msg)
    if tmp:
        tmp = tmp.group(group).strip()
        try:
            if sep is not None:
                tmp = re.split(sep, tmp)[num].strip()
            if convert_to is not None:
                return convert_to(tmp)
            else:
                return tmp
        except:
            return None


class DiscoveryFCSwitch(object):

    def __init__(self, ip, username, password, port=22, timeout=5):
        self.client = None
        self.ip = ip
        self.username = username
        self.password = password
        self.port = int(port)
        self.timeout = timeout
        self.client = None
        self.channel = None
        self.use_bash = False

        self.switch_ci = None
        self.port_cis = {}
        self.wwn = None
        self.sn = None

    def login(self):
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(self.ip, self.port, username=self.username, password=self.password, timeout=self.timeout)
            self.client = client
            __ci__.result_log('INFO', '{}@{}:{} login succeed'.format(self.username, self.ip, self.port))
            return True
        except Exception as e:
            __ci__.result_log('ERROR', '{}@{}:{} login failed: {}'.format(self.username, self.ip, self.port, e))
            return False

    def run_cmd(self, cmd):
        if not self.client:
            self.login()
        self.channel = self.client.get_transport().open_session()
        self.channel.get_pty()
        self.channel.exec_command(cmd)
        stdout = self.channel.makefile('r', -1).read()
        stderr = self.channel.makefile_stderr('r', -1).read()
        code = self.channel.recv_exit_status()
        if code or stderr:
            __ci__.result_log('WARN', 'run cmd: {}, return code {}, {}'.format(repr(cmd), code, stderr))
        # print self.normalize_lf(stdout).strip()
        return code, self.normalize_lf(stdout).strip()

    def logout(self):
        try:
            if self.channel:
                # self.run_cmd('exit')
                self.channel.close()
                self.client.close()
                __ci__.result_log('INFO', 'logout')
        except Exception as e:
            __ci__.result_log('WARN', 'logout failed, {}'.format(e))

    @staticmethod
    def create_port_ci(ci_code, parent_ci, name, **kwargs):
        """
        用于创建 fcSwitchPort 或 zonePort  Ci
        """
        port_ci = __ci__.create(ci_code, name)
        port_ci['properties'] = kwargs
        __ci__.createrelationship(parent_ci['cid'], port_ci['cid'], 'Inlines')
        return port_ci

    @staticmethod
    def normalize_lf(a_string, to='\n'):
        """标准化换行符, 所有换行符转为 \n"""
        return re.sub('\r+\n|\n\r|\r', to, a_string)

    @staticmethod
    def normalize_wwn(wwn):
        """标准化 wwn,  去除冒号转大写，100000051EA39600"""
        if wwn:
            return wwn.replace(':', '').upper()

    def discovery_ports(self):
        """
        获取所有fc端口信息
        """
        code, flogi = self.run_cmd('show flogi database |grep ^fc')
        code, interface = self.run_cmd('show interface brief |grep ^fc')

        # INTERFACE        VSAN    FCID           PORT NAME               NODE NAME
        flogi_head = ['name', 'vsan', 'fc_id', 'wwpn', 'wwnn']
        flogi_dict = [dict(zip(flogi_head, line.split())) for line in flogi.splitlines()]
        flogi_dict = {i['name']: i for i in flogi_dict}

        head = ['name', 'vsan', 'admin_mode', 'trunk_Mode', 'status', 'sfp', 'port_type', 'speed', '_']
        interface_list = [dict(zip(head, line.split())) for line in interface.splitlines()]
        __ci__.result_log('INFO', '发现 {} 个端口'.format(len(interface_list)))
        for fc in interface_list:
            name = fc['name']
            port_flogi = flogi_dict.get(fc['name'], {})
            speed = '{} Gbps'.format(fc['speed']) if fc.get('speed', '--') != '--' else None

            wwn = self.normalize_wwn(port_flogi.get('wwpn'))
            port_ci = self.create_port_ci('fcSwitchPort',
                                          self.switch_ci,
                                          name,
                                          wwn=wwn,
                                          port_type=fc.get('port_type') if fc.get('port_type', '--') != '--' else None,
                                          port_speed=speed,
                                          status=fc.get('status')
                                          )
            self.port_cis[name] = port_ci
            if port_flogi:
                self.port_cis[port_flogi['fc_id']] = port_ci

        self.switch_ci['properties']['port_num'] = len(interface_list)

    def discovery_zone(self):
        """
        执行 show zoneset active 命令，发现zone信息
        """
        zone_num = 0
        out = self.run_cmd("show zoneset active")[1]

        #   * fcid 0x0a0000 [interface fc1/3 swwn 20:00:00:2a:6a:21:1a:58]
        reg1 = re.compile(r'fcid (\w+) \[interface ([\w/]+) swwn [\w:]+')

        #   * fcid 0x0a0200 [pwwn 50:05:07:68:02:30:75:07]
        reg2 = re.compile(r'fcid (\w+) \[pwwn ([\w:]+)')

        data = {}
        zoneset = zone_name = vsan = None
        for line in out.splitlines():
            line = line.strip()
            if line.startswith('zoneset name'):
                zoneset = line.split()[2]
                if zoneset not in data:
                    data[zoneset] = {}
            elif line.startswith('zone name'):
                _, _, zone_name, _, vsan = line.split()
                if zone_name not in data[zoneset]:
                    data[zoneset][zone_name] = {'vsan': vsan, 'ports': []}
            else:
                tmp = reg2.findall(line)
                if tmp:
                    data[zoneset][zone_name]['ports'].append(
                        dict(zip(('fc_id', 'wwn'), tmp[0])))
        print json.dumps(data)
        # zoneset name => cfg配置名称
        self.switch_ci['properties']['cfgname'] = ','.join(data.keys())

        for zones in data.values():
            for zone_name, zone_info in zones.items():
                vsan = zone_info['vsan']
                zone_ports = zone_info['ports']
                zone_num += 1
                zone_ci = __ci__.create('FCSwitchZone', zone_name)
                zone_ci['properties'] = {
                    'fcswitch_serial': self.sn,
                    'fcswitch_name': self.switch_ci['name'],
                    'wwn': self.wwn,
                    'vsan_id': vsan
                    }
                # zone 运行在交换机上
                __ci__.createrelationship(zone_ci['cid'], self.switch_ci['cid'], 'RunsOn')

                for zp in zone_ports:
                    port_ci = self.port_cis.get(zp['fc_id'])
                    if port_ci:
                        # port_ci 添加当前 zone_name
                        if not port_ci['properties'].get('zone_name'):
                            port_ci['properties']['zone_name'] = zone_name
                        elif zone_name not in port_ci['properties']['zone_name'].split(','):
                            port_ci['properties']['zone_name'] += ',' + zone_name
                        # 创建Zone 内联的 ZonePort
                        self.create_port_ci('ZonePort',
                                            zone_ci,
                                            port_ci['name'],
                                            wwn=port_ci['properties'].get('wwn'),
                                            )
        __ci__.result_log('INFO', '发现 {} 个zone'.format(zone_num))

    def discovery_cascade_switch(self):
        """发现级联交换机, 非 Local的就是级联交换机，取不到name，用 wwn 代替 """
        code, out = self.run_cmd('show fcdomain domain-list |grep 0x | grep -v Local')
        if code:
            __ci__.result_log('WARN', '获取级联信息失败，{}'.format(out))

        wwns = [line.split()[1] for line in out.splitlines()]
        # print wwns
        for wwn in wwns:
            fc_ci = __ci__.create('FabricFCSwitch', wwn)
            fc_ci['properties'] = {'wwn': wwn}
            __ci__.createrelationship(self.switch_ci['cid'], fc_ci['cid'], 'Inlines')
            __ci__.result_log('INFO', '发现及联交换机  www: {}'.format(wwn))

    def discovery_switch(self):
        """主入口"""
        if not self.login():
            return False
        # code, show_ver = self.run_cmd("show version")
        code, show_hard = self.run_cmd("show hardware")

        if code:
            __ci__.result_log('ERROR', '发现失败 {}'.format(show_hard))
            return False

        code, name = self.run_cmd('show switchname')
        self.wwn = self.normalize_wwn(re_search(r'([0-9a-f]{2}:?){7}[0-9a-f]{2}:?',
                                                self.run_cmd('show wwn switch')[1]))

        self.sn = re_search(r'=(\w+)', self.run_cmd('show license host-id')[1], group=1)

        ntp = self.run_cmd('show ntp peers')[1]
        ntp_server = ','.join([line.split()[0] for line in ntp.splitlines()[3:]])

        snmp = self.run_cmd('show snmp host')[1]
        snmp_server = ','.join([line.split()[0] for line in snmp.splitlines()[3:]])

        if not self.sn and not self.wwn:
            __ci__.result_log('ERROR', '获取序列号和WWN失败，请确认发现对象是否为思科光纤交换机')
            return False
        __ci__.result_log('INFO', '发现思科光纤交换机： {}'.format(name))

        self.switch_ci = __ci__.create('FCSwitch', name)
        self.switch_ci['properties'] = {
            'ip': self.ip,
            'hostname': name,
            'wwn': self.wwn,
            'version': re_search('system: *version (.*)', show_hard, group=1),
            'domain_id': None,
            'serial_number': self.sn,
            'model': re_search(r'Switch type is(.*)', show_hard, group=1),
            'fcswitch_brand': 'cisco',
            'ntp_server': ntp_server,
            'snmp_server': snmp_server
        }

        self.discovery_cascade_switch()
        self.discovery_ports()
        self.discovery_zone()
        self.logout()


def merge_args(ip='ip'):
    """合并 __ip__ 和 __args__"""
    all_args = {}
    for i in globals().get('__ip__', []):
        all_args[i] = __args__
    for i in globals().get('__ip_ranges__', []):
        all_args[i] = __args__
    for _arg in __args__:
        if _arg.get(ip):
            all_args[_arg[ip]] = [_arg]
    # print all_args
    __ci__.result_log('INFO', "Merged {} args".format(len(all_args)))
    return all_args


if __name__ == '__main__':
    for ip, args in merge_args().items():
        __ci__.ip = ip
        for _args in args:
            arg = copy.deepcopy(_args)
            arg['ip'] = ip
        fc_switch = DiscoveryFCSwitch(arg['ip'],
                                      arg['username'],
                                      arg['password'],
                                      arg.get('port')
                                      )
        fc_switch.discovery_switch()

    __ci__.result_data()
