/*!Action
action.name=Windows_remote_discovery_87f32e9
action.descr=Windows_remote_discovery
action.version=1.0.0
action.protocols=wmi
action.main.model=Windows
discovery.output=Computer

*/
/*!Params
ip:目标设备IP,ip,,true
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties
default_gateway:默认网关,string,null,null,default_gateway,默认网关
winFileSystem:文件系统,inline,null,null,winFileSystem,文件系统
mw_soft_ver:中间件软件/版本,string,null,null,mw_soft_ver,中间件软件/版本
winTaskScheduler:任务计划,inline,null,null,winTaskScheduler,任务计划
osLunInfo:OS的LUN,inline,null,null,osLunInfo,OS的LUN
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
enforced_pass_history:强制密码历史,int,null,个,enforced_pass_history,强制密码历史
cpu_arch:CPU架构,string,null,null,cpu_arch,CPU架构
hostname:主机名,string,null,null,hostname,主机名
pass_max_day:密码最长有效期,int,null,天,pass_max_day,密码最长有效期
pass_must_meet_complex:密码必须符合复杂性要求,string,null,null,pass_must_meet_complex,密码必须符合复杂性要求
password_minlen:密码最小长度,int,null,null,password_minlen,密码最小长度
osNIC:网卡,inline,null,null,osNIC,网卡
pass_min_day:密码最短有效期,int,null,天,pass_min_day,密码最短有效期
tool_soft_ver:工具软件/版本,string,null,null,tool_soft_ver,工具软件/版本
db_soft_ver:数据库软件/版本,string,null,null,db_soft_ver,数据库软件/版本
windowsPatch:Windows补丁,inline,null,null,windowsPatch,Windows补丁
vir_mem_size:虚拟内存大小,string,null,null,vir_mem_size,虚拟内存大小
ip:IP地址,string,null,null,ip,IP地址
dns_server:DNS服务器,string,null,null,dns_server,DNS服务器
bits:位数,string,null,null,bits,位数
cpuArch:ant必须字段,string,null,null,cpuArch,ant必须字段
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
time_zone:时区,string,null,null,time_zone,时区
version:版本,string,null,null,version,版本
ips:IP列表,array,null,null,ips,IP列表
winUser:用户,inline,null,null,winUser,用户
memory_size:内存大小,string,null,null,memory_size,内存大小
osHBA:HBA卡,inline,null,null,osHBA,HBA卡
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
*/

/*!Model
WinFileSystem:Windows文件系统,WinFileSystem,Windows文件系统,true,false
properties
fs_type:文件系统类型,string,null,null,fs_type,文件系统类型
name:文件系统名称,string,null,null,name,文件系统名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
*/

/*!Model
WinTaskScheduler:Windows任务计划,WinTaskScheduler,Windows任务计划,true,false
properties
name:任务计划名称,string,null,null,name,任务计划名称
trigger:触发器,string,null,null,trigger,触发器
script:脚本,string,null,null,script,脚本
status:状态,string,null,null,status,状态
*/

/*!Model
OsLunInfo:OS的LUN,OsLunInfo,OS的LUN,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
*/

/*!Model
OsNIC:OS的网卡,OsNIC,OS的网卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后网卡,string,null,null,bonding_flag,bonding后网卡
name:网卡名称,string,null,null,name,网卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
status:状态,string,null,null,status,状态
*/

/*!Model
WindowsPatch:Windows补丁,WindowsPatch,Windows补丁,true,false
properties
name:补丁名称,string,null,null,name,补丁名称
*/

/*!Model
WinUser:Windows用户,WinUser,Windows用户,true,false
properties
name:用户名,string,null,null,name,用户名
groups:附属用户组,string,null,null,groups,附属用户组
active_directory_name:所在域控,string,null,null,active_directory_name,所在域控
*/

/*!Model
OsHBA:OS的HBA卡,OsHBA,OS的HBA卡,true,false
properties
name:HBA卡名称,string,null,null,name,HBA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
status:状态,string,null,null,status,状态
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
PCServer:PC服务器,PCServer,PC服务器,false,false
properties
serverMemoryModule:服务器内存,inline,null,null,serverMemoryModule,服务器内存
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
model:型号,string,null,null,model,型号
bmc_version:BMC固件版本,string,null,null,bmc_version,BMC固件版本
firmware:BIOS固件版本,string,null,null,firmware,BIOS固件版本
serverHBA:服务器HBA卡,inline,null,null,serverHBA,服务器HBA卡
os_ipv6:操作系统IPV6地址,string,null,null,os_ipv6,操作系统IPV6地址
power_supply_mode:电源节能模式,string,null,null,power_supply_mode,电源节能模式
ip:带外管理IP,string,null,null,ip,带外管理IP
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
serverRaidCard:服务器RAID卡,inline,null,null,serverRaidCard,服务器RAID卡
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
hyper_threading_open_flag:超线程打开模式,string,null,null,hyper_threading_open_flag,超线程打开模式
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
memory_size:内存大小,string,null,null,memory_size,内存大小
pcserver_brand:品牌,string,null,null,pcserver_brand,品牌
os_ip:操作系统IP,string,null,null,os_ip,操作系统IP
name:PC服务器名称,string,null,null,name,PC服务器名称
serverHCA:服务器HCA卡,inline,null,null,serverHCA,服务器HCA卡
serverNIC:服务器网卡,inline,null,null,serverNIC,服务器网卡
*/

/*!Model
ServerMemoryModule:服务器内存,ServerMemoryModule,服务器内存,true,false
properties
memory_module_size:内存条大小,string,null,null,memory_module_size,内存条大小
memory_clock_speed:内存条主频,string,null,null,memory_clock_speed,内存条主频
name:内存条型号,string,null,null,name,内存条型号
alias_type:类型,string,null,null,type,类型
memory_module_num:内存条数量,int,null,null,memory_module_num,内存条数量
*/

/*!Model
ServerHBA:服务器HBA卡,ServerHBA,服务器HBA卡,true,false
properties
hba_port_id:HBA卡端口号,string,null,null,hba_port_id,HBA卡端口号
name:HBA卡型号,string,null,null,name,HBA卡型号
hba_slot_id:HBA卡槽位号,string,null,null,hba_slot_id,HBA卡槽位号
hba_speed:HBA卡速率,string,null,null,hba_speed,HBA卡速率
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
ServerRaidCard:服务器RAID卡,ServerRaidCard,服务器RAID卡,true,false
properties
name:RAID卡型号,string,null,null,name,RAID卡型号
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
*/

/*!Model
ServerHCA:服务器HCA卡,ServerHCA,服务器HCA卡,true,false
properties
hca_slot_id:HCA卡槽位号,string,null,null,hca_slot_id,HCA卡槽位号
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:HCA卡型号,string,null,null,name,HCA卡型号
hca_port_id:HCA卡端口号,string,null,null,hca_port_id,HCA卡端口号
hca_speed:HCA卡速率,string,null,null,hca_speed,HCA卡速率
*/

/*!Model
ServerNIC:服务器网卡,ServerNIC,服务器网卡,true,false
properties
nic_slot_id:网卡槽位号,string,null,null,nic_slot_id,网卡槽位号
nic_speed:网卡速率,string,null,null,nic_speed,网卡速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:网卡型号,string,null,null,name,网卡型号
nic_port_id:网卡端口号,string,null,null,nic_port_id,网卡端口号
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def osCi = discovery_windows('windows')
def serverCi = discovery_server(osCi)
discovery_user(osCi)
discover_file_system(osCi)
discovery_nic(osCi, serverCi)

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatmanufacturer();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discover_file_system(osCi) {
	$logger.logInfo("Discover file system");
	
	def table = $wmi.query("select name, freespace, size, filesystem from win32_logicaldisk");
	for (row in table) {
		if (!row.size){
			continue;
		}

		def ci = $ci.create("WinFileSystem", row.name);
		$ci.createRelationship("Inlines", osCi.id, ci.id);
        ci.putAll([
        	fs_total_size : convert_bytes(row.size),
        	fs_type : row.fileSystem
        ])
	}
}

def discovery_user(osCi){
	$logger.logInfo("Discover user");
	
	def ugroup = [:];
	for(def group in $wmi.query('select * from Win32_GroupUser')){
		def gname = group.GroupComponent.split('=')[-1].replace('"', '')
	    def guser = group.PartComponent.split('=')[-1].replace('"', '')
	    def groups = ugroup[guser];
	    if(!groups){
	    	groups = [];
	    	ugroup[guser] = groups;
	    }
	    groups.add(gname);
	}
	
	for(def user in $wmi.query('select * from Win32_Account')){
		if(user.SIDType == 1){
			continue;
		}
		def groups = ugroup[user.Name]
		if(!groups){
			groups = []	
		}
		def ci = $ci.create('WinUser', user.Name)
        $ci.createRelationship("Inlines", osCi.id, ci.id);
        ci.putAll([
        	groups : groups.join(","),
        	active_directory_name : user.Domain
        ])
	}
}

def discovery_nic(osCi, serverCi){
	$logger.logInfo("Discover nic");
	def defaultIPGateways = []
	def drivers = $wmi.query('select * from Win32_PnPSignedDriver')
	for(def nic in $wmi.query('Select * from Win32_NetworkAdapterConfiguration  Where IPEnabled = True')){
		def ip = nic.IPAddress
		if(ip){
			ip = ip.split(",")[0]
		}
		def defaultIPGateway = nic.defaultipgateway
		if(defaultIPGateway){
			defaultIPGateway = defaultIPGateway.split(",")[0]
			defaultIPGateways.add(defaultIPGateway)
		}
		def driver_version = null
		for(def driver : drivers){
			if(driver.deviceName && driver.deviceName == nic.Description){
				driver_version = driver.driverversion
				break;
			}
		}
		def description = nic.description
		def name = description
		def settingID = nic.settingID
		if(settingID){
			name = $wmi.queryForObject("Select * from Win32_NetworkAdapter  Where GUID = '${settingID}'").NetConnectionID;
		}
		def ci = $ci.create('OsNIC', name)
        $ci.createRelationship("Inlines", osCi.id, ci.id)
        ci.putAll([
            mac_addr : nic.MACAddress.toLowerCase(),
            ip: ip,
            netmask : nic.IPSubnet,
            driver_version : driver_version
        ])
        if(serverCi && !(description.contains("VMware") || description.contains("VirtualBox"))){
        	ci = $ci.create('ServerNIC', description)
        	$ci.createRelationship("Inlines", serverCi.Id, ci.id)
            ci.mac_addr = nic.MACAddress.toLowerCase()
        }
	}
	osCi.default_gateway = defaultIPGateways.join(",")
}

def discovery_server(osCi){
	def manufacturer = osCi.manufacturer;
	if (manufacturer) {
    	manufacturer = manufacturer.toLowerCase();
		if (manufacturer.endsWith(" inc.")){
			manufacturer = manufacturer.substring(0, manufacturer.length() - 5);
		}
		if(manufacturer.contains("ibm")){
			manufacturer = "IBM";
		}else if(manufacturer.contains("huawei")){
			manufacturer = "huawei";
	    }else if(manufacturer.contains("lenovo")){
	    	manufacturer = "lenovo";
        }else if(manufacturer.contains("hp")){
        	manufacturer = "hp";
        }
		else if(manufacturer.indexOf(" co., ltd.")!=-1){
			manufacturer = manufacturer.replace(" co., ltd.", " ");
		}else{
			manufacturer = manufacturer.replace(",","");
		}
	}
	if (manufacturer && (manufacturer == 'vmware' || manufacturer == 'kvm' || manufacturer == 'xen')) {
		$logger.logInfo("this is virtual machine");
        return
	}
	$logger.logInfo("Discover pc server");
	
	def bios = $wmi.queryForObject("select SMBIOSBIOSVersion,version,SerialNumber from Win32_BIOS ");
	def cpu_model = null
	def cpu_speed_clock = null
	def cpu_phys_num = 0
	for(def processor in $wmi.query("select * from win32_processor")){
		cpu_phys_num ++
		cpu_model = processor.name
		cpu_speed_clock = processor.maxclockspeed
	}
	def model = $wmi.queryForObject("select * from Win32_OperatingSystem").name; 
	ci  = $ci.create('PCServer',  model + "/" + osCi.serial_number);
    $ci.createRelationship("RunsOn", osCi.id, ci.id);
    ci.putAll([
    			model : model,
       	 		pcserver_brand : manufacturer,
       	 		serial_number : osCi.serial_number,
        		firmware : bios.SMBIOSBIOSVersion,
                cpu_model : cpu_model,
                cpu_phys_num : cpu_phys_num,
                cpu_speed_clock: cpu_speed_clock,
                memory_size: osCi.memory_size
              ])
    return ci
}

def discovery_windows(system) {
	$logger.logInfo("Discover windows");
	
	def computerSystem =$wmi.queryForObject("select * from Win32_ComputerSystem");

	def hostname = computerSystem.name
	def osCi = $ci.create("Windows", "Windows", $wmi.params.ip + "-" + hostname);

	osCi.os_type = system
	osCi.hostname = hostname
	osCi.ip = $wmi.params.ip
	osCi.manufacturer = computerSystem.manufacturer

	osCi.memory_size = convert_bytes(computerSystem.totalphysicalmemory)
	
	def computerSystemProduct = $wmi.queryForObject("select * from Win32_ComputerSystemProduct");
	osCi.serial_number = computerSystemProduct.uuid
	def operatingSystem = $wmi.queryForObject("select * from Win32_OperatingSystem");
	if(operatingSystem.osarchitecture.contains("64")){
		osCi.bits = 64
	}else if(operatingSystem.osarchitecture.contains("32")){
		osCi.bits = 32
	}
	osCi.os_ver_detl = "${operatingSystem.caption}${operatingSystem.csdversion}"
	osCi.vir_mem_size = convert_bytes(operatingSystem.totalvirtualmemorysize)
	
	osCi.cpu_core_num = 0;
	for(def processor in $wmi.query("select * from win32_processor")){
		osCi.cpu_core_num += processor.numberofcores
		if(processor.datawidth == 64){
			osCi.cpu_arch = 'x86_64'
		}
		else {
			osCi.cpu_arch = 'x86'
		}
	}
	
	def timeZone = $wmi.queryForObject("select * from Win32_TimeZone");
	if(timeZone){
		timeZone = search(timeZone.caption, "[A-Za-z]{3}\\+0[0-9]:[0-5][0-9]|1[0-9]:[0-5][0-9]|2[0-3]:[0-5][0-9]")
	}
	osCi.timeZone = timeZone;
	return osCi;
}