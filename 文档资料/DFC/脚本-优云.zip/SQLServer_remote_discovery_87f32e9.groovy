/*!Action 
action.name=SQLServer_remote_discovery_87f32e9
action.descr=SQLServer_remote_discovery
action.version=1.0.0
action.protocols=sqlserver
action.main.model=SQLServer
discovery.output=Database
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,1433,false
db:数据库,text,master,false
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
SQLServer:SQLServer实例,SQLServer,SQLServer实例,false,false
properties
max_connections:最大连接数,int,null,null,max_connections,最大连接数
hostname:主机名,string,null,null,hostname,主机名
instance_name:实例名,string,null,null,instance_name,实例名
port:端口,int,null,null,port,端口
install_path:安装路径,string,null,null,install_path,安装路径
serverPrincipals:SQLServer服务器主体,inline,null,null,serverPrincipals,SQLServer服务器主体
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
target_server_memory:TargetServerMemory,string,null,null,target_server_memory,TargetServerMemory
version:版本,string,null,null,version,版本
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
ServerPrincipals:SQLServer服务器用户,ServerPrincipals,SQLServer服务器用户,true,false
properties
default_database_name:默认数据库,string,null,null,default_database_name,默认数据库
name:名称,string,null,null,name,名称
type_desc:类型描述,string,null,null,type_desc,类型描述
*/

/*!Model
SQLServerDatabase:SQLServer数据库,SQLServerDatabase,SQLServer数据库,false,false
properties
instance_name:实例名,string,null,null,instance_name,实例名
db_name:数据库名,string,null,null,db_name,数据库名
filegroups:SQLServer文件组,inline,null,null,filegroups,SQLServer文件组
ip:IP地址,string,null,null,ip,IP地址
db_size:数据库大小,string,null,null,db_size,数据库大小
name:名称,string,null,null,name,名称
is_read_only:是否只读,string,null,null,is_read_only,是否只读
databasePrincipals:SQLServer数据库主体,inline,null,null,databasePrincipals,SQLServer数据库主体
db_role:数据库角色,string,null,null,db_role,数据库角色
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Filegroups:SQLServer文件组,Filegroups,SQLServer文件组,true,false
properties
size:大小,string,null,null,size,大小
file_name:文件名,string,null,null,file_name,文件名
name:名称,string,null,null,name,名称
*/

/*!Model
DatabasePrincipals:SQLServer数据库用户名,DatabasePrincipals,SQLServer数据库用户名,true,false
properties
role:角色,string,null,null,role,角色
name:名称,string,null,null,name,名称
type_desc:类型描述,string,null,null,type_desc,类型描述
default_schema_name:默认Schema,string,null,null,default_schema_name,默认Schema
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def sqlserverCi = discovery_sqlserver();
discovery_serverPrincipals(sqlserverCi)
discovery_database(sqlserverCi)


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_sqlserver(){
	$logger.logInfo("Discover SQLServer");
	def instance_name = $sqlserver.queryForValue("select @@servicename")
	def version_dict = ['8': 'SQL Server 2000', '9': 'SQL Server 2005', '10': 'SQL Server 2008', '10.50': 'SQL Server 2008R2',
              '11': 'SQL Server 2012', '12': 'SQL Server 2014', '13': 'SQL Server 2016', '14': 'SQL Server 2017',
              '15': 'SQL Server 2019']
	
	def ci = $ci.create("SQLServer", "SQLServer", instance_name);
	ci.putAll([
			ip : $sqlserver.params.ip,
			port : $sqlserver.params.port,
			hostname : $sqlserver.queryForValue("SELECT SERVERPROPERTY('MachineName')"),
			version : $sqlserver.queryForValue("SELECT Left(@@Version, Charindex('-', @@version) - 2)  + ' ' +  CAST(SERVERPROPERTY('Edition') AS VARCHAR)"),
            target_server_memory : convert_bytes($sqlserver.queryForValue("SELECT cntr_value FROM sys.dm_os_performance_counters WHERE counter_name in('Target Server Memory (KB)')"), new convert_bytes_params(src_unit : 'KB')),
            max_connections : $sqlserver.queryForValue("select @@MAX_CONNECTIONS"),
            instance_name : instance_name
		])
    def osCode = 'Windows'
    if(osCode){
    	def osCi = $ci.create(osCode, $sqlserver.params.ip + "-" + ci.hostname)
    	osCi.ip = $sqlserver.params.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}


def discovery_serverPrincipals(sqlserverCi){
	$logger.logInfo("Discover ServerPrincipals");
	def excludes = ['bulkadmin','dbcreator','diskadmin' ,'processadmin','setupadmin','serveradmin','securityadmin']
	def sql = "select name,type_desc,default_database_name,name from sys.server_principals"
	for(def row in $sqlserver.query(sql)){
		def item = row.getValues();
		def name = item[0]
		if(name in excludes){
			continue
		}
		if(name.startsWith("NT") || name.startsWith("#") || name.contains("\\") ){
			continue
		}
		def ci = $ci.create('ServerPrincipals', name)
        $ci.createRelationship("Inlines", sqlserverCi.id, ci.id);
        ci.putAll([
       		type_desc : item[1],
       		default_database_name : item[2]
        ])
	}
}

def discovery_database(sqlserverCi){
	$logger.logInfo("Discover database");
	def dbSizes = [:]
	for(def row in $sqlserver.query("exec sp_helpdb")){
		def item = row.getValues();
		dbSizes[item[0]] = convert_bytes(item[1])
	}
	
	def sql = "SELECT name,database_id, is_read_only, collation_name, compatibility_level FROM sys.databases where name not in ('ReportServerTempDB','ReportServer','msdb','model','tempdb','master')"
	for(def row in $sqlserver.query(sql)){
		def item = row.getValues();
		def name = item[0]
		def dbSize = dbSizes[name];
		if(!dbSize){
			dbSize = ''
		}
		def ci = $ci.create('SQLServerDatabase', name)
        $ci.createRelationship("RunsOn", ci.id, sqlserverCi.id);
        ci.putAll([
       		ip : $sqlserver.params.ip,
       		db_size : dbSize,
            is_read_only : item[2] == 0 ? 'false' : 'true',
            instance_name : sqlserverCi.instance_name,
            db_name : name
        ])
	}
}