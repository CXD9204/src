/*!Action
action.name=F5_SNMP_remote_discovery_87f32e9
action.descr=F5_SNMP_remote_discovery   跟F5_iControl_remote_discovery相比,少了ntp,snmp和Policies  V11及以下版本，使用SNMP采集,V12及以上建议使用F5_iControl_remote_discovery采集
action.version=1.0.0
action.protocols=snmp
action.main.model=F5Dev
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
port:端口,number,161,false
snmpVersion:版本,enum,v2c,false,[v1, v2c]
community:Community,password,,false
retries:重试次数,number,1,false
timeout:超时(ms),number,1000,false
*/

/*!Model
F5Dev:F5设备,F5Dev,F5设备,false,false
properties
lbPort:负载均衡设备接口,inline,null,null,lbPort,负载均衡设备接口
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
selfIP:SelfIP地址,inline,null,null,selfIP,SelfIP地址
model:型号,string,null,null,model,型号
brand:品牌,string,null,null,brand,品牌
ip:带外管理IP,string,null,null,ip,带外管理IP
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:软件版本,string,null,null,version,软件版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
LBPort:负载均衡设备接口,LBPort,负载均衡设备接口,true,false
properties
media_speed:接口速率,string,null,null,media_speed,接口速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:接口名称,string,null,null,name,接口名称
port_index:端口索引号,int,null,null,port_index,端口索引号
trunk:trunk名称,string,null,null,trunk,trunk名称
*/

/*!Model
SelfIP:SelfIP,SelfIP,SelfIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:SelfIIP名称,string,null,null,name,SelfIIP名称
*/

/*!Model
F5VS:F5VS,F5VS,F5VS,false,false
properties
default_perst_profile:单默认会话保持方式,string,null,null,default_perst_profile,单默认会话保持方式
source_addr_trans:源地址转换,string,null,null,source_addr_trans,源地址转换
default_pool:缺省Pool,string,null,null,default_pool,缺省Pool
profile:profile,string,null,null,profile,profile
ip:VIP地址,string,null,null,ip,VIP地址
vs_name:VS名称,string,null,null,vs_name,VS名称
policies:Policies,inline,null,null,policies,Policies
iRules:iRules规则,inline,null,null,iRules,iRules规则
network_domain:网络域,string,null,null,network_domain,网络域
snatIP:SnatIP地址,inline,null,null,snatIP,SnatIP地址
protocol:协议,string,null,null,protocol,协议
port:端口,int,null,null,port,端口
trafficgroup_name:所在TrafficGroup名称,string,null,null,trafficgroup_name,所在TrafficGroup名称
name:名称,string,null,null,name,名称
*/

/*!Model
Policies:Policies,Policies,Policies,true,false
properties
name:Policies名称,string,null,null,name,Policies名称
*/

/*!Model
IRules:IRules,IRules,IRules,true,false
properties
name:iRules名称,string,null,null,name,iRules名称
*/

/*!Model
SnatIP:SnatIP,SnatIP,SnatIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
F5Pool:F5Pool,F5Pool,F5Pool,false,false
properties
prio_group_activation:优先组状态,string,null,null,prio_group_activation,优先组状态
dev_cluster_serial_number:设备/集群序列号,string,null,null,dev_cluster_serial_number,设备/集群序列号
load_balance_method:负载均衡方式,string,null,null,load_balance_method,负载均衡方式
name:名称,string,null,null,name,名称
health_monitor:健康检查方式,string,null,null,health_monitor,健康检查方式
poolMember:PoolMember成员,inline,null,null,poolMember,PoolMember成员
pool_name:Pool名称,string,null,null,pool_name,Pool名称
*/

/*!Model
PoolMember:服务池成员,PoolMember,服务池成员,true,false
properties
port:端口,int,null,null,port,端口
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
F5Cluster:F5集群,F5Cluster,F5集群,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
floatingIP:FloatingIP地址,inline,null,null,floatingIP,FloatingIP地址
cluster_serial_number:集群成员序列号,string,null,null,cluster_serial_number,集群成员序列号
name:名称,string,null,null,name,名称
cluster_hostname:集群成员主机名,string,null,null,cluster_hostname,集群成员主机名
*/

/*!Model
FloatingIP:FloatingIP,FloatingIP,FloatingIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:FloatingIP名称,string,null,null,name,FloatingIP名称
*/

import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.snmp4j.Snmp;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeUtils;

def transport = new DefaultUdpTransportMapping();
transport.listen();
treeUtils = new TreeUtils(new Snmp(transport), new DefaultPDUFactory());
treeUtils.setIgnoreLexicographicOrder(true);
Method method = $snmp.getClass().getDeclaredMethod("getTarget");
method.setAccessible(true);
myTarget = method.invoke($snmp).getTarget();

def sysObjectId = get(".1.3.6.1.2.1.1.2.0")
if(sysObjectId.split("\\.")[7] != '3375'){
	$logger.logError("It's not an F5 device")
	return 
}

def f5Ci = discovery_f5()
discovery_pool(f5Ci)
discovery_vs(f5Ci)

def discovery_f5(){
	$logger.logInfo("Discover f5");
	def cis = []
	def current_serial_number = get(".1.3.6.1.4.1.3375.2.1.3.3.3.0")
	def selfInfos = get_all_self()
	def data = [:]
	walkformateIp('.1.3.6.1.4.1.3375.2.1.2.14.1.2.1', '2', '3', 'ip', data)
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.14.1.2.1.13")){
		def map = getOrInitMapValue(item.key, data)
		map.version = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.14.1.2.1.16")){
		def map = getOrInitMapValue(item.key, data)
		map.model = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.14.1.2.1.18")){
		def map = getOrInitMapValue(item.key, data)
		map.serial_number = item.value
	}
	
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.14.1.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value.split("/")[-1]
		
		def ci = $ci.create("F5Dev", "F5Dev", name)
		ci.brand = 'F5'
		ci.putAll(map)
		cis.add(ci)
		println map
	}
	if(!cis) {
		def ci = $ci.create("F5Dev", "F5Dev", get(".1.3.6.1.2.1.1.5.0"))
		ci.putAll([
			brand : 'F5',
			serial_number : current_serial_number,
			version : get('.1.3.6.1.4.1.3375.2.1.4.2.0'),
			model : get('.1.3.6.1.4.1.3375.2.1.3.5.2.0'),
			ip : $scriptParams.ip
		])
		cis.add(ci)
	}
	if(!cis){
		throw new RuntimeException("not find f5 device")
	}
	for(def ci : cis){
		if(ci.serial_number == current_serial_number){
			for(def selfIP in selfInfos[0]){
				def selfIPCi = $ci.create("SelfIP", selfIP.name ? selfIP.name :  selfIP.ip);
				selfIPCi.ip = selfIP.ip
				$ci.createRelationship("Inlines", ci.id, selfIPCi.id)
			}
			discovery_interface(ci)
		}
	}
	
	if(cis.size() == 1){
		return cis[0]
	}
	def cluster_hostname = cis.collect{e->e.name}.sort().join("/")
	def name = discovery_groupName();
	if(!name){
		name = cluster_hostname
	}
	def clusterCi = $ci.create("F5Cluster", "F5Cluster", name)
	clusterCi.putAll([
		cluster_serial_number : cis.collect{e->e.serial_number}.sort().join("/"),
		cluster_hostname : cluster_hostname,
		cluster_name : name
	])
	for(def ci : cis){
		$ci.createRelationship("Contains", clusterCi.id, ci.id)
	}
	for(def floatingIP in selfInfos[1]){
		def floatingIPCi = $ci.create("FloatingIP", floatingIP.name ? floatingIP.name :  floatingIP.ip);
		floatingIPCi.ip = floatingIP.ip
		$ci.createRelationship("Inlines", clusterCi.id, floatingIPCi.id)
	}
	return clusterCi
}

def discovery_pool(def f5Ci){
	$logger.logInfo("Discover pool");
	poolCis = [:]
	def dev_cluster_serial_number = f5Ci.cluster_serial_number
	if(!dev_cluster_serial_number){
		dev_cluster_serial_number = f5Ci.serial_number
	}
	def balances = ['roundRobin', 'ratioMember', 'leastConnMember', 'observedMember', 'predictiveMember', 'ratioNodeAddress', 'leastConnNodeAddress',
                           'fastestNodeAddress', 'observedNodeAddress', 'predictiveNodeAddress', 'dynamicRatio', 'fastestAppResponse', 'leastSessions',
                           'dynamicRatioMember', 'l3Addr', 'weightedLeastConnMember', 'weightedLeastConnNodeAddr', 'ratioSession']
	def data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.1.2.1.17")){
		def map = getOrInitMapValue(item.key, data)
		map.health_monitor = item.value.split("/")[-1]
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.1.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		map.load_balance_method = balances[Integer.parseInt(item.value)]
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.1.2.1.7")){
		def map = getOrInitMapValue(item.key, data)
		map.prio_group_activation = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.1.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		def ci = $ci.create('F5Pool', item.value.split('/')[-1]);
		ci.putAll(map)
		ci.pool_name = ci.name
		ci.dev_cluster_serial_number = dev_cluster_serial_number
		poolCis[item.value] = ci
	}
	
	data = [:]
	walkformateIp('.1.3.6.1.4.1.3375.2.2.5.3.2.1', '3', '2', 'ip', data)
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.3.2.1.19")){
		def map = getOrInitMapValue(item.key, data)
		map.name = item.value.split("/")[-1]
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.3.2.1.4")){
		def map = getOrInitMapValue(item.key, data)
		map.port = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.5.3.2.1.1")){
		def poolCi = poolCis[item.value]
		if(!poolCi){
			continue
		}
		def map = getOrInitMapValue(item.key, data)
		def ci = $ci.create('PoolMember', (map.name ? map.name : map.ip) + ":" + map.port)
		ci.ip = map.ip
		ci.port = map.port
		$ci.createRelationship("Inlines", poolCi.id, ci.id)
	}
}

def discovery_vs(def f5Ci){
	$logger.logInfo("Discover vs");
	def source_addr_transMap = ['0' : 'none', '1': 'snat', '2': 'lsn', '3' : 'automap']
	def vsCis = [:]
	def data = [:]
	walkformateIp('.1.3.6.1.4.1.3375.2.2.10.1.2.1', '3', '2', 'ip', data)
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.6")){
		def map = getOrInitMapValue(item.key, data)
		map.port = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.7")){
		def map = getOrInitMapValue(item.key, data)
		if(item.value == '0'){
			map.protocol = 'All'
		}
		else if(item.value == '6'){
			map.protocol = 'TCP'
		}
		else if(item.value == '17'){
			map.protocol = 'UDP'
		}
		else if(item.value == '50'){
			map.protocol = 'IPsec ESP'
		}
		else if(item.value == '51'){
			map.protocol = 'IPsec AH'
		}
		else if(item.value == '132'){
			cmapi.protocol = 'SCTP'
		}
		else {
			map.protocol = 'Other'
		}
		
		map.protocol = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.19")){
		def map = getOrInitMapValue(item.key, data)
		map.default_pool = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.30")){
		def map = getOrInitMapValue(item.key, data)
		map.source_addr_trans = source_addr_transMap[item.value]
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.31")){
		def map = getOrInitMapValue(item.key, data)
		map.snat_pool = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.1.2.1.1")){
		def ci = $ci.create('F5VS', item.value.split('/')[-1]);
		def map = getOrInitMapValue(item.key, data)
		def snat_pool = map.snat_pool
		ci.putAll(map)
		ci.vs_name = ci.name
		$ci.createRelationship("RunsOn", ci.id, f5Ci.id)
		if(ci.default_pool){
			def poolCi = poolCis[ci.default_pool]
			if(poolCi){
				$ci.createRelationship("Links", ci.id, poolCi.id)
			}
		}
		ci.parent.snat_pool = snat_pool
		ci.remove('snat_pool')
		ci.remove('default_pool')
		vsCis[item.value] = ci
	}
	
	data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.4.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		map.key = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.4.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		def vsCi = vsCis[map.key]
		if(vsCi){
			vsCi.default_perst_profile = item.value
		}
	}
	
	data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.5.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		map.key = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.5.2.1.3")){
		def map = getOrInitMapValue(item.key, data)
		map.value = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.5.2.1.4")){
		def map = getOrInitMapValue(item.key, data)
		map.context = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.4.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		if(map.context == '2'){
			continue
		}
		def vsCi = vsCis[map.key]
		if(vsCi){
			if(vsCi.protocol == 'TCP' && map.type == '5'){
				ci.profile = map.value.split("/")[-1]
			}
			if(vsCi.protocol == 'UDP' && map.type == '6'){
				ci.profile = map.value.split("/")[-1]
			}
			if(vsCi.protocol == 'SCTP' && map.type == '22'){
				ci.profile = map.value.split("/")[-1]
			}
		}
	}
	def snat_pools = [:]
	data = [:]
	walkformateIp('.1.3.6.1.4.1.3375.2.2.9.9.2.1', '3', '2', 'ip', data)
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.9.9.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value
		def snat_pool = snat_pools[name]
		if(!snat_pool){
			snat_pool = []
			snat_pools[name] = snat_pool
		}
		snat_pool.add(map.ip)
	}
	for(def entry : vsCis){
		def vsCi = entry.value
		if(vsCi.parent.snat_pool){
			def poolMembers = snat_pools[vsCi.parent.snat_pool]
			if(poolMembers){
				def snatCi = $ci.create("SnatIP", vsCi.parent.snat_pool.split("/")[-1]);
				snatCi.ip = poolMembers.join(",")
				$ci.createRelationship("Inlines", vsCi.id, snatCi.id)
			}
		}
	}
	
	data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.8.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		map.value = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.2.10.8.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		def vsCi = vsCis[item.value]
		if(!vsCi){
			continue
		}
		def name = map.value.split("/")[-1]
		def ruleCi = $ci.create("IRules", name)
		$ci.createRelationship("Inlines", vsCi.id, ruleCi.id)
	}
}

def discovery_groupName(){
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.14.2.2.1.2")){
		def name = item.value
		if(name.contains('(In Sync):')){
			return name.split()[0]
		}
	}
	return null
}

def discovery_interface(def f5Ci){
	$logger.logInfo("Discover interface");
	
	def trunkMap = get_all_trunk()
	def data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.4.1.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		map.media_speed = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.4.1.2.1.6", true)){
		def map = getOrInitMapValue(item.key, data)
		map.mac_addr = item.value
	}
	
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.4.1.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		def name = item.value
		
		def lbPortCi = $ci.create("LBPort", name);
		lbPortCi.putAll(map)
		lbPortCi.trunk = trunkMap[name]
		$ci.createRelationship("Inlines", f5Ci.id, lbPortCi.id)
	}
}

def get_all_trunk(){
	def result = [:]
	def data = [:]
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.12.3.2.1.1")){
		def map = getOrInitMapValue(item.key, data)
		map.trunk = item.value
	}
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.12.3.2.1.2")){
		def map = getOrInitMapValue(item.key, data)
		result[item.value] = map.trunk
	}
	return result
}

def get_all_self(){
	def floating = []
	def no_floating = []
	
	def data = [:]
	walkformateIp('.1.3.6.1.4.1.3375.2.1.2.8.1.2.1', '2', '1', 'ip', data)
	
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.8.1.2.1.8")){
		def map = getOrInitMapValue(item.key, data)
		map.name = item.value.split('/')[-1]
	}
	
	for(def item in walk(".1.3.6.1.4.1.3375.2.1.2.8.1.2.1.6")){
		def map = getOrInitMapValue(item.key, data)
		if(item.value == '0'){
			no_floating.add(map)
		}
		else {
			floating.add(map)
		}
	}
	
	return [no_floating, floating]
}

def walkformateIp(def oid, def ipId, def typeId, def ipKey, def data){
	for(def item in walk(oid + "." + typeId)){
		def map = getOrInitMapValue(item.key, data)
		map[ipKey + '_type'] = item.value
	}
	for(def item in walk(oid + "." + ipId, true)){
		def map = getOrInitMapValue(item.key, data)
		def type = map[ipKey + '_type']
		if(type == '1'){
			map.ip = item.value.split(":").collect{e->Long.parseLong(e, 16)}.join(".")
		}
		else {
			map.ip = item.value.split(":").collect{e->Long.parseLong(e, 16)}.join(":")
		}
		map.remove(ipKey + '_type') 
	}
}

def getOrInitMapValue(def key, def map, def islist = false){
	def m = map[key]
	if(!m){
		m = islist ? [] : [:]
		map[key] = m
	}
	return m
}

def walk(def oid, def tohexString = false){
	def length = oid.size()
	if(!oid.startsWith(".")){
		length += 1
	}
	def events = treeUtils.getSubtree(myTarget, new OID(oid));
	
	def results = []
	for(def event : events){
		def vbs = event.getVariableBindings();
		if(vbs != null){
			for(def vb : vbs){
				def result = [:]
				result.key = vb.getOid().toString().substring(length)
				if(vb.getVariable().getSyntax() == org.snmp4j.asn1.BER.ASN_OCTET_STR){
					result.value = tohexString ? vb.getVariable().toHexString() : new String(vb.getVariable().getValue())
				}
				else{
					result.value = vb.getVariable().toString()
				}
				results.add(result)
			}
		}
	}
	return results;
}

def get(def oid){
	def value = $snmp.get(oid)
	if(!value || value.isNull()){
		return "";
	}
	return value.toString()
}