/*!Action
action.name=Huawei_OceanStore_SMI-S_remote_discovery_87f32e9
action.descr=Huawei_OceanStore_SMI-S_remote_discovery 已验证通过18500,5500
action.protocols=smis
action.main.model=FCStorage
discovery.output=Storage
*/

/*!Params
protocol:连接协议,enum,https,false,[http, https]
ip:目标设备IP,ip,,true
port:端口,number,5989,false
username:用户名,text,,false
password:密码,password,,false
namespace:命名空间,text,root/huawei,false
privProtocol:加密协议,text,null,true
*/

/*!Model
FCStorage:FC存储,FCStorage,FC存储,false,false
properties
front_port_num:前端端口数量,int,null,null,front_port_num,前端端口数量
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
data_cache:数据缓存,string,null,null,data_cache,数据缓存
mt_model:M/T型号,string,null,null,mt_model,M/T型号
hostname:主机名,string,null,null,hostname,主机名
unconfigured_size:未配置容量,string,null,null,unconfigured_size,未配置容量
model:型号,string,null,null,model,型号
fcstge_brand:品牌,string,null,null,fcstge_brand,品牌
ip:带外管理IP,string,null,null,ip,带外管理IP
version:软件版本(固件版本),string,null,null,version,软件版本(固件版本)
hotspare_num:热备盘个数,int,null,null,hotspare_num,热备盘个数
hardDiskInfo:硬盘信息,inline,null,null,hardDiskInfo,硬盘信息
name:名称,string,null,null,name,名称
controller_num:控制器个数,int,null,个,controller_num,控制器个数
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
fcStoragePool:存储池,inline,null,null,fcStoragePool,存储池
fcStgeLUN:FC存储卷,inline,null,null,fcStgeLUN,FC存储卷
disk_driver_num:磁盘驱动器数,int,null,个,disk_driver_num,磁盘驱动器数
frontPort:前端端口,inline,null,null,frontPort,前端端口
avl_size_after_raid:RAID后可用容量,string,null,null,avl_size_after_raid,RAID后可用容量
phys_size:物理容量,string,null,null,phys_size,物理容量
raidGroup:RAID组,inline,null,null,raidGroup,RAID组
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
used_size_after_raid:RAID后已使用容量,string,null,null,used_size_after_raid,RAID后已使用容量
controller_cache:控制器缓存,string,null,null,controller_cache,控制器缓存
enclosure_num:盘柜个数,int,null,null,enclosure_num,盘柜个数
*/

/*!Model
HardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
name:硬盘型号,string,null,null,name,硬盘型号
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
*/

/*!Model
FCStoragePool:FC存储池,FCStoragePool,FC存储池,true,false
properties
stge_pool_total_size:容量,string,null,null,stge_pool_total_size,容量
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:存储池名称,string,null,null,name,存储池名称
stge_pool_used_size:已使用容量,string,null,null,stge_pool_used_size,已使用容量
raidgroup_num:RAID组数量,int,null,null,raidgroup_num,RAID组数量
stge_pool_free_size:剩余容量,string,null,null,stge_pool_free_size,剩余容量
lun_num:LUN数量,int,null,null,lun_num,LUN数量
*/

/*!Model
FCStgeLUN:FC存储LUN,FCStgeLUN,FC存储LUN,true,false
properties
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
lun_size:LUN大小,string,null,null,lun_size,LUN大小
host_mapping:主机映射,string,null,null,host_mapping,主机映射
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池/RAID组名称,string,null,null,stge_pool_name,存储池/RAID组名称
status:状态,string,null,null,status,状态
*/

/*!Model
FrontPort:前端端口,FrontPort,前端端口,true,false
properties
port_speed:端口速率,string,null,null,port_speed,端口速率
name:前端端口名称,string,null,null,name,前端端口名称
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
RaidGroup:FC存储RAID组,RaidGroup,FC存储RAID组,true,false
properties
stge_raid_level:RAID级别,string,null,null,stge_raid_level,RAID级别
name:RAID组名称,string,null,null,name,RAID组名称
combination:组成方式,string,null,null,combination,组成方式
*/

/*!Model
HostGroup:FC存储主机组,HostGroup,FC存储主机组,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
hostGroupLUN:主机组卷,inline,null,null,hostGroupLUN,主机组卷
hostgroup_aloc_size:主机组分配容量,string,null,null,hostgroup_aloc_size,主机组分配容量
hostgroup_name:主机组名称,string,null,null,hostgroup_name,主机组名称
name:名称,string,null,null,name,名称
hostGroupMapPort:主机组映射端口,inline,null,null,hostGroupMapPort,主机组映射端口
*/

/*!Model
HostGroupLUN:FC存储主机组卷,HostGroupLUN,FC存储主机组卷,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:主机组卷名称,string,null,null,name,主机组卷名称
lun_id:LUNID,string,null,null,lun_id,LUNID
stge_pool_name:存储池名称,string,null,null,stge_pool_name,存储池名称
*/

/*!Model
HostGroupMapPort:FC主机组映射端口,HostGroupMapPort,FC主机组映射端口,true,false
properties
name:端口名称,string,null,null,name,端口名称
*/

/*!Model
NAS:NAS存储,NAS,NAS存储,false,false
properties
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
disk_driver_num:磁盘驱动器数,int,null,个,disk_driver_num,磁盘驱动器数
hostname:主机名,string,null,null,hostname,主机名
avl_size_after_raid:RAID后可用容量,string,null,null,avl_size_after_raid,RAID后可用容量
model:型号,string,null,null,model,型号
ip:带外管理IP,string,null,null,ip,带外管理IP
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
nas_brand:品牌,string,null,null,nas_brand,品牌
port:端口,int,null,null,port,端口
name:NAS存储名称,string,null,null,name,NAS存储名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
CIFSShareFS:CIFS共享,CIFSShareFS,CIFS共享,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
cifsAccessIP:客户端IP,inline,null,null,cifsAccessIP,客户端IP
name:名称,string,null,null,name,名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
fs_free_size:文件系统剩余大小,string,null,null,fs_free_size,文件系统剩余大小
fs_used_size:文件系统已使用大小,string,null,null,fs_used_size,文件系统已使用大小
*/

/*!Model
CIFSAccessIP:CIFS客户端IP,CIFSAccessIP,CIFS客户端IP,true,false
properties
name:IP地址,string,null,null,name,IP地址
desc:描述,string,null,null,desc,描述
*/

/*!Model
NFSShareFS:NFS共享,NFSShareFS,NFS共享,false,false
properties
stge_sn:存储序列号,string,null,null,stge_sn,存储序列号
nfsAccessIP:客户端IP,inline,null,null,nfsAccessIP,客户端IP
name:名称,string,null,null,name,名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
fs_free_size:文件系统剩余大小,string,null,null,fs_free_size,文件系统剩余大小
fs_used_size:文件系统已使用大小,string,null,null,fs_used_size,文件系统已使用大小
*/

/*!Model
NFSAccessIP:NFS客户端IP,NFSAccessIP,NFS客户端IP,true,false
properties
name:IP地址,string,null,null,name,IP地址
desc:描述,string,null,null,desc,描述
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def storageCis = discovery_storage()
if(!storageCis){
	return
}

for(def storageCi in storageCis){
 	if(storageCi.type == 'FCStorage'){
 		$logger.logInfo("Discover pool");
		discovery_pool(storageCi)
		$logger.logInfo("Discover disk");
		discovery_disk(storageCi)
		$logger.logInfo("Discover fc_port");
		discovery_fc_port(storageCi)
		$logger.logInfo("Discover volume");
		discovery_volume(storageCi)
		$logger.logInfo("Discover host");
		discovery_hostgroup(storageCi)
	}
	else {
		discovery_disk_num(storageCi)
		$logger.logInfo("Discover NFS");
		discovery_nfs(storageCi)
		$logger.logInfo("Discover CIFS");
		discovery_cifs(storageCi)
	}
}


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
    	return 0
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_storage(){
	def storageSystems = $smis.getInstancesByClass('Nex_StorageSystem');
	if(!storageSystems){
		$logger.logWarn("not find CIM:Nex_StorageSystem");
		return ;
	}
	
	def storageCis = []
	for(def storageSystem in storageSystems){
		def name = $smis.getProperty(storageSystem, 'NAME')
		def objectPath = storageSystem.getObjectPath()
		def chassises = $smis.getAssociatedInstances(objectPath, "CIM_Dependency", "Nex_ArrayChassis", "Dependent", "Antecedent");
		def chassise = chassises[0]
		def product = $smis.getAssociatedInstances(chassise.getObjectPath(), "CIM_Component", "Nex_ArrayProduct", "PartComponent", "GroupComponent")[0];
		def enclosureChassis = $smis.getAssociatedInstances(product.getObjectPath(), "CIM_Component", "Nex_EnclosureChassis", "GroupComponent", "PartComponent");
		
		def hostname = $smis.getProperty(storageSystem, 'ElementName')
		
		def hostGroups = []
		for(def server : $smis.getAssociatedInstances(objectPath, "CIM_Dependency", "Nex_ControllerConfigurationService", "Antecedent", "Dependent")){
			hostGroups.addAll($smis.getAssociatedInstances(server.getObjectPath(), "CIM_ServiceAffectsElement", "Nex_InitiatorMaskingGroup", "AffectingElement", "AffectedElement"))
		}
		def ci = null
		if(hostGroups){//只要有主机主的数据  就认为是FC存储
			def primordialStoragePool = $smis.getAssociatedInstances(objectPath, "CIM_Component", "Nex_PrimordialStoragePool", "GroupComponent", "PartComponent")[0];
			def storageControllerSystems = $smis.getAssociatedInstances(objectPath, "CIM_Component", "Nex_StorageControllerSystem", "GroupComponent", "PartComponent")
		
			ci = $ci.create("FCStorage", "FCStorage", hostname);
			ci.putAll([
				ip : $smis.getProperty(storageSystem, 'PrimaryOwnerContact'),
				hostname: hostname,
		        model : $smis.getProperty(product, 'type'),
		        version : $smis.getProperty(product, 'Version'),
		        fcstge_brand : $smis.getProperty(product, 'Vendor', '').toLowerCase(),
		        enclosure_num : enclosureChassis.size(),
		        serial_number : $smis.getProperty(chassise, 'SerialNumber'),
		        controller_num : storageControllerSystems.size(),
		        unconfigured_size : convert_bytes($smis.getProperty(primordialStoragePool, 'RemainingManagedSpace')),
		        phys_size : convert_bytes($smis.getProperty(primordialStoragePool, 'TotalManagedSpace')),
		        avl_size_after_raid : convert_bytes($smis.getProperty(storageSystem, 'StoragepoolTotalCapacity')),
		        used_size_after_raid : convert_bytes($smis.getProperty(storageSystem, 'StoragepoolUsedCapacity')),
		        controller_cache : convert_bytes($smis.getProperty(storageControllerSystems[0], 'MemorySize'), new convert_bytes_params(src_unit : 'MB'))
			])
			ci.parent.hostGroups = hostGroups
		}
		else {
			ci = $ci.create("NAS", "NAS", hostname);
			ci.putAll([
				ip : $scriptParams.ip,
				hostname: hostname,
				model : $smis.getProperty(product, 'type'),
				nas_brand : $smis.getProperty(product, 'Vendor', '').toLowerCase(),
				serial_number : $smis.getProperty(chassise, 'SerialNumber'),
				avl_size_after_raid : convert_bytes($smis.getProperty(storageSystem, 'StoragepoolTotalCapacity'))
			])
		}
		ci.parent.objectPath = objectPath
		storageCis.add(ci)
	}
	return storageCis
}

def discovery_pool(def storageCi){
	def pool = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Nex_ConcreteStoragePool", "GroupComponent", "PartComponent");
	def poolCis = [:]
	for(def item in pool){
		def capability = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_ElementCapabilities", "Nex_ConcreteStoragePoolCapabilities", "ManagedElement", "Capabilities")[0]
		def setting = $smis.getAssociatedInstances(capability.getObjectPath(), "CIM_Dependency", "Nex_ConcreteStoragePoolSetting", "Antecedent", "Dependent")[0]
		def raids = $smis.getProperty(setting, 'ElementName').split(",").findAll{e->e != 'Unknown'};
		def raidgroup_num = raids.size()
		def stge_raid_level = raids.unique().join(',').toLowerCase()
		
		def poolname = $smis.getProperty(item, 'ElementName')
		def ci = $ci.create("FCStoragePool", poolname);
		ci.putAll([
			stge_pool_total_size : convert_bytes($smis.getProperty(item, 'TotalManagedSpace')),
			stge_pool_used_size : convert_bytes($smis.getProperty(item, 'TotalManagedSpace') - $smis.getProperty(item, 'RemainingManagedSpace')),
			stge_pool_free_size: convert_bytes($smis.getProperty(item, 'RemainingManagedSpace')),
			stge_raid_level : stge_raid_level,
			raidgroup_num : raidgroup_num,
			lun_num : 0
		])
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
		poolCis.put($smis.getProperty(item, "InstanceID"), ci)
	}
	storageCi.parent.poolCis = poolCis
}


def discovery_disk_num(def storageCi){
	def systems = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Nex_StorageEngineSystem", "GroupComponent", "PartComponent")
	def num = 0;
	for(def system in systems){
		def disks = $smis.getAssociatedInstances(system.getObjectPath(), "CIM_Component", "Nex_DiskDrive", "GroupComponent", "PartComponent")
		num += disks.size()
	}
	storageCi.putAll([
		disk_driver_num : num
	])
}

def discovery_disk(def storageCi){
	def disk_infos = [:]
	def total_disk_capacity = 0L
	def systems = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Nex_StorageEngineSystem", "GroupComponent", "PartComponent")
	def num = 0;
	for(def system in systems){
		def disks = $smis.getAssociatedInstances(system.getObjectPath(), "CIM_Component", "Nex_DiskDrive", "GroupComponent", "PartComponent")
		for(def item in disks){
			num ++
			def diskExtent = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_Dependency", "Nex_DiskExtent", "Antecedent", "Dependent")[0]
			def diskPackage = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_Dependency", "Nex_DiskPackage", "Dependent", "Antecedent")[0]

			def capacity = $smis.getProperty(diskExtent, 'NumberOfBlocks') * $smis.getProperty(diskExtent, 'BlockSize')
			total_disk_capacity += capacity
			def productID = $smis.getProperty(diskPackage, 'Model')
			def disk_info = disk_infos[productID]
			if(!disk_info){
				disk_info = [:]
				disk_infos[productID] = disk_info
				def type = $smis.getProperty(item, 'Caption').split()
				disk_info.putAll([
					disk_num : 1,
	                disk_rpm : $smis.getProperty(item, 'DiskRotationalSpeed', 0)/1000 + 'k rpm',
	                disk_size : convert_bytes(capacity),
	                disk_type : type[0].toLowerCase(),
                	disk_media : type[1].toLowerCase()
	            ])
			}
			else{
				disk_info['disk_num'] += 1
			}
		}
	}
	
	storageCi.putAll([
		disk_driver_num : num
	])
	for(def item in disk_infos){
		def ci = $ci.create("HardDiskInfo", item.key.trim());
		ci.putAll(item.value)
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
	}
}

def discovery_fc_port(def storageCi){
	def num = 0;
	def systems = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Nex_StorageControllerSystem", "GroupComponent", "PartComponent")
	for(def system in systems){
		def ports = $smis.getAssociatedInstances(system.getObjectPath(), "CIM_Component", "Nex_FrontEndFCPort", "GroupComponent", "PartComponent")
		for(def item in ports){
			num ++
			def name = $smis.getProperty(item, 'ElementName')
			def ci = $ci.create("FrontPort", name);
			def maxSpeed = $smis.getProperty(item, 'MaxSpeed') 
			if(maxSpeed == 0){
				ci.port_speed = 'N/A'
			}
			else{
				ci.port_speed = convert_bytes(maxSpeed, new convert_bytes_params(src_unit : 'GB', return_str : false, multiple : 1000))[0] + " Gbps"
			}
			ci.wwn = $smis.getProperty(item, 'PermanentAddress')
			$ci.createRelationship("Inlines", storageCi.id, ci.id);
		}
	
	}
	storageCi.front_port_num = num
}

def discovery_volume(def storageCi){
	def OPERATION_STATUS = [
	    0: 'Unknown',
	    1: 'Other',
	    2: 'OK',
	    3: 'Degraded or Predicted Failure',
	    4: 'Stressed',
	    5: 'Predictive Failure',
	    6: 'Error',
	    7: 'Non-Recoverable Error',
	    8: 'Starting',
	    9: 'Stopping',
	    10: 'Stopped',
	    11: 'In Service',
	    12: 'No Contact',
	    13: 'Lost Communication',
	    14: 'Aborted',
	    15: 'Dormant',
	    16: 'Supporting Entity In Error',
	    17: 'Completed',
	    18: 'Power Mode',
	    19: 'Flushing',
	    32768: 'Removed',
	    32769: 'Online',
	    32770: 'Offline',
	    32771: 'Rebooting',
	    32772: 'Success',
	    32773: 'Failure',
	    32774: 'Write Disabled',
	    32775: 'Write Protected',
	    32776: 'Not Ready',
	    32777: 'Power Saving Mode'
	]
	def poolCis = storageCi.parent.poolCis
	def volumes = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Component", "Nex_StorageVolume", "GroupComponent", "PartComponent");
	def volumeCis = [:]
	for(def item in volumes){
		def name = $smis.getProperty(item, 'ElementName')
		def ci = $ci.create("FCStgeLUN", name);
		def lun_value = $smis.getProperty(item, 'NumberOfBlocks') * $smis.getProperty(item, 'BlockSize')
		ci.putAll([
			lun_id : $smis.getProperty(item, 'Name'),
			status : $smis.getProperty(item, 'OperationalStatus').collect{e->OPERATION_STATUS[e]}.join(","),
			lun_size : convert_bytes(lun_value)
		])
		def pools = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_Dependency", "Nex_ConcreteStoragePool", "Dependent", "Antecedent");
		if(pools){
			def poolCi = poolCis[$smis.getProperty(pools[0], "InstanceID")]
			poolCi.lun_num ++
			ci.stge_pool_name = poolCi.name
		}
		ci.parent.lun_value = lun_value
		ci.parent.lun_host = []
		volumeCis[ci.lun_id] = ci
		$ci.createRelationship("Inlines", storageCi.id, ci.id);
	}
	storageCi.parent.volumeCis = volumeCis
}

def discovery_hostgroup(def storageCi){
	def hostGroups = storageCi.parent.hostGroups
	def volumeCis = storageCi.parent.volumeCis
	for(def item in hostGroups){	
		def name = $smis.getProperty(item, 'ElementName')
		def hostGroupCi = $ci.create("HostGroup", name);
		hostGroupCi.putAll([
			stge_sn : storageCi.serial_number,
			hostgroup_name : name
		]) 
		$ci.createRelationship("RunsOn", hostGroupCi.id, storageCi.id);

		def storageHardwares = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_MemberOfCollection", "Nex_StorageHardwareID", "Collection", "Member");
		for(def storageHardware in storageHardwares){
			def ci = $ci.create("HostGroupMapPort", $smis.getProperty(storageHardware, 'StorageID'));
			$ci.createRelationship("Inlines", hostGroupCi.id, ci.id);
		}
		
		long hosts_lun = 0L
		for(def masking in $smis.getAssociatedInstances(item.getObjectPath(), "CIM_Dependency", "Nex_MaskingSCSIProtocolController", "Dependent", "Antecedent")){
			def volumes = $smis.getAssociatedInstances(masking.getObjectPath(), "CIM_Dependency", "Nex_StorageVolume", "Antecedent", "Dependent");
			for(def volume in volumes){
				def volumeId = $smis.getProperty(volume, 'Name')
				def volumeCi = volumeCis[volumeId]
				def ci = $ci.create('HostGroupLUN', volumeCi.name)
		        ci.putAll([
		        	lun_id : volumeId,
		            lun_size : volumeCi.parent.lun_size,
		            stge_pool_name : volumeCi.stge_pool_name
		        ])
		        $ci.createRelationship("Inlines", hostGroupCi.id, ci.id);
				hosts_lun += volumeCi.parent.lun_value
				volumeCi.parent.lun_host.add(name)
			}
		}
		hostGroupCi.hostgroup_aloc_size = convert_bytes(hosts_lun)
	}

	for(def entry in volumeCis){
		if(entry.value.parent.lun_host){
    		entry.value.hostgroup_name = entry.value.parent.lun_host.join(",")
    		entry.value.host_mapping = true
    	}
    	else {
    		entry.value.host_mapping = false
    	}
    }
}

def discovery_nfs(def storageCi){
	def nfses = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Dependency", "Nex_NFSShare", "Antecedent", "Dependent");
	for(def item in nfses){
		def name = $smis.getProperty(item, 'Name')
		def ci = $ci.create("NFSShareFS", name);
		ci.stge_sn = storageCi.serial_number
		
		def localFiles = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_LogicalIdentity", "Nex_LocalFileSystem", "SameElement", "SystemElement")
		if(localFiles){
			def localFile = localFiles[0]
			ci.putAll([
				fs_total_size : convert_bytes($smis.getProperty(localFile, 'FileSystemSize')),
				fs_used_size : convert_bytes($smis.getProperty(localFile, 'FileSystemSize') - $smis.getProperty(localFile, 'AvailableSpace')),
				fs_free_size : convert_bytes($smis.getProperty(localFile, 'AvailableSpace'))
			]) 
		}
	}
}

def discovery_cifs(def storageCi){
	def cifses = $smis.getAssociatedInstances(storageCi.parent.objectPath, "CIM_Dependency", "Nex_CIFSShare", "Antecedent", "Dependent");
	for(def item in cifses){
		def name = $smis.getProperty(item, 'Name')
		def ci = $ci.create("CIFSShareFS", name);
		ci.stge_sn = storageCi.serial_number
		
		def localFiles = $smis.getAssociatedInstances(item.getObjectPath(), "CIM_LogicalIdentity", "Nex_LocalFileSystem", "SameElement", "SystemElement")
		if(localFiles){
			def localFile = localFiles[0]
			ci.putAll([
				fs_total_size : convert_bytes($smis.getProperty(localFile, 'FileSystemSize')),
				fs_used_size : convert_bytes($smis.getProperty(localFile, 'FileSystemSize') - $smis.getProperty(localFile, 'AvailableSpace')),
				fs_free_size : convert_bytes($smis.getProperty(localFile, 'AvailableSpace'))
			])
		}
	}
}