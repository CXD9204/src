/*!Action 
action.name=Memcached_remote_discovery_87f32e9
action.descr=Memcached_remote_discovery
action.protocols=ccli
action.main.model=Memcached
discovery.output=Database
*/
 
/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
Memcached:Memcached实例,Memcached,Memcached实例,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
port:端口,int,null,null,port,端口
hostname:主机名,string,null,null,hostname,主机名
maxconn:最大连接数,int,null,null,maxconn,最大连接数
version:版本,string,null,null,version,版本
cachesize:内存大小,string,null,null,cachesize,内存大小
user_name:用户名,string,null,null,user_name,用户名
install_path:安装路径,string,null,null,install_path,安装路径
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

cliUtil = $script.use("common/cli_util");

def system = cliUtil.executeCommand("uname");
def osCode = osCodeSearch(system)
if(osCode != 'Linux'){
	$logger.logWarn("Only Linux is supported");
	return
}
def prces = get_proces('memcached')
if(!prces){
	return
}

def osCi = $ci.create(osCode, $scriptParams.ip + "-" + cliUtil.executeCommand("uname -n"))
osCi.ip = $scriptParams.ip

for(def prce in prces){
	def result = parsing_cmdline(prce[3].join(' '))
	def port = prce[1]
	if(!port){
		port = result['-p']
	}
	def name = "Memcached${port}"
	def ci = $ci.create('Memcached', name)
	ci.putAll([
		ip : $scriptParams.ip,
	    port : port,
	    version : cliUtil.executeCommand("${prce[2]} -V |awk '{print \$2}'"),
	    hostname : cliUtil.executeCommand("uname -n"),
	    maxconn : result['-c'],
	    cachesize : convert_bytes(result['-m'], new convert_bytes_params(src_unit : 'MB')),
	    user_name : prce[0],
	    install_path : cliUtil.executeCommand("echo \$(dirname \$(dirname ${prce[2]}))")
	])
	$ci.createRelationship("RunsOn", ci.id, osCi.id);
}

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HP_UX', 'hp_ux' : 'HP_UX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}


def is_dir(def db_dir){
	if($text.isNull(cliUtil.executeCommand("[ -d '${db_dir}' ] && echo true"))){
		return false;
	}
	return true
}

def get_proces(def name){
	def proces = []
	def commondResult = cliUtil.executeCommand("ps -eo user,pid,comm,args|grep -w $name")
	if(!$text.isNull(commondResult)){
		for(def line in $text.splitLine(commondResult)){
			def ss = line.split()
			if(ss[2] != name){
				continue
			}
			def pid = ss[1]
			def exec = cliUtil.executeCommand("echo \$(ls -l /proc/$pid/exe|awk -F'>' '{print \$NF}')")
			if(exec == '/usr/bin/bash'){
				continue
			}
			port = cliUtil.executeCommand("netstat -antp 2>/dev/null | grep -w '${pid}/${name}'| awk '{print \$4}'|awk -F: '{print \$NF}'")
			proces.add([ss[0], port, exec, ss[3..-1]])
		}
	}
	return proces
}

def parsing_cmdline(cmdline){
	def	value_dict = [
        '-c': '1024',
        '-p': '11211',
        '-m': '64',
        '-t': '4',
        '-b': '1024',
        '-R': '20'
    ]
	def arg_maps = [
        '-c': '--conn-limit=',
        '-m': '--memory-limit=',
        '-s': '--unix-socket=',
        '-l': '--listen=',
        '-p': '--port=',
        '-u': '--user=',
        '-P': '--pidfile=',
        '-t': '--threads=',
        '-b': '--listen-backlog=',
        '-R': '--max-reqs-per-event='
    ]
    for(def entry in arg_maps){
    	def value = findAllFirst(cmdline, "(?<=${entry.key}\\s)(\\d+|\\S+)")
    	if(!value){
    		value = findAllFirst(cmdline, "(?<=${entry.value})(\\d+|\\S+)")
    	}
    	if(value){
    		value_dict[entry.key] = value
    	}
    }
    return value_dict
}
