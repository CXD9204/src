/*!Action 
action.name=DB2_remote_discovery_87f32e9
action.descr=DB2_remote_discovery
action.version=1.0.0
action.protocols=db2
action.main.model=DB2
discovery.output=Database
*/
 
/*!Params
ip:目标设备IP,ip,,true
port:端口,number,50000,false
db:数据库名,text,,false
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
DB2:DB2实例,DB2,DB2实例,false,false
properties
tcpip_svname:TCP/IP服务名,string,null,null,tcpip_svname,TCP/IP服务名
db2_diagpath:诊断日志目录,string,null,null,db2_diagpath,诊断日志目录
instance_name:实例名,string,null,null,instance_name,实例名
database_path:database路径,string,null,null,database_path,database路径
install_path:安装路径,string,null,null,install_path,安装路径
sysmaint_group_name:系统维护组,string,null,null,sysmaint_group_name,系统维护组
ip:IP地址,string,null,null,ip,IP地址
db2territory:地区代码,string,null,null,db2territory,地区代码
version:版本,string,null,null,version,版本
db2codepage:页代码,string,null,null,db2codepage,页代码
hostname:主机名,string,null,null,hostname,主机名
sysadm_group_name:系统管理组,string,null,null,sysadm_group_name,系统管理组
port:端口,int,null,null,port,端口
instance_memory:实例内存,string,null,null,instance_memory,实例内存
sysctrl_group_name:系统控制组,string,null,null,sysctrl_group_name,系统控制组
name:名称,string,null,null,name,名称
db2comm:通讯协议,string,null,null,db2comm,通讯协议
sysmon_group_name:系统监控组,string,null,null,sysmon_group_name,系统监控组
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
DB2Database:DB2数据库,DB2Database,DB2数据库,false,false
properties:
name:名称,string,null,null,name,名称
db2BP:DB2缓冲池,inline,null,null,db2BP,DB2缓冲池
db2TBS:DB2表空间,inline,null,null,db2TBS,DB2表空间
db2User:DB2用户,inline,null,null,db2User,DB2用户
db_name:数据库名,string,null,null,db_name,数据库名
db_role:数据库角色,string,null,null,db_role,数据库角色
maxappls:最大连接数,string,null,null,maxappls,最大连接数
page_size:页大小,string,null,null,page_size,页大小
db2codeset:代码集,string,null,null,db2codeset,代码集
log_second:辅助日志文件个数,int,null,null,log_second,辅助日志文件个数
db2codepage:页代码,string,null,null,db2codepage,页代码
log_primary:主日志文件个数,int,null,null,log_primary,主日志文件个数
logfile_siz:日志文件大小,string,null,null,logfile_siz,日志文件大小
newlog_path:活动日志路径,string,null,null,newlog_path,活动日志路径
db2territory:地区代码,string,null,null,db2territory,地区代码
log_archmeth1:归档日志路径,string,null,null,log_archmeth1,归档日志路径
mirrorlog_path:镜像日志路径,string,null,null,mirrorlog_path,镜像日志路径
database_memory:数据库内存,string,null,null,database_memory,数据库内存
instance_cluster_ip:实例/集群IP,string,null,null,instance_cluster_ip,实例/集群IP
instance_cluster_name:实例/集群名称,string,null,null,instance_cluster_name,实例/集群名称
instance_cluster_hostname:实例/集群主机名,string,null,null,instance_cluster_hostname,实例/集群主机名
*/

/*!Model
DB2User:DB2用户,DB2User,DB2用户,true,false
properties
explain:EXPLAIN,string,null,null,explain,EXPLAIN
dbadm:DBADM,string,null,null,dbadm,DBADM
dataaccess:DATAACCESS,string,null,null,dataaccess,DATAACCESS
wlmadm:WLMADM,string,null,null,wlmadm,WLMADM
quiesceconn:QUIESCECONN,string,null,null,quiesceconn,QUIESCECONN
implschema:IMPLSCHEMA,string,null,null,implschema,IMPLSCHEMA
bindaddr:BINDADDR,string,null,null,bindaddr,BINDADDR
securityadm:SECURITYADM,string,null,null,securityadm,SECURITYADM
extroutine:EXTROUTINE,string,null,null,extroutine,EXTROUTINE
createtab:CREATETAB,string,null,null,createtab,CREATETAB
sqladm:SQLADM,string,null,null,sqladm,SQLADM
nofence:NOFENCE,string,null,null,nofence,NOFENCE
load:LOAD,string,null,null,load,LOAD
createsecure:CREATESECURE,string,null,null,createsecure,CREATESECURE
name:名称,string,null,null,name,名称
accessctrl:ACCESSCTRL,string,null,null,accessctrl,ACCESSCTRL
connect:CONNECT,string,null,null,connect,CONNECT
*/

/*!Model
DB2TBS:DB2表空间,DB2TBS,DB2表空间,true,false
properties
tbs_total_size:表空间大小,string,null,null,tbs_total_size,表空间大小
name:名称,string,null,null,name,名称
tbs_id:表空间ID,int,null,null,tbs_id,表空间ID
tbs_type:表空间类型,string,null,null,tbs_type,表空间类型
tbs_free_size:表空间剩余大小,string,null,null,tbs_free_size,表空间剩余大小
tbs_container_num:容器个数,int,null,null,tbs_container_num,容器个数
page_size:页大小,string,null,null,page_size,页大小
status:状态,string,null,null,status,状态
tbs_used_size:表空间已使用大小,string,null,null,tbs_used_size,表空间已使用大小
*/

/*!Model
DB2BP:DB2缓冲池,DB2BP,DB2缓冲池,true,false
properties:
name:名称,string,null,null,name,名称
bp_size:缓冲池大小,string,null,null,bp_size,缓冲池大小
pagesize:页大小,int,null,null,pagesize,页大小
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

def databaseCi = discovery_db2_database();
discovery_db2_instance(databaseCi)
discovery_tbsp(databaseCi);
discovery_db_user(databaseCi);
discovery_db_bp(databaseCi)

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}


def discovery_db2_database(){
	$logger.logInfo("Discover database");
	def ci = null;
	
	def database_name = $db2.queryForValue("select current server from sysibm.sysdummy1")
	def instance_cluster_name = $db2.queryForValue("SELECT INST_NAME FROM SYSIBMADM.ENV_INST_INFO")
	def hostname = $db2.queryForValue("SELECT HOST_NAME FROM TABLE(SYSPROC.ENV_GET_SYS_INFO())");
	ci = $ci.create("DB2Database", "DB2Database", database_name);
	ci.putAll([
		    db_name : database_name,
		    instance_cluster_ip : $db2.params.ip,
		    instance_cluster_name : instance_cluster_name,
		    instance_cluster_hostname : hostname
		])
	return ci;
}


def discovery_db2_instance(databaseCi){
	$logger.logInfo("Discover instance");
	
	def version = $db2.queryForValue("SELECT service_level FROM TABLE (sysproc.env_get_inst_info()) as INSTANCEINFO");
	version = version.split()[-1];
	def hostname = $db2.queryForValue("SELECT HOST_NAME FROM TABLE(SYSPROC.ENV_GET_SYS_INFO())");
	def ci = $ci.create("DB2", databaseCi.instance_cluster_name);
	$ci.createRelationship("RunsOn", databaseCi.id, ci.id);
	ci.putAll([
		    instance_name : databaseCi.instance_cluster_name,
		    ip : $db2.params.ip,
		    port : $db2.params.port,
		    version : version,
		    hostname : hostname
		])
}

def discovery_tbsp(databaseCi){
	$logger.logInfo("Discover tbsp");
	def table = $db2.query("SELECT tbsp_id, tbsp_name, tbsp_type, tbsp_state, tbsp_total_size_kb, tbsp_used_size_kb, tbsp_utilization_percent, tbsp_page_size, tbsp_num_containers FROM sysibmadm.tbsp_utilization");
	for(def row in table){
		def item = row.getValues();
		
		ci = $ci.create('DB2TBS', item[1])
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			name : item[1],
                    status : item[3],
                    tbs_id : item[0],
                    tbs_type : item[2],
                    page_size : item[7],
                    tbs_used_pct : item[6],
                    tbs_free_size : convert_bytes(item[4] - item[5], new convert_bytes_params(src_unit : 'KB')),
                    tbs_used_size : convert_bytes(item[5], new convert_bytes_params(src_unit : 'KB')),
                    tbs_total_size : convert_bytes(item[4], new convert_bytes_params(src_unit : 'KB')),
                    tbs_container_num : item[8]
                  ])
	}
}


def discovery_db_user(databaseCi){
	$logger.logInfo("Discover db user");
	def table = $db2.query("select trim(authid) as username, nvl(bindaddauth, '-'), nvl(connectauth, '-'), nvl(createtabauth, '-'), nvl(dbadmauth, '-'), nvl(externalroutineauth, '-'), " + 
		"nvl(implschemaauth, '-'), nvl(loadauth, '-'), nvl(nofenceauth, '-'), nvl(quiesceconnectauth, '-'), nvl(securityadmauth, '-'), nvl(sqladmauth, '-'), nvl(wlmadmauth, '-'), " +
		"nvl(explainauth, '-'), nvl(dataaccessauth,'-'), nvl(accessctrlauth, '-'), nvl(createsecureauth, '-') from sysibmadm.authorizationids a left join syscat.dbauth d on d.grantee = a.authid " +
		"where authidtype = 'U' order by username");
	for(def row in table){
		def item = row.getValues();
		ci = $ci.create('DB2User', item[0])
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
        			bindaddr : item[1],
        			connect : item[2],
        			createtab : item[3],
        			dbadm : item[4],
        			extroutine : item[5],
        			implschema : item[6],
        			load : item[7],
        			nofence : item[8],
        			quiesceconn : item[9],
        			securityadm : item[10],
        			sqladm : item[11],
        			wlmadm : item[12],
        			explain : item[13],
        			dataaccess : item[14],
        			accessctrl : item[15],
        			createsecure : item[16]
                  ])
	}
}

def discovery_db_bp(databaseCi){
    def bps = $db2.query("select substr(BPNAME, 1, 30) as BP_NAME, PAGESIZE from SYSCAT.BUFFERPOOLS")
    for(def bp in bps){
    	def name = bp.BP_NAME.trim();
        def bp_sz = $db2.queryForValue("select BP_CUR_BUFFSZ from table(MON_GET_BUFFERPOOL('${name}',-1))")
        if(!bp_sz){
        	continue
        }
        def ci = $ci.create('DB2BP', name)
        $ci.createRelationship("Inlines", databaseCi.id, ci.id);
        ci.putAll([
            bp_size : convert_bytes(bp_sz * bp.PAGESIZE),
            pagesize : bp.PAGESIZE
        ])
    }
}