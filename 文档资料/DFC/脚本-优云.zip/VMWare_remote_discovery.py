# coding: UTF-8
# @Author: zhengyd@uyunsoft.cn
# @Date  : 2021/6/3
# vCenter 远程发现
import sys
try:
    reload(sys)
    sys.setdefaultencoding('utf-8')
except:
    pass
import os
import re
import ssl
import json
import time
import copy
import functools
import traceback
import requests
from urllib import unquote
import chardet
from pyVmomi import vim
import pyVmomi
from pyVim.connect import SmartConnect, Disconnect
import atexit
from functools import reduce
from pyramid.exceptions import CenterNotConnected
try:
    # 测试使用
    from _utils.Ci import Ci
    __ci__ = Ci()
    __ip__ = ['10.1.5.251']
    # __ip__ = ['10.1.2.202']
    __args__ = [{'port': 443,
                 'username': 'administrator',
                 'password': os.getenv('VC_PWD_251'),
                 'tenant_url': 'http://10.1.5.250',
                 'apikey': '9cc4871e46094635a19d26557f9bb7f4'
                 }]
except BaseException:
    pass

"""!Action
action.name=VMware虚拟化
action.descr=通过VMware的SDK协议远程发现，同时指定租户地址和apikey则支持删除VM漂移后CMDB中历史错误关系，需要此功能找开发要依赖包
discovery.output=Virtual
action.main.model=vCenter
"""

"""!Params
ip:目标设备IP,ip,,true
port:端口,number,443,false
username:用户名,text,administrator@vsphere.local,false
password:密码,password,,false
tenant_url:UYUN平台租户地址,text,,true
apikey:ApiKey,text,,true
discover_vm_os:是否发现VM的OS,enum,no,true,[yes,no]
"""

"""!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
ips:IP列表,array,null,null,ips,IP列表
name:名称,string,null,null,name,名称
hostname:主机名,string,null,null,hostname,主机名
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
ips:IP列表,array,null,null,ips,IP列表
name:名称,string,null,null,name,名称
hostname:主机名,string,null,null,hostname,主机名
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
vCenter:vCenter,vCenter,vCenter,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
port:端口,int,null,null,port,端口
vm_num:虚拟机数量,int,null,台,vm_num,虚拟机数量
version:版本,string,null,null,version,版本
esxi_num:ESXi主机数量,int,null,null,esxi_num,ESXi主机数量
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
vSphereDC:vSphere数据中心,vSphereDC,vSphere数据中心,false,false
properties:
name:名称,string,null,null,name,名称
vm_num:虚拟机数量,int,null,台,vm_num,虚拟机数量
esxi_num:ESXi主机数量,int,null,null,esxi_num,ESXi主机数量
vCenter_ip:vCenter的IP,string,null,null,vCenter_ip,vCenter的IP
vCenter_name:vCenter名称,string,null,null,vCenter_name,vCenter名称
network_domain:网络域,string,null,null,network_domain,网络域
"""

"""!Model
vSphereCluster:vSphere集群,vSphereCluster,vSphere集群,false,false
properties:
name:名称,string,null,null,name,名称
vm_num:虚拟机数量,int,null,台,vm_num,虚拟机数量
esxi_num:ESXi主机数量,int,null,null,esxi_num,ESXi主机数量
vCenter_ip:vCenter的IP,string,null,null,vCenter_ip,vCenter的IP
vCenter_name:vCenter名称,string,null,null,vCenter_name,vCenter名称
network_domain:网络域,string,null,null,network_domain,网络域
vSphereDC_name:数据中心名称,string,null,null,vSphereDC_name,数据中心名称
vcluster_cpu_free:CPU剩余,string,null,null,vcluster_cpu_free,CPU剩余
vcluster_memory_free:内存剩余,string,null,null,vcluster_memory_free,内存剩余
dataStore:DataStore,inline,null,null,dataStore,DataStore
vSphereRP:vSphere资源池,inline,null,null,vSphereRP,vSphere资源池
"""

"""!Model
dataStore:DataStore,DataStore,DataStore,true,false
properties:
name:名称,string,null,null,name,名称
lun_id:LUNID,string,null,null,lun_id,LUNID
avl_size:可用容量,string,null,null,avl_size,可用容量
lun_size:LUN大小,string,null,null,lun_size,LUN大小
local_disk_flag:是否本地硬盘,string,null,null,local_disk_flag,是否本地硬盘
provisioned_space:置备空间,string,null,null,provisioned_space,置备空间
provisioned_spare:置备率,string,null,null,provisioned_spare,置备率
datastore_disk_type:硬盘类型,string,null,null,datastore_disk_type,硬盘类型
"""

"""!Model
vSphereRP:vSphere资源池,VSphereRP,vSphere资源池,true,false
properties:
name:名称,string,null,null,name,名称
vm_num:虚拟机数量,int,null,null,vm_num,虚拟机数量
"""

"""!Model
vSphereNetwork:vSphere网络,vSphereNetwork,vSphere网络,false,false
properties:
name:名称,string,null,null,name,名称
vlan_id:VLAN名称,string,null,null,vlan_id,VLAN名称
vCenter_ip:vCenter的IP,string,null,null,vCenter_ip,vCenter的IP
vSphereDC_name:数据中心名称,string,null,null,vSphereDC_name,数据中心名称
vSphereCluster_name:vSphere集群名称,string,null,null,vSphereCluster_name,vSphere集群名称
"""

"""!Model
ESXi:ESXi,ESXi,ESXi,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
bits:位数,string,null,null,bits,位数
name:名称,string,null,null,name,名称
vm_num:虚拟机数量,int,null,台,vm_num,虚拟机数量
hostname:主机名,string,null,null,hostname,主机名
time_zone:时区,string,null,null,time_zone,时区
dns_server:DNS服务器,string,null,null,dns_server,DNS服务器
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
memory_size:内存大小,string,null,null,memory_size,内存大小
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
network_domain:网络域,string,null,null,network_domain,网络域
osHBA:OS的HBA卡,inline,null,null,osHBA,OS的HBA卡
osNIC:OS的网卡,inline,null,null,osNIC,OS的网卡
dataStore:DataStore,inline,null,null,dataStore,DataStore
"""

"""!Model
osHBA:OS的HBA卡,OsHBA,OS的HBA卡,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
status:状态,string,null,null,status,状态
firmware:固件版本,string,null,null,firmware,固件版本
driver_version:驱动版本,string,null,null,driver_version,驱动版本
"""

"""!Model
osNIC:OS的网卡,OsNIC,OS的网卡,true,false
properties:
ips:IP列表,array,null,null,ips,IP列表
name:名称,string,null,null,name,名称
status:状态,string,null,null,status,状态
firmware:固件版本,string,null,null,firmware,固件版本
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:是否做bonding,string,null,null,bonding_flag,是否做bonding
driver_version:驱动版本,string,null,null,driver_version,驱动版本
ip_ranges:IP范围,string,null,null,ip_ranges:IP范围
"""

"""!Model
dataStore:DataStore,DataStore,DataStore,true,false
properties:
name:名称,string,null,null,name,名称
lun_id:LUNID,string,null,null,lun_id,LUNID
avl_size:可用容量,string,null,null,avl_size,可用容量
lun_size:LUN大小,string,null,null,lun_size,LUN大小
local_disk_flag:是否本地硬盘,string,null,null,local_disk_flag,是否本地硬盘
provisioned_space:置备空间,string,null,null,provisioned_space,置备空间
provisioned_spare:置备率,string,null,null,provisioned_spare,置备率
datastore_disk_type:硬盘类型,string,null,null,datastore_disk_type,硬盘类型
"""

"""!Model
VM:虚拟机,VM,虚拟机,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
ipv6:IPV6,string,null,null,ipv6,IPV6
ips:IP列表,array,null,null,ips,IP列表
name:名称,string,null,null,name,名称
uuid:UUID,string,null,null,uuid,UUID
hostname:主机名,string,null,null,hostname,主机名
os_ip:操作系统IP,string,null,null,os_ip,操作系统IP
os_ipv6:操作系统IPV6地址,string,null,null,os_ipv6,操作系统IPV6地址
uuid_bios:bios的UUID,string,null,null,uuid_bios,bios的UUID
memory_size:内存大小,string,null,null,memory_size,内存大小
power_state:电源状态,string,null,null,power_state,电源状态
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
hypervisor_ip:宿主机IP,string,null,null,hypervisor_ip,宿主机IP
vmtools_state:VMTools状态,string,null,null,vmtools_state,VMTools状态
vmtools_version:VMTools版本,string,null,null,vmtools_version,VMTools版本
network_domain:网络域,string,null,null,network_domain,网络域
monitor_enabled:是否监控,string,null,null,monitor_enabled,是否监控
phys_size:物理容量,string,null,null,phys_size,物理容量
vmNIC:虚拟机网卡,inline,null,null,vmNIC,虚拟机网卡
vmDisk:虚拟机硬盘,inline,null,null,vmDisk,虚拟机硬盘
comment:备注,string,null,null,comment,备注
"""

"""!Model
vmNIC:虚拟机网卡,VmNIC,虚拟机网卡,true,false
properties:
name:名称,string,null,null,name,名称
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
network_name:所在网络,string,null,null,network_name,所在网络
"""

"""!Model
vmDisk:虚拟机硬盘,VmDisk,虚拟机硬盘,true,false
properties:
name:名称,string,null,null,name,名称
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
vm_disk_type:硬盘类型,string,null,null,vm_disk_type,硬盘类型
vm_disk_mode:硬盘模式,string,null,null,vm_disk_mode,硬盘模式
virtual_device_node:虚拟设备节点,string,null,null,virtual_device_node,虚拟设备节点
datastore_name:所在存储,string,null,null,datastore_name,所在存储
"""

"""!Model
VmTemplate:虚拟机模板,VmTemplate,虚拟机模板,false,false
properties:
name:名称,string,null,null,name,名称
uuid:UUID,string,null,null,uuid,UUID
uuid_bios:bios的UUID,string,null,null,uuid_bios,bios的UUID
memory_size:内存大小,string,null,null,memory_size,内存大小
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
vmNIC:虚拟机网卡,inline,null,null,vmNIC,虚拟机网卡
vmDisk:虚拟机硬盘,inline,null,null,vmDisk,虚拟机硬盘
"""


"""!Model
PCServer:PC服务器,PCServer,PC服务器,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
ipv6:IPV6,string,null,null,ipv6,IPV6
name:名称,string,null,null,name,名称
port:端口,int,null,null,port,端口
model:型号,string,null,null,model,型号
os_ip:操作系统IP,string,null,null,os_ip,操作系统IP
os_ipv6:操作系统IPV6地址,string,null,null,os_ipv6,操作系统IPV6地址
firmware:固件版本,string,null,null,firmware,固件版本
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
bmc_version:BMC固件版本,string,null,null,bmc_version,BMC固件版本
memory_size:内存大小,string,null,null,memory_size,内存大小
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
device_model:设备型号,reference,null,null,device_model,设备型号
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
pcserver_brand:品牌,string,null,null,pcserver_brand,品牌
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
monitor_enabled:是否监控,string,null,null,monitor_enabled,是否监控
power_supply_mode:电源节能模式,string,null,null,power_supply_mode,电源节能模式
hyper_threading_open_flag:超线程打开模式,string,null,null,hyper_threading_open_flag,超线程打开模式
serverHBA:服务器HBA卡,inline,null,null,serverHBA,服务器HBA卡
serverHCA:服务器HCA卡,inline,null,null,serverHCA,服务器HCA卡
serverNIC:服务器网卡,inline,null,null,serverNIC,服务器网卡
serverVDisk:服务器虚拟磁盘,inline,null,null,serverVDisk,服务器虚拟磁盘
hardDiskInfo:硬盘,inline,null,null,hardDiskInfo,硬盘
serverRaidCard:RAID卡,inline,null,null,serverRaidCard,RAID卡
serverMemoryModule:内存,inline,null,null,serverMemoryModule,内存
"""

"""!Model
serverHBA:服务器HBA卡,ServerHBA,服务器HBA卡,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
hba_speed:HBA卡速率,string,null,null,hba_speed,HBA卡速率
hba_port_id:HBA卡端口号,string,null,null,hba_port_id,HBA卡端口号
hba_slot_id:HBA卡槽位号,string,null,null,hba_slot_id,HBA卡槽位号
"""

"""!Model
serverHCA:服务器HCA卡,ServerHCA,服务器HCA卡,true,false
properties:
name:名称,string,null,null,name,名称
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
hca_speed:HCA卡速率,string,null,null,hca_speed,HCA卡速率
hca_port_id:HCA卡端口号,string,null,null,hca_port_id,HCA卡端口号
hca_slot_id:HCA卡槽位号,string,null,null,hca_slot_id,HCA卡槽位号
"""

"""!Model
serverNIC:服务器网卡,ServerNIC,服务器网卡,true,false
properties:
name:名称,string,null,null,name,名称
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
nic_speed:网卡速率,string,null,null,nic_speed,网卡速率
nic_port_id:网卡端口号,string,null,null,nic_port_id,网卡端口号
nic_slot_id:网卡槽位号,string,null,null,nic_slot_id,网卡槽位号
"""

"""!Model
serverVDisk:服务器虚拟磁盘,ServerVDisk,服务器虚拟磁盘,true,false
properties:
name:名称,string,null,null,name,名称
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
raid_level:RAID级别,string,null,null,raid_level,RAID级别
vdisk_size:虚拟磁盘大小,string,null,null,vdisk_size,虚拟磁盘大小
"""

"""!Model
hardDiskInfo:硬盘,HardDiskInfo,硬盘,true,false
properties:
name:名称,string,null,null,name,名称
disk_num:硬盘数量,int,null,null,disk_num,硬盘数量
disk_rpm:硬盘转速,string,null,null,disk_rpm,硬盘转速
disk_size:硬盘大小,string,null,null,disk_size,硬盘大小
disk_type:硬盘类型,string,null,null,disk_type,硬盘类型
disk_media:硬盘介质,string,null,null,disk_media,硬盘介质
"""

"""!Model
serverRaidCard:RAID卡,ServerRaidCard,RAID卡,true,false
properties:
name:名称,string,null,null,name,名称
firmware:固件版本,string,null,null,firmware,固件版本
driver_version:驱动版本,string,null,null,driver_version,驱动版本
"""

"""!Model
serverMemoryModule:内存,ServerMemoryModule,内存,true,false
properties:
name:名称,string,null,null,name,名称
type:类型,string,null,null,type,类型
memory_module_num:内存条数量,int,null,null,memory_module_num,内存条数量
memory_clock_speed:内存条主频,string,null,null,memory_clock_speed,内存条主频
memory_module_size:内存条大小,string,null,null,memory_module_size,内存条大小
"""

"""!Model
vSphereDVS:vSphere分布式交换机,vSphereDVS,vSphere分布式交换机,false,false
properties:
name:名称,string,null,null,name,名称
uuid:UUID,string,null,null,uuid,UUID
port_nums:端口数,int,null,null,port_nums,端口数
vCenter_ip:vCenter的IP,string,null,null,vCenter_ip,vCenter的IP
vSphereDC_name:数据中心名称,string,null,null,vSphereDC_name,数据中心名称
vSphereDVSPort:分布式端口,inline,null,null,vSphereDVSPort,分布式端口
vSphereDVSUpLinkPort:上行端口,inline,null,null,vSphereDVSUpLinkPort,上行端口
"""

"""!Model
vSphereDVSPort:分布式端口,vSphereDVSPort,分布式端口,true,false
properties:
name:名称,string,null,null,name,名称
port_id:端口ID,string,null,null,port_id,端口ID
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
link_peer:连接对象,string,null,null,link_peer,连接对象
"""

"""!Model
vSphereDVSUpLinkPort:上行端口,vSphereDVSUpLinkPort,上行端口,true,false
properties:
name:名称,string,null,null,name,名称
port_id:端口ID,string,null,null,port_id,端口ID
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
link_peer:连接对象,string,null,null,link_peer,连接对象
neighbor_portmac:邻居设备端口mac,string,null,null,neighbor_portmac,邻居设备端口mac
neighbor_hostname:邻居设备主机名,string,null,null,neighbor_hostname,邻居设备主机名
neighbor_portname:邻居设备端口名,string,null,null,neighbor_portname,邻居设备端口名
"""


def _encode(_str):
    if not isinstance(_str, basestring):
        return str(_str)
    if not _str.strip():
        return _str
    if isinstance(_str, unicode):
        return _str.encode('utf-8')
    encoding = chardet.detect(_str).get('encoding') or 'utf-8'
    return _str.decode(encoding, 'ignore').encode('utf-8', 'ignore')


def convert_bytes(size, unit=None, src_unit=None,
                  multiple=1024, return_str=True):
    """自动转换字节大小, 支持指定原始单位"""
    if not size:
        return None
    symbols = ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB')
    symbols1 = ('B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
    symbols2 = ('B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB')
    try:
        # 10.21g 获取大小和单位
        if isinstance(size, str):
            size = size.replace(',', '')
            util_tmp = re.search('[bkmgtpezyi]{1,3}', size, re.I)
            if util_tmp:
                _src_unit = util_tmp.group().upper()
                if _src_unit in symbols1:
                    src_unit = symbols[symbols1.index(_src_unit)]
                elif _src_unit in symbols2:
                    src_unit = symbols[symbols2.index(_src_unit)]
                elif _src_unit in symbols:
                    src_unit = _src_unit

            size = float(re.search(r'\d+(\.\d+)?', size).group())
        else:
            size = float(size)
        # print size, src_unit
        step = 0
        if src_unit:  # 指定了原始单位
            size = size * (multiple ** (symbols.index(src_unit.upper())))
        if not unit:  # 自动计算单位
            while size >= multiple and step < len(symbols) - 1:
                size /= multiple
                step += 1
            unit = symbols[step]
        else:  # 转换为指定单位
            index_of_unit = symbols.index(unit)
            while len(symbols) - 1 > step and index_of_unit != step:
                size /= multiple
                step += 1
        if return_str:
            return '{:.2f} {}'.format(size, unit)
        else:
            return size, unit
    except Exception as e:
        print('[ERROR] Convert bytes error, {}'.format(e))
        return size


def convert_mask_int(mask_int):
    """子网掩码转换，如 24 转为 255.255.255.0"""
    bin_str = '{0:0<32}'.format('1' * int(mask_int))
    return '.'.join([str(int(i, 2))
                     for i in [bin_str[i * 8:i * 8 + 8] for i in range(4)]])


def match_brand(mf):
    """匹配品牌"""
    mf = mf.strip()
    tmp = re.search(r'IBM|HP|Dell|Oracle|Lenovo|HUAWEI|H3C|ZTE|inspur'
                    r'|sugon|Supermicro|Asus|Acer|Cisco|Fujitsu|sun|msi'
                    r'|EMC|HDS|NETAPP|HITACHI|Juniper|Hillstone|BROCADE',
                    mf, re.I)
    if tmp:
        brand = tmp.group()
    elif re.search('fiberhome|fiber home', mf, re.I):
        brand = 'fiberhome'
    elif re.search(r'o\.?e\.?m', mf, re.I):
        brand = 'oem'
    else:
        brand = re.sub(r'inc\.|\.| ', '', mf)
    return brand


def int_to_hex(x, sep=':'):
    # 整数转换为hex格式，冒号分隔
    x = hex(x).lstrip('0x').rstrip('L')
    return sep.join([x[i:i + 2] for i in range(0, len(x), 2)])


def ip_to_int(ip):
    """转换IPv4地址为整数"""
    return reduce(lambda a, b: a << 8 | b, list(map(int, ip.split("."))))


def is_private_ip(ip):
    """判断IP是否为私有地址和所属类别"""
    ip_int = ip_to_int(ip)
    # '10.0.0.0', '10.255.255.255'
    if 167772160 <= ip_int <= 184549375:
        return 'A'
    # '172.16.0.0', '172.31.255.255'
    elif 2886729728 <= ip_int <= 2887778303:
        return 'B'
    # '192.168.0.0', '192.168.255.255'
    elif 3232235520 <= ip_int <= 3232301055:
        return 'C'
    else:
        # Public ip
        return 0


def is_ipv4(ipv4):
    if re.match(r'^(\d+\.){3}\d+', ipv4):
        return True


def is_valid_ip(ip):
    """有效IP"""
    if ip and is_ipv4(ip) and not ip.startswith(('169.254', '127.0.0')):
        return True


def handle_uuid(uuid):
    """去除空格和 '-'， 并转大写"""
    if uuid:
        return re.sub(r'[ \-]', '', uuid).upper()


def elapsed_time(func):
    """方法耗时计算"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        out = func(*args, **kwargs)
        print(
            '{} elapsed times: {}'.format(
                func.__name__,
                time.time() -
                start))
        return out
    return wrapper


def get_attr(obj, names, put_log=False):
    """
    获取多层属性
    :param obj: host
    :param names: 'summary.quickStats.overallCpuUsage'
    :param put_log: 获取失败是否上报日志
    :return:
    """

    x = obj
    try:
        for i in names.split('.'):
            if x:
                x = getattr(x, i)
        return x
    except Exception as e:
        print(e)
        if put_log:
            report_log('WARN', e)


class VMWareDiscovery(object):
    def __init__(self, args):
        self.ip = args['ip']
        self.port = args.get('port') or 443
        self.user = args['username']
        self.pwd = args['password']
        self.discover_vm_os = args.get('discover_vm_os')
        self.si = None
        self.vc = None
        self.vc_ci = None
        self.dc_cis = {}
        self.cluster_cis = {}
        self.hosts = {}
        self.networks = {}
        # vc_ci, dc_ci, cluster_ci, esxi_ci
        self.host_dc_cluster_ci_map = {}
        self.host_pnics = {}
        self.ds_cis = {}
        self.discovered_datastore = []
        self.discovered_network = []
        self.dvs_port_group = {}
        self.dvs_cis = {}

    def connect(self):
        try:
            requests.urllib3.disable_warnings()
            context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
            self.si = SmartConnect(host=self.ip, user=self.user, pwd=self.pwd,
                                   port=int(self.port), sslContext=context)
            atexit.register(Disconnect, self.si)
            self.vc = self.si.RetrieveContent()
            report_log('INFO', "vSphere {} connect succeed".format(self.ip))
            return self.vc
        except IOError as e:
            report_log('ERROR', "vSphere {} connect failed, please check ip and port, {}".format(
                self.ip, e))
        except Exception as e:
            if hasattr(e, 'msg'):
                report_log('ERROR', "vSphere {} connect failed, {}".format(
                    self.ip, _encode(e.msg)))
            else:
                report_log('ERROR', "vSphere {} connect failed, {}".format(self.ip, e))

    def get_obj(self, vim_type, name=None, to_list=True):
        if not isinstance(vim_type, (list, tuple)):
            vim_type = [vim_type]
        container = self.vc.viewManager.CreateContainerView(
            self.vc.rootFolder, vim_type, True)
        if not to_list:
            return container
        if not name:
            return container.view
        for i in container.view:
            if _encode(unquote(i.name)) == _encode(name):
                return i

    @elapsed_time
    def collect_properties(self, obj_type, path_set=None, view_ref=None):
        """
        使用属性收集器批量获取，加快速度
        https://github.com/vmware/pyvmomi-community-samples/blob/master/samples/vminfo_quick.py
        """
        if view_ref is None:
            view_ref = self.get_obj(obj_type, to_list=False)

        collector = self.si.content.propertyCollector
        # Create object specification to define the starting point of
        # inventory navigation
        obj_spec = pyVmomi.vmodl.query.PropertyCollector.ObjectSpec()
        obj_spec.obj = view_ref
        obj_spec.skip = True

        # Create a traversal specification to identify the path for collection
        traversal_spec = pyVmomi.vmodl.query.PropertyCollector.TraversalSpec()
        traversal_spec.name = 'traverseEntities'
        traversal_spec.path = 'view'
        traversal_spec.skip = False
        traversal_spec.type = view_ref.__class__
        obj_spec.selectSet = [traversal_spec]

        # Identify the properties to the retrieved
        property_spec = pyVmomi.vmodl.query.PropertyCollector.PropertySpec()
        property_spec.type = obj_type

        if not path_set:
            property_spec.all = True

        property_spec.pathSet = path_set

        # Add the object and property specification to the
        # property filter specification
        filter_spec = pyVmomi.vmodl.query.PropertyCollector.FilterSpec()
        filter_spec.objectSet = [obj_spec]
        filter_spec.propSet = [property_spec]

        # Retrieve properties
        props = collector.RetrieveContents([filter_spec])

        data = {}
        for obj in props:
            properties = {}
            for prop in obj.propSet:
                properties[prop.name] = prop.val
            data[obj.obj] = properties
        return data

    def filter_folder(self, child, out=None):
        """过滤各种集群或主机的目录"""
        if out is None:
            out = []
        if isinstance(child, vim.Folder):
            for c in child.childEntity:
                if isinstance(c, vim.Folder):
                    self.filter_folder(c, out)
                else:
                    out.append(c)
        else:
            out.append(child)
        return out

    def discover_vc(self):
        vc_name = self.ip
        for i in self.vc.setting.setting:
            if i.key == 'VirtualCenter.InstanceName':
                vc_name = i.value
                break

        if not is_ipv4(vc_name):
            vc_name = '{}-{}'.format(self.ip, vc_name)
        # vCenter ci
        self.vc_ci = __ci__.create('vCenter', vc_name)
        self.vc_ci['properties'] = {'ip': self.ip,
                                    'port': self.ip,
                                    'version': self.vc.about.version,
                                    # 'user_name': args['username'],
                                    # 'password': args['password'],
                                    'vm_num': 0,
                                    'esxi_num': 0
                                    }
        return self.vc_ci

    def discover_vc_os(self):
        """vCenter 所在操作系统"""
        os_class = 'Windows' if self.vc.about.osType.startswith(
            'win') else 'Linux'
        os_ci = __ci__.create(os_class, self.ip)
        __ci__.createrelationship(self.vc_ci['cid'], os_ci['cid'], 'RunsOn')
        os_ci['properties'] = {'ip': self.ip}

    def discover_dc(self, dc, vc_ci):
        """发现数据中心"""
        # log('INFO', 'Discover DataCenter {}'.format(_encode(dc.name)))
        dc_ci = __ci__.create('vSphereDC', _encode(unquote(dc.name)))
        dc_ci['properties'] = {'vCenter_ip': vc_ci['properties']['ip'],
                               # 'vCenterRef': self.vc_ci['cid'],
                               'vCenter_name': vc_ci['name'],
                               'esxi_num': 0,
                               'vm_num': 0
                               }
        __ci__.createrelationship(vc_ci['cid'], dc_ci['cid'], 'Manages')
        self.dc_cis[dc] = dc_ci
        return dc_ci

    def discover_cluster(self, cluster, vc_ci, dc_ci):
        """发现集群"""
        # log('INFO', 'Discover cluster {}'.format(_encode(unquote(cluster.name))))
        cluster_mem_used_mb = 0
        cluster_cpu_used = 0
        for host in cluster.host:
            if host.summary.quickStats.overallMemoryUsage:
                cluster_mem_used_mb += host.summary.quickStats.overallMemoryUsage
            if host.summary.quickStats.overallCpuUsage:
                cluster_cpu_used += host.summary.quickStats.overallCpuUsage

        cluster_cpu_free = round(
            float(
                cluster.summary.totalCpu -
                cluster_cpu_used) /
            1000,
            2)
        cluster_mem_free = cluster.summary.totalMemory - \
            (cluster_mem_used_mb * 1024 * 1024)

        cluster_ci = __ci__.create(
            'vSphereCluster',
            cluster.name.encode('utf8'))
        cluster_ci['properties'] = {'vCenter_ip': vc_ci['properties']['ip'],
                                    'vCenter_name': vc_ci['name'],
                                    'vSphereDC_name': dc_ci['name'],
                                    # 'vCenterRef': vc_ci['cid'],
                                    # 'vSphereDCRef': dc_ci['cid'],
                                    'esxi_num': len(cluster.host),
                                    'vm_num': 0,
                                    'vcluster_cpu_free': '{} Ghz'.format(cluster_cpu_free),
                                    'vcluster_memory_free': convert_bytes(cluster_mem_free)
                                    }
        __ci__.createrelationship(dc_ci['cid'], cluster_ci['cid'], 'Contains')
        self.cluster_cis[cluster] = cluster_ci
        return cluster_ci

    @staticmethod
    def handle_key_any_value(obj):
        return {i.key: i.value for i in obj}

    # @elapsed_time
    def discover_esxi(self, host, vc_ci, dc_ci, cluster_ci):
        """发现ESXi"""
        host_name = unquote(_encode(host['name']))
        config_manager = host['configManager']
        config = host['config']
        summary = host['summary']
        hardware = host['hardware']

        vc_ci['properties']['esxi_num'] += 1
        dc_ci['properties']['esxi_num'] += 1

        if _encode(summary.runtime.connectionState) == 'disconnected':
            report_log('WARN', 'ESXi {} is disconnected, ignore'.format(host_name))
            return

        if not config:
            report_log('WARN', 'ESXi {} not config, ignore'.format(host_name))
            return

        manage_ip = None
        if is_valid_ip(host_name):
            manage_ip = host_name
        nics = {}
        ips = []
        pnics = {}
        self.host_pnics[str(summary.host)] = pnics

        nic_subnet = {}
        # 物理网卡的邻居信息
        # vim.host.PhysicalNic.NetworkHint
        for hint in config_manager.networkSystem.QueryNetworkHint():
            if hasattr(hint, 'lldpInfo') and hint.lldpInfo:
                # vim.host.PhysicalNic.LldpInfo
                parameter = {i.key: i.value for i in hint.lldpInfo.parameter}
                pnics[hint.device] = {
                    'neighbor_hostname': parameter.get('System Name'),
                    'neighbor_portmac': hint.lldpInfo.chassisId,
                    'neighbor_portname': hint.lldpInfo.portId,
                }
            elif hint.connectedSwitchPort:
                # vim.host.PhysicalNic.CdpInfo
                # https://kb.vmware.com/s/article/1007069
                pnics[hint.device] = {
                    'neighbor_hostname': hint.connectedSwitchPort.devId,
                    'neighbor_portmac': None,
                    'neighbor_portname': hint.connectedSwitchPort.portId,
                }
            subnets = []
            for i in hint.subnet:
                subnet = i.ipSubnet
                if i.vlanId != 0:
                    subnet += '(VLAN{})'.format(i.vlanId)
                subnets.append(subnet)
            nic_subnet[hint.device] = ','.join(subnets)

        # 物理网卡信息
        for pnic in config.network.pnic:
            pname = pnic.device
            mac = pnic.mac
            if pname not in pnics:
                pnics[pname] = {}
            pnics[pname]['mac_addr'] = mac
            pnics[pname]['link_peer'] = '{}.{}'.format(host_name, pname)
            speed = pnic.linkSpeed.speedMb if pnic.linkSpeed else None
            nics[mac] = {
                'name': pnic.device,
                'mac': pnic.mac,
                'pci': pnic.pci,
                'driver': pnic.driver,
                'speedMb': speed,
                'status': 'Connected' if speed else 'Not Connected'
            }
            # 取最大网卡速率
            sps = [i.speedMb for i in pnic.validLinkSpecification]
            if sps:
                nics[mac]['maxSpeedMb'] = '{} Mbps'.format(max(sps))

        # 取网卡IP
        for vnic in config.network.vnic:
            mac = vnic.spec.mac
            ip = vnic.spec.ip.ipAddress
            if is_valid_ip(ip):
                ips.append(ip)
            if vnic.portgroup == "Management Network" or \
                    'mgmt' in vnic.portgroup.lower():
                manage_ip = ip

            if not nics.get(mac):
                nics[mac] = {}
            nics[mac].update({'v_name': vnic.device,
                              'ips': ip,
                              'portgroup': vnic.portgroup})
        if not ips:
            report_log('INFO', json.dumps(nics))

        # min_mac = min(nics.keys())
        if not manage_ip:
            for mac, nic in nics.items():
                if is_valid_ip(nic.get('ip')) and 'vMotion' not in nic.get(
                        'portgroup', ''):
                    manage_ip = nic.get('ip')
                    break
        if not manage_ip and ips:
            manage_ip = ips[0]

        # ESXi Ci
        hostname = dns_server = None
        if config_manager and config_manager.networkSystem.dnsConfig:
            hostname = config_manager.networkSystem.dnsConfig.hostName
            dns_server = config_manager.networkSystem.dnsConfig.address

        esxi_ci = __ci__.create('ESXi', '{}-{}'.format(manage_ip, host_name))
        esxi_ci['properties'] = {
            'ip': manage_ip,
            'ips': ','.join(ips),
            'vm_num': 0,
            'bits': '64',
            'hostname': hostname,
            'dns_server': dns_server,
            'os_ver_detl': 'ESXi {}'.format(summary.config.product.version),
            'cpu_core_num': summary.hardware.numCpuCores,  # CPU 核心数
            # 内存总量 GB
            'memory_size': convert_bytes(summary.hardware.memorySize),
            # 'vCenterRef': vc_ci['cid'],
            # 'vSphereDCRef': dc_ci['cid']
        }
        # 可能没有集群, 数据中心直接管理ESXi
        if cluster_ci:
            __ci__.createrelationship(
                cluster_ci['cid'], esxi_ci['cid'], 'Contains')
            # esxi_ci['properties']['vSphereClusterRef'] = cluster_ci['cid']
        else:
            __ci__.createrelationship(dc_ci['cid'], esxi_ci['cid'], 'Contains')

        if config_manager:
            if config_manager.dateTimeSystem.dateTimeInfo:
                esxi_ci['properties']['time_zone'] = \
                    config_manager.dateTimeSystem.dateTimeInfo.timeZone.name
                esxi_ci['properties']['ntp_server'] = \
                    ','.join(
                    config_manager.dateTimeSystem.dateTimeInfo.ntpConfig.server)

        # 获取SN
        try:
            sn = hardware.systemInfo.serialNumber.strip()
        except BaseException:
            sn = None
        if not sn:
            for i in summary.hardware.otherIdentifyingInfo:
                if isinstance(i, vim.host.SystemIdentificationInfo) \
                        and i.identifierValue \
                        and i.identifierValue.strip() \
                        and i.identifierType.key == 'ServiceTag' \
                        and i.identifierValue not in ['00', '11', '123456789', 'Chassis Serial Number'] \
                        and not re.search(r'123456789|O\.E\.M', i.identifierValue):
                    sn = i.identifierValue.strip()
                    break

        # PCServer CI
        brand = match_brand(hardware.systemInfo.vendor)
        model = re.sub(r'-\[.*\]-', '', hardware.systemInfo.model).strip()
        pc_name = '{}/{}'.format(model, sn)
        pc_ci = __ci__.create('PCServer', pc_name)
        __ci__.createrelationship(esxi_ci['cid'], pc_ci['cid'], 'RunsOn')
        pc_ci['properties'] = {
            # 'ip': manage_ip,
            'os_ip': manage_ip,
            'ips': ','.join(ips),
            # 'minMacAddr': min_mac,
            # 'os': summary.config.product.name,
            'uuid': handle_uuid(hardware.systemInfo.uuid),
            'serial_number': sn,  # 序列号
            'pcserver_brand': brand.lower(),  # 厂商
            'model': model,  # 型号
            'cpu_model': summary.hardware.cpuModel,  # CPU 型号
            'cpu_phys_num': summary.hardware.numCpuPkgs,  # CPU 物理核心数
            # CPU 频率 GHz
            'cpu_speed_clock': '{} GHz'.format(round(float(summary.hardware.cpuMhz) / 1000, 2)),
            # 内存总量 GB
            'memory_size': convert_bytes(summary.hardware.memorySize),
            'firmware': get_attr(hardware, 'biosInfo.biosVersion'),
            # 'power_supply_mode': get_attr(config_manager, 'powerSystem.info.currentPolicy.shortName')
        }

        self.discover_hba(config_manager, esxi_ci, pc_ci)

        # 主机的物理网卡
        pci_devices = {p.id: p.deviceName for p in hardware.pciDevice}
        # print nics
        for mac, nic in nics.items():
            if not nic.get('name'):
                continue
            # ESXi OsNiC
            os_nic_ci = __ci__.create('osNIC', nic['name'])
            __ci__.createrelationship(esxi_ci['cid'], os_nic_ci['cid'], "Inlines")
            os_nic_ci['properties'] = {
                'mac_addr': mac,
                'ips': nic.get('ips'),
                'driver_version': nic.get('driver'),
                'status': nic.get('status'),
                'ip_ranges': nic_subnet.get(nic['name'])
            }

            # PCServer ServerNIC
            p_name = pci_devices.get(nic.get('pci')) or nic['name']
            pnic_ci = __ci__.create('serverNIC', p_name)
            __ci__.createrelationship(pc_ci['cid'], pnic_ci['cid'], "Inlines")
            pnic_ci['properties'] = {
                'mac_addr': mac,
                'nic_speed': nic.get('maxSpeedMb'),
            }

        self.host_dc_cluster_ci_map[summary.host] = [
            vc_ci, dc_ci, cluster_ci, esxi_ci]
        # log('INFO', 'Discover ESXi: {}'.format(host_name))
        # return esxi_ci, pc_ci

    def discover_vm(self, vm):
        """发现虚拟机"""
        summary = vm['summary']
        config = vm.get('config')
        runtime = vm['runtime']
        guest = vm['guest']
        vm_name = _encode(unquote(vm['name']))

        if not config or (summary.overallStatus == 'gray' and not config.instanceUuid):
            report_log('WARN', 'VM {} not available, ignore'.format(vm_name))
            return

        if not self.host_dc_cluster_ci_map.get(runtime.host):
            report_log('WARN', 'VM {} Belongs esxi not available, ignore'.format(vm_name))
            return
        vc_ci, dc_ci, cluster_ci, esxi_ci = self.host_dc_cluster_ci_map[runtime.host]

        if not config.template:
            vc_ci['properties']['vm_num'] += 1
            dc_ci['properties']['vm_num'] += 1
            esxi_ci['properties']['vm_num'] += 1
            if cluster_ci:
                cluster_ci['properties']['vm_num'] += 1

        # 个别情况VM迁移失败会变成孤立状态
        # if runtime.connectionState == 'orphaned':
        #     log('WARN', 'VM {} is orphaned, ignore'.format(vm_name))
        #     return

        # if not summary:
        #     log('WARN', 'VM {} not summary data, ignore'.format(vm_name))
        #     return

        vm_class = 'VmTemplate' if config.template else 'VM'

        uuid = handle_uuid(summary.config.instanceUuid) or vm_name
        # 孤立虚拟机uuid 添加 '_orphaned'，与正常VM区分
        power_state = runtime.powerState
        if runtime.connectionState == 'orphaned':
            uuid += '_orphaned'
            vm_name += '(已孤立)'

        os_ip = guest.ipAddress
        if not is_valid_ip(os_ip):
            os_ip = None

        comment = None
        if config.annotation:
            comment = _encode(config.annotation)

        vm_ci = __ci__.create(vm_class, vm_name)
        vm_ci['properties'] = {
            # 'ip': os_ip,
            'os_ip': os_ip,
            'uuid_bios': handle_uuid(summary.config.uuid),       # BIOS uuid
            'uuid': uuid,    # 实例 uuid
            'comment': comment,   # 备注
            'power_state': power_state,
            'hostname': guest.hostName,
            'vmtools_state': guest.toolsStatus,
            'vmtools_version': guest.toolsVersion,           # 未安装时版本为0
            'cpu_core_num': summary.config.numCpu,
            'memory_size': convert_bytes(summary.config.memorySizeMB, src_unit='MB'),
            # 'vCenterRef': vc_ci['cid'],
            # 'vSphereDCRef': dc_ci['cid'],
            # 'vSphereClusterRef': cluster_ci['cid'] if cluster_ci else None,
            'hypervisor_ip': esxi_ci['properties']['ip'],
        }

        if vm_class == 'VM':
            __ci__.createrelationship(vm_ci['cid'], esxi_ci['cid'], 'RunsOn')
        else:
            parent_ci = cluster_ci or esxi_ci
            __ci__.createrelationship(vm_ci['cid'], parent_ci['cid'], 'RunsOn')

        all_disk_size_kb = 0
        vnics = {}
        devices = {i.key: i for i in config.hardware.device}
        vm_ctrl_types = {
            vim.VirtualIDEController: 'IDE',
            vim.VirtualSATAController: 'SATA',
            vim.VirtualAHCIController: 'SATA',
            vim.VirtualSCSIController: 'SCSI',
            vim.ParaVirtualSCSIController: 'SCSI',
            vim.VirtualLsiLogicController: '(LSI Logic)SCSI',
            vim.VirtualLsiLogicSASController: '(LSI Logic SAS)SCSI',
            vim.VirtualBusLogicController: '(BusLogic)SCSI',
        }
        for device in config.hardware.device:
            # 虚拟机磁盘
            if isinstance(device, vim.VirtualDisk):
                controller = devices[device.controllerKey]
                # print vm_name, device.deviceInfo.label, device.controllerKey, type(controller)
                if vm_ctrl_types.get(type(controller)):
                    virtual_device_node = vm_ctrl_types[type(controller)] + \
                        ' {}:{}'.format(controller.busNumber, device.unitNumber)
                else:
                    virtual_device_node = '{}:{}'.format(
                        controller.deviceInfo.label, device.unitNumber)

                all_disk_size_kb += device.capacityInKB
                if get_attr(device, 'backing.thinProvisioned'):
                    disk_type = '精简置备'
                elif get_attr(device, 'backing.eagerlyScrub'):
                    disk_type = '厚置备快速置零'
                else:
                    disk_type = '厚置备延迟置零'

                vdisk_ci = __ci__.create('vmDisk', device.deviceInfo.label)
                vdisk_ci['properties'] = {
                    'disk_size': convert_bytes(device.capacityInBytes),
                    'datastore_name': device.backing.datastore.name,
                    'vm_disk_type': disk_type,
                    'vm_disk_mode': device.backing.diskMode,
                    'virtual_device_node': virtual_device_node
                }

                __ci__.createrelationship(
                    vm_ci['cid'], vdisk_ci['cid'], 'Inlines')

            # 虚拟机网卡
            elif isinstance(device, vim.VirtualEthernetCard):
                vnics[device.macAddress] = {
                    'name': device.deviceInfo.label, 'ips': []}
                if isinstance(device.backing,
                              vim.VirtualEthernetCard.NetworkBackingInfo):
                    network_name = device.backing.network.name
                elif isinstance(device.backing,
                                vim.VirtualEthernetCard.DistributedVirtualPortBackingInfo):
                    network_name = self.dvs_port_group.get(
                        device.backing.port.portgroupKey)
                else:
                    network_name = None
                vnic_ci = __ci__.create('vmNIC', device.deviceInfo.label)
                vnic_ci['properties'] = {'mac_addr': device.macAddress,
                                         'network_name': network_name}
                __ci__.createrelationship(
                    vm_ci['cid'], vnic_ci['cid'], 'Inlines')

        ips = []
        for nic in guest.net:
            if not nic.macAddress:
                continue
            ipconfig = nic.ipConfig
            if ipconfig:
                for i in ipconfig.ipAddress:
                    if is_valid_ip(i.ipAddress):
                        if not vnics.get(nic.macAddress):
                            vnics[nic.macAddress] = {'ips': []}
                        vnics[nic.macAddress]['network'] = nic.network
                        vnics[nic.macAddress]['ips'].append(i.ipAddress)
                        ips.append(i.ipAddress)
        # if vnics:
        #     vm_ci['properties']['minMacAddr'] = min(vnics.keys())
        vm_ci['properties']['phys_size'] = convert_bytes(
            all_disk_size_kb, src_unit='KB')

        # 按公网地址>A>B>C 优先级排序
        ips = sorted(ips, key=lambda x: is_private_ip(x))
        vm_ci['properties']['ips'] = ','.join(ips)
        if ips:
            os_ip = ips[0]

        # 安装 docker virbr0 都存在相同IP 192.168.122.1
        if os_ip == '192.168.122.1':
            for i in ips:
                if i != '192.168.122.1':
                    os_ip = i

        # 定制开发，指定IP段优先级
        # 中粮
        # ip_prefix1 = ('10.6',)
        # ip_prefix2 = ('10.6', '152.5')
        # 环保部
        # ip_prefix1 = ('10.', '2')
        # ip_prefix2 = ('10.251', )

        vm_ci['properties']['os_ip'] = os_ip

        # 去除关机状态下 guest 缓存的IP
        if runtime.powerState == 'poweredOff':
            vm_ci['properties']['os_ip'] = None
            vm_ci['properties']['ips'] = None

        if self.discover_vm_os == "yes":
            # 只有安装了vmtools 且有IP的虚拟机才发现操作系统
            guest_os_dict = {'linuxGuest': 'Linux', 'windowsGuest': 'Windows'}
            os_class = guest_os_dict.get(guest.guestFamily)
            os_ip = vm_ci['properties']['os_ip']
            if guest.ipAddress and os_class and os_ip:
                vm_os_ci = __ci__.create(
                    os_class, '{}-{}'.format(os_ip, guest.hostName))
                vm_os_ci['properties'] = {
                    'ip': os_ip,
                    'ips': ','.join(ips),
                    'hostname': guest.hostName,
                    # BIOS uuid
                    'serial_number': handle_uuid(summary.config.uuid),
                }
                __ci__.createrelationship(vm_os_ci['cid'], vm_ci['cid'], 'RunsOn')

        return vm_ci

    @elapsed_time
    def discover_vms(self):
        vm_properties = ['name', 'config', 'summary', 'runtime', 'guest']
        vm_data = self.collect_properties(vim.VirtualMachine, vm_properties)
        report_log('INFO', 'Get {} VM and VmTemplate'.format(len(vm_data)))
        for vm_obj, vm_data in vm_data.items():
            self.discover_vm(vm_data)

    @staticmethod
    def discover_os_nic(nics, esxi_ci):
        """ ESXi osNIC """
        # 所有pci设备
        for mac, info in nics.items():
            # 取最大网卡速率
            nic_ci = __ci__.create('osNIC', info['name'])
            __ci__.createrelationship(esxi_ci['cid'], nic_ci['cid'], "Inlines")
            nic_ci['properties'] = {'mac_addr': mac,
                                    'ips': info['ip'],
                                    'driver_version': info.get('driver')}

    @staticmethod
    def discover_hba(config_manager, esxi_ci, pc_ci):
        """光纤HBA卡"""
        if not config_manager.storageSystem or\
                not config_manager.storageSystem.storageDeviceInfo:
            return
        adps = config_manager.storageSystem.storageDeviceInfo.hostBusAdapter
        wwns = []
        for adp in adps:
            if isinstance(adp, vim.host.FibreChannelHba):
                # print adp
                wwn = int_to_hex(adp.portWorldWideName, sep='').upper()
                if wwn in wwns:
                    continue

                wwns.append(wwn)
                hba_ci = __ci__.create('serverHBA', adp.model)
                __ci__.createrelationship(
                    pc_ci['cid'], hba_ci['cid'], 'Inlines')
                hba_ci['properties'] = {
                    'wwn': wwn,
                    'wwnn': int_to_hex(adp.nodeWorldWideName, sep='').upper(),
                    'hba_speed': '{} Gbps'.format(adp.speed),
                    'hba_slot_id': None
                }

                os_hba_ci = __ci__.create('OsHBA', adp.device)
                __ci__.createrelationship(
                    esxi_ci['cid'], os_hba_ci['cid'], 'Inlines')
                os_hba_ci['properties'] = {
                    'wwn': wwn,
                    'status': adp.status,
                    'firmware': None,
                    'driver_version': adp.driver,
                }

    @elapsed_time
    def discover_datastore(self):
        """发现数据存储"""
        # 如果可以多机访问则不是本地磁盘
        ds_properties = ['name', 'summary', 'info', 'host']
        datastores = self.collect_properties(vim.Datastore, ds_properties)
        report_log('INFO', 'Get {} Datastore'.format(len(datastores)))
        for ds_obj, ds in datastores.items():
            name = ds['name']
            summary = ds['summary']
            info = ds['info']
            hosts = ds['host']
            is_local = 'no' if summary.multipleHostAccess else None
            if is_local is not None:
                if hasattr(info, 'vmfs'):
                    if info.vmfs.local:
                        is_local = 'yes'
                    elif info.vmfs.local is False:
                        is_local = 'no'
                else:
                    is_local = 'no'

            # 计算已置备空间和置备率
            provisioned_space = summary.capacity - summary.freeSpace
            if summary.uncommitted:
                provisioned_space += summary.uncommitted
            if summary.capacity:
                provisioned_spare = round(
                    float(provisioned_space) /
                    float(
                        summary.capacity) *
                    100,
                    2)
            else:
                provisioned_spare = None

            ds_ci = __ci__.create('dataStore', name)
            ds_ci['properties'] = {
                'lun_size': convert_bytes(summary.capacity),
                'avl_size': convert_bytes(summary.freeSpace),
                'local_disk_flag': is_local,
                'datastore_disk_type': summary.type,
                'provisioned_space': convert_bytes(provisioned_space),
                'provisioned_spare': provisioned_spare
            }
            if isinstance(info, vim.NasDatastoreInfo):
                ds_ci['properties']['lun_id'] = info.nas.remoteHost
            elif isinstance(info, vim.VmfsDatastoreInfo):
                ds_ci['properties']['datastore_disk_type'] = 'SSD' if info.vmfs.ssd else 'HDD'
                ds_ci['properties']['local_disk_flag'] = 'yes' if info.vmfs.local else is_local
                ds_ci['properties']['lun_id'] = ','.join(
                    [i.diskName.lstrip('naa.') for i in info.vmfs.extent])

            self.ds_cis[ds_obj] = ds_ci

            # 根据存储的主机，判断存储属于
            cluster_cis = []
            host_cis = []
            for h in hosts:
                if self.host_dc_cluster_ci_map.get(h.key):
                    cluster_ci, host_ci = self.host_dc_cluster_ci_map[h.key][-2:]
                    if cluster_ci and cluster_ci not in cluster_cis:
                        cluster_cis.append(cluster_ci)
                    host_cis.append(host_ci)

            if is_local == 'yes':
                # 本地存储，
                __ci__.createrelationship(
                    host_cis[0]['cid'], ds_ci['cid'], 'Inlines')

            elif cluster_cis:
                for cluster_ci in cluster_cis:
                    __ci__.createrelationship(
                        cluster_ci['cid'], ds_ci['cid'], 'Inlines')

    @elapsed_time
    def discover_res_pool(self):
        """发现资源池, 放在集群发现之后"""
        rp_properties = ['name', 'vm', 'owner', 'parent']
        res_pools = self.collect_properties(vim.ResourcePool, rp_properties)
        report_log('INFO', 'Get {} ResourcePool'.format(len(res_pools)))
        for res_pool in res_pools.values():
            if isinstance(res_pool['parent'], vim.ClusterComputeResource):
                continue
            cluster_ci = self.cluster_cis.get(res_pool['owner'])
            if cluster_ci:
                res_pool_ci = __ci__.create('vSphereRP', _encode(res_pool['name']))
                res_pool_ci['properties'] = {'vm_num': len(res_pool['vm'])}
                __ci__.createrelationship(
                    cluster_ci['cid'], res_pool_ci['cid'], 'Inlines')

    def discover_host_network(
            self, host_config, host_network, vc_ci, dc_ci, cluster_ci):
        """发现ESXi上的网络"""
        port_groups = {}
        for i in host_config.network.portgroup:
            port_groups[i.spec.name] = i.spec.vlanId

        for net in host_network:
            if net in self.discovered_network:
                continue
            vlan_id = None
            if isinstance(net, vim.dvs.DistributedVirtualPortgroup):

                uplink = False
                for tag in net.tag:
                    if tag.key == 'SYSTEM/DVS.UPLINKPG':
                        uplink = True
                if uplink:
                    self.discovered_network.append(net)
                    continue

                if hasattr(net.config.defaultPortConfig.vlan, 'vlanId') and \
                        isinstance(net.config.defaultPortConfig.vlan.vlanId, int):
                    vlan_id = net.config.defaultPortConfig.vlan.vlanId
            else:
                vlan_id = port_groups.get(net.name)

            # print type(net), vlan_id
            # 忽略没有vlan id 的网络
            # if vlan_id is None:
            #     continue

            net_ci = __ci__.create('vSphereNetwork', net.name)
            net_ci['properties'] = {'vlan_id': vlan_id,
                                    'vCenter_ip': vc_ci['properties']['ip'],
                                    'vSphereDC_name': dc_ci['name']
                                    }
            __ci__.createrelationship(dc_ci['cid'], net_ci['cid'], 'Manages')

            if cluster_ci:
                net_ci['properties']['vSphereCluster_name'] = cluster_ci['name']
                # net_ci['properties']['vSphereClusterRef'] = cluster_ci['cid']

            self.discovered_network.append(net)

    def get_parent(self, obj, parent_type=vim.Datacenter):
        """递归查找父节点，直到为指定类型"""
        if isinstance(obj, parent_type):
            return obj
        return self.get_parent(obj.parent, parent_type)

    def discover_dvs(self):
        for dvs in self.get_obj(vim.DistributedVirtualSwitch):
            dc_ci = self.dc_cis.get(self.get_parent(dvs))
            dvs_ci = __ci__.create('vSphereDVS', _encode(dvs.name))
            dvs_ci['properties'] = {
                'uuid': handle_uuid(dvs.uuid),
                'port_nums': dvs.summary.numPorts,
                'vCenter_ip': dc_ci['properties']['vCenter_ip'],
                'vSphereDC_name': dc_ci['name']
            }
            self.dvs_cis[dvs] = dvs_ci
            __ci__.createrelationship(dc_ci['cid'], dvs_ci['cid'], 'Manages')

            for port in dvs.FetchDVPorts():
                if not port.connectee:
                    continue
                port_ci = None
                if port.connectee.type == 'vmVnic':
                    if port.state and port.state.runtimeInfo:
                        port_ci = __ci__.create(
                            'vSphereDVSPort', port.config.name or port.key)
                        port_ci['properties'] = {
                            'port_id': port.key,
                            'mac_addr': port.state.runtimeInfo.macAddress,
                            'link_peer': port.state.runtimeInfo.linkPeer,

                        }
                # elif port.connectee.type == 'pnic':
                else:
                    # 上行端口
                    if port.connectee and port.connectee.connectedEntity:
                        port_ci = __ci__.create(
                            'vSphereDVSUpLinkPort', port.config.name or port.key)
                        port_ci['properties'] = {
                            'port_id': port.key,
                        }
                        port_ci['properties'].update(
                            self.host_pnics.get(str(port.connectee.connectedEntity), {}).get(
                                port.connectee.nicKey, {}))
                if port_ci:
                    __ci__.createrelationship(
                        dvs_ci['cid'], port_ci['cid'], 'Inlines')

    @elapsed_time
    def discover(self):
        """发现总入口"""
        if not self.connect():
            return False
        vc_ci = self.discover_vc()
        self.discover_vc_os()

        host_properties = [
            'name',
            'config',
            'summary',
            'configManager',
            'hardware',
            'network']
        self.hosts = self.collect_properties(vim.HostSystem, host_properties)
        report_log('INFO', 'Get {} hosts'.format(len(self.hosts)))

        # 分布式网络名称
        self.dvs_port_group = {net.key: _encode(net.name) for net in
                               self.get_obj(vim.dvs.DistributedVirtualPortgroup)}

        # 数据中心
        dcs = self.get_obj(vim.Datacenter)
        report_log('INFO', 'Get {} Datacenter'.format(len(dcs)))
        for dc in dcs:
            dc_ci = self.discover_dc(dc, vc_ci)

            # 排出集群目录
            clusters = self.filter_folder(dc.hostFolder)

            # 集群, ESXi 也可以不在集群内
            for cluster in clusters:
                cluster_ci = None
                if isinstance(cluster, vim.ClusterComputeResource):
                    cluster_ci = self.discover_cluster(cluster, vc_ci, dc_ci)

                # ESXi
                for host in cluster.host:
                    host = self.hosts[host]
                    self.discover_esxi(host, vc_ci, dc_ci, cluster_ci)
                    # try:
                    #     pass
                    # except Exception as e:
                    #     log('ERROR', 'Discover ESXi {} failed, {}'.format(host['name'], e))
                    # Host Network
                    self.discover_host_network(host['config'], host['network'],
                                               vc_ci, dc_ci, cluster_ci)
        # 发现资源池
        self.discover_res_pool()

        # 分布式交换机
        # self.discover_dvs()

        # 发现存储
        self.discover_datastore()

        # 发现VM
        self.discover_vms()

        return True


class CalcCMDBData(object):
    def __init__(self, base_url, api_key):
        self.client = Service(base_url, api_key)
        # 将本次发现的资源按类型分类
        self.current_cis = {}
        for i in __ci__.citypes:
            if i['code'] not in self.current_cis:
                self.current_cis[i['code']] = []
            self.current_cis[i['code']].append(i)

        self.vc_cis = []
        self.dc_cis = []
        self.cluster_cis = []
        self.esxi_cis = []
        self.vm_cis = []
        self.vm_template_cis = []
        self.network_cis = []

        self.cmdb_cis = {}
        self.get_cmdb_cis()

    def get_relation_cis(self, src_ci, dst_code):
        cis = []
        for r in self.client.relations_query(
                src_id=src_ci.id, dst_clz_code=dst_code):
            cis.append(r.dst_ci)
        return cis

    def get_cmdb_cis(self):
        # 本次发现对 vCenter IP
        vc_ips = [i['properties']['ip']
                  for i in self.current_cis.get('vCenter', [])]
        # vc_ips = ['10.1.5.251']
        if not vc_ips:
            return
        # 根据vCenter ip, 查询CMDB中的 vc_ci
        self.vc_cis = self.client.query_cis(conditions=[
            {"field": "classCode", "value": 'vCenter'},
            {"field": "ip", "value": vc_ips, 'operator': 'IN'}
        ])

        # 批量查询一次所有资源
        self.client.get_cis_by_code(
            'vSphereDC', 'vSphereCluster', 'ESXi',
            'VM', 'vSphereNetwork', 'VmTemplate')

        # 根据 vCenter 与 vSphereDC 的关系查询 dc_ci
        for vc in self.vc_cis:      # type: CiInstance
            self.dc_cis.extend(self.get_relation_cis(vc, 'vSphereDC'))

        for dc in self.dc_cis:      # type: CiInstance
            # vSphereDC 包含 vSphereCluster
            self.cluster_cis.extend(self.get_relation_cis(dc, 'vSphereCluster'))

            # vSphereDC 包含 ESXi
            self.esxi_cis.extend(self.get_relation_cis(dc, 'ESXi'))

            # vSphereDC 包含 vSphereNetwork
            self.network_cis.extend(self.get_relation_cis(dc, 'vSphereNetwork'))

        for cluster in self.cluster_cis:
            # vSphereCluster 包含 ESXi
            self.esxi_cis.extend(self.get_relation_cis(cluster, 'ESXi'))

            # vSphereCluster 包含 VmTemplate
            self.vm_template_cis.extend(self.get_relation_cis(
                cluster, 'VmTemplate'))

        # ESXi 和 VM 可能很多，批量查询再过滤，提高性能，
        all_esxi_vm_rel = self.client.relations_query(
            src_clz_code='VM', dst_clz_code='ESXi')
        for r in all_esxi_vm_rel:
            if r.dst_ci in self.esxi_cis:
                self.vm_cis.append(r.src_ci)

        self.cmdb_cis = {
            'vCenter': self.vc_cis,
            'vSphereDC': self.dc_cis,
            'vSphereCluster': self.cluster_cis,
            'vSphereNetwork': self.network_cis,
            'ESXi': self.esxi_cis,
            'VM': self.vm_cis,
            'VmTemplate': self.vm_template_cis,
        }

    def calc_deleted(self, class_code, keys, state_code='resource_state'):
        """
        根据资源的关键属性比对，判断CDMB中的资源是否已删除
        :param class_code: 模型code
        :param keys: 关键属性code
        :param state_code: 要修改的状态字段code
        :return:
        """
        if isinstance(keys, basestring):
            keys = [keys]
        # 本次发现的资源, 把所以关键属性找出来
        discover_ci_keys = []
        for i in self.current_cis.get(class_code, []):
            key_values = []
            for key in keys:
                value = i['name'] if key == 'name' else i['properties'].get(key, '')
                key_values.append(_encode(value))
            discover_ci_keys.append('&'.join(key_values))

        # print keys
        # print new_ci_keys

        data = []
        data1 = []

        # CMDB中的资源
        delete_ci_nums = 0
        cmdb_cis = self.cmdb_cis.get(class_code, [])
        for ci in cmdb_cis:
            cmdb_ci_key = '&'.join([str(getattr(ci, key, '')) for key in keys])
            # print ci_key
            if cmdb_ci_key not in discover_ci_keys:
                delete_ci_nums += 1
                if _encode(getattr(ci, state_code)) != '已删除':
                    data.append({'id': ci.id, state_code: '已删除'})
            else:
                if _encode(getattr(ci, state_code)) == '已删除':
                    data1.append({'id': ci.id, state_code: ''})

        report_log('INFO', 'Calc {}: CMDB {}, Discovery {}, Deleted {}'.format(
            class_code, len(cmdb_cis),
            len(self.current_cis.get(class_code, [])),
            delete_ci_nums))
        if data:
            # __ci__.result_log('INFO', json.dumps(data))
            out = self.client.batch_save_res(data, source='discovery')
            print out
            # if out:
            #     for i in out:
            #         ci = self.client.get_ci_by_id(i.get('item'))
            #         print ci.name, i['data']
        if data1:
            out = self.client.batch_save_res(data1, source='discovery')
            print out

    def calc_all_deleted(self, state_code='resource_state'):
        # 模型关键属性对应表
        class_keys = {
            'vCenter': ['ip'],
            'vSphereDC': ['name', 'vCenter_ip'],
            'vSphereCluster': ['name', 'vCenter_ip', 'vSphereDC_name'],
            'vSphereNetwork': ['name', 'vCenter_ip', 'vlan_id'],
            'ESXi': ['ip'],
            'VmTemplate': ['uuid'],
            'VM': ['uuid'],
        }
        for code, attrs in class_keys.items():
            self.calc_deleted(code, attrs, state_code)

    def delete_vm_esxi_relations(self):
        """通过store res openapi 计算已存在的关系与新发现的关系是否相同，不同则删除CMDB中的关系"""
        # CMDB 查询资源和关系
        vm_cis = self.client.get_cis_by_code('VM')
        esxi_cis = self.client.get_cis_by_code('ESXi')
        cmdb_vm_esxi_rels = self.client.relations_query(
            'RunsOn', src_clz_code='VM', dst_clz_code='ESXi')

        # log('INFO', 'CMDB get {} VM, {} ESXI, {} relations'.format(
        #     len(vm_cis), len(esxi_cis), len(old_relations)
        # ))

        # CMDB仓库查到的资源，转为关键属性为key的字典
        cmdb_vm_dict = {i.uuid: i for i in vm_cis}
        cmdb_esxi_dict = {i.ip: i for i in esxi_cis}

        # print cmdb_esxi_dict

        # CMDB仓库查到的VM与ESXi关系，转为VM ci为key的字典
        cmdb_vm_esxi_rel_dict = {i.src_ci: i for i in cmdb_vm_esxi_rels}

        report_log('INFO', 'CMDB get {} VM RunsOn ESXI relations'.format(
            len(cmdb_vm_esxi_rel_dict)))

        self.cmdb_vm_esxi_rel_dict = cmdb_vm_esxi_rel_dict
        # print cmdb_relation_dict

        # 新发现的VM和ESXi 资源，转为 {cid: ci}
        new_vm_dict = {i['cid']: i for i in self.current_cis.get('VM', [])}
        new_esxi_dict = {i['cid']: i for i in self.current_cis.get('ESXi', [])}

        # 过滤出VM和ESXi 的关系, 转为 {vm_cid: esxi_cid}
        new_vm_esxi_rel_dict = {}
        for r in __ci__.relations:
            if r['type'] == 'RunsOn' and r['source'] in new_vm_dict and r['target'] in new_esxi_dict:
                new_vm_esxi_rel_dict[r['source']] = r['target']

        # print new_vm_dict.keys()
        # print new_vm_esxi_rel

        delete_rel = 0
        for new_vm in new_vm_dict.values():
            # 通过uuid关键属性判断新发现VM在CMDB是否存在

            vm_ci = cmdb_vm_dict.get(new_vm['properties']['uuid'])
            # print "vm_ci", new_vm['name'], vm_ci
            if not vm_ci:
                continue

            # 在本次新发现的关系中获取VM RunsON 的 ESXi
            esxi_cid = new_vm_esxi_rel_dict.get(new_vm['cid'])
            # print "esxi_cid", esxi_cid
            if not esxi_cid:
                continue

            # 通过 esxi 的 IP 获取对应CMDB中的 ESXi CI
            esxi_ci = cmdb_esxi_dict.get(
                new_esxi_dict[esxi_cid]['properties']['ip'])
            # print "esxi_ci", esxi_ci

            # 获取VM在CMDB中已存在的关系
            cmdb_rel = cmdb_vm_esxi_rel_dict.get(vm_ci)
            # print "cmdb_rel", cmdb_rel

            # 当CMDB中已存在关系，且ESXi与本次发现的ESXi 不同时，删除CMDB关系
            if cmdb_rel and cmdb_rel.dst_ci != esxi_ci:
                # print 'cmdb_dst_ci', cmdb_rel.dst_ci
                delete_rel += 1
                report_log('INFO', 'DELETE {}'.format(cmdb_rel))
                try:
                    print(cmdb_rel.delete())
                except Exception as err:
                    report_log('WARN', 'Delete {} relations failed, {}'.format(
                        cmdb_rel, err))
            # log('INFO', 'Calc relations succeed')
        report_log('INFO', 'Calc {} DELETE VM_RunsOn_ESXi'.format(delete_rel))


def merge_args(ip='ip'):
    """合并 __ip__ 和 __args__"""
    all_args = {}
    for i in globals().get('__ip__', []):
        all_args[i] = __args__
    for i in globals().get('__ip_ranges__', []):
        all_args[i] = __args__
    for _arg in __args__:
        if _arg.get(ip):
            all_args[_arg[ip]] = [_arg]
    # print all_args
    report_log('INFO', "Merged {} args".format(len(all_args)))
    return all_args


def report_log(level, msg):
    try:
        __ci__.result_log(level, msg)
    except BaseException:
        pass


def report_data():
    try:
        __ci__.result_data()
    except CenterNotConnected:
        time.sleep(1)
        __ci__.result_data()


if __name__ == '__main__':
    start_time = time.time()
    for _ip, _args in merge_args().items():
        __ci__.ip = _ip
        for arg in _args:
            arg = copy.deepcopy(arg)
            arg['ip'] = _ip
            vmware = VMWareDiscovery(arg)
            if vmware.discover():
                break

    # 同时指定租户地址和apikey，才删除无效关系
    if __args__[0].get('tenant_url') and __args__[0].get('apikey'):
        try:
            # 先添加 calc_utils 到 /opt/ant-agent/agent/packages/
            # from uyun_utils.store_utils import Service
            from calc_utils.store_utils import Service, CiInstance
            cmdb = CalcCMDBData(
                __args__[0]['tenant_url'],
                __args__[0]['apikey'])

            # 计算CMDB中已删除资源，状态改为已删除
            cmdb.calc_all_deleted(state_code='resource_state')
            # cmdb.calc_all_deleted(state_code='RunningState')
            # 计算VM漂移情况，如果已漂移，删除CMDB中的历史关系
            cmdb.delete_vm_esxi_relations()

        except Exception:
            report_log('ERROR', 'Calc delete/relations failed, {}'.format(
                traceback.format_exc()))
    report_log('INFO', 'Discovery Done, elapsed times {}'.format(time.time() - start_time))

    # 数据量太多，将VM提取出来，分成两次上报，为了与ESXi建立关系，ESXi需要上报两次
    all_ci_by_cid = {i['cid']: i for i in __ci__.citypes}
    no_vm_copy = copy.copy(all_ci_by_cid)
    no_vm_rels = copy.copy(__ci__.relations)
    org_relations = copy.copy(__ci__.relations)
    # 将VM和它的操作系统、内联资源提取出来，并结构化
    # {
    #     "100": {
    #         "cid": 100,
    #         "esxi": 11,
    #         "subs": [101, 102],
    #         "relations": [{}]
    #     }
    # }
    vm_dict = {}
    for rel in __ci__.relations:
        src = all_ci_by_cid[rel['source']]
        dst = all_ci_by_cid[rel['target']]
        if dst['code'] == 'VM':
            src, dst = dst, src
        if src['code'] != 'VM':
            continue

        vm_cid = src['cid']
        if vm_cid not in vm_dict:
            vm_dict[vm_cid] = {
                'cid': src['cid'],
                'esxi': None,
                'relations': [],
                'subs': []
            }
        vm_dict[vm_cid]['relations'].append(rel)

        if rel in no_vm_rels:
            no_vm_rels.remove(rel)

        if vm_cid in no_vm_copy:
            no_vm_copy.pop(vm_cid)

        if dst['code'] == 'ESXi':
            vm_dict[vm_cid]['esxi'] = dst['cid']
        else:
            no_vm_copy.pop(dst['cid'])
            vm_dict[vm_cid]['subs'].append(dst['cid'])
    # print vm_dict
    vms = vm_dict.values()
    report_num = 3000
    # report_num = 23
    # 将数据量太大时，分成两次上报，
    citypes1 = copy.copy(no_vm_copy).values()
    relations1 = copy.copy(no_vm_rels)
    for vm in vms[:report_num]:
        citypes1.append(all_ci_by_cid[vm['cid']])
        citypes1.extend([all_ci_by_cid[i] for i in vm['subs']])
        relations1.extend(vm['relations'])

    __ci__.citypes = citypes1
    __ci__.relations = relations1
    report_data()
    if vms[report_num:]:
        report_log('INFO', 'Report data1, {} cis'.format(len(citypes1)))
        citypes2 = []
        relations2 = []
        for vm in vms[report_num:]:
            citypes2.append(all_ci_by_cid[vm['cid']])
            citypes2.append(all_ci_by_cid[vm['esxi']])
            citypes2.extend([all_ci_by_cid[i] for i in vm['subs']])
            relations2.extend(vm['relations'])
        __ci__.citypes = citypes2
        __ci__.relations = relations2
        report_data()
        report_log('INFO', 'Report data2, {} cis'.format(len(citypes2)))

    report_log('INFO', 'Report all data Done')


