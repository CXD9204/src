/*!Action 
action.name=Tuxedo_remote_discovery_87f32e9
action.descr=Tuxedo_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=Tuxedo
discovery.output=Middleware
*/

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
TuxedoMP:TuxedoMP,TuxedoMP,TuxedoMP,false,false
properties
ipckey:IPCKEY,string,null,null,ipckey,IPCKEY
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
tuxedo_domain_id:DomainID,string,null,null,tuxedo_domain_id,DomainID
cluster_machine:集群成员主机,string,null,null,cluster_machine,集群成员主机
cluster_hostname:集群成员主机名,string,null,null,cluster_hostname,集群成员主机名
*/

/*!Model
Tuxedo:Tuxedo主机,Tuxedo,Tuxedo主机,false,false
properties
patch_number:补丁号,string,null,null,patch_number,补丁号
install_path:安装路径,string,null,null,install_path,安装路径
ipckey:IPCKEY,string,null,null,ipckey,IPCKEY
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
version:Tuxedo版本,string,null,null,version,Tuxedo版本
tuxedo_domain_id:DomainID,string,null,null,tuxedo_domain_id,DomainID
lmid:逻辑主机标识,string,null,null,lmid,逻辑主机标识
hostname:主机名,string,null,null,hostname,主机名
machine:主机,string,null,null,machine,主机
name:名称,string,null,null,name,名称
tuxedoServer:Server,inline,null,null,tuxedoServer,Server
*/

/*!Model
TuxedoServer:TuxedoServer,TuxedoServer,TuxedoServer,true,false
properties
srvgrp:SRVGRP,string,null,null,srvgrp,SRVGRP
mindispatchthreads:最小线程数,int,null,null,mindispatchthreads,最小线程数
maxdispatchthreads:最大线程数,int,null,null,maxdispatchthreads,最大线程数
srvid:SRVID,int,null,null,srvid,SRVID
name:Server名称,string,null,null,name,Server名称
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

cliUtil = $script.use("common/cli_util");
def system = cliUtil.executeCommand("uname");
def osCode = osCodeSearch(system)
if(osCode != 'Linux'){
	$logger.logWarn("Only Linux is supported");
	return
}

def currentUser = cliUtil.executeCommand("whoami");
def commondResult = cliUtil.executeCommand("ps -eo user,pid,comm|grep -w BBL");
if($text.isNull(commondResult)){
	$logger.logWarn("未找到 BBL进程");
	return ;
}

osCi = $ci.create(osCode, $scriptParams.ip + "-" + cliUtil.executeCommand("uname -n"))
osCi.ip = $scriptParams.ip

for(def line in $text.splitLine(commondResult)){
	def ss = line.split()
	if(ss[2] != 'BBL'){
		continue
	}
	def notEqualUser = ss[0] != currentUser
	if(currentUser != 'root' && notEqualUser){
		continue
	}
	def pid = ss[1]
	$logger.logInfo("发现BBL进程:" + pid);
	if(notEqualUser){
		cliUtil.executeCommand("su - " + ss[0]);
	}
	try{
		discovery_tuxedo();
	}finally{
		if(notEqualUser){
			cliUtil.executeCommand("exit")
		}
	}
}

def discovery_tuxedo(){
	def config_data = get_config_data()
	def machines = config_data['MACHINES']
	if(!machines){
		$logger.logWarn("tmunloadcf 中没有获取的 MACHINES 数据");
		return ;
	}
	
	def info = cliUtil.executeCommand("tmadmin -v");
	def version = findAllFirst(info, 'Version\\s*([\\d\\.]+)')
	def patch = findAllFirst(info, 'Patch Level (.+)')
	
	def networks = [:]
	if(config_data.NETWORK){
		for(def item : config_data.NETWORK){
			networks[item.name] = item.NADDR.split('//|:')[1]
		}
	}
	def resources = config_data.RESOURCES
	
	def tuxedoCis = [:]
	for(def machine in machines){
		def name = machine.name
		def tuxedoCi = $ci.create("Tuxedo", name);
		def network = networks[machine.LMID]
		if(!network){
			network = $scriptParams.ip
		}
		tuxedoCi.putAll([
			ip : network,
	        lmid : machine.LMID,
	        machine : name,
	        version : version,
	        patch_number : patch,
	        ipckey : resources.IPCKEY,
	        tuxedo_domain_id : resources.DOMAINID,
	        model : resources.MODEL
		])
		if(tuxedoCi.ip == $scriptParams.ip){
			tuxedoCi.putAll([
				hostname : cliUtil.executeCommand("uname -n"),
				install_path : cliUtil.executeCommand("echo \$(dirname \$(dirname \$(which tmadmin)))")
			])
			$ci.createRelationship("RunsOn", tuxedoCi.id, osCi.id);
		}
		tuxedoCis.put(machine.LMID, tuxedoCi)
	}
	
	if(tuxedoCis.size() > 1){
		def allCis = tuxedoCis.values()
		def ips = allCis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);})
		def clusterCi = $ci.create("TuxedoMP", resources.DOMAINID);
		clusterCi.putAll([
        	ipckey : resources.IPCKEY,
        	tuxedo_domain_id : resources.DOMAINID,
            cluster_perst_ip : ips.join(",")
		])
		for(def ci in allCis){
			$ci.createRelationship("Contains", clusterCi.id, ci.id);
		}
	}
	
	def groups = [:]
	for(def group in config_data.GROUPS){
		groups[group.name] = group.LMID
	}
	
	for(def server in config_data.SERVERS){
		def name = server.name
		def lmid = groups[server.SRVGRP]
		def tuxedoCi = tuxedoCis[lmid]
		
		if(!tuxedoCi){
			$logger.logWarn("server:" + name + ",not find machine");
			continue
		}
		def ci = $ci.create("TuxedoServer", name);
		ci.putAll([
			srvid : server.SRVID,
	        srvgrp : server.SRVGRP,
	        mindispatchthreads : server.MINDISPATCHTHREADS,
			maxdispatchthreads : server.MAXDISPATCHTHREADS
		])
		$ci.createRelationship("Inlines", tuxedoCi.id, ci.id);
	}
}


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def get_config_data(){
	def commondResult = cliUtil.executeCommand("tmunloadcf 2>/dev/null");
	def data = [:]
	for(def section in commondResult.split('\\*')){
		section = section.trim()
		if(!section){
			continue
		}
		section = "*${section}"
		def section_name = findAllFirst(section, '\\*(\\w+)')
		if(!section_name){
			continue
		}
		if(section_name == 'RESOURCES'){
			def tmp = [:]
			data[section_name] = tmp
        	for(def item : findAll(section, '([A-Z]+)\\t+(.*)')){
        		tmp[item[0]] = trim_str(item[1])
        	}
        }
        else {
        	def tmp = []
			data[section_name] = tmp
       	 	def lines = $text.splitLine(section)
       	 	if(lines.size() == 1){
       	 		continue
       	 	}
       	 	def str = ''
       	 	for(def line in lines[1..-1]){
                if(line.trim() && !line.startsWith('\t')){
                    str += '\n' + line
                }
                else {
                    str += line
                }
            }
            str = str.trim()
            if(!str){
            	continue
            }
            for(def line in $text.splitLine(str)){
            	def ss = line.split('\t')
            	def values = [:]
            	values.name = trim_str(ss[0])
            	for(def item : ss[1..-1]){
            		def kk = item.split('=');
            		values[kk[0]] = trim_str(kk[1])
            	}
            	tmp.add(values)
            }
        }
	}
	return data
}

def trim_str(def str){
	if(!str){
		return '';
	}
	str = str.trim()
	if(str.startsWith('"') && str.endsWith('"')){
		return str.substring(1, str.size() -1)
	}
	return str
}


