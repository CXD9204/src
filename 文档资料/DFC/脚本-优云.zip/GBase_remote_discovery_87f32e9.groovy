/*!Action 
action.name=Gbase_remote_discovery_87f32e9
action.descr=Gbase_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=GBaseMPPCluster
discovery.output=Database
*/
 
/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
*/

/*!Model
GBaseCoord:GBase协调节点,GBaseCoord,GBase协调节点,false,false
properties
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
version:版本,string,null,null,version,版本
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
*/

/*!Model
GBaseData:GBase数据节点,GBaseData,GBase数据节点,false,false
properties
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
network_domain:网络域,string,null,null,network_domain,网络域
version:版本,string,null,null,version,版本
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
*/

/*!Model
GBaseMPPCluster:GBaseMPP集群,GBaseMPPCluster,GBaseMPP集群,false,false
properties
gbaseDatabase:GBase数据库,inline,null,null,gbaseDatabase,GBase数据库
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
GBaseDatabase:GBase数据库,GBaseDatabase,GBase数据库,true,false
properties
name:名称,string,null,null,name,名称
database_size:数据库大小,string,null,null,database_size,数据库大小
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/


import java.util.regex.Matcher;
import java.util.regex.Pattern;

cliUtil = $script.use("common/cli_util");
if(!$text.isNull(cliUtil.executeCommand("which gcadmin >/dev/null"))){
	$logger.logWarn("未找到 gcadmin 命令");
	return 
}
def system = cliUtil.executeCommand("uname");
def osCode = osCodeSearch(system)
if(osCode != 'Linux'){
	$logger.logWarn("Only Linux is supported");
	return
}

$logger.logInfo("Discover gbase cluster")
def clusterCi = discover_gbase_cluster()

def osCi = $ci.create(osCode, $scriptParams.ip + "-" + cliUtil.executeCommand("uname -n"))
osCi.ip = $scriptParams.ip

$logger.logInfo("Discover gbase data")
discover_gbase_data(clusterCi, osCi)
$logger.logInfo("Discover gbase coord")
discover_gbase_coord(clusterCi, osCi)


def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HP_UX', 'hp_ux' : 'HP_UX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}


def discover_gbase_cluster(){
	def commondResult = cliUtil.executeCommand("gcadmin showcluster c|grep '\\<coordinator'|awk -F\\| '{print \$3}'")
	def ips = $text.splitLine(commondResult).collect{e->e.trim()}.sort({a, b -> return compareStr(a, b);});
	
	def clusterCi = $ci.create("GBaseMPPCluster", 'GBaseCluster' + ips.join('_'));
	clusterCi.cluster_perst_ip = ips.join('_')
	
	commondResult = cliUtil.executeCommand("gcadmin showcluster d|grep '\\<node'|awk -F\\| '{print \$3}'")
	ips = $text.splitLine(commondResult).collect{e->e.trim()}.sort({a, b -> return compareStr(a, b);});
	for(def ip : ips){
		if(ip == $scriptParams.ip){
			continue
		}
		def dataCi = $ci.create("GBaseData", 'GBaseData' + ip);
		dataCi.ip = ip
		$ci.createRelationship("Contains", clusterCi.id, dataCi.id);
	}
	return clusterCi
}

def discover_gbase_data(def clusterCi, def osCi){
	def proces = get_proces('gbased')
	for(def proce : proces){
		def commondResult = cliUtil.executeCommand("su - ${proce[0]} -c '${proce[2]} -V'");
		def dataCi = $ci.create("GBaseData", 'GBaseData' + $scriptParams.ip);
		dataCi.putAll([
			port : proce[1],
		 	ip : $scriptParams.ip,
		 	version : findAllFirst(commondResult, '(?<=ver\\s)(\\S+)'),
		 	hostname : cliUtil.executeCommand("uname -n"),
		 	install_path : cliUtil.executeCommand("echo \$(dirname \$(dirname \$(dirname ${proce[2]})))")
		])
		$ci.createRelationship("Contains", clusterCi.id, dataCi.id);
		$ci.createRelationship("RunsOn", dataCi.id, osCi.id);
	}
}


def discover_gbase_coord(def clusterCi, def osCi){
	def proces = get_proces('gclusterd')
	for(def proce : proces){
		def commondResult = cliUtil.executeCommand("su - ${proce[0]} -c '${proce[2]} -V'");
		def dataCi = $ci.create("GBaseCoord", 'GBaseCoord' + proce[1]);
		dataCi.putAll([
			port : proce[1],
		 	ip : $scriptParams.ip,
		 	version : findAllFirst(commondResult, '(?<=ver\\s)(\\S+)'),
		 	hostname : cliUtil.executeCommand("uname -n"),
		 	install_path : cliUtil.executeCommand("echo \$(dirname \$(dirname \$(dirname ${proce[2]})))")
		])
		$ci.createRelationship("Contains", clusterCi.id, dataCi.id);
		$ci.createRelationship("RunsOn", dataCi.id, osCi.id);
		discover_gbase_database(clusterCi, dataCi.install_path + '/userdata/gcluster')
	}
}

def discover_gbase_database(def clusterCi, def db_dir){
	if(!is_dir(db_dir)){
		return
	}
	def exclude_dbs = ['gbase', 'gclusterdb', 'gctmpdb']
	def count_datanode = $number.parse(cliUtil.executeCommand("gcadmin showcluster d|grep '\\<node' |wc -l")).intValue();
	for(def name : $text.splitWord(cliUtil.executeCommand("ls ${db_dir}"))){
		def dir = db_dir + '/' + name
		if(!is_dir(dir) || name in exclude_dbs){
			continue;
		}
		def db_path_size = $number.parse(cliUtil.executeCommand("du -s ${dir}|awk '{print \$1}'")).intValue();
		def databaseCi = $ci.create("GBaseDatabase", name);
		databaseCi.database_size = convert_bytes(db_path_size * count_datanode, new convert_bytes_params(src_unit : 'KB'))
		$ci.createRelationship("Inlines", clusterCi.id, databaseCi.id);
	}
}


def is_dir(def db_dir){
	if($text.isNull(cliUtil.executeCommand("[ -d '${db_dir}' ] && echo true"))){
		return false;
	}
	return true
}

def get_proces(def name){
	def proces = []
	def system = cliUtil.executeCommand("uname");
	def commondResult = cliUtil.executeCommand("ps -eo user,pid,comm|grep -w $name")
	if(!$text.isNull(commondResult)){
		for(def line in $text.splitLine(commondResult)){
			def ss = line.split()
			if(ss[2] != name){
				continue
			}
			def pid = ss[1]
			def exec = cliUtil.executeCommand("echo \$(ls -l /proc/$pid/exe|awk -F'>' '{print \$NF}')")
			if(exec == '/usr/bin/bash'){
				continue
			}
			if(system == 'AIX'){
				port = cliUtil.executeCommand("netstat -Aan|grep LISTEN|while read saddr proto recv send laddr raddr state; do  pid=\$(rmsock \$saddr tcpcb|awk '{print \$(NF-1)}'); [[ \$pid == '${pid}' ]] && echo \$laddr|awk -F'.' '{print  \$NF}'; done")
			}
			else {
				port = cliUtil.executeCommand("netstat -antp 2>/dev/null | grep -w '${pid}/${name}'| awk '{print \$4}'|awk -F: '{print \$NF}'")
			}
			proces.add([ss[0], port, exec])
		}
	}
	return proces

}
