/*!Action
action.name=Redis_remote_discovery_87f32e9
action.descr=Redis_remote_discovery
action.version=1.0.0
action.protocols=redis
action.main.model=Redis
discovery.output=Database
 */

/*!Params
ip:IP,ip,,true
port:Port,number,6379,false
password:密码,password,,true
timeout:超时(ms),number,1000,false
*/

/*!Model
Redis:Redis实例,Redis,Redis实例,false,false
properties
tcp_keepalive:tcp_keepalive值,int,null,null,tcp_keepalive,tcp_keepalive值
maxmemory:最大内存,string,null,null,maxmemory,最大内存
working_dir:工作目录和持久化文件路径,string,null,null,working_dir,工作目录和持久化文件路径
install_path:安装路径,string,null,null,install_path,安装路径
bind_address:绑定地址,string,null,null,bind_address,绑定地址
timeout:连接超时时间,int,null,毫秒,timeout,连接超时时间
pidfile:进程pid文件,string,null,null,pidfile,进程pid文件
appendfsync:AOF同步机制,string,null,null,appendfsync,AOF同步机制
dbfilename:rdb文件名称,string,null,null,dbfilename,rdb文件名称
hostname:主机名,string,null,null,hostname,主机名
redis_conf:配置文件,string,null,null,redis_conf,配置文件
cluster_config_file:集群配置文件,string,null,null,cluster_config_file,集群配置文件
databases:最大db个数,int,null,个,databases,最大db个数
cluster_node_timeout:节点通讯超时时间,int,null,毫秒,cluster_node_timeout,节点通讯超时时间
logfile:日志文件,string,null,null,logfile,日志文件
ip:IP地址,string,null,null,ip,IP地址
appendfilename:AOF文件名称,string,null,null,appendfilename,AOF文件名称
daemonize_flag:守护进程标志,string,null,null,daemonize_flag,守护进程标志
version:版本,string,null,null,version,版本
maxclients:最大客户端数,int,null,null,maxclients,最大客户端数
cluster_enabled:是否集群,string,null,null,cluster_enabled,是否集群
port:端口,int,null,null,port,端口
loglevel:日志级别,string,null,null,loglevel,日志级别
appendonly_flag:是否开启AOF,string,null,null,appendonly_flag,是否开启AOF
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
RedisCluster:Redis集群,RedisCluster,Redis集群,false,false
properties
cluster_instance_port:集群实例端口,string,null,null,cluster_instance_port,集群实例端口
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
RedisSentinel:Redis哨兵实例,RedisSentinel,Redis哨兵实例,false,false
properties
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
logfile:日志文件,string,null,null,logfile,日志文件
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
conf_file:配置文件,string,null,null,conf_file,配置文件
name:名称,string,null,null,name,名称
bind_address:绑定地址,string,null,null,bind_address,绑定地址
version:版本,string,null,null,version,版本
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
RedisSentinelCluster:Redis哨兵集群,RedisSentinelCluster,Redis哨兵集群,false,false
properties
cluster_instance_port:集群实例端口,string,null,null,cluster_instance_port,集群实例端口
name:名称,string,null,null,name,名称
cluster_perst_ip:集群永久IP,string,null,null,cluster_perst_ip,集群永久IP
*/

/*!Model
AIX:AIX,AIX,AIX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Linux:Linux,Linux,Linux,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
Windows:Windows,Windows,Windows,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
network_domain:网络域,string,null,null,network_domain,网络域
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;

jedis = null
try{
	jedis = $redis.getJedis()
	initGlobalParameters()
	if(mode == 'sentinel'){
		def sentinelCi = discovery_sentinel();
		discover_sentinel_cluster(sentinelCi);
	}
	else {
		def redisCi = discovery_redis();
		if(redisCi.cluster_enabled == 'yes'){
			discover_redis_cluster(redisCi);		
		}
		else if(redisCi.cluster_enabled == 'no' && slaveNodes.size() > 0 ){
			//1.redis master/slave结构   可以通过info来获取所有在线的slave信息,但是可能不全,通过sentinel的命令 setntinel slaves <master name> 来获取
			//discover_redis_master_slave(redisCi);		
			//2.可以通过 监听命令(SUBSCRIBE  __sentinel__:hello)来获取所有的在线的sentinel信息
			//TODO
		}
	}
}finally{
	if(jedis != null){
		jedis.close();
	}
}

def osCodeSearch(String txt){
	def map = ['linux' : 'Linux', 'hpux' : 'HPUX', 'hp_ux' : 'HPUX', 'aix' : 'AIX', 'win' : 'Windows']
	for(def e in map){
		def key = e.key;
		def value = e.value;
		if(search(txt, key, Pattern.CASE_INSENSITIVE)){
			return value;
		}
	}
	return null;
}

def compareStr(str1, str2){
	def ss1 = str1.split("\\.|:");
	def ss2 = str2.split("\\.|:");
	def size = Math.min(ss1.length, ss2.length);
	for(def i = 0; i < size; i++){
		def s1 = ss1[i];
		def s2 = ss2[i];
		def s1Length = s1.length();
		def s2Length = s2.length();
		if(s1Length > s2Length){
			s2 = repeat("0", s1Length - s2Length) + s2;
		}
		else if(s1Length < s2Length){
			s1 = repeat("0", s2Length - s1Length) + s1;
		}
		def r = s1.compareTo(s2);
		if(r != 0){
			return r;
		}
	}
	if(ss1.length > size){
		return 1;
	}
	else if(ss2.length > size){
		return -1;
	}
	else {
		return 0;
	}
}

def repeat(str, repeat) {
	def tmp = str;
	while(--repeat > 0){
		str += tmp;
	}
	return str;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def initGlobalParameters(){
	info = [:];
	for(def line : jedis.info().split("\r*\n")){
		def ss = line.split(":");
		if(ss.size() != 2){
			continue;
		}
		def key = ss[0].trim();
		def value = ss[1].trim();
		info[key] = value;
	}
	mode = info['redis_mode'];
	if(mode != 'sentinel'){
		configgetall = $redis.getAllConfigList()
	}
	else {
		configgetall = []
	}
}

def discovery_redis(){
	$logger.logInfo("Discover redis ${mode}");
	
	def cluster_enabled = 'no'
	def cluster_value = info['cluster_enabled']
	if(cluster_value == '1'){
		cluster_enabled = 'yes'
	}
	else if(cluster_value == '0'){
		def role = info['role']
		slaveNodes = []
		if(role == 'master'){
			for(def index = 0; index < Integer.parseInt(info['connected_slaves']); index ++){
				def value = info['slave' + index]
				def node = [:]
				for(def keyValue : value.split(",")){
					def ss = keyValue.split("=")
					node[ss[0]] = ss[1] 
				}
				slaveNodes.add([ip:node['ip'], port:Integer.parseInt(node['port'])]);
			}
		}
	}
	
	def ci = $ci.create("Redis", "Redis", 'Redis' + $redis.params.port);
	ci.putAll([
			ip : $redis.params.ip,
            port : $redis.params.port,
            hostname : '',
            logfile : configgetall['logfile'],
            pidfile : configgetall['pidfile'],
            timeout : configgetall['timeout'],
            version : info['redis_version'],
            loglevel: configgetall['loglevel'],
            databases: configgetall['databases'],
            maxmemory: convert_bytes(configgetall['maxmemory'], new convert_bytes_params(src_unit : 'B')),
            dbfilename: configgetall['dbfilename'],
            maxclients: configgetall['maxclients'],
            redis_conf: info['config_file'],
            appendfsync: configgetall['appendfsync'],
            working_dir: configgetall['dir'],
            bind_address: configgetall['bind'],
            install_path: configgetall['dir'],
            tcp_keepalive: configgetall['tcp-keepalive'],
            daemonize_flag: configgetall['daemonize'],
            appendonly_flag: configgetall['appendonly'],
            cluster_node_timeout: configgetall['cluster-node-timeout'],
            cluster_enabled: cluster_enabled
		])
	def osInfo = info['os']
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, ci.hostname ? ci.ip + "-" + ci.hostname : ci.ip)
    	osCi.ip = ci.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}

def buildClusterCi(cis, def code, def namePrefix){
	if(cis.size() > 2){
		def cluster_instance_port = namePrefix + cis.collect{e->e.port + ""}.sort({a, b -> return compareStr(a, b);}).join("_")
        def ips = cis.collect{e->e.ip}.sort({a, b -> return compareStr(a, b);}).join("_")
        def clusterCi = $ci.create(code, cluster_instance_port)
        clusterCi.putAll([
        	cluster_instance_port : cluster_instance_port,
        	cluster_perst_ip : ips
        ])
        for(def ci : cis){
			$ci.createRelationship("Contains", clusterCi.id, ci.id);
        }
        return clusterCi
	}
}

def discover_redis_cluster(redisCi){
	$logger.logInfo("Discover redis cluster");
	def clusterCis = [redisCi]
	def ci = null
	for(def line : jedis.clusterNodes().split("\r*\n")){
		def ss = line.split()[1].split("@")[0].split(":");
		def ip = ss[0].trim();
		def port = Integer.parseInt(ss[1].trim());
		if(ip == redisCi.ip && port == redisCi.port){
			continue
		}
		def name = "Redis${port}"
		ci = $ci.create('Redis', name)
        ci.putAll([
        	ip : ip,
			port : port
        ])
        clusterCis.add(ci)
	}
	buildClusterCi(clusterCis, 'RedisCluster', 'Redis')
}

def discover_redis_master_slave(redisCi){
	$logger.logInfo("Discover redis slave");
	def allCis = [redisCi]
	def ci = null
	for(def node : slaveNodes){
		def ip = node.ip;
		def port = node.port;
		def name = "Redis${port}"
		ci = $ci.create('Redis', name)
        ci.putAll([
        	ip : ip,
			port : port
        ])
        allCis.add(ci)
	}
	buildClusterCi(allCis, 'RedisCluster', 'Redis')
}

def discovery_sentinel(){
	$logger.logInfo("Discover redis ${mode}");
	
	def ci = $ci.create("RedisSentinel", "RedisSentinel", 'Sentinel' + $redis.params.port);
	ci.putAll([
			ip : $redis.params.ip,
            port : $redis.params.port,
            hostname : '',
            version : info['redis_version'],
            conf_file : info['config_file'],
            install_path : info['executable'].split('bin')[0..-2].join('bin')
		])
	def osInfo = info['os']
    def osCode = osCodeSearch(osInfo)
    if(osCode){
    	def osCi = $ci.create(osCode, ci.hostname ? ci.ip + "-" + ci.hostname : ci.ip)
    	osCi.ip = ci.ip
    	$ci.createRelationship("RunsOn", ci.id, osCi.id);
    }
	return ci;
}


def discover_sentinel_cluster(sentinelCi){
	$logger.logInfo("Discover sentinel cluster");
	def ci = null
	
	def sentinelAll = [:]
	def sentinelClusterCis = [:]
	def client = jedis.getClient();
	for(def masterInfo : jedis.sentinelMasters()){
		def masterName = masterInfo.name
		def ip = masterInfo.ip
		def port = Integer.parseInt(masterInfo.port)
		
		ci = $ci.create('Redis', "Redis${port}")
        ci.putAll([
        	ip : ip,
			port : port
        ])
        def redisCis = [ci]
        
        for (def map : jedis.sentinelSlaves(masterName)){
			ci = $ci.create('Redis', "Redis${map.port}")
	        ci.putAll([
	        	ip : map.ip,
				port : Integer.parseInt(map.port)
	        ])
       		redisCis.add(ci)
        }
        if(redisCis.size() <= 1){
        	$logger.logWarn("redis cluster[${masterName}] node size :" + redisCis.size());
        	continue;
        }
        def redisClusterCi = buildClusterCi(redisCis, 'RedisCluster', 'Redis')
		
		def sentinelCis = [sentinelCi]
		client.sentinel("sentinels", masterName);
	    def reply = client.getObjectMultiBulkReply();
	    for (def obj : reply) {
	    	def sentinel = redis.clients.jedis.BuilderFactory.STRING_MAP.build(obj);
	    	def key = sentinel.ip + ":" + sentinel.port
	    	ci = sentinelAll[key]
	    	if(!ci){
	    		ci = $ci.create("RedisSentinel", "Sentinel${sentinel.port}");
				ci.putAll([
					ip : sentinel.ip,
       				port : Integer.parseInt(sentinel.port)
       			])
       			sentinelAll[key] = ci
       			sentinelCis.add(ci)
	    	}
	    }
	    if(sentinelCis.size() > 1){
	    	def key = sentinelCis.collect{e->e.ip + "|" + e.port}.sort({a, b -> return compareStr(a, b);}).join("_")
	    	def sentinelClusterCi = sentinelClusterCis[key]
	    	if(!sentinelClusterCi){
	    		sentinelClusterCi = buildClusterCi(sentinelCis, 'RedisSentinelCluster', 'RedisSentinel');
	    		sentinelClusterCis[key] = sentinelClusterCi
	    	}
	    	$ci.createRelationship("Manages", sentinelClusterCi.id, redisClusterCi.id);
	    }
	    else {
	    	$ci.createRelationship("Manages", sentinelCi.id, redisClusterCi.id);
	    }
	}
}