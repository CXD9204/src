/*!Action
action.name=WAS_remote_discovery_87f32e9
action.descr=WAS_remote_discovery  不支持集群
action.version=1.0.0
action.protocols=http
action.main.model=WAS
discovery.output=Middleware
*/
/*!Params
ip:目标设备IP,ip,,true
port:控制台端口,number,9043,false
consoleUsername:控制台用户名,text,,false
consolePassword:控制台密码,password,,false
timeout:控制台密码,text,300000,false
*/

/*!Model
WAS:WAS实例,WAS,WAS实例,false,false
properties
maximum_heap_size:最大堆大小,string,null,null,maximum_heap_size,最大堆大小
cluster_name:集群名称,string,null,null,cluster_name,集群名称
server_name:实例名,string,null,null,server_name,实例名
install_path:安装路径,string,null,null,install_path,安装路径
ip:IP地址,string,null,null,ip,IP地址
node_name:节点名称,string,null,null,node_name,节点名称
initial_heap_size:初始堆大小,string,null,null,initial_heap_size,初始堆大小
web_container_max:最大线程池,int,null,null,web_container_max,最大线程池
jdk_version:JDK版本,string,null,null,jdk_version,JDK版本
version:WAS版本,string,null,null,version,WAS版本
hostname:主机名,string,null,null,hostname,主机名
port:端口,int,null,null,port,端口
web_container_min:最小线程池,int,null,null,web_container_min,最小线程池
name:名称,string,null,null,name,名称
javaApp:Java应用,inline,null,null,javaApp,Java应用
jdbc_DS:JDBC数据源,inline,null,null,jdbc_DS,JDBC数据源
network_domain:网络域,string,null,null,network_domain,网络域
*/

/*!Model
JavaApp:Java应用,JavaApp,Java应用,true,false
properties
context_path:上下文根,string,null,null,context_path,上下文根
name:应用名称,string,null,null,name,应用名称
target:目标,string,null,null,target,目标
*/

/*!Model
JDBC_DS:JDBC数据源,JDBC_DS,JDBC数据源,true,false
properties
jndi_name:JNDI名称,string,null,null,jndi_name,JNDI名称
ds_driver_type:数据源驱动类型,string,null,null,ds_driver_type,数据源驱动类型
ds_max_conn:连接池最大连接数,int,null,个,ds_max_conn,连接池最大连接数
ds_scope:数据源作用域,string,null,null,ds_scope,数据源作用域
user_name:用户标志,string,null,null,user_name,用户标志
name:数据源名称,string,null,null,name,数据源名称
ds_url:数据源URL,string,null,null,ds_url,数据源URL
ds_min_conn:连接池最小连接数,int,null,个,ds_min_conn,连接池最小连接数
*/

/*!Model
WASServerCluster:WAS集群,WASServerCluster,WAS集群,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
hostname:Dmgr主机名,string,null,null,hostname,Dmgr主机名
port:Dmgr端口,int,null,null,port,Dmgr端口
ip:Dmgr地址,string,null,null,ip,Dmgr地址
name:名称,string,null,null,name,名称
javaApp:Java应用,inline,null,null,javaApp,Java应用
jdbc_DS:JDBC数据源,inline,null,null,jdbc_DS,JDBC数据源
network_domain:网络域,string,null,null,network_domain,网络域
*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import uyun.hawk.discovery.action.protocol.impl.websphere.WebSphereProtocol;
import uyun.hawk.discovery.action.protocol.impl.websphere.WebSphereSession;


def protocol = new WebSphereProtocol($http.params);
$websphere = new WebSphereSession(protocol);

def isLogon = $websphere.login();
if (!isLogon) {
	$logger.logWarn("login fail");
	return 
}

//获取导航链接
initNavigationHrefs();
def applicationServers = analysisTable(hrefMap.get("ApplicationServer.content.main"))
if(!applicationServers){
	$logger.logWarn("Application Server Not Found");
	return ;
}
//不支持集群
if(applicationServers.size() > 1 && applicationServers.findAll{e -> e.clusterName && e.clusterName.text() != ''}){
	//由于核心属性ip在网页上查不到,故不支持
	$logger.logWarn("Cluster discovery is not supported");
	return ;
}
discovery_was(applicationServers)
discovery_application_deployment()
discovery_dataSource()


def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discovery_dataSource(){
	def href = hrefMap.get("DataSource.content.main")
	if(!href){
		return 
	}
	for(def dataSource in analysisTable(href)){
		def name = dataSource['namecom.ibm.ws.console.resources.database.DataSourceCollectionForm'].text()
		def jndi_name = dataSource['jndiNamecom.ibm.ws.console.resources.database.DataSourceCollectionForm'].text()
		def ds_scope = dataSource['contextIdcom.ibm.ws.console.resources.database.DataSourceCollectionForm'].text()
		def cis = []
		if(ds_scope.startsWith("Cluster=")){
			def key = ds_scope.split("=")[-1]
			def ci = wasClusterCis[key]
			if(ci){
				cis.add(ci)
			}
		}
		else if(ds_scope.startsWith("Node=")){
			def ss = ds_scope.split(",")
			if(ss.size() == 2 && ss[1].startsWith("Server=")){
				def nodeName = ss[0].split("=")[-1]
				def serverName = ss[1].split("=")[-1]
				def key = buildWasKey(nodeName, serverName)
				def ci = wasCis[key]
				if(ci){
					cis.add(ci)
				}
			}
		}
		if(!cis){
			$logger.logWarn("JavaApp : ${name} not find deployed object");
			continue;
		}
		def ds_driver_type = dataSource['providercom.ibm.ws.console.resources.database.DataSourceCollectionForm'].text()
		
		href = "/ibm/console/" + dataSource['namecom.ibm.ws.console.resources.database.DataSourceCollectionForm'].getElementsByTag("a").first().attr("href")
		def response = $websphere.getHtmlResp(href);
		def doc = $websphere.parseHtmlToDoc(response);
		def child_additional_element = doc.getElementById('child_additional.properties')
		def child_related_element = doc.getElementById('child_related.items')
		def dataSource_properties_element = doc.getElementById('DataSource.required.properties')
		def ds_max_conn = null
		def ds_min_conn = null
		if(child_additional_element){
			href = "/ibm/console/" + child_additional_element.getElementsByAttributeValue("title", "An optional set of connection pool settings.").first().getElementsByTag("a").first().attr("href")
			response = $websphere.getHtmlResp(href);
			doc = $websphere.parseHtmlToDoc(response);
			ds_min_conn = doc.getElementById('maxConnections').attr("value")
			ds_max_conn = doc.getElementById('minConnections').attr("value")
		}
		def user_name = ""
		if(child_related_element){
			href = "/ibm/console/" + child_related_element.getElementsByAttributeValue("title", "Specifies a list of user identities and passwords for Java(TM) 2 connector security to use.").first().getElementsByTag("a").first().attr("href")
			user_name = analysisTable(href).collect{e->e['userIdcom.ibm.ws.console.security.JAASAuthDataCollectionForm'].text()}.join(",")
		}
		def ds_url = ""
		if(dataSource_properties_element){
			for(def tr : dataSource_properties_element.getElementsByClass("table-row").first().getElementsByTag("tr")){
				def tds = tr.getElementsByTag("td")
				if(tds[0].text() == 'URL'){
					ds_url =  tds[1].getElementsByTag("input").first().attr("value")
				}
			}
		}
		
		def ci = $ci.create("JDBC_DS", name);
		ci.putAll([
			jndi_name : jndi_name,
			ds_scope : ds_scope,
			ds_driver_type : ds_driver_type,
			ds_min_conn : ds_min_conn,
			ds_max_conn : ds_max_conn,
			user_name : user_name,
			ds_url : ds_url
		])
		for(def wasCi : cis){
			$ci.createRelationship("Inlines", wasCi.id, ci.id)
		}
	}
}

def discovery_application_deployment(){
	def href = hrefMap.get("ApplicationDeployment.content.main")
	if(!href){
		return 
	}
	for(def deployment in analysisTable(href)){
		href = deployment.Name.getElementsByTag("a").first().attr("href")
		def response = $websphere.getHtmlResp("/ibm/console/" + href);
    	def doc = $websphere.parseHtmlToDoc(response);
    	def element = doc.getElementById("child_ApplicationDeployment.WebModuleProperties.category")
    	def contentRoot = ""
    	if(element){
			def contentRootHref = "/ibm/console/" + element.getElementsByAttributeValue("title", "Context Root For Web Modules").first().getElementsByTag("a").first().attr("href")
			contentRoot = analysisTable(contentRootHref)[0]["Context Root"].getElementsByTag("input").first().attr("value")
		}
		
		element = doc.getElementById("child_ApplicationDeployment.DetailProperties.category")
		def cis = []
    	if(element){
			def contentRootHref = "/ibm/console/" + element.getElementsByAttributeValue("title", "Specifies the mapping of this deployed object (application or module) into a target environment (server, cluster, or cluster member).").first().getElementsByTag("a").first().attr("href")
			for(def item : analysisTable(contentRootHref)){
				def name = item["target"].text()
				def node = item["node"].text()
				if(node == ''){
					def ci = wasClusterCis[name]
					if(ci){
						cis.add(ci)
					}
				}
				else {
					def ci = wasCis[buildWasKey(node, name)]
					if(ci){
						cis.add(ci)
					}
				}
			}
		}
		def name = deployment.Name.text()
		if(!cis){
			$logger.logWarn("JavaApp : ${name} not find deployed object");
			continue;
		}
		def ci = $ci.create('JavaApp', name)
        ci.putAll([
        	context_path : contentRoot,
        	target : cis.collect{e->e.name}.join(",")
        ])
        for(def wasCi : cis){
			$ci.createRelationship("Inlines", wasCi.id, ci.id)
		}
	}
}

def initNavigationHrefs() {
    hrefMap = [:];
    //获取导航页面
    def navigationPage = $websphere.getHtmlResp("/ibm/console/nsc.do");
    def navigationPageDoc = $websphere.parseHtmlToDoc(navigationPage);
    def table = navigationPageDoc.getElementsByClass("navigation-bullet");
    for (def row in table) {
        def ref = row.getElementsByTag("a").attr("href");
        def ss = ref.substring(ref.indexOf("?") + 1).split("&")
        def str = ss.find{e->e.startsWith("forwardName=")}
        if(str){
        	str = str.split("=", 2)[-1]
        	hrefMap[str] = ref
        }
    }
}

def analysisTable(def href){
	if(!href){
		return []
	}
    def response = $websphere.getHtmlResp(href);
    def doc = $websphere.parseHtmlToDoc(response);
    
    def element = doc.getElementsByClass("table-totals")
    if(element && '0' == doc.getElementsByClass("table-totals").text().split()[-1]){
    	return [];
    }
    def results = []
    def head = [:]
    def elements = doc.getElementsByClass("column-head-name");
    for (def index = 0; index < elements.size(); index ++) {
    	element = elements.get(index);
    	def key = element.attr("id")
    	if(!key){
    		key = element.text()
    	}
    	head[index] = key
    }
    elements = doc.getElementsByClass("table-row");
    for (def resultElement in doc.getElementsByClass("table-row")) {
    	elements = resultElement.getElementsByClass("collection-table-text");
    	def result = [:]
    	for (def index = 0; index < elements.size(); index ++) {
    		def key = head[index]
    		element = elements.get(index);
    		def a = element.getElementsByTag("a").first();
    		result[key] = element
    	}
    	results.add(result)
    }
    return results
}

def discovery_was(applicationServers){
	wasClusterCis = [:] 
	wasCis = [:] 
	for(def applicationServer : applicationServers){
		def ci = $ci.create("WAS", "WAS", applicationServer.name.text());
		def href = "/ibm/console/" + applicationServer.name.getElementsByTag("a").first().attr("href")
		def response = $websphere.getHtmlResp(href);
		def doc = $websphere.parseHtmlToDoc(response);
		def trElements = doc.getElementsByAttributeValue("title", "Specifies the TCP/IP ports this server uses for connections.").first().getElementsByClass("framing-table").first().getElementsByTag("tr");
		def port = -1;
		for(def tr : trElements){
			if(tr.child(0).text() == 'WC_defaulthost'){
				port = tr.child(1).text()
			}
		}
		href = "/ibm/console/" + doc.getElementsByAttributeValue("title", "This page lists the SDKs that are installed on the server.").first().getElementsByTag("a").first().attr("href");
		def jdk_version = analysisTable(href)[0]['versioncom.ibm.ws.console.servermanagement.javasdk.InstalledSDKsCollectionForm'].text();
		def web_container_min = ''
		def web_container_max = ''
		href = "/ibm/console/" + doc.getElementsByAttributeValue("title", "Specifies the thread pools defined for this server.").first().getElementsByTag("a").first().attr("href");
		for(def item : analysisTable(href)){
			if(item['namecom.ibm.ws.console.servermanagement.process.ThreadPoolCollectionForm'].text() == 'WebContainer'){
				web_container_min = item['minimumSizecom.ibm.ws.console.servermanagement.process.ThreadPoolCollectionForm'].text()
				web_container_max = item['maximumSizecom.ibm.ws.console.servermanagement.process.ThreadPoolCollectionForm'].text()
			}
		}
		href = "/ibm/console/" + doc.getElementById("child_javaprocessmanagement.properties").getElementsByAttributeValue("title", "Use this page to configure a process definition. A process definition defines the command line information necessary to start or initialize a process.").first().getElementsByTag("a").first().attr("href");
		response = $websphere.getHtmlResp(href);
		doc = $websphere.parseHtmlToDoc(response);
		href = "/ibm/console/" + doc.getElementById("child_additional.properties").getElementsByAttributeValue("title", "Use this page to configure advanced Java(TM) virtual machine settings.").first().getElementsByTag("a").first().attr("href");
		response = $websphere.getHtmlResp(href);
		doc = $websphere.parseHtmlToDoc(response);
		def initial_heap_size = convert_bytes(doc.getElementById("initialHeapSize").attr("value") + ' MB')
		def maximum_heap_size = convert_bytes(doc.getElementById("maximumHeapSize").attr("value") + ' MB')
		
		ci.putAll([
			ip : $websphere.params.ip,
			port : port,
			server_name : applicationServer.name.text(),
			version : applicationServer.expandedVersion.text(),
			hostname : applicationServer.hostName.text(),
			node_name : applicationServer.node.text(),
			jdk_version : jdk_version,
			web_container_min : web_container_min,
			web_container_max : web_container_max,
			initial_heap_size : initial_heap_size,
			maximum_heap_size : maximum_heap_size
		])
		
		wasCis[buildWasKey(ci.node_name, ci.server_name)] = ci
	}
}

def buildWasKey(def nodeName, def serverName){
	return nodeName + "/" + serverName
}