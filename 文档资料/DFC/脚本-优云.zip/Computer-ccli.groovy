/*!Action
action.name=HPUX_remote_discovery_crj
action.descr=HPUX_remote_discovery
action.version=1.0.0
action.protocols=ccli
action.main.model=HPUX
discovery.output=Computer
 */

/*!Params
ip:目标设备IP,ip,,true
protocol:连接协议,enum,ssh,false,[ssh, telnet]
username:用户名,text,,false
password:密码,password,,false
commandPrompt:命令提示符,text,$;#,false
loginPrompt:登录提示符,text,,true
passwordPrompt:密码提示符,text,,true
connTimeout:连接超时(ms),number,1000,false
waitTimeout:等待超时(ms),number,10000,false
port:端口,number,null,true
charset:字符集,text,null,true
file:配置文件路径,text,null,true
 */

/*!Model
HPUX:HPUX,HPUX,HPUX,false,false
properties
mw_soft_ver:中间件软件/版本,string,null,null,mw_soft_ver,中间件软件/版本
unix_crontab:定时作业,table,null,null,unix_crontab,定时作业
unixGroup:用户组,inline,null,null,unixGroup,用户组
hostname:主机名,string,null,null,hostname,主机名
pass_max_day:密码有效期,int,null,天,pass_max_day,密码有效期
osHCA:OS的HCA卡,inline,null,null,osHCA,OS的HCA卡
password_minlen:密码最小长度,int,null,null,password_minlen,密码最小长度
swap_size:交换分区大小,string,null,null,swap_size,交换分区大小
pass_min_day:密码最短有效期,int,null,天,pass_min_day,密码最短有效期
user_tmout:会话超时时间,int,null,秒,user_tmout,会话超时时间
hp_max_uproc:最大用户进程数,int,null,null,hp_max_uproc,最大用户进程数
ip:IP地址,string,null,null,ip,IP地址
dns_server:DNS服务器,string,null,null,dns_server,DNS服务器
bits:位数,string,null,null,bits,位数
version:版本,string,null,null,version,版本
ips:IP列表,array,null,null,ips,IP列表
openssl_ver:openssl版本,string,null,null,openssl_ver,openssl版本
unixUser:用户信息,inline,null,null,unixUser,用户信息
name:名称,string,null,null,name,名称
password_dcredit:密码最少数字,int,null,null,password_dcredit,密码最少数字
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
default_gateway:默认网关,string,null,null,default_gateway,默认网关
password_ucredit:密码最少大写字母,int,null,null,password_ucredit,密码最少大写字母
osLunInfo:OS的LUN,inline,null,null,osLunInfo,OS的LUN
os_ver_detl:操作系统版本,string,null,null,os_ver_detl,操作系统版本
cpu_arch:CPU架构,string,null,null,cpu_arch,CPU架构
user_unlock_time:锁定时间,int,null,秒,user_unlock_time,锁定时间
osNIC:OS的网卡,inline,null,null,osNIC,OS的网卡
tool_soft_ver:工具软件/版本,string,null,null,tool_soft_ver,工具软件/版本
db_soft_ver:数据库软件/版本,string,null,null,db_soft_ver,数据库软件/版本
unixVG:卷组,inline,null,null,unixVG,卷组
fileSystem:文件系统,inline,null,null,fileSystem,文件系统
password_ocredit:密码最少特殊字符,int,null,null,password_ocredit,密码最少特殊字符
serial_number:序列号,string,null,null,serial_number,序列号
network_domain:网络域,string,null,null,network_domain,网络域
time_zone:时区,string,null,null,time_zone,时区
memory_size:内存大小,string,null,null,memory_size,内存大小
osHBA:OS的HBA卡,inline,null,null,osHBA,OS的HBA卡
user_deny_cnt:用户登录失败锁定次数,int,null,null,user_deny_cnt,用户登录失败锁定次数
password_lcredit:密码最少小写字母,int,null,null,password_lcredit,密码最少小写字母
unixLV:逻辑卷,inline,null,null,unixLV,逻辑卷
hp_nfile:所有进程打开的文件数,int,null,null,hp_nfile,所有进程打开的文件数
openssh_ver:openssh版本,string,null,null,openssh_ver,openssh版本
cpu_core_num:CPU核数,int,null,核,cpu_core_num,CPU核数
osDisk:OS的本地磁盘,inline,null,null,osDisk,OS的本地磁盘
*/

/*!Model
unix_crontab:定时作业,unix_crontab,定时作业,false,true
properties
user_name:用户,string,null,null,user_name,用户
script:脚本,string,null,null,script,脚本
run_time:执行时间,string,null,null,run_time,执行时间
*/

/*!Model
UnixGroup:Unix用户组,UnixGroup,Unix用户组,true,false
properties
gid:用户组ID,string,null,null,gid,用户组ID
name:用户组名,string,null,null,name,用户组名
*/

/*!Model
OsHCA:OS的HCA卡,OsHCA,OS的HCA卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后HCA卡,string,null,null,bonding_flag,bonding后HCA卡
name:HCA卡名称,string,null,null,name,HCA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
*/

/*!Model
UnixUser:Unix用户,UnixUser,Unix用户,true,false
properties
uid:用户ID,string,null,null,uid,用户ID
umask:umask值,string,null,null,umask,umask值
password_expires:密码过期时间,string,null,null,password_expires,密码过期时间
shell:缺省shell目录,string,null,null,shell,缺省shell目录
primary_group:主用户组,string,null,null,primary_group,主用户组
name:用户名,string,null,null,name,用户名
groups:附属用户组,string,null,null,groups,附属用户组
locked_flag:是否锁定,string,null,null,locked_flag,是否锁定
home:用户home目录,string,null,null,home,用户home目录
*/

/*!Model
OsLunInfo:OS的LUN,OsLunInfo,OS的LUN,true,false
properties
lun_size:LUN大小,string,null,null,lun_size,LUN大小
name:LUN名称,string,null,null,name,LUN名称
lun_id:LUNID,string,null,null,lun_id,LUNID
*/

/*!Model
OsNIC:OS的网卡,OsNIC,OS的网卡,true,false
properties
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
bonding_flag:bonding后网卡,string,null,null,bonding_flag,bonding后网卡
name:网卡名称,string,null,null,name,网卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
ips:IP列表,array,null,null,ips,IP列表
status:状态,string,null,null,status,状态
*/

/*!Model
UnixVG:Unix卷组,UnixVG,Unix卷组,true,false
properties
lv_num:逻辑卷个数,int,null,null,lv_num,逻辑卷个数
vg_free_size:卷组剩余大小,string,null,null,vg_free_size,卷组剩余大小
pv_num:物理卷个数,int,null,null,pv_num,物理卷个数
name:卷组名,string,null,null,name,卷组名
pp_size:物理段大小,string,null,null,pp_size,物理段大小
vg_used_size:卷组已使用大小,string,null,null,vg_used_size,卷组已使用大小
vg_total_size:卷组大小,string,null,null,vg_total_size,卷组大小
*/

/*!Model
FileSystem:Unix文件系统,FileSystem,Unix文件系统,true,false
properties
fs_mount_num:挂载次数,string,null,null,fs_mount_num,挂载次数
fs_type:文件系统类型,string,null,null,fs_type,文件系统类型
name:文件系统名称,string,null,null,name,文件系统名称
fs_total_size:文件系统总大小,string,null,null,fs_total_size,文件系统总大小
fs_mount_point:文件系统挂载点,string,null,null,fs_mount_point,文件系统挂载点
fs_need_fsck_flag:是否需要强制检查,string,null,null,fs_need_fsck_flag,是否需要强制检查
auto_mount:是否自动挂载,string,null,null,auto_mount,是否自动挂载
fs_mount_time:挂载时间,string,null,null,fs_mount_time,挂载时间
status:状态,string,null,null,status,状态
*/

/*!Model
OsHBA:OS的HBA卡,OsHBA,OS的HBA卡,true,false
properties
name:HBA卡名称,string,null,null,name,HBA卡名称
driver_version:驱动版本,string,null,null,driver_version,驱动版本
firmware:固件版本,string,null,null,firmware,固件版本
status:状态,string,null,null,status,状态
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
UnixLV:Unix逻辑卷,UnixLV,Unix逻辑卷,true,false
properties
name:逻辑卷名,string,null,null,name,逻辑卷名
vg_name:卷组名称,string,null,null,vg_name,卷组名称
lv_size:逻辑卷大小,string,null,null,lv_size,逻辑卷大小
*/

/*!Model
OsDisk:OS的本地磁盘,OsDisk,OS的本地磁盘,true,false
properties
os_disk_size:磁盘大小,string,null,null,os_disk_size,磁盘大小
name:磁盘名称,string,null,null,name,磁盘名称
*/

/*!Model
HPMiniServer:HP小型机,HPMiniServer,HP小型机,false,false
properties
cellboard_num:Cell板/Blade数量,int,null,个,cellboard_num,Cell板/Blade数量
cpu_model:CPU型号,string,null,null,cpu_model,CPU型号
model:型号,string,null,null,model,型号
par_num:分区数量,int,null,null,par_num,分区数量
firmware:系统固件版本,string,null,null,firmware,系统固件版本
miniserver_brand:品牌,string,null,null,miniserver_brand,品牌
serverHBA:服务器HBA卡,inline,null,null,serverHBA,服务器HBA卡
ip:带外管理IP地址,string,null,null,ip,带外管理IP地址
cpu_speed_clock:CPU主频,string,null,null,cpu_speed_clock,CPU主频
serial_number:序列号,string,null,null,serial_number,序列号
cpu_phys_num:CPU个数,int,null,null,cpu_phys_num,CPU个数
memory_size:内存大小,string,null,null,memory_size,内存大小
name:HP小型机名称,string,null,null,name,HP小型机名称
serverHCA:服务器HCA卡,inline,null,null,serverHCA,服务器HCA卡
serverNIC:服务器网卡,inline,null,null,serverNIC,服务器网卡
*/

/*!Model
ServerHBA:服务器HBA卡,ServerHBA,服务器HBA卡,true,false
properties
hba_port_id:HBA卡端口号,string,null,null,hba_port_id,HBA卡端口号
name:HBA卡型号,string,null,null,name,HBA卡型号
hba_slot_id:HBA卡槽位号,string,null,null,hba_slot_id,HBA卡槽位号
hba_speed:HBA卡速率,string,null,null,hba_speed,HBA卡速率
wwn:WWN号,string,null,null,wwn,WWN号
*/

/*!Model
ServerHCA:服务器HCA卡,ServerHCA,服务器HCA卡,true,false
properties
hca_slot_id:HCA卡槽位号,string,null,null,hca_slot_id,HCA卡槽位号
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:HCA卡型号,string,null,null,name,HCA卡型号
hca_port_id:HCA卡端口号,string,null,null,hca_port_id,HCA卡端口号
hca_speed:HCA卡速率,string,null,null,hca_speed,HCA卡速率
*/

/*!Model
ServerNIC:服务器网卡,ServerNIC,服务器网卡,true,false
properties
nic_slot_id:网卡槽位号,string,null,null,nic_slot_id,网卡槽位号
nic_speed:网卡速率,string,null,null,nic_speed,网卡速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:网卡型号,string,null,null,name,网卡型号
nic_port_id:网卡端口号,string,null,null,nic_port_id,网卡端口号
*/

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

cliUtil = $script.use("common/cli_util");
def system = cliUtil.executeCommand("uname");

if('HP-UX' != system){
	$logger.logWarn("The current operating system is not supported:" + system);
	return ;
}


def osCi = discovery_HP_UX(system);
def osCiId = osCi.id;

def miniserCi = discovery_server(osCi);

def nics = discover_nic(osCiId);
discover_file_system(osCiId);
discovery_user_group(osCiId);

discover_vg_lv(osCiId);
discover_hba(osCi, miniserCi);

if(miniserCi){
	discover_hp_miniserver_nic(nics, miniserCi)
}


def subList(list, start, end, step=1){
	int size = list.size();
	if(end >= 0){
		size = Math.min(size, end);
	}
	def result = [];
	for(def i = start; i < size; i += step){
		result.add(list[i]);
	}
	return result;
}

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}

def discover_hba(osCi, miniserCi){
	$logger.logInfo("Discover HBA");
	def commondResult = commondResult = cliUtil.executeCommand("ioscan -kfnNC fc|tail -n+3");
	if($text.isNull(commondResult)){
		return ;
	}
	def models = []
    def fc_all = []
    for(def fc in subList($text.splitLine(commondResult), 0, -1, 2)){
        models.add(fc.split()[7])
    }
    for(fc in subList($text.splitLine(commondResult), 1, -1, 2)){
        fc_all.add(fc.trim())
    }
    def size = Math.min(models.size(), fc_all.size());
    for(def i = 0; i <size; i++){
    	def fc = fc_all[i];
    	def model = models[i];
    	def fc_info = cliUtil.executeCommand("fcmsutil ${fc}");
    	
    	def status = search(fc_info, '(?<=Driver\\sstate\\s=\\s)(\\S+)')
        def wwn = search(fc_info, '(?<=N_Port\\sPort\\sWorld\\sWide\\sName\\s=\\s)(\\S+)')
        def speed = search(fc_info, '(?<=Link\\sSpeed\\s=\\s)(\\S+)')

        def firmware_version = search(fc_info, '(?<=Firmware\\sVersion\\s=\\s)(\\S+)')

        def driver_result = search(fc_info, '(?<=Driver\\sVersion\\s=\\s)(.+)')
        def driver_version = search(driver_result, '(?<=fcd\\s)(\\S+)')
        if(!driver_version){
            driver_version = search(driver_result, '(?<=fclp\\s)(\\S+)')
		}
        def hardware_path = search(fc_info, '(?<=Hardware\\sPath\\sis\\s=\\s)(\\S+)')
        def hba_slot_id = null;
        def hba_port_id = null;
    	if(hardware_path){
            hba_slot_id = hardware_path.split('/')[0..-2].join('/')
            hba_port_id = hardware_path.split('/')[-1]
        }
    	wwn = wwn.replace('0x', '')
    	def os_hba_ci = $ci.create('osHBA', fc.split('/')[-1])
    	$ci.createRelationship("Inlines", osCi.id, os_hba_ci.id);
        os_hba_ci.putAll([
            'wwn': wwn,
            'status': status,
            'firmware': firmware_version,
            'driver_version': driver_version
        ])
		
		if(miniserCi){
	        def miniserver_hba_ci = $ci.create('serverHBA', model)
	        $ci.createRelationship("Inlines", miniserCi.id, miniserver_hba_ci.id);
	        miniserver_hba_ci.putAll([
	            'wwn': wwn,
	            'hba_speed': speed,
	            'hba_port_id': hba_port_id,
	            'hba_slot_id': hba_slot_id
	        ])
        }
    }
}

def discover_hca(osCi, miniserCi){
	$logger.logInfo("Discover HCA");
	def commondResult = commondResult = cliUtil.executeCommand("lanscan |grep -w IB|awk '{print \$5,\$1}'");
	if($text.isNull(commondResult)){
		return ;
	}
	def hca_dict = [:]
    for(def line in $text.splitLine(commondResult)){
    	def ss = line.split();
        def name = ss[0]
        def hardware_path = ss[1]
        hca_dict[name] = hardware_path
	}
	
	commondResult = commondResult = cliUtil.executeCommand("ioscan -kfnNCib |tail -n+3");
	if($text.isNull(commondResult)){
		return ;
	}
	def models = [:]
    for(def line in $text.splitLine(commondResult)){
    	def ss = line.split();
        def hw_path = ss[2]
        def model = ss[7]
        models[hw_path] = model
	}
	
	for ( e in hca_dict ) {
		def name = e.key
		def hw_path = e.value

        def result = cliUtil.executeCommand("nwmgr -v -c ${name}")

        def mac_address = search(result, '(?<=MAC\\sAddress\\s=\\s)(\\S+)')
        def mac = parse_hp_mac(mac_address)
        if(hw_path.startsWith('LinkAgg')){
            bonding = 'true'
        }
        else{
            bonding = 'false'
		}
        def ci = $ci.create('osHCA', name)
        $ci.createRelationship("Inlines", osCi.id, ci.id);
        ci.putAll([
            mac_addr : mac,
            bonding_flag : bonding
        ])
        
        if(hw_path.startsWith('LinkAgg') && !miniserCi){
            continue
        }
        
        def hca_slot_id = null
        def hca_port_id = null
        hca_hardware_path = search(result, '''(?<=HCA\\'s\\sHardware\\sPath\\s=\\s)(\\S+)''')
        if(hca_hardware_path){
            hca_slot_id = hca_hardware_path.split('/')[0..-2].join('/')
            hca_port_id = hca_hardware_path.split('/')[-1]
        }
        
        def speed = search(result, '(?<=Speed\\s=\\s)(.+)')
        def model_name = models.get(hw_path)

        ci = $ci.create('ServerHCA', model_name)
        $ci.createRelationship('Inlines', miniserCi.id, ci.id)
        ci.putAll([
             mac_addr : mac,
             hca_speed : speed.split().join(''),
             hca_slot_id : hca_slot_id,
             hca_port_id : hca_port_id
        ])
    }
}

def parse_hp_mac(strings){
	strings = strings.toLowerCase()
	def length = strings.length();
	def result = []
	for(def i = 2; i < length; i += 2){
		def end = i + 1;
		if(end == length){
			end = length -1
		}
		result.add(strings[i..end])
	}
	return result.join(":")
}


def discover_nic(osCiId){
	$logger.logInfo("Discover NIC");
	def ipMap = [:];
	def commondResult = cliUtil.executeCommand("""lanscan |tail -n +3""");
	if($text.isNull(commondResult)){
    	return ;
    }
    def exclude_snap = ['snap900', 'snap901', 'snap902', 'snap903', 'snap904']
    def cis = []
	for (def line in $text.splitLine(commondResult)) {
		def ss = $text.splitWord(line);
		def mac_addr = ss[1]
		def status = ss[3]
		def name = ss[4]
		def snap = ss[5]
		if(status == 'DOWN' && snap in exclude_snap){
			continue;
		}
		def bonding_flag = 'false';
		if(snap in exclude_snap){
			bonding_flag = 'true'
		}
		def ci = $ci.create('osNIC', name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			 ips : $text.splitLine(cliUtil.executeCommand("ifconfig lan1 2>/dev/null|grep -w inet|awk '{print \$2}'")).join(","),
        			 mac_addr : parse_hp_mac(mac_addr),
        			 bonding_flag : bonding_flag
                  ])
       	cis.add(ci);
	}
	return cis
}

def discovery_server(osCi){
	$logger.logInfo("Discover miniserver pars");
	def commondResult = cliUtil.executeCommand("parstatus >/dev/null 2>&1 && echo true");
    if(!$text.isNull(commondResult)){
    	return ;
    }

	$logger.logInfo("Discover PCServer");
	def machinfo = cliUtil.executeCommand("machinfo")
	def cpu_speed_clock = search(machinfo, '(?<=processor\\s\\()(.+?)(?=,)')
	def firmware_ver = search(machinfo, '(?<=Firmware\\srevision:)(.+)')
	def model = search(machinfo, '(?<=Model:)(.+)')
	if(model.contains('Virtual Machine')){
        $logger.logInfo("this is virtual machine");
        return
    }
    model = model.split()[-1].trim();
    if(model.startsWith('"')){
    	model = model.substring(1);
    }
    if(model.endsWith('"')){
    	model = model.substring(0, model.length() - 1);
    }
    def physical_cpus = search(machinfo, '(\\d+)(?=\\ssocket)')
    def total_memory = convert_bytes(search(machinfo, '(?<=Memory:\\s)(\\S+)'), new convert_bytes_params(src_unit : 'MB'))
    def name = "${model}/${osCi.serial_number}";
    def serverCi = $ci.create('HPMiniServer', name)
    serverCi.putAll([
        model : model,
        firmware : firmware_ver,
        cpu_model : osCi.cpuArch,
        cellboard_num : cliUtil.executeCommand("parstatus -C 2>/dev/null|grep ^cab|wc -l"),
        serial_number : osCi.serial_number,
        cpu_speed_clock : cpu_speed_clock.split().join(''),
        cpus : physical_cpus,
        memory : total_memory,
        miniserver_brand : 'hp'
    ])
    $ci.createRelationship("RunsOn", osCi.id, serverCi.id);
    return serverCi
}

def discover_file_system(osCiId){
	$logger.logInfo("Discover file system");
	def commondResult = cliUtil.executeCommand("""bdf |tail -n +2""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def tmp_ss = "";
    for(def line in $text.splitLine(commondResult)){
        if (!line.contains("%")) {
	tmp_ss = line;
	continue;
        } else if (tmp_ss.length() > 0) {
	line = tmp_ss + line;
	tmp_ss = "";
        }
    	def ss = $text.splitWord($text.trim(line));
        def dev_name = ss[0];
        def fs_size = ss[1];
        def fs_mount = ss[5];
        if(dev_name.contains('lvol1')){
            continue
        }
        ci = $ci.create('fileSystem', dev_name)
        $ci.createRelationship("Inlines", osCiId, ci.id);
        ci.putAll([
        			fs_type : cliUtil.executeCommand("fstyp ${dev_name}"),
        			fs_mount_point : fs_mount,
        			fs_total_size : convert_bytes(fs_size, new convert_bytes_params(src_unit : 'KB'))
                  ])
    }
}

def discover_vg_lv(osCiId){
	$logger.logInfo("Discover VG and LV");
	def commondResult = cliUtil.executeCommand("""vgdisplay -vF""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def vgs = findAll(commondResult, '(?<=vg_name=)(\\S+)')
    def lvs = findAll(commondResult, '(?<=lv_name=)(\\S+)');
    
    for(def vg in vgs){
        def vgname = vg.split(':')[0].split('/')[-1]
        def pp_size = search(vg, '(?<=pe_size=)(.+?)(?=:)')
        def free_pe = search(vg, '(?<=free_pe=)(.+?)(?=:)')
        def total_pe = search(vg, '(?<=total_pe=)(.+?)(?=:)')
        def alloc_pe = search(vg, '(?<=alloc_pe=)(.+?)(?=:)')
        def vg_status = search(vg, '(?<=vg_status=)(.+?)(?=:)')

        if(vg_status != 'available'){
            continue
		}
		
		def ci = $ci.create('unixVG', vgname)
        ci.putAll([
        	pp_size : convert_bytes(pp_size, new convert_bytes_params(src_unit : 'MB')), 
            lv_num : search(vg, '(?<=cur_lv=)(.+?)(?=:)'),
            pv_num : search(vg, '(?<=act_pv=)(.+?)(?=:)'),
            vg_free_size : convert_bytes($number.parse(free_pe).intValue() * $number.parse(pp_size).intValue(), new convert_bytes_params(src_unit : 'MB')),
            vg_used_size : convert_bytes($number.parse(alloc_pe).intValue() * $number.parse(pp_size).intValue(), new convert_bytes_params(src_unit : 'MB')),
            vg_total_size : convert_bytes($number.parse(total_pe).intValue() * $number.parse(pp_size).intValue(), new convert_bytes_params(src_unit : 'MB'))
        ]);
        $ci.createRelationship("Inlines", osCiId, ci.id)
    }
    
    for(def lv in lvs){
        def lvname = lv.split(':')[0].split('/')[-1]
        def lvsize = search(lv, '(?<=lv_size=)(.+?)(?=:)')
        def lvstatus = search(lv, '(?<=lv_status=)(.+?)(?=:)')

        if(lvname.contains('lvol1') || lvstatus != 'available,syncd'){
            continue
		}
        def vgname = lv.split(':')[0].split('/')[-2]

        def ci = $ci.create('unixLV', lvname)
        $ci.createRelationship("Inlines", osCiId, ci.id)
        ci.putAll([
            lv_size : convert_bytes(lvsize, new convert_bytes_params(src_unit : 'MB')),
            vg_name : vgname
        ])
    }
}


def get_servernic_models(){
    def output = [:]
    def commondResult = cliUtil.executeCommand("ioscan -kfnNClan |tail -n+3");
    if($text.isNull(commondResult)){
    	return output;
    }
    for(def line in $text.splitLine(commondResult)){
    	def ss = line.split();
        def model = ss[7]
        def hw_path = ss[2]
        output[hw_path] = model
	}
    return output
}

def discover_hp_miniserver_nic(nics, miniserCi){
	$logger.logInfo("Discover miniserver nic");
	def servernic_models = get_servernic_models()
    for(def nic in nics){
        def nic_info = cliUtil.executeCommand("nwmgr -v -c ${nic.name}");
        def nic_speed = search(nic_info, '(?<=Speed\\s=\\s)(.+)')
		
		def speed = null;
        if(nic_speed.startsWith('Autonegotiation')){
            speed = 'Autonegotiation'
        }
        else{
            speed = nic_speed.split()[0..1].join('')
		}
		
		def nic_slot_id = null
        def nic_port_id = null
        def hardware_path = search(nic_info, '(?<=Hardware\\sPath\\s=\\s)(.+)')
        if(hardware_path){
            nic_slot_id = hardware_path.split('/')[0..-2].join('/')
            nic_port_id = hardware_path.split('/')[-1]
        }
		
        def nic_model_name = servernic_models.get(hardware_path)
        if(!nic_model_name){
            continue
		}
        def ci = $ci.create('ServerNIC', nic_model_name)
        ci.putAll([
             mac_addr : nic.mac_addr,
             nic_speed : speed,
             nic_port_id : nic_port_id,
             nic_slot_id : nic_slot_id
        ])
        $ci.createRelationship("Inlines", miniserCi.id, ci.id)
    }
}

def discovery_user_group(osCiId){
	$logger.logInfo("Discover users and user groups");
	def exclude_users = ['root', 'daemon', 'bin', 'sys', 'adm', 'uucp', 'lp', 'nuucp', 'hpdb', 'nobody', 'www', 'cimsrvr', 'smbnull', 'opc_op', 'hpsmh', 'sfmdb', 'sshd', 'iwww', 'owww'];
	def all_groups = [];
	def excludeShell = []
	def commondResult = cliUtil.executeCommand("""cat /etc/passwd""");
    if($text.isNull(commondResult)){
    	return ;
    }
    def passwd_maxdays = get_password_policy().get('PASSWORD_MAXDAYS');
	for(def userStr in $text.splitLine(commondResult)){
		def ss = userStr.split(":", 7);
		def user = [loginName: ss[0], passwd: ss[1], UID: ss[2], GID: ss[3], userName: ss[4], homeDirectory: ss[5], shell: ss[6]]
		if(excludeShell.contains(user.shell)){
            continue;
        }
        if(exclude_users.contains(user.loginName)){
            continue;
        }
        def user_info = cliUtil.executeCommand("""id ${user.loginName}""");
        def tmp = findAll(user_info, "(\\d+)\\((.*?)\\)");
        def groups = tmp[1..-1];
        all_groups.addAll(groups);
        def ci = $ci.create("unixUser", user.loginName);
        $ci.createRelationship("Inlines", osCiId, ci.id);
		ci.uid = user.UID;
        ci.home = user.homeDirectory;
        ci.shell = user.shell;
        ci.groups = groups.collect{e->e[1]}.join(",");
        ci.primary_group =  primary_group = tmp[1][1];
        ci.password_expires = get_password_expires(user.loginName, passwd_maxdays);
	}
	def exclude_groups = ['other', 'bin', 'sys', 'adm', 'daemon', 'mail', 'lp', 'tty', 'nuucp', 'users', 'nogroup', 'cimsrvr', 'smbnull', 'opcgrp', 'hpsmh', 'sshd', 'asmadmin', 'asmoper', 'asmdba', 'hpvmsys']
	for(g in all_groups.unique()){
		def groupName = g[1]
		if(exclude_groups.contains(groupName)){
            continue;
        }
		def ci = $ci.create('unixGroup', groupName)
        ci.gid = g[0]
        $ci.createRelationship("Inlines", osCiId, ci.id)
	}
}

def get_password_expires(user, passwd_maxdays){
    def result = cliUtil.executeCommand("passwd -s ${user}").split();
    if(result.size() == 2 && result[1] == 'LK'){
        return 'nopassword'
    }
    else if(result.size() == 2 && result[1] == 'PS'){
    	if(!passwd_maxdays){
    		return 'never'
    	}
    	else {
    		return 'PS'
    	}
    }
    else if(result.size() > 2 && result.size() < 5){
        return 'never'
    }
    else if(result.size() >= 5){
    	def date = result[2]
        def max_day = result[4]
        def ss = date.split('/');
        def m = $number.parse(ss[0]).intValue();
        def d = $number.parse(ss[1]).intValue();
        def y = $number.parse("20" + ss[2]).intValue();
        def localDate = LocalDate.of(y, m, d);
        localDate = localDate.plusDays($number.parse(max_day).intValue());
    	return localDate.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
    return "";
}

def get_password_policy(){
    def output = [:]
    def f = '/etc/default/security'
    def data = cliUtil.executeCommand("cat ${f}");

    for(def line in $text.splitLine(data)){
    	if(line.startsWith("#")){
    		continue
    	}
        def key_value = line.split('=', 2)
        if(key_value.size() == 1){
        	continue
        }
        output[key_value[0].trim()] = key_value[1].trim();
	}
    return output
}


def discovery_HP_UX(system) {
	$logger.logInfo("Discover HP-UX");
	def hostname = cliUtil.executeCommand("uname -n");
    def ci = $ci.create("HPUX", "HPUX", $ccli.params.ip + "-" + hostname);
    ci.ip = $ccli.params.ip;
    
    ci.hostname = hostname
    ci.bits = search(cliUtil.executeCommand("osinfo"), "(?<=OSCapability:\\s)(\\d+)");
    ci.cpuArch = cliUtil.executeCommand("uname -m");
    ci.hp_nfile = cliUtil.executeCommand("ulimit -n");
    ci.time_zone = cliUtil.executeCommand("echo \$TZ");
    ci.ntp_server = cliUtil.executeCommand("cat /etc/resolv.conf 2>/dev/null |grep ^nameserver |awk '{print \$2}'")
    ci.dns_server = $text.splitLine(cliUtil.executeCommand("cat /etc/ntp.conf 2>/dev/null |grep ^server |awk '{print \$2}'")).join(" | ") 
    
    ci.swap_size = convert_bytes(cliUtil.executeCommand("swapinfo |grep memory |awk '{print \$2}'"),  new convert_bytes_params(src_unit : 'KB'))
    ci.memory_size =  convert_bytes(cliUtil.executeCommand("machinfo |grep Memory:|awk -F'[()]' '{print \$2}'"))
    def openssh_ver = cliUtil.executeCommand("ssh -V 2>&1 |grep 'OpenSSH'")
    openssh_ver = search(openssh_ver, "(?<=OpenSSH_)(.+)(?=\\+)");
    if(openssh_ver){
    	openssh_ver = "OpenSSH_6${openssh_ver}"
    }
    ci.openssh_ver = openssh_ver
    def openssl_ver = cliUtil.executeCommand("openssl version |awk '{print \$2}'")
    if(openssl_ver){
    	openssl_ver = "OpenSSL${openssl_ver}"
    }
    ci.openssl_ver = openssl_ver
    def os_ver_detl = cliUtil.executeCommand("swlist -l bundle|grep 'HPUX.*OE' |awk '{print \$2}'")
    if(os_ver_detl.startsWith("B.")){
    	os_ver_detl = os_ver_detl.replaceFirst("B.", "HP-UX")
    }
    ci.os_ver_detl =  os_ver_detl
    ci.cpu_core_num = $number.parse(cliUtil.executeCommand("machinfo   | sed -n '3p' |awk '{print \$1}'")).intValue();
    ci.hp_max_uproc = cliUtil.executeCommand("kcusage maxuprc|tail -n 1|awk '{print \$NF}'");
    def multi_soft_ver = cliUtil.executeCommand("pcmpath query version 2>/dev/null|grep -w SDDPCM |awk '{print \$3}'");
    if(multi_soft_ver){
    	multi_soft_ver = "SDDPCM: ${multi_soft_ver}"
    }
    ci.serial_number = cliUtil.executeCommand("getconf CS_MACHINE_SERIAL")
    ci.multi_soft_ver = multi_soft_ver
    ci.default_gateway = cliUtil.executeCommand("netstat -nr |grep -w default |awk '{print \$2}'")
    
    def hpux_passwd_policy = get_password_policy();
    ci.putAll([
    	pass_max_day : hpux_passwd_policy.get('PASSWORD_MAXDAYS'),
        pass_min_day : hpux_passwd_policy.get('PASSWORD_MINDAYS'),
        user_deny_cnt : hpux_passwd_policy.get('AUTH_MAXTRIES'),
        password_minlen : hpux_passwd_policy.get('MIN_PASSWORD_LENGTH'),
        password_dcredit : hpux_passwd_policy.get('PASSWORD_MIN_DIGIT_CHARS'),
        password_lcredit : hpux_passwd_policy.get('PASSWORD_MIN_LOWER_CASE_CHARS'),
        password_ocredit : hpux_passwd_policy.get('PASSWORD_MIN_SPECIAL_CHARS'),
        password_ucredit : hpux_passwd_policy.get('PASSWORD_MIN_UPPER_CASE_CHARS')
    ])
    return ci;
}