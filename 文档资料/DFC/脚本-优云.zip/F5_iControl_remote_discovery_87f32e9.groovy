/*!Action
action.name=F5_iControl_remote_discovery_87f32e9
action.descr=F5_iControl_remote_discovery   支持 V12及以上版本
action.version=1.0.0
action.protocols=http
action.main.model=F5Dev
discovery.output=NetworkDevice
*/

/*!Params
ip:目标设备IP,ip,,true
username:用户名,text,,false
password:密码,password,,false
*/

/*!Model
F5Dev:F5设备,F5Dev,F5设备,false,false
properties
lbPort:负载均衡设备接口,inline,null,null,lbPort,负载均衡设备接口
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
selfIP:SelfIP地址,inline,null,null,selfIP,SelfIP地址
model:型号,string,null,null,model,型号
brand:品牌,string,null,null,brand,品牌
ip:带外管理IP,string,null,null,ip,带外管理IP
network_domain:网络域,string,null,null,network_domain,网络域
serial_number:序列号,string,null,null,serial_number,序列号
version:软件版本,string,null,null,version,软件版本
port:端口,int,null,null,port,端口
name:名称,string,null,null,name,名称
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
*/

/*!Model
LBPort:负载均衡设备接口,LBPort,负载均衡设备接口,true,false
properties
media_speed:接口速率,string,null,null,media_speed,接口速率
mac_addr:MAC地址,string,null,null,mac_addr,MAC地址
name:接口名称,string,null,null,name,接口名称
trunk:trunk名称,string,null,null,trunk,trunk名称
*/

/*!Model
SelfIP:SelfIP,SelfIP,SelfIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:SelfIIP名称,string,null,null,name,SelfIIP名称
*/

/*!Model
F5VS:F5VS,F5VS,F5VS,false,false
properties
default_perst_profile:单默认会话保持方式,string,null,null,default_perst_profile,单默认会话保持方式
source_addr_trans:源地址转换,string,null,null,source_addr_trans,源地址转换
default_pool:缺省Pool,string,null,null,default_pool,缺省Pool
profile:profile,string,null,null,profile,profile
ip:VIP地址,string,null,null,ip,VIP地址
vs_name:VS名称,string,null,null,vs_name,VS名称
policies:Policies,inline,null,null,policies,Policies
iRules:iRules规则,inline,null,null,iRules,iRules规则
network_domain:网络域,string,null,null,network_domain,网络域
snatIP:SnatIP地址,inline,null,null,snatIP,SnatIP地址
protocol:协议,string,null,null,protocol,协议
port:端口,int,null,null,port,端口
trafficgroup_name:所在TrafficGroup名称,string,null,null,trafficgroup_name,所在TrafficGroup名称
name:名称,string,null,null,name,名称
*/

/*!Model
Policies:Policies,Policies,Policies,true,false
properties
name:Policies名称,string,null,null,name,Policies名称
*/

/*!Model
IRules:IRules,IRules,IRules,true,false
properties
name:iRules名称,string,null,null,name,iRules名称
*/

/*!Model
SnatIP:SnatIP,SnatIP,SnatIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
F5Pool:F5Pool,F5Pool,F5Pool,false,false
properties
prio_group_activation:优先组状态,string,null,null,prio_group_activation,优先组状态
dev_cluster_serial_number:设备/集群序列号,string,null,null,dev_cluster_serial_number,设备/集群序列号
load_balance_method:负载均衡方式,string,null,null,load_balance_method,负载均衡方式
name:名称,string,null,null,name,名称
health_monitor:健康检查方式,string,null,null,health_monitor,健康检查方式
poolMember:PoolMember成员,inline,null,null,poolMember,PoolMember成员
pool_name:Pool名称,string,null,null,pool_name,Pool名称
*/

/*!Model
PoolMember:服务池成员,PoolMember,服务池成员,true,false
properties
port:端口,int,null,null,port,端口
ip:IP地址,string,null,null,ip,IP地址
name:名称,string,null,null,name,名称
*/

/*!Model
F5Cluster:F5集群,F5Cluster,F5集群,false,false
properties
cluster_name:集群名称,string,null,null,cluster_name,集群名称
floatingIP:FloatingIP地址,inline,null,null,floatingIP,FloatingIP地址
cluster_serial_number:集群成员序列号,string,null,null,cluster_serial_number,集群成员序列号
name:名称,string,null,null,name,名称
cluster_hostname:集群成员主机名,string,null,null,cluster_hostname,集群成员主机名
*/

/*!Model
FloatingIP:FloatingIP,FloatingIP,FloatingIP,true,false
properties
ip:IP地址,string,null,null,ip,IP地址
name:FloatingIP名称,string,null,null,name,FloatingIP名称
*/

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.auth.AuthScope;
import org.apache.http.client.methods.HttpGet;


def httpclientBuild = HttpClientBuilder.create().setSSLSocketFactory(getSSL())
def provider = new BasicCredentialsProvider()
def credentials = new UsernamePasswordCredentials($scriptParams.username, $scriptParams.password)
provider.setCredentials(AuthScope.ANY, credentials)
httpclientBuild.setDefaultCredentialsProvider(provider)
httpclient = httpclientBuild.build()
baseUrl = "https://" + $scriptParams.ip

def f5Ci = discovery_f5()
discovery_pool(f5Ci)
discovery_vs(f5Ci)

def search(msg, regex, flags=0){
	def pattern = Pattern.compile(regex, flags);
	def matcher = pattern.matcher(msg);
	while(matcher.find()){
		return matcher.group(0).trim();
	}
	return ""	
}

def findAll(msg, regex){
	def pattern = Pattern.compile(regex);
	def matcher = pattern.matcher(msg);
	def result = [];
	while(matcher.find()){
		int count = matcher.groupCount();
		if(count == 1){
			result.add(matcher.group(1));
		}
		else {
			def ss = [];
			for(def i = 0; i < count; i++){
				ss[i] = matcher.group(i + 1);
			}
			result.add(ss);
		}
	}
	return result;	
}

def findAllFirst(msg, regex){
	def x = findAll(msg, regex);
	if(x.size() != 0){
		x = x[0];
		if(x in List){
			if(x.size() != 0){
				return x[0];
			}
		}
		else {
			return x;
		}
	}
	return "";
}

class convert_bytes_params{
	def unit;
	def src_unit;
	def multiple = 1024;
	def return_str = true;
}
def convert_bytes(size, convert_bytes_params=new convert_bytes_params()){
	def unit=convert_bytes_params.unit;
	def src_unit=convert_bytes_params.src_unit;
	def multiple=convert_bytes_params.multiple;
	def return_str=convert_bytes_params.return_str;
    def symbols = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    def symbols1 = ['B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'];
    def symbols2 = ['B', 'KIB', 'MIB', 'GIB', 'TIB', 'PIB', 'EIB', 'ZIB', 'YIB'];
    if(!size){
        return
    }
    try{
	    if(size.class == String.class){
	    	size = size.replace(',', '')
	    	def util_tmp = search(size, '[bkmgtpezyi]{1,3}', Pattern.CASE_INSENSITIVE);
	    	if(util_tmp){
	        	def _src_unit = util_tmp.toUpperCase();
	            if(symbols1.contains(_src_unit)){
	            	src_unit = symbols[symbols1.indexOf(_src_unit)]
	            }
	            else if(symbols2.contains(_src_unit)){
	                src_unit = symbols[symbols2.indexOf(_src_unit)]
	            }
	            else if(symbols.contains(_src_unit)){
	            	src_unit = _src_unit
	            }
	        }
	        size = new Double(search(size, """\\d+(\\.\\d+)?""")).floatValue();
	    }
	    else{
	         size = size.floatValue();
	    }
	    def step = 0
	    if(src_unit){  //指定了原始单位
	        size = size * (multiple ** (symbols.indexOf(src_unit.toUpperCase())))
	    }
	    if(!unit){  //自动计算单位
	        while (size >= multiple && step < symbols.size() - 1){
	            size /= multiple
	            step += 1
	        }
	        unit = symbols[step]
	    }
	    else{ //转换为指定单位
	        def index_of_unit = symbols.indexOf(unit)
	        while(symbols.size() - 1 > step && index_of_unit != step){
	            size /= multiple
	            step += 1
	        }
	    }
	    if(return_str){
	        return String.format('%.2f %s', size, unit)
	    }
	    else {
	        return [size, unit];
	    }
	}catch(Exception e){
        return size
    }
}



def doGet(url) {
	def response = null;
	def method = null;
	try{
		method = new HttpGet(url);
		method.addHeader("Accept", "application/json");
		method.addHeader("Connection", "close");
		response = httpclient.execute(method);
		def entity = response.getEntity();
		def code = response.getStatusLine().getStatusCode();
		def body = "";
		if(entity){
			body = EntityUtils.toString(entity, "UTF-8");
		}
		//println url + "!" + code
		if(!responseIsSuccess(code)){
			throw new RuntimeException("httpErroe!url:${url},responseCode:${code},responseBody${body}")
		}
		return body;
	} finally {
		close(method)
		close(response)
	}
}

def close(obj){
	try{
		if(obj){
			obj.close();
		}
	}catch(Exception e){
		
	}
}

def responseIsSuccess(code){
    if (code >= 200 && code < 300){
        return true;
    }
    return false;
}

def getSSL(){
	def sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
	    //信任所有
	    public boolean isTrusted(X509Certificate[] chain,
	        String authType) throws CertificateException {
	        return true;
	    }
	
	}).build();
	
	def sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
	return sslsf;
}

def discovery_f5(){
	$logger.logInfo("Discover f5");
	def selfInfos = get_all_self();
	def body = doGet(baseUrl + '/mgmt/tm/cm/device')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items");
	def cis = []
	def trunkMap = get_all_trunk()
	for(def i = 0; i < items.size(); i++){
		def device = items.getJSONObject(i)
		def ci = $ci.create("F5Dev", "F5Dev", device.name)
		ci.putAll([
			ip : device.managementIp,
			brand : 'F5',
			version : device.version,
			model : device.marketingName,
			serial_number : device.chassisId
		])
		cis.add(ci)
		if(device.selfDevice == 'true'){
			def servers = JSONObject.parseObject(doGet(baseUrl + '/mgmt/tm/sys/ntp')).servers
			if(servers){
				ci.ntp_server = servers.join(",")
			}
			def snmps = JSONObject.parseObject(doGet(baseUrl + '/mgmt/tm/sys/snmp/traps')).items
			if(snmps){
				ci.snmp_server = snmps.collect{e->e.host}.join(",")
			}
			for(def selfIP in selfInfos[0]){
				def selfIPCi = $ci.create("SelfIP", selfIP.name);
				selfIPCi.ip = selfIP.address.split("/")[0]
				$ci.createRelationship("Inlines", ci.id, selfIPCi.id)
			}
			
			def interfaces = JSONObject.parseObject(doGet(baseUrl + '/mgmt/tm/net/interface')).items
			for(def interf in interfaces){
				def lbPortCi = $ci.create("LBPort", interf.name);
				lbPortCi.putAll([
					media_speed : interf.mediaMax,
					mac_addr : interf.macAddress,
					trunk : trunkMap[interf.selfLink]
				])
				$ci.createRelationship("Inlines", ci.id, lbPortCi.id)
			}
		}
	}
	if(!cis){
		throw new RuntimeException("not find f5 device")
	}
	
	if(cis.size() == 1){
		return cis[0]
	}
	def cluster_hostname = cis.collect{e->e.name}.sort().join("/")
	def name = discovery_groupName(cis.size());
	if(!name){
		name = cluster_hostname
	}
	def clusterCi = $ci.create("F5Cluster", "F5Cluster", name)
	clusterCi.putAll([
		cluster_serial_number : cis.collect{e->e.serial_number}.sort().join("/"),
		cluster_hostname : cluster_hostname,
		cluster_name : name
	])
	for(def ci : cis){
		$ci.createRelationship("Contains", clusterCi.id, ci.id)
	}
	for(def floatingIP in selfInfos[1]){
		def floatingIPCi = $ci.create("FloatingIP", floatingIP.name);
		floatingIPCi.ip = floatingIP.address.split("/")[0]
		$ci.createRelationship("Inlines", clusterCi.id, floatingIPCi.id)
	}
	return clusterCi
}

def discovery_pool(def f5Ci){
	$logger.logInfo("Discover pool");
	poolCis = [:]
	def body = doGet(baseUrl + '/mgmt/tm/ltm/pool')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items");
	def dev_cluster_serial_number = f5Ci.cluster_serial_number
	if(!dev_cluster_serial_number){
		dev_cluster_serial_number = f5Ci.serial_number
	}
	if(items){
		for(def i = 0; i < items.size(); i++){
			def pool = items.getJSONObject(i);
			def poolCi = $ci.create("F5Pool", pool.name);
			poolCis[pool.fullPath] = poolCi
			poolCi.putAll([
				pool_name : pool.name,
				dev_cluster_serial_number : dev_cluster_serial_number,
				load_balance_method : pool.loadBalancingMode,
				prio_group_activation : pool.minActiveMembers,
				health_monitor : pool.monitor ? pool.monitor.split(" and ").collect{e->e.split("/")[-1]}.join(",") : ""
			])
			body = doGet(baseUrl + '/' + pool.getJSONObject("membersReference").getString('link').split('/', 4)[-1])
			def members = JSONObject.parseObject(body).getJSONArray("items");
			if(members){
				for(def j = 0; j < members.size(); j++){
					def member = members.getJSONObject(j)
					def name = member.name;
					def ci = $ci.create('PoolMember', name);
					ci.ip = member.address
					ci.port = name.split(":")[1]
					$ci.createRelationship("Inlines", poolCi.id, ci.id)
				}
			}
		}
	}
}

def discovery_vs(def f5Ci){
	$logger.logInfo("Discover vs");
	def profileMap = get_all_profile()

	def body = doGet(baseUrl + '/mgmt/tm/ltm/virtual')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items");
	if(items){
		for(def i = 0; i < items.size(); i++){
			def vs = items.getJSONObject(i);
			def ci = $ci.create("F5VS", vs.name);
			$ci.createRelationship("RunsOn", ci.id, f5Ci.id)
			def ss = vs.destination.split("/")[-1].split(":")
			ci.putAll([
				ip : ss[0],
				port : ss[1],
				vs_name : vs.name,
				protocol : vs.ipProtocol,
				source_addr_trans : vs.sourceAddressTranslation.type,
				default_perst_profile : vs.persist ? vs.persist[0].name : ""
			])
			if(vs.pool){
				def poolCi = poolCis[vs.pool]
				if(poolCi){
					ci.default_pool = poolCi.name
					$ci.createRelationship("Links", ci.id, poolCi.id)
				}
			}

			body = doGet(baseUrl + '/' + vs.getJSONObject("profilesReference").getString('link').split('/', 4)[-1])
			def profileArray = profileMap[vs.ipProtocol]
			def profiles = JSONObject.parseObject(body).getJSONArray("items");
			for(def j = 0; j < profiles.size(); j++){
				def profile = profiles.getJSONObject(j);
				if(profile.context == 'serverside'){
					continue
				}
				def name = profile.getString("fullPath");
				if(profileArray && name in profileArray){
					ci.profile = name.split("/")[-1]
					break
				}
			}
			
			if(ci.source_addr_trans == 'snat'){
				body = doGet(baseUrl + '/' + vs.getJSONObject("sourceAddressTranslation").getJSONObject('poolReference').getString("link").split('/', 4)[-1])
				def snatpool = JSONObject.parseObject(body);
				def name = snatpool.getString("name");
				def snatCi = $ci.create("SnatIP", name);
				if(snatpool.members){
					def ips = []
					for(def member : snatpool.members){
						ips.add(member.split("/")[-1])
					}
					snatCi.ip = ips.join(",")
				}
				$ci.createRelationship("Inlines", ci.id, snatCi.id)
			}
			
			if(vs.rulesReference){
				for(def j = 0; j < vs.rulesReference.size(); j++){
					def rule = vs.rulesReference.getJSONObject(j)
					body = doGet(baseUrl + '/' + rule.getString("link").split('/', 4)[-1])
					def name = JSONObject.parseObject(body).getString("name")
					def ruleCi = $ci.create("IRules", name);
					$ci.createRelationship("Inlines", ci.id, ruleCi.id)
				}
			}
			
			if(vs.policiesReference){
				body = doGet(baseUrl + '/' + vs.policiesReference.getString("link").split('/', 4)[-1])
				def policies = JSONObject.parseObject(body).getJSONArray("items")
				if(policies){
					for(def j = 0; j < policies.size(); j++){
						def name = policies.getJSONObject(j).getString("name")
						def policyCi = $ci.create("Policies", name);
						$ci.createRelationship("Inlines", ci.id, policyCi.id)
					}
				}
			}
		}
	}
}

def get_all_self(){
	def floating = []
	def no_floating = []
	def body = doGet(baseUrl + '/mgmt/tm/net/self')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items")
	def result = []
	if(items){
		for(def i = 0; i < items.size(); i++){
			def item = items.getJSONObject(i)
			if(item.floating == 'enabled'){
				floating.add(item)
			}
			else {
				no_floating.add(item)
			}
		}
	}
	return [no_floating, floating]
}


def get_all_profile(){
	def codes = ['tcp', 'udp', 'sctp']
	def results = [:]
	for(def code : codes){
		def body = doGet(baseUrl + '/mgmt/tm/ltm/profile/' + code)
		def obj = JSONObject.parseObject(body)
		def items = obj.getJSONArray("items")
		def result = []
		if(items){
			for(def i = 0; i < items.size(); i++){
				def item = items.getJSONObject(i)
				result.add(item.fullPath)
			}
		}
		results.put(code, result)
	}
	return results
}

def get_all_trunk(){
	def results = [:]
	def body = doGet(baseUrl + '/mgmt/tm/net/trunk')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items")
	if(items){
		for(def i = 0; i < items.size(); i++){
			def item = items.getJSONObject(i)
			def name = item.name
			def interfacesReferences = item.getJSONArray("interfacesReference")
			if(interfacesReferences){
				for(def j = 0; j < interfacesReferences.size(); j++){
					results.put(interfacesReferences.getJSONObject(j).link, name)
				}
			}
		}
	}
	return results
}

def discovery_groupName(def nodeSize){
	def body = doGet(baseUrl + '/mgmt/tm/cm/device-group')
	def obj = JSONObject.parseObject(body)
	def items = obj.getJSONArray("items");
	for(def i = 0; i < items.size(); i++){
		def item = items.getJSONObject(i)
		if(item.name == 'gtm' || item.name == 'device_trust_group'){
			continue
		}
		body = doGet(baseUrl + '/' + item.getJSONObject("devicesReference").getString('link').split('/', 4)[-1])
		if(JSONObject.parseObject(body).getJSONArray("items").size() == nodeSize){
			return  item.name
		}
	}
	return null
}