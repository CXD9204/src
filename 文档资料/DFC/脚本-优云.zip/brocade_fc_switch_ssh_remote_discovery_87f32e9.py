# coding: UTF-8
# UYUN script
# @Author: zhengyd@uyunsoft.cn
# @Date  : 2020/10/25
import copy
import sys
import re
import paramiko
try:
    reload(sys)
    sys.setdefaultencoding('utf-8')
except:
    pass

try:
    # 测试使用
    from _utils.Ci import Ci
    __ci__ = Ci()
    __args__ = [{'ip': '10.1.5.4', 'port': 22, 'username': 'user', 'password': 'password'}]
except ImportError:
    pass


"""!Action
action.name=博科FC存储交换机(ssh)_87f32e9
action.descr=博科FC存储交换机(ssh)远程发现
action.version=1.0.2
action.main.model=FCSwitch
discovery.output=storage
"""

"""!Params
ip:IP地址,text,,true
port:端口,number,22,false
username:用户名,text,admin,false
password:密码,password,password,false
"""

"""!Model
FCSwitch:FC存储交换机,FCSwitch,FC存储交换机,false,false
properties:
ip:IP地址,string,null,null,ip,IP地址
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
model:型号,string,null,null,model,型号
cfgname:cfg配置名称,string,null,null,cfgname,cfg配置名称
version:固件版本,string,null,null,version,固件版本
hostname:主机名,string,null,null,hostname,主机名
ntp_server:NTP服务器,string,null,null,ntp_server,NTP服务器
snmp_server:SNMP服务器,string,null,null,snmp_server,SNMP服务器
port_num:端口数,int,null,个,port_num,端口数
domain_id:Domain ID,int,null,null,domain_id,Domain ID
switch_role:交换机角色,string,null,null,switch_role,交换机角色
fcSwitchPort:端口信息,inline,null,null,fcSwitchPort,端口信息
serial_number:序列号,string,null,null,serial_number,序列号
fabricFCSwitch:级联FC存储交换机,inline,null,null,fabricFCSwitch,级联FC存储交换机
fcswitch_brand:品牌,string,null,null,fcswitch_brand,品牌
"""

"""!Model
fcSwitchPort:端口信息,FCSwitchPort,端口信息,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
status:状态,string,null,null,status,状态
port_type:端口类型,string,null,null,port_type,端口类型
zone_name:所属Zone名称,string,null,null,zone_name,所属Zone名称
port_index:端口索引号,int,null,null,port_index,端口索引号
port_speed:端口速率,string,null,null,port_speed,端口速率
"""

"""!Model
fabricFCSwitch:级联FC存储交换机,FabricFCSwitch,级联FC存储交换机,true,false
properties:
name:名称,string,null,null,name,名称
wwn:WWN号,string,null,null,wwn,WWN号
ip:IP地址,string,null,null,ip,IP地址
"""

"""!Model
FCSwitchZone:FC存储交换机Zone,FCSwitchZone,FC存储交换机Zone,false,false
properties:
name:名称,string,null,null,name,名称
wwn:WWN号,string,null,null,wwn,WWN号
vsan_id:VSAN编号,int,null,null,vsan_id,VSAN编号
zonePort:Zone端口,inline,null,null,zonePort,Zone端口
fcswitch_name:存储交换机名称,string,null,null,fcswitch_name,存储交换机名称
fcswitch_serial:交换机序列号,string,null,null,fcswitch_serial,交换机序列号
"""

"""!Model
zonePort:Zone端口,ZonePort,Zone端口,true,false
properties:
wwn:WWN号,string,null,null,wwn,WWN号
name:名称,string,null,null,name,名称
port_index:端口索引号,int,null,null,port_index,端口索引号
"""


def re_search(pattern, msg, convert_to=str, sep=None, num=-1):
    tmp = re.search(pattern, msg)
    if tmp:
        tmp = tmp.group().strip()
        try:
            if sep is not None:
                tmp = re.split(sep, tmp)[num].strip()
            return convert_to(tmp)
        except:
            return None


class DiscoveryFCSwitch(object):
    def __init__(self, ip, username, password, port=22, timeout=5):
        self.client = None
        self.ip = ip
        self.username = username
        self.password = password
        self.port = int(port)
        self.timeout = timeout
        self.client = None
        self.channel = None
        self.use_bash = True

        self.switch_ci = None
        self.ports_dict = {}
        self.port_cis = {}
        self.wwn = ''
        self.sn = None

    def login(self):
        try:
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            client.connect(self.ip, self.port, username=self.username,
                           password=self.password, timeout=self.timeout)
            self.client = client
            __ci__.result_log('INFO', '{}@{}:{} login succeed'.format(
                self.username, self.ip, self.port))
            return True
        except Exception as e:
            __ci__.result_log('ERROR', '{}@{}:{} login failed: {}'.format(
                self.username, self.ip, self.port, e))
            return False

    def run_cmd(self, cmd):
        if not self.client:
            self.login()
        if self.use_bash:
            cmd = "bash --login -c '{}'".format(cmd)
        self.channel = self.client.get_transport().open_session()
        self.channel.get_pty()
        self.channel.exec_command(cmd)
        stdout = self.channel.makefile('r', -1).read()
        stderr = self.channel.makefile_stderr('r', -1).read()
        code = self.channel.recv_exit_status()
        if code or stderr:
            __ci__.result_log('WARN', 'run cmd: {}, return code {}, {}'.format(repr(cmd), code, stderr))
        return code, stdout

    def logout(self):
        try:
            if self.channel:
                self.run_cmd('exit')
                self.channel.close()
                self.client.close()
                __ci__.result_log('INFO', 'logout')
        except Exception as e:
            __ci__.result_log('WARN', 'logout failed, {}'.format(e))

    @staticmethod
    def create_port_ci(ci_code, parent_ci, name, **kwargs):
        """
        用于创建 fcSwitchPort 或 zonePort  Ci
        """
        port_ci = __ci__.create(ci_code, name)
        port_ci['properties'] = kwargs
        __ci__.createrelationship(parent_ci['cid'], port_ci['cid'], 'Inlines')
        return port_ci

    @staticmethod
    def normalize_wwn(wwn):
        """标准化 wwn,  去除冒号转大写，100000051EA39600"""
        if wwn:
            return wwn.replace(':', '').upper()

    def port_show(self, port_id):
        code, res = self.run_cmd("portshow {}".format(port_id))
        # __ci__.result_log('INFO', res)
        if code:
            __ci__.result_log('ERROR', 'portshow {} ，Return Error： {}'.format(port_id, res))
            return
        else:
            connected = re_search(r'(?<=connected:)[\s\S]*(?=Distance:)', res)
            if connected:
                return {'wwn': ','.join(connected.split()),
                        'port_wwn': re_search('(?<=portWwn:).*', res)}

    def discovery_ports(self, switchshow):
        """
        从 switchshow 命令结果获取所有端口信息，
        当端口协议为 NPIV 时使用 portshow $port_id 发现端口详情
        """
        head = re_search(r'.*Proto', switchshow)
        if not head:
            __ci__.result_log('ERROR', 'switchshow 没有获取到端口表头信息')
            return False
        # area port media speed state     proto
        head = head.lower().split()

        port_lines = re.search(r'===+([\s\S]*)', switchshow)
        if not port_lines:
            __ci__.result_log('WARN', 'switchshow 命令未匹配到端口信息')
            return

        port_lines = port_lines.group(1).strip()
        for line in port_lines.splitlines():
            if not line.replace('=', '').strip():
                continue
            # Proto 列可能无数据， 将端口行数据 split 标题列数-1 次,
            line = re.split(r'\s+', line.strip(), maxsplit=len(head)-1)

            # index 非数字的则忽略, 比如网口
            if not line or not str.isdigit(line[0]):
                continue

            # 将标题与数据转换为字典格式数据
            port_dict = dict(zip(head, line))

            # 有些交换机第一列为area
            if port_dict.get('area'):
                port_dict['index'] = port_dict['area']
                port_dict.pop('area')

            # 拼接slot/port
            port_dict['port_id'] = '{}/{}'.format(port_dict.get('slot', 0), port_dict.get('port'))

            # 速率转换为类似 8 Gbps
            if re_search(r'\d+', port_dict.get('speed', '')):
                port_dict['speed'] = '{} Gbps'.format(re_search(r'\d+', port_dict.get('speed')))

            # 从 Proto 列获取链接端的 wwn 和 端口类型
            port_dict['wwn'] = re_search(r'([0-9a-f]{2}:?){7}[0-9a-f]{2}:?', line[-1])
            port_dict['port_type'] = re_search(r'\w+-Port', line[-1])

            # NPIV 模式从 portshow 获取 device 的 wwn
            if 'NPIV' in line[-1]:
                port_dict.update(self.port_show(port_dict['port_id']))

            # wwn 去掉冒号，转大写
            if port_dict.get('wwn'):
                port_dict['wwn'] = self.normalize_wwn(port_dict['wwn'])

            if port_dict.get('port_wwn'):
                port_dict['port_wwn'] = self.normalize_wwn(port_dict['port_wwn'])

            port_ci = self.create_port_ci('fcSwitchPort',
                                          self.switch_ci,
                                          port_dict['port_id'],
                                          port_index=port_dict.get('index'),
                                          wwn=port_dict.get('wwn'),
                                          port_type=port_dict.get('port_type'),
                                          port_speed=port_dict.get('speed'),
                                          status=port_dict.get('state')
                                          )

            self.ports_dict[port_dict['index']] = port_dict

            # 按 index 和 wwn 为 key 重复添加 self.port_cis， 方便后面 zonePort发现根据 index 或 wwn 定位 port_ci
            self.port_cis[port_dict['index']] = port_ci
            if port_dict.get('wwn'):
                for w in port_dict['wwn'].split(','):
                    self.port_cis[w] = port_ci

        __ci__.result_log('INFO', '发现 {} 个端口'.format(len(self.ports_dict)))
        self.switch_ci['properties']['port_num'] = len(self.ports_dict)
        return self.ports_dict

    def discovery_zone(self):
        """
        执行 zoneshow 命令，发现zone信息
        """
        zone_num = 0
        zoneshow = self.run_cmd("zoneshow")[1]
        # 获取生效的配置
        cfg = re.search(r'Effective configuration:([\s\S]*)', zoneshow)
        # cfg = re.search(r'Effective configuration:([\s\S]*)(\r+\n|\n){2,}', zoneshow)
        # cfg = re.search(r'Defined configuration:([\s\S]*?)(\r+\n|\n){2,}', zoneshow)
        if not cfg:
            __ci__.result_log('WARN', '获取运行配置文件失败, {}'.format(repr(zoneshow)))
            return
        cfg = cfg.group(1)
        cfg_name = re.findall(r'cfg:\s*(\w+)', cfg)[0]
        self.switch_ci['properties']['cfgname'] = cfg_name

        # 解析 zone 配置, 将非zone: 开头的添加到上一行, 方便后面按行解析
        cfg_tmp = ''
        for line in cfg.splitlines():
            if line.strip().startswith('zone:'):
                cfg_tmp += '\n' + line
            else:
                cfg_tmp += line

        # 按行解析 zone， 每行一个zone
        for line in cfg_tmp.splitlines():
            if not line.strip().startswith('zone:'):
                continue
            z = line.split()
            zone_num += 1
            # print(z)
            zone_name = z[1]
            zone_ci = __ci__.create('FCSwitchZone', zone_name)
            zone_ci['properties'] = {
                'fcswitch_serial': self.switch_ci['properties']['serial_number'],
                'fcswitch_name': self.switch_ci['name'],
                'wwn': self.wwn,
                'vsan_id': 0
                }
            # zone 运行在交换机上
            __ci__.createrelationship(zone_ci['cid'], self.switch_ci['cid'], 'RunsOn')

            for p in z[2:]:
                # 1,1 1,2  端口索引方式
                if ',' in p:
                    p = p.split(',')[-1]

                p = self.normalize_wwn(p)

                # 根据index 或 wwn 定位 port_ci
                port_ci = self.port_cis.get(p)
                # print p, port_ci
                if port_ci:

                    # port_ci 添加当前 zone_name
                    if not port_ci['properties'].get('zone_name'):
                        port_ci['properties']['zone_name'] = zone_name
                    elif zone_name not in port_ci['properties']['zone_name']:
                        port_ci['properties']['zone_name'] += ',' + zone_name

                    self.create_port_ci('zonePort',
                                        zone_ci,
                                        port_ci['name'],
                                        port_index=port_ci['properties']['port_index'],
                                        wwn=port_ci['properties'].get('wwn'))
                # else:
                #     __ci__.result_log('WARN', '发现zone {} 的端口 {}， 但没有找到对应端口信息'.format(zone_name, p))

        __ci__.result_log('INFO', '发现 {} 个zone'.format(zone_num))

    def discovery_cascade_switch(self):
        """执行 fabricshow 命令发现级联交换机 """
        code, out = self.run_cmd('fabricshow')
        __ci__.result_log('INFO', 'fabricshow: {}'.format(out))
        if code:
            __ci__.result_log('WARN', '获取级联信息失败，{}'.format(out))
        # 过滤无效的行

        out_list = filter(lambda x: x.strip() and not x.startswith(('Switch ID', '---')), out.splitlines())
        # print out_list
        head = ['id', '_id', 'wwn', 'ip', 'fc_ip', 'name']
        fcs = [dict(zip(head, line.split())) for line in out_list]

        for fc in fcs:
            if not re.match(r'([0-9a-f]{2}:?){7}[0-9a-f]{2}', fc.get('wwn', ''), re.I):
                continue
            # print fc
            wwn = self.normalize_wwn(fc.get('wwn'))
            name = re.sub(r'>|"', '', fc.get('name', '')) or wwn
            if not wwn or wwn == self.wwn:
                continue
            fc_ci = __ci__.create('FabricFCSwitch', name)
            fc_ci['properties'] = {'wwn': wwn,
                                   'ip': fc.get('ip')
                                   }
            __ci__.createrelationship(self.switch_ci['cid'], fc_ci['cid'], 'Inlines')
            __ci__.result_log('INFO', '发现及联交换机 name: {}, wwn: {}'.format(name, wwn))

    def analysis_chassisshow(self, msg):
        pass

    def discovery_switch(self):
        """主入口， 执行 switchshow 命令"""
        if not self.login():
            return False
        code, switch_show = self.run_cmd("version; switchshow")

        if code:
            self.use_bash = False
            code, switch_show = self.run_cmd("version; switchshow")
            if code:
                __ci__.result_log('ERROR', '发现失败 {}'.format(switch_show))
                return False
        chassis_show = self.run_cmd("chassisshow")[1]
        tsclockserver = self.run_cmd("tsclockserver")[1]
        snmpv1_trap = self.run_cmd("snmpconfig --show snmpv1")[1]
        name = re_search('(?<=switchName:).*', switch_show)

        self.sn = re_search(re.compile(r'(?<=^Serial Num:).*', re.M), chassis_show)\
            or re_search('(?<=Chassis Factory Serial Num:).*', chassis_show)\
            or re_search('(?<=Factory Serial Num:).*', chassis_show)

        self.wwn = re_search('(?<=switchWwn:).*', switch_show,
                             convert_to=self.normalize_wwn)

        if not self.sn and not self.wwn:
            __ci__.result_log('ERROR',
                              '获取序列号或wwn失败，请确认发现对象是否为博科光纤交换机')
            return False
        __ci__.result_log('INFO', '发现光纤交换机： {}'.format(name))

        self.switch_ci = __ci__.create('FCSwitch', name)
        self.switch_ci['properties'] = {
            'ip': self.ip,
            'hostname': name,
            'wwn': self.wwn,
            'version': re_search('(?<=Fabric OS:).*', switch_show),
            'switch_type': re_search('(?<=switchType:).*', switch_show),
            'switch_role': re_search('(?<=switchRole:).*', switch_show),
            'switch_mode': re_search('(?<=switchMode:).*', switch_show),
            'domain_id': re_search('(?<=switchDomain:).*', switch_show, int),
            'serial_number': self.sn,
            'model': re_search('(?<=\nPart Num:).*', chassis_show),
            'fcswitch_brand': 'brocade',
            'ntp_server': re_search(r'(?<=Configured NTP Server List).*', tsclockserver),
            'snmp_server': ','.join(set(re.findall(r'(?:\d+\.){3}\d+', snmpv1_trap)))
        }

        self.discovery_cascade_switch()
        self.discovery_ports(switch_show)
        self.discovery_zone()
        self.logout()


def merge_args(ip='ip'):
    """合并 __ip__ 和 __args__"""
    all_args = {}
    for i in globals().get('__ip__', []):
        all_args[i] = __args__
    for i in globals().get('__ip_ranges__', []):
        all_args[i] = __args__
    for _arg in __args__:
        if _arg.get(ip):
            all_args[_arg[ip]] = [_arg]
    # print all_args
    __ci__.result_log('INFO', "Merged {} args".format(len(all_args)))
    return all_args


if __name__ == '__main__':

    for ip, args in merge_args().items():
        __ci__.ip = ip
        for _args in args:
            arg = copy.deepcopy(_args)
            arg['ip'] = ip
            fc_switch = DiscoveryFCSwitch(arg['ip'],
                                          arg['username'],
                                          arg['password'],
                                          arg.get('port')
                                          )
            fc_switch.discovery_switch()

    __ci__.result_data()
